package com.emanyata.app.exceptions;





import java.util.Map;

public class CustomFileProcessingException extends RuntimeException {
    private final Map<String, Object> errorDetails;

    public CustomFileProcessingException(Map<String, Object> errorDetails) {
        this.errorDetails = errorDetails;
    }

    public Map<String, Object> getErrorDetails() {
        return errorDetails;
    }
}
