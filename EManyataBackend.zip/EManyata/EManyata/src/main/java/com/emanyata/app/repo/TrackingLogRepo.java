package com.emanyata.app.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.TrackingLog;

public interface TrackingLogRepo extends JpaRepository<TrackingLog,Long> {
		Optional<TrackingLog> findBySchoolId(Long id);
}
