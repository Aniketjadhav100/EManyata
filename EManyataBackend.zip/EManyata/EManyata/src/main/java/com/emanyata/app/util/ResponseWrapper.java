package com.emanyata.app.util;




import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL) // Ensure that null fields are excluded from JSON response
public class ResponseWrapper<T> {
    private String code;
    private String message;
    private T data; // Generic data field for success responses
    private Object errormessage; // Object to hold error messages

    public ResponseWrapper(String code, String message, T data, Object errormessage) {
        this.code = code;
        this.message = message;
        this.data = data;
        this.errormessage = errormessage;
    }

    public ResponseWrapper() {
    }

    // Getters and Setters
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public Object getErrormessage() {
        return errormessage;
    }

    public void setErrormessage(Object errormessage) {
        this.errormessage = errormessage;
    }
}