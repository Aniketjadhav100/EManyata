package com.emanyata.app.service;


import com.emanyata.app.dto.SchoolGeneralInfoDTO;
import com.emanyata.app.entity.SchoolGeneralInfo;

public interface SchoolGeneralInfoService {
    SchoolGeneralInfo getSchoolById(Long id);
    SchoolGeneralInfo createSchoolInfo(SchoolGeneralInfoDTO schoolInfo);
}
