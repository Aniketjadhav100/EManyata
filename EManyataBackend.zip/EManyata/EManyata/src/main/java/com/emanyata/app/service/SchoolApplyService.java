package com.emanyata.app.service;

import com.emanyata.app.dto.SchoolApplyDTO;
import com.emanyata.app.dto.StatusCountDTO;

import java.util.List;

public interface SchoolApplyService {
    List<SchoolApplyDTO> getDetails(Long userId, Long schoolId);
    SchoolApplyDTO saveSchoolApply(SchoolApplyDTO dto);
    List<SchoolApplyDTO> getAllDetails();
    
    // This is for status Count 
    List<StatusCountDTO> getStatusCounts();
}
