package com.emanyata.app.serviceImpl;

import com.emanyata.app.authdto.*;
import com.emanyata.app.entity.*;
import com.emanyata.app.repo.*;
import com.emanyata.app.service.UserService;
import com.emanyata.app.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import java.time.Instant;
import java.time.Year;
import java.util.*;

@Service
public class UserServiceImpl implements UserService {

    private String verifiedIdentifier;

    @Autowired private JwtUtil jwtUtil;
    @Autowired private JavaMailSender mailSender;
    @Autowired private UserRepo userRepo;
    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private TalukaRepo talukaRepo;
    @Autowired private VillageRepo villageRepo;
    @Autowired private ImageRepo imageRepo; 
    @Autowired private SchoolApplyRepo schoolApplyRepo; 

    private String generateOtp() {
        return String.format("%06d", new Random().nextInt(999999));
    }

    @Override
    @Transactional
    public String register(UserDTO dto) {
        if (userRepo.findByEmail(dto.getEmail()).isPresent()) return "Email already registered.";
        if (userRepo.findByPhone(dto.getMobile()).isPresent()) return "Mobile number already registered.";
        if (userRepo.findBySchools_UdiseNo(dto.getUdiseNo()).isPresent()) return "UDISE number already registered.";

        Optional<Taluka> taluka = talukaRepo.findById(dto.getTaluka().getId());
        Optional<Village> village = villageRepo.findById(dto.getVillage().getId());

        if (taluka.isEmpty() || village.isEmpty()) return "Invalid Taluka or Village.";

        // Create User
        User user = new User();
        user.setName(dto.getName());
        user.setUdiseNo(dto.getUdiseNo());
        user.setEmail(dto.getEmail());
        user.setMobile(dto.getMobile());
        user.setPassword(passwordEncoder.encode(dto.getPassword()));
        user.setDesignation(dto.getDesignation());
        user.setPermissions(dto.getPermissions());
        user.setStatus(dto.getStatus());
        user.setRole(dto.getRole());
        user.setDesignationId(dto.getDesignationId());

        // Save user and set image or signature if present
        if (dto.getImage() != null) {
            Image savedImage = imageRepo.save(dto.getImage());
            user.setImage(savedImage);
        }

        if (dto.getDigitalSignature() != null) {
            Image savedSignature = imageRepo.save(dto.getDigitalSignature());
            user.setDigitalSignature(savedSignature);
        }

        user.setOtp(generateOtp());
        user.setCreatedAt(Instant.now());

        // School data setup
        School school = new School();
        school.setSchoolName(dto.getSchoolName());
        school.setUdiseNo(dto.getUdiseNo());
        school.setTransactionalAddress(dto.getTransactionalAddress());
        school.setDistrict(dto.getDistrict());
        school.setTaluka(taluka.get());
        school.setVillage(village.get());
        school.setPincode(dto.getPincode());
        school.setTelephoneNumber(dto.getTelephoneNumber());
        school.setSchoolMobile(dto.getMobile());
        school.setPoliceStation(dto.getPoliceStation());
        school.setSchoolType(dto.getSchoolType());

        school.setUser_id(user);
        school.setCreatedat(Instant.now());
        user.setSchools(List.of(school));

        // Save user
        userRepo.save(user);

        // Generate unique application number
        String applicationNo = generateApplicationNo(user);

        SchoolApply schoolApply = new SchoolApply();
        schoolApply.setApplyStatus("Pending");
        schoolApply.setSchool(school);
        schoolApply.setUser(user);
        schoolApply.setApplicationNo(applicationNo);

        schoolApplyRepo.save(schoolApply);

        sendEmail(user.getEmail(), "OTP Verification", "Your OTP is: " + user.getOtp());
        return "Registration successful. OTP sent to email.";
    }
    
    private String generateApplicationNo(User user) {
        if (user.getSchools() == null || user.getSchools().isEmpty()) {
            throw new IllegalArgumentException("User has no associated schools.");
        }

        String udiseNo = user.getSchools().get(0).getUdiseNo();

        if (udiseNo == null || udiseNo.length() < 4) {
            throw new IllegalArgumentException("Invalid UdiseNo: less than 4 digits");
        }

        String year = String.valueOf(Year.now().getValue());
        String udiseSuffix = udiseNo.substring(udiseNo.length() - 4);
        String prefix = year + udiseSuffix;
        long count = schoolApplyRepo.countByApplicationNoStartingWith(prefix);
        String suffix = String.format("%04d", count + 1);
        return prefix + suffix;
    }


	@Override
    public String verifyOtp(OtpRequest otpRequest) {
        Optional<User> optionalUser = userRepo.findByEmail(otpRequest.getEmail());
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();

            // Validate OTP
            if (user.getOtp() == null || !user.getOtp().equals(otpRequest.getOtp())) {
                return "Invalid OTP.";
            }

            // Set the OTP verified time
            user.setVerified(Instant.now());
            user.setOtp(null);
            userRepo.save(user);

            return "Email verified successfully.";
        }
        return "User not found.";
    }


    @Override
    public String resendOtp(String email) {
        Optional<User> optionalUser = userRepo.findByEmail(email);
        if (optionalUser.isEmpty()) return "User not found.";

        User user = optionalUser.get();

        // Check if the user is already verified by checking if email_otp_verified_at is not null
        if (user.getVerified() != null) {
            return "User already verified.";
        }

        // Generate new OTP
        String otp = generateOtp();
        user.setOtp(otp);
        userRepo.save(user);

        // Send the OTP via email
        sendEmail(email, "Resend OTP", "Your new OTP is: " + otp);

        return "New OTP sent.";
    }

    @Override
    public String login(LoginRequest request) {
        Optional<User> userOptional = request.getEmailOrMobile().contains("@")
            ? userRepo.findByEmail(request.getEmailOrMobile())
            : userRepo.findByPhone(request.getEmailOrMobile());

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            if (user.getVerified() == null) return "Please verify your email first.";
            
            if (passwordEncoder.matches(request.getPassword(), user.getPassword())) {
                String token = jwtUtil.generateToken(user.getEmail());
                user.setToken(token);
                user.setRememberToken(token);
                user.setLastLogin(Instant.now());
                userRepo.save(user);
                return "{\"message\": \"Login successful!\", \"token\": \"" + token + "\"}";
            } else {
                return "Invalid password.";
            }
        }
        return "User not found.";
    }


    @Override
    public String logout(String emailOrMobile) {
        Optional<User> userOptional = emailOrMobile.contains("@")
            ? userRepo.findByEmail(emailOrMobile)
            : userRepo.findByPhone(emailOrMobile);

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            user.setToken(null);
            userRepo.save(user);
            return "Logout successful.";
        }
        return "User not found.";
    }


    @Override
    public String verifyEmailOrMobile(ForgotPasswordRequest request) {
        Optional<User> userOptional = request.getEmailOrMobile().contains("@")
            ? userRepo.findByEmail(request.getEmailOrMobile())
            : userRepo.findByPhone(request.getEmailOrMobile());

        if (userOptional.isPresent()) {
            verifiedIdentifier = request.getEmailOrMobile();
            return "User verified. Proceed to reset password.";
        }
        return "User not found.";
    }

    @Override
    public String updatePassword(UpdatePasswordRequest request) {
        if (verifiedIdentifier == null) return "Please verify your email or phone first.";
        if (!request.getNewPassword().equals(request.getConfirmPassword())) return "Passwords do not match.";

        Optional<User> userOptional = verifiedIdentifier.contains("@")
            ? userRepo.findByEmail(verifiedIdentifier)
            : userRepo.findByPhone(verifiedIdentifier);

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            user.setPassword(passwordEncoder.encode(request.getNewPassword()));
            userRepo.save(user);
            verifiedIdentifier = null;
            return "Password updated successfully.";
        }
        return "User not found.";
    }

    private void sendEmail(String to, String subject, String body) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(to);
            message.setSubject(subject);
            message.setText(body);
            message.setFrom("nagoudasantosh1999@gmail.com"); 
            mailSender.send(message);
            System.out.println("OTP email sent successfully to " + to);
        } catch (Exception e) {
            System.err.println("Error while sending OTP email: " + e.getMessage());
        }
    }	
    
    
    @Override
    @Transactional
    public String updateUser(Long userId, UserDTO dto) {
    	if (userRepo.findByEmail(dto.getEmail()).isPresent()) return "Email already registered.";
        if (userRepo.findByPhone(dto.getMobile()).isPresent()) return "Mobile number already registered.";
        
        Optional<User> userOpt = userRepo.findById(userId);
        if (userOpt.isEmpty()) return "User not found.";
        User user = userOpt.get();
        user.setEmail(dto.getEmail());
        user.setMobile(dto.getMobile());

        if (dto.getImage() != null) {
            Image savedImage = imageRepo.save(dto.getImage());
            user.setImage(savedImage);
        }

        if (dto.getDigitalSignature() != null) {
            Image savedSignature = imageRepo.save(dto.getDigitalSignature());
            user.setDigitalSignature(savedSignature);
        }

        if (!user.getSchools().isEmpty()) {
            School school = user.getSchools().get(0);
            school.setSchoolName(dto.getSchoolName());
            school.setSchoolMobile(dto.getSchoolMobile());
            school.setTransactionalAddress(dto.getTransactionalAddress());
            school.setDistrict(dto.getDistrict());

            Optional<Taluka> taluka = talukaRepo.findById(dto.getTaluka().getId());
            Optional<Village> village = villageRepo.findById(dto.getVillage().getId());

            if (taluka.isEmpty() || village.isEmpty()) return "Invalid Taluka or Village.";

            school.setTaluka(taluka.get());
            school.setVillage(village.get());
            school.setTelephoneNumber(dto.getTelephoneNumber());
            school.setPoliceStation(dto.getPoliceStation());
            school.setSchoolType(dto.getSchoolType());
            school.setUpdatedat(Instant.now());
        }
        user.setUpdatedAt(Instant.now());
      
        userRepo.save(user);

        return "User and School details updated successfully.";
    }
}