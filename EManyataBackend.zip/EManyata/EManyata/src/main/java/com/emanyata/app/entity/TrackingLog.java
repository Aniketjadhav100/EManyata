	package com.emanyata.app.entity;
	
	import jakarta.persistence.*;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Size;
	import org.hibernate.annotations.OnDelete;
	import org.hibernate.annotations.OnDeleteAction;
	
	import java.time.Instant;
	
	@Entity
	@Table(name = "tracking_logs", schema = "emanyata")
	public class TrackingLog {
	    @Id
	    @Column(name = "id", nullable = false)
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	
	    @NotNull
	    @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @OnDelete(action = OnDeleteAction.CASCADE)
	    @JoinColumn(name = "school_id", nullable = false,unique = true)
	    private School school;
	
	    @NotNull
	    @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @OnDelete(action = OnDeleteAction.CASCADE)
	    @JoinColumn(name = "user_id", nullable = false,unique = true)
	    private User user;
	
	    @Size(max = 255)
	    @Column(name = "status")
	    private String status;
	
	    @Size(max = 191)
	    @Column(name = "steps", length = 191)
	    private String steps;
	
	    @Size(max = 10000)
	    @Column(name = "message", length = 10000)
	    private String message;
	
	    @Column(name = "created_at")
	    private Instant createdAt;
	
	    @Column(name = "updated_at")
	    private Instant updatedAt;
	
	    @Column(name = "application_id",unique = true)
	    private Long applicationId;
	
	    public Long getId() {
	        return id;
	    }
	
	    public void setId(Long id) {
	        this.id = id;
	    }
	
	    public School getSchool() {
	        return school;
	    }
	
	    public void setSchool(School school) {
	        this.school = school;
	    }
	
	    public User getUser() {
	        return user;
	    }
	
	    public void setUser(User user) {
	        this.user = user;
	    }
	
	    public String getStatus() {
	        return status;
	    }
	
	    public void setStatus(String status) {
	        this.status = status;
	    }
	
	    public String getSteps() {
	        return steps;
	    }
	
	    public void setSteps(String steps) {
	        this.steps = steps;
	    }
	
	    public String getMessage() {
	        return message;
	    }
	
	    public void setMessage(String message) {
	        this.message = message;
	    }
	
	    public Instant getCreatedAt() {
	        return createdAt;
	    }
	
	    public void setCreatedAt(Instant createdAt) {
	        this.createdAt = createdAt;
	    }
	
	    public Instant getUpdatedAt() {
	        return updatedAt;
	    }
	
	    public void setUpdatedAt(Instant updatedAt) {
	        this.updatedAt = updatedAt;
	    }
	
	    public Long getApplicationId() {
	        return applicationId;
	    }
	
	    public void setApplicationId(Long applicationId) {
	        this.applicationId = applicationId;
	    }
	
	}