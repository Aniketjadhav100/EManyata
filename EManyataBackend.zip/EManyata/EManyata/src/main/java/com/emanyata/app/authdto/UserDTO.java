package com.emanyata.app.authdto;



import java.time.Instant;
import java.util.List;


import com.emanyata.app.entity.Image;
import com.emanyata.app.entity.Role;
import com.emanyata.app.entity.School;
import com.emanyata.app.entity.Taluka;
import com.emanyata.app.entity.Village;


public class UserDTO {

	private Long id;
    private String name;
    private String email;
    private String otp;
    private Boolean Verified;
    private String mobile;
    private String mobile_otp;
    private Boolean mverified;
    private String rememberToken;
    private String token;  
    private String designation;
    private String password;
    private String permissions;
    private Instant lastLogin;
    private Byte status;
    private Image image;
    private Image digitalSignature;
    private Role role;
    private Long designationId;
    private Instant createdAt;
    private Instant updatedAt;
    private String UdiseNo;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public Boolean getVerified() {
		return Verified;
	}

	public void setVerified(Boolean verified) {
		Verified = verified;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getMobile_otp() {
		return mobile_otp;
	}

	public void setMobile_otp(String mobile_otp) {
		this.mobile_otp = mobile_otp;
	}

	public Boolean getMverified() {
		return mverified;
	}

	public void setMverified(Boolean mverified) {
		this.mverified = mverified;
	}

	public String getRememberToken() {
		return rememberToken;
	}

	public void setRememberToken(String rememberToken) {
		this.rememberToken = rememberToken;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPermissions() {
		return permissions;
	}

	public void setPermissions(String permissions) {
		this.permissions = permissions;
	}

	public Instant getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Instant lastLogin) {
		this.lastLogin = lastLogin;
	}

	public Byte getStatus() {
		return status;
	}

	public void setStatus(Byte status) {
		this.status = status;
	}

	public Image getImage() {
		return image;
	}

	public void setImage(Image image) {
		this.image = image;
	}

	public Image getDigitalSignature() {
		return digitalSignature;
	}

	public void setDigitalSignature(Image digitalSignature) {
		this.digitalSignature = digitalSignature;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Long getDesignationId() {
		return designationId;
	}

	public void setDesignationId(Long designationId) {
		this.designationId = designationId;
	}

	public Instant getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}

	public Instant getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Instant updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Long getUser_id() {
		return id;
	}

	public void setUser_id(Long user_id) {
		this.id = user_id;
	}
	private List<School> school;
    private String schoolName;
    private String udiseNo;
    private String transactionalAddress;
    private String district;
    private Taluka taluka; 
    private Village village;
    private String pincode;
    private String telephoneNumber;
    private String schoolMobile;
    private String policeStation;
    private String schoolType;
    private Instant createdat;
    private Instant updatedat;
    

	public List<School> getSchool() {
		return school;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSchoolName() {
		return schoolName;
	}
	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getUdiseNo() {
		return UdiseNo;
	}

	public void setUdiseNo(String udiseNo) {
		UdiseNo = udiseNo;
	}

	public String getTransactionalAddress() {
		return transactionalAddress;
	}
	public void setTransactionalAddress(String transactionalAddress) {
		this.transactionalAddress = transactionalAddress;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public Taluka getTaluka() {
		return taluka;
	}
	public void setTaluka(Taluka taluka) {
		this.taluka = taluka;
	}
	public Village getVillage() {
		return village;
	}
	public void setVillage(Village village) {
		this.village = village;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getTelephoneNumber() {
		return telephoneNumber;
	}
	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}
	public String getSchoolMobile() {
		return schoolMobile;
	}
	public void setSchoolMobile(String schoolMobile) {
		this.schoolMobile = schoolMobile;
	}
	public String getPoliceStation() {
		return policeStation;
	}
	public void setPoliceStation(String policeStation) {
		this.policeStation = policeStation;
	}
	public String getSchoolType() {
		return schoolType;
	}
	public void setSchoolType(String schoolType) {
		this.schoolType = schoolType;
	}
	public Instant getCreatedat() {
		return createdat;
	}
	public void setCreatedat(Instant createdat) {
		this.createdat = createdat;
	}
	public Instant getUpdatedat() {
		return updatedat;
	}
	public void setUpdatedat(Instant updatedat) {
		this.updatedat = updatedat;
	}
	public void setSchool(List<School> school) {
		this.school = school;
	}
	
	

}

