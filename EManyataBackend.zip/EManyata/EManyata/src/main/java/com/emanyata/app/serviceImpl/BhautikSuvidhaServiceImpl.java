package com.emanyata.app.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emanyata.app.dto.BhauticSuvidhaDTO;
import com.emanyata.app.entity.BhauticSuvidha;
import com.emanyata.app.entity.School;
import com.emanyata.app.repo.BhautikSuvidhaRepository;
import com.emanyata.app.repo.SchoolRepo;
import com.emanyata.app.service.BhautikSuvidhaService;

import jakarta.transaction.Transactional;

import java.time.Instant;
import java.util.Optional;

@Service
public class BhautikSuvidhaServiceImpl implements BhautikSuvidhaService {

	@Autowired
	private BhautikSuvidhaRepository repository;

	@Autowired
	private SchoolRepo schoolRepository;

	@Override
	public BhauticSuvidhaDTO getById(Long id) {
		return repository.findById(id).map(this::mapToDto).orElse(null);
	}

	private BhauticSuvidhaDTO mapToDto(BhauticSuvidha entity) {
		BhauticSuvidhaDTO dto = new BhauticSuvidhaDTO();
		dto.setId(entity.getId());
		dto.setSchoolId(entity.getSchool().getId());
		dto.setClassroom(entity.getClassroom());
		dto.setOfficeRoom(entity.getOfficeRoom());
		dto.setKitchen(entity.getKitchen());
		dto.setSeparateToiletsForBoysAndGirls(entity.getSeparateToiletsForBoysAndGirls());
		dto.setDrinkingWaterFacility(entity.getDrinkingWaterFacility());
		dto.setCreatedAt(entity.getCreatedAt());
		dto.setUpdatedAt(entity.getUpdatedAt());
		dto.setApplicationId(entity.getApplicationId());
		dto.setWhetherSchoolIsMovedToAnotherLocation(entity.getWhetherSchoolIsMovedToAnotherLocation());
		dto.setTypeOfProofAvailableAndItsDate(entity.getTypeOfProofAvailableAndItsDate());
		dto.setForYouTakePropertyDocumentType(entity.getForYouTakePropertyDocumentType());
		dto.setAreaSqM(entity.getAreaSqM());
		dto.setTotalAreaSqM(entity.getTotalAreaSqM());
		dto.setSchoolTotalAreaSqM(entity.getSchoolTotalAreaSqM());
		dto.setPrincipalCount(entity.getPrincipalCount());
		dto.setPrincipalArea(entity.getPrincipalArea());
		dto.setOfficeCount(entity.getOfficeCount());
		dto.setOfficeArea(entity.getOfficeArea());
		dto.setStaffCount(entity.getStaffCount());
		dto.setStaffArea(entity.getStaffArea());
		dto.setStorageCount(entity.getStorageCount());
		dto.setStorageArea(entity.getStorageArea());
		dto.setClassroomCount(entity.getClassroomCount());
		dto.setClassroomArea(entity.getClassroomArea());
		dto.setLabCount(entity.getLabCount());
		dto.setLabArea(entity.getLabArea());
		dto.setCompCount(entity.getCompCount());
		dto.setCompArea(entity.getCompArea());
		dto.setLibraryCount(entity.getLibraryCount());
		dto.setLibraryArea(entity.getLibraryArea());
		dto.setSchoolTotalCount(entity.getSchoolTotalCount());
		dto.setSchoolTotalArea(entity.getSchoolTotalArea());
		dto.setWesternToiletCount(entity.getWesternToiletCount());
		dto.setToiletAvailableFacilityDetails(entity.getToiletAvailableFacilityDetails());
		dto.setSeperateBoysToiletCount(entity.getSeperateBoysToiletCount());
		dto.setSeperateBoysToiletFacilityDetails(entity.getSeperateBoysToiletFacilityDetails());
		dto.setSeperateBoysWashroomCount(entity.getSeperateBoysWashroomCount());
		dto.setSeperateBoysWashroomFacilityDetails(entity.getSeperateBoysWashroomFacilityDetails());
		dto.setSeperateBoysDrinkingWaterCount(entity.getSeperateBoysDrinkingWaterCount());
		dto.setSeperateBoysDrinkingWaterFacilityDetails(entity.getSeperateBoysDrinkingWaterFacilityDetails());
		dto.setSeperateGirlsToiletCount(entity.getSeperateGirlsToiletCount());
		dto.setSeperateGirlsToiletFacilityDetails(entity.getSeperateGirlsToiletFacilityDetails());
		dto.setSeperateGirlsWashroomCount(entity.getSeperateGirlsWashroomCount());
		dto.setSeperateGirlsWashroomFacilityDetails(entity.getSeperateGirlsWashroomFacilityDetails());
		dto.setSeperateGirlsDrinkingWaterCount(entity.getSeperateGirlsDrinkingWaterCount());
		dto.setSeperateGirlsDrinkingWaterFacilityDetails(entity.getSeperateGirlsDrinkingWaterFacilityDetails());
		dto.setRampRoad(entity.getRampRoad());
		dto.setRocksOnTheSideOfTheRamp(entity.getRocksOnTheSideOfTheRamp());
		dto.setRampFacilityDetails(entity.getRampFacilityDetails());
		dto.setRoomNumber(entity.getRoomNumber());
		dto.setTheRoofIsSolidRcc(entity.getTheRoofIsSolidRcc());
		dto.setFireWarrantyCylinderNo(entity.getFireWarrantyCylinderNo());
		dto.setMedicalPrimaryBoxNumber(entity.getMedicalPrimaryBoxNumber());
		dto.setCctvNo(entity.getCctvNo());
		dto.setPlaquesInFacadesOfSchoolRecognition(entity.getPlaquesInFacadesOfSchoolRecognition());
		dto.setaRampForBarrierFreeAccess(entity.getARampForBarrierFreeAccess());
		dto.setAreaOfPlayground(entity.getAreaOfPlayground());
		dto.setAreaOfPlaygroundDetails(entity.getAreaOfPlaygroundDetails());
		dto.setRetainingWallCompound(entity.getRetainingWallCompound());
		dto.setEntranceWithProtectiveWallAndIronGate(entity.getEntranceWithProtectiveWallAndIronGate());
		dto.setKitchenShed(entity.getKitchenShed());
		dto.setKitchenShedDetails(entity.getKitchenShedDetails());
		dto.setWaterTapCount(entity.getWaterTapCount());
		dto.setWaterTankCapacity(entity.getWaterTankCapacity());
		dto.setActualAvailableFacilityDetailsTap(entity.getActualAvailableFacilityDetailsTap());
		dto.setActualAvailableFacilityDetailsWater(entity.getActualAvailableFacilityDetailsWater());
		dto.setSection1InspectionApproval(entity.getSection1InspectionApproval());
		dto.setSection2InspectionApproval(entity.getSection2InspectionApproval());
		dto.setSection3InspectionApproval(entity.getSection3InspectionApproval());
		dto.setSection4InspectionApproval(entity.getSection4InspectionApproval());
		dto.setSection5InspectionApproval(entity.getSection5InspectionApproval());
		dto.setSection6InspectionApproval(entity.getSection6InspectionApproval());
		dto.setSection1InspectionComment(entity.getSection1InspectionComment());
		dto.setSection2InspectionComment(entity.getSection2InspectionComment());
		dto.setSection3InspectionComment(entity.getSection3InspectionComment());
		dto.setSection4InspectionComment(entity.getSection4InspectionComment());
		dto.setSection5InspectionComment(entity.getSection5InspectionComment());
		dto.setSection6InspectionComment(entity.getSection6InspectionComment());
		return dto;
	}

	private BhauticSuvidha mapToEntity(BhauticSuvidhaDTO dto) {
		BhauticSuvidha entity = new BhauticSuvidha();
		entity.setId(dto.getId());
		School school = schoolRepository.findById(dto.getSchoolId())
				.orElseThrow(() -> new RuntimeException("School not found with ID: " + dto.getSchoolId()));
		entity.setSchool(school);
		entity.setClassroom(dto.getClassroom());
		entity.setOfficeRoom(dto.getOfficeRoom());
		entity.setKitchen(dto.getKitchen());
		entity.setSeparateToiletsForBoysAndGirls(dto.getSeparateToiletsForBoysAndGirls());
		entity.setDrinkingWaterFacility(dto.getDrinkingWaterFacility());
		entity.setCreatedAt(dto.getCreatedAt());
		entity.setUpdatedAt(dto.getUpdatedAt());
		entity.setApplicationId(dto.getApplicationId());
		entity.setWhetherSchoolIsMovedToAnotherLocation(dto.getWhetherSchoolIsMovedToAnotherLocation());
		entity.setTypeOfProofAvailableAndItsDate(dto.getTypeOfProofAvailableAndItsDate());
		entity.setForYouTakePropertyDocumentType(dto.getForYouTakePropertyDocumentType());
		entity.setAreaSqM(dto.getAreaSqM());
		entity.setTotalAreaSqM(dto.getTotalAreaSqM());
		entity.setSchoolTotalAreaSqM(dto.getSchoolTotalAreaSqM());
		entity.setPrincipalCount(dto.getPrincipalCount());
		entity.setPrincipalArea(dto.getPrincipalArea());
		entity.setOfficeCount(dto.getOfficeCount());
		entity.setOfficeArea(dto.getOfficeArea());
		entity.setStaffCount(dto.getStaffCount());
		entity.setStaffArea(dto.getStaffArea());
		entity.setStorageCount(dto.getStorageCount());
		entity.setStorageArea(dto.getStorageArea());
		entity.setClassroomCount(dto.getClassroomCount());
		entity.setClassroomArea(dto.getClassroomArea());
		entity.setLabCount(dto.getLabCount());
		entity.setLabArea(dto.getLabArea());
		entity.setCompCount(dto.getCompCount());
		entity.setCompArea(dto.getCompArea());
		entity.setLibraryCount(dto.getLibraryCount());
		entity.setLibraryArea(dto.getLibraryArea());
		entity.setSchoolTotalCount(dto.getSchoolTotalCount());
		entity.setSchoolTotalArea(dto.getSchoolTotalArea());
		entity.setWesternToiletCount(dto.getWesternToiletCount());
		entity.setToiletAvailableFacilityDetails(dto.getToiletAvailableFacilityDetails());
		entity.setSeperateBoysToiletCount(dto.getSeperateBoysToiletCount());
		entity.setSeperateBoysToiletFacilityDetails(dto.getSeperateBoysToiletFacilityDetails());
		entity.setSeperateBoysWashroomCount(dto.getSeperateBoysWashroomCount());
		entity.setSeperateBoysWashroomFacilityDetails(dto.getSeperateBoysWashroomFacilityDetails());
		entity.setSeperateBoysDrinkingWaterCount(dto.getSeperateBoysDrinkingWaterCount());
		entity.setSeperateBoysDrinkingWaterFacilityDetails(dto.getSeperateBoysDrinkingWaterFacilityDetails());
		entity.setSeperateGirlsToiletCount(dto.getSeperateGirlsToiletCount());
		entity.setSeperateGirlsToiletFacilityDetails(dto.getSeperateGirlsToiletFacilityDetails());
		entity.setSeperateGirlsWashroomCount(dto.getSeperateGirlsWashroomCount());
		entity.setSeperateGirlsWashroomFacilityDetails(dto.getSeperateGirlsWashroomFacilityDetails());
		entity.setSeperateGirlsDrinkingWaterCount(dto.getSeperateGirlsDrinkingWaterCount());
		entity.setSeperateGirlsDrinkingWaterFacilityDetails(dto.getSeperateGirlsDrinkingWaterFacilityDetails());
		entity.setRampRoad(dto.getRampRoad());
		entity.setRocksOnTheSideOfTheRamp(dto.getRocksOnTheSideOfTheRamp());
		entity.setRampFacilityDetails(dto.getRampFacilityDetails());
		entity.setRoomNumber(dto.getRoomNumber());
		entity.setTheRoofIsSolidRcc(dto.getTheRoofIsSolidRcc());
		entity.setFireWarrantyCylinderNo(dto.getFireWarrantyCylinderNo());
		entity.setMedicalPrimaryBoxNumber(dto.getMedicalPrimaryBoxNumber());
		entity.setCctvNo(dto.getCctvNo());
		entity.setPlaquesInFacadesOfSchoolRecognition(dto.getPlaquesInFacadesOfSchoolRecognition());
		entity.setARampForBarrierFreeAccess(dto.getaRampForBarrierFreeAccess());
		entity.setAreaOfPlayground(dto.getAreaOfPlayground());
		entity.setAreaOfPlaygroundDetails(dto.getAreaOfPlaygroundDetails());
		entity.setRetainingWallCompound(dto.getRetainingWallCompound());
		entity.setEntranceWithProtectiveWallAndIronGate(dto.getEntranceWithProtectiveWallAndIronGate());
		entity.setKitchenShed(dto.getKitchenShed());
		entity.setKitchenShedDetails(dto.getKitchenShedDetails());
		entity.setWaterTapCount(dto.getWaterTapCount());
		entity.setWaterTankCapacity(dto.getWaterTankCapacity());
		entity.setActualAvailableFacilityDetailsTap(dto.getActualAvailableFacilityDetailsTap());
		entity.setActualAvailableFacilityDetailsWater(dto.getActualAvailableFacilityDetailsWater());
		entity.setSection1InspectionApproval(dto.getSection1InspectionApproval());
		entity.setSection2InspectionApproval(dto.getSection2InspectionApproval());
		entity.setSection3InspectionApproval(dto.getSection3InspectionApproval());
		entity.setSection4InspectionApproval(dto.getSection4InspectionApproval());
		entity.setSection5InspectionApproval(dto.getSection5InspectionApproval());
		entity.setSection6InspectionApproval(dto.getSection6InspectionApproval());
		entity.setSection1InspectionComment(dto.getSection1InspectionComment());
		entity.setSection2InspectionComment(dto.getSection2InspectionComment());
		entity.setSection3InspectionComment(dto.getSection3InspectionComment());
		entity.setSection4InspectionComment(dto.getSection4InspectionComment());
		entity.setSection5InspectionComment(dto.getSection5InspectionComment());
		entity.setSection6InspectionComment(dto.getSection6InspectionComment());
		return entity;
	}

	@Override
	public BhauticSuvidhaDTO getBySchoolID(Long id) {
	    BhauticSuvidha entity = repository.getBySchoolId(id);
	    if (entity == null) {
	        throw new RuntimeException("No BhauticSuvidha found for schoolId: " + id);
	    }
	    return mapToDto(entity);
	}

	@Override
	@Transactional
	public BhauticSuvidhaDTO save(BhauticSuvidhaDTO dto) {
	    BhauticSuvidha entity;

	    if (dto.getSchoolId() != null && dto.getApplicationId() != null) {
	        Optional<BhauticSuvidha> bs = repository.findBySchoolId(dto.getSchoolId());

	        if (bs.isPresent()) {
	            BhauticSuvidha existing = bs.get();
	            if (existing.getApplicationId() != null && existing.getApplicationId().equals(dto.getApplicationId())) {
	                entity = existing;

	                // update fields...
	            } else {
	                // ❗ if applicationId mismatch, you still need to create a new entity
	                entity = mapToEntity(dto);
	                entity.setCreatedAt(Instant.now());
	            }
	        } else {
	            // ❗ if not present, create new entity
	            entity = mapToEntity(dto);
	            entity.setCreatedAt(Instant.now());
	        }

	        entity.setUpdatedAt(Instant.now());
	        BhauticSuvidha saved = repository.save(entity);
	        return mapToDto(saved);
	    } else {
	        throw new RuntimeException("SchoolId or ApplicationId is missing in DTO");
	    }
	}

}
