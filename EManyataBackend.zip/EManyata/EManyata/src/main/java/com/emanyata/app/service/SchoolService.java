package com.emanyata.app.service;

import com.emanyata.app.dto.SchoolDTO;
import com.emanyata.app.entity.School;

public interface SchoolService {
    School save(School school);
    SchoolDTO getSchoolByUdiseNo(String udiseNo);
}
