package com.emanyata.app.service;

import java.util.List;
import java.util.Optional;

import com.emanyata.app.dto.TalukaDTO;
import com.emanyata.app.entity.Taluka;

public interface TalukaService {
	TalukaDTO addTaluka(TalukaDTO dto);
    Optional<Taluka> getByName(String name);
    List<TalukaDTO> getAllTalukas();
    Optional<Taluka> getById(Long id);
    void deleteById(Long id);
    TalukaDTO updateTaluka(Long id, TalukaDTO dto);
}

