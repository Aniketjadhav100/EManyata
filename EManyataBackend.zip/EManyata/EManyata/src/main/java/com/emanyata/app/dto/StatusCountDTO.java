package com.emanyata.app.dto;

public class StatusCountDTO {

    private String status;
    private Long count;

    // No-arg constructor (required for some frameworks like Jackson)
    public StatusCountDTO() {
    }

    // All-args constructor
    public StatusCountDTO(String status, Long count) {
        this.status = status;
        this.count = count;
    }

    // Getter for status
    public String getStatus() {
        return status;
    }

    // Setter for status
    public void setStatus(String status) {
        this.status = status;
    }

    // Getter for count
    public Long getCount() {
        return count;
    }

    // Setter for count
    public void setCount(Long count) {
        this.count = count;
    }
}