package com.emanyata.app.controller;

import com.emanyata.app.dto.OtherFacilityDTO;
import com.emanyata.app.serviceImpl.OtherFacilityServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/other-facility")
public class OtherfaclityController {

    @Autowired
    private OtherFacilityServiceImpl otherFacilityService;

    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createOtherFacility(@RequestBody OtherFacilityDTO dto) {
        OtherFacilityDTO saved = otherFacilityService.saveOtherFacility(dto);

        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", "Record created successfully.");
        response.put("data", saved);

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @PostMapping("/get/{id}")
    public ResponseEntity<Map<String, Object>> getOtherFacility(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();

        try {
            OtherFacilityDTO dto = otherFacilityService.getOtherFacility(id);
            response.put("status", "success");
            response.put("message", "Record fetched successfully.");
            response.put("data", dto);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("status", "fail");
            response.put("message", "Record not found with ID: " + id);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }
}
