package com.emanyata.app.serviceImpl;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emanyata.app.dto.TalukaDTO;
import com.emanyata.app.entity.Taluka;
import com.emanyata.app.repo.TalukaRepo;
import com.emanyata.app.service.TalukaService;

import jakarta.transaction.Transactional;

@Service
public class TalukaServiceImpl  implements TalukaService{

	@Autowired
    private TalukaRepo talukaRepo;

	@Override
	public TalukaDTO addTaluka(TalukaDTO dto) {

		  Taluka existing = talukaRepo.findByName(dto.getName()).orElse(null);

		    if (existing != null) {
		        // Already exists - return existing TalukaDTO
		        return new TalukaDTO(existing);
		    }

		    // Create new Taluka
		    Taluka taluka = new Taluka();

		    // Manually set ID if provided
		    if (dto.getId() != null) {
		        taluka.setId(dto.getId());
		    } else {
		        throw new RuntimeException("ID must be provided for new Taluka"); // or generate if allowed
		    }

		    taluka.setName(dto.getName());
		    taluka.setStatus("1"); // default
		    taluka.setCreatedAt(Instant.now());
		    taluka.setUpdatedAt(Instant.now());

		    Taluka saved = talukaRepo.save(taluka);
		    return new TalukaDTO(saved);
		}


	@Override
	public List<TalukaDTO> getAllTalukas() {
		 List<Taluka> entities = talukaRepo.findAll();
		    return entities.stream()
		                   .map(TalukaDTO::new)
		                   .collect(Collectors.toList());
		}


	@Override
	public Optional<Taluka> getByName(String name) {
		 return talukaRepo.findByName(name);
	}


	@Override
	public Optional<Taluka> getById(Long id) {
		    return talukaRepo.findById(id);
		}


	@Override
	public void deleteById(Long id) {
	    if (!talukaRepo.existsById(id)) {
	        throw new RuntimeException("Taluka with ID " + id + " not found.");
	    }
	    talukaRepo.deleteById(id);
	}


	@Override
	@Transactional
	public TalukaDTO updateTaluka(Long id, TalukaDTO dto) {
		 Taluka existing = talukaRepo.findById(id)
		            .orElseThrow(() -> new RuntimeException("Taluka with ID " + id + " not found."));

		    // Update the fields
		    existing.setName(dto.getName());
		    existing.setStatus(dto.getStatus());
		    existing.setUpdatedAt(Instant.now());

		    // Save the updated entity
		    Taluka saved = talukaRepo.save(existing);
		    return new TalukaDTO(saved);
		}	}


