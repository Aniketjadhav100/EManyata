package com.emanyata.app.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.emanyata.app.dto.SchoolApplyDTO;
import com.emanyata.app.dto.StatusCountDTO;
import com.emanyata.app.service.SchoolApplyService;

import java.util.List;

@RestController
@RequestMapping("/api/school-apply")
public class SchoolApplyController {

    @Autowired
    private SchoolApplyService service;

    @PostMapping("/details")
    public List<SchoolApplyDTO> getDetails(
            @RequestParam(required = false) Long userId,
            @RequestParam(required = false) Long schoolId) {

        return service.getDetails(userId, schoolId);
    }
    
    @PostMapping("/save")
    public ResponseEntity<SchoolApplyDTO> saveSchoolApply(@RequestBody SchoolApplyDTO dto) {
        SchoolApplyDTO saved = service.saveSchoolApply(dto);
        return ResponseEntity.ok(saved);
    }
    
    @PostMapping("/getall")
    public ResponseEntity<List<SchoolApplyDTO>> getAll() {
        List<SchoolApplyDTO> saved = service.getAllDetails();
        return ResponseEntity.ok(saved);
    }
    
    // This is For Student COunt 
    @PostMapping("/status-counts")
    public ResponseEntity<List<StatusCountDTO>> getStatusCounts() {
        List<StatusCountDTO> result = service.getStatusCounts();
        return ResponseEntity.ok(result);
    }

}
