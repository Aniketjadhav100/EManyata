package com.emanyata.app.dto;


import java.time.Instant;

public class StudentCountDTO {
    private Long id;
    private Long schoolId;
    private String totalBoys;
    private String totalGirls;
    private String total;
    private String lower;
    private String higher;
    private Instant createdAt;
    private Instant updatedAt;
    private Long applicationId;
    private String inspectionAppoval;
    private String inspectionComment;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(Long schoolId) {
		this.schoolId = schoolId;
	}
	public String getTotalBoys() {
		return totalBoys;
	}
	public void setTotalBoys(String totalBoys) {
		this.totalBoys = totalBoys;
	}
	public String getTotalGirls() {
		return totalGirls;
	}
	public void setTotalGirls(String totalGirls) {
		this.totalGirls = totalGirls;
	}
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getLower() {
		return lower;
	}
	public void setLower(String lower) {
		this.lower = lower;
	}
	public String getHigher() {
		return higher;
	}
	public void setHigher(String higher) {
		this.higher = higher;
	}
	public Instant getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}
	public Instant getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Instant updatedAt) {
		this.updatedAt = updatedAt;
	}
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	public String getInspectionAppoval() {
		return inspectionAppoval;
	}
	public void setInspectionAppoval(String inspectionAppoval) {
		this.inspectionAppoval = inspectionAppoval;
	}
	public String getInspectionComment() {
		return inspectionComment;
	}
	public void setInspectionComment(String inspectionComment) {
		this.inspectionComment = inspectionComment;
	}




}
