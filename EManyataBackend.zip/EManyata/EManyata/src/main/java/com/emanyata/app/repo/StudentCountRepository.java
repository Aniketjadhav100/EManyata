package com.emanyata.app.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.StudentCount;

public interface StudentCountRepository extends JpaRepository<StudentCount, Long> {
    Optional<StudentCount> findBySchoolId(Long schoolId);
}