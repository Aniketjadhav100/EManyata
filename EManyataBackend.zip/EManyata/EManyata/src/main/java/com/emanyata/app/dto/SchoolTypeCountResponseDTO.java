package com.emanyata.app.dto;

import java.util.List;

public class SchoolTypeCountResponseDTO {
    private List<SchoolTypeCountDTO> counts;
    private Long totalCount;

    public SchoolTypeCountResponseDTO(List<SchoolTypeCountDTO> counts, Long totalCount) {
        this.counts = counts;
        this.totalCount = totalCount;
    }

    public List<SchoolTypeCountDTO> getCounts() {
        return counts;
    }

    public void setCounts(List<SchoolTypeCountDTO> counts) {
        this.counts = counts;
    }

    public Long getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Long totalCount) {
        this.totalCount = totalCount;
    }
}
