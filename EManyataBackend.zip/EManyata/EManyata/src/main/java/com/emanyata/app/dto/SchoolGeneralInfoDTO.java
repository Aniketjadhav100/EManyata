package com.emanyata.app.dto;

import java.time.Instant;

public class SchoolGeneralInfoDTO {
    private Long id;
    private Long schoolId;

    private String schoolAddress;
    private String addressMentionedInGovernmentApprovalDocument;
    private String schoolEstablishmentYear;
    private String dateOfFirstCommencementOfSchool;
    private String schoolAcademicSession;
    private String schoolTimeFullTime;
    private String schoolTimeHalfTime;
    private String academicLearningTimeForEachClass;
    private String lunchTimeForEachClass;
    private String sportsAndPhysicalEducationTimeForEachClass;

    private String nameOfTrustSocietyManagementCommittee;
    private String registrationNo;
    private String underTheSocietiesRegistrationAct1860;
    private String underTheMumbaiPublicTrusteeSystemAct1950;
    private String tillWhatPeriodTheRegistrationOfTrust;
    private String isThereEvidenceThatTheTrust;

    private String schoolUserName;
    private String schoolUserDegisnation;
    private String schoolUserAddress;
    private String schoolUserTelephone;

    private String accountYear;
    private String accountIncome;
    private String accountExpense;
    private String accountBalance;

    private Long applicationId;
    private Instant createdAt;
    private Instant updatedAt;

    private String forWhichYearYouWantToApplyForACertificate;
    private String yearOfFoundationzOfSchool;
    private String dateOfFirstOpeningOfSchool;

    private String lowerStandard;
    private String higherStandard;
    private String schoolArea;
    private String mediumOfInstruction;
    private String schoolBoard;

    private String sangsthaCompanyName;
    private String sansthaCompanyHasPurposeForOnlyEducationService;
    private String isSchoolOpenWhereAddressMentionedInApproval;
    private String ifSansthaIsHandoverToSomeone;

    private String doYouHaveMaharastraShashanManyataNo;
    private String maharastraShashanApprovalNumber;
    private String maharastraShashanApprovalDate;

    private String doYouHaveShikshanUpsanchalakApproval;
    private String shikshanUpsanchalakApprovalDate;
    private String shikshanUpsanchalakApprovalNumber;

    private String doYouHavePrathamManyataCertificate;
    private String prathamManyataNumber;
    private String prathamManyataDate;

    private String doYouRunOnGovernmentNoObjectionCertificate;
    private String noObjectionCertificateNumber;
    private String noObjectionCertificateDate;

    private String whetherSchoolIsMovedToAnotherLocation;
    private String members;

    private String simpleHigherStandard;
    private String simpleLowerStandard;
    private String udiseLowerStandard;
    private String udiseHigherStandard;

    private String isThereAnAffiliationCertificate;
    private String affiliationCertificateNumber;
    private String affiliationCertificateDate;

    private String section1InspectionApproval;
    private String section2InspectionApproval;
    private String section3InspectionApproval;

    private String section1InspectionComment;
    private String section2InspectionComment;
    private String section3InspectionComment;

    public SchoolGeneralInfoDTO() {
    }

    public SchoolGeneralInfoDTO(Long id, Long schoolId, String schoolAddress, String addressMentionedInGovernmentApprovalDocument,
                            String schoolEstablishmentYear, String dateOfFirstCommencementOfSchool, String schoolAcademicSession,
                            String schoolTimeFullTime, String schoolTimeHalfTime, String academicLearningTimeForEachClass,
                            String lunchTimeForEachClass, String sportsAndPhysicalEducationTimeForEachClass,
                            String nameOfTrustSocietyManagementCommittee, String registrationNo, String underTheSocietiesRegistrationAct1860,
                            String underTheMumbaiPublicTrusteeSystemAct1950, String tillWhatPeriodTheRegistrationOfTrust,
                            String isThereEvidenceThatTheTrust, String schoolUserName, String schoolUserDegisnation,
                            String schoolUserAddress, String schoolUserTelephone, String accountYear, String accountIncome,
                            String accountExpense, String accountBalance, Long applicationId, Instant createdAt, Instant updatedAt,
                            String forWhichYearYouWantToApplyForACertificate, String yearOfFoundationzOfSchool,
                            String dateOfFirstOpeningOfSchool, String lowerStandard, String higherStandard, String schoolArea,
                            String mediumOfInstruction, String schoolBoard, String sangsthaCompanyName,
                            String sansthaCompanyHasPurposeForOnlyEducationService, String isSchoolOpenWhereAddressMentionedInApproval,
                            String ifSansthaIsHandoverToSomeone, String doYouHaveMaharastraShashanManyataNo,
                            String maharastraShashanApprovalNumber, String maharastraShashanApprovalDate,
                            String doYouHaveShikshanUpsanchalakApproval, String shikshanUpsanchalakApprovalDate,
                            String shikshanUpsanchalakApprovalNumber, String doYouHavePrathamManyataCertificate,
                            String prathamManyataNumber, String prathamManyataDate,
                            String doYouRunOnGovernmentNoObjectionCertificate, String noObjectionCertificateNumber,
                            String noObjectionCertificateDate, String whetherSchoolIsMovedToAnotherLocation, String members,
                            String simpleHigherStandard, String simpleLowerStandard, String udiseLowerStandard,
                            String udiseHigherStandard, String isThereAnAffiliationCertificate, String affiliationCertificateNumber,
                            String affiliationCertificateDate, String section1InspectionApproval, String section2InspectionApproval,
                            String section3InspectionApproval, String section1InspectionComment, String section2InspectionComment,
                            String section3InspectionComment) {
        this.id = id;
        this.schoolId = schoolId;
        this.schoolAddress = schoolAddress;
        this.addressMentionedInGovernmentApprovalDocument = addressMentionedInGovernmentApprovalDocument;
        this.schoolEstablishmentYear = schoolEstablishmentYear;
        this.dateOfFirstCommencementOfSchool = dateOfFirstCommencementOfSchool;
        this.schoolAcademicSession = schoolAcademicSession;
        this.schoolTimeFullTime = schoolTimeFullTime;
        this.schoolTimeHalfTime = schoolTimeHalfTime;
        this.academicLearningTimeForEachClass = academicLearningTimeForEachClass;
        this.lunchTimeForEachClass = lunchTimeForEachClass;
        this.sportsAndPhysicalEducationTimeForEachClass = sportsAndPhysicalEducationTimeForEachClass;
        this.nameOfTrustSocietyManagementCommittee = nameOfTrustSocietyManagementCommittee;
        this.registrationNo = registrationNo;
        this.underTheSocietiesRegistrationAct1860 = underTheSocietiesRegistrationAct1860;
        this.underTheMumbaiPublicTrusteeSystemAct1950 = underTheMumbaiPublicTrusteeSystemAct1950;
        this.tillWhatPeriodTheRegistrationOfTrust = tillWhatPeriodTheRegistrationOfTrust;
        this.isThereEvidenceThatTheTrust = isThereEvidenceThatTheTrust;
        this.schoolUserName = schoolUserName;
        this.schoolUserDegisnation = schoolUserDegisnation;
        this.schoolUserAddress = schoolUserAddress;
        this.schoolUserTelephone = schoolUserTelephone;
        this.accountYear = accountYear;
        this.accountIncome = accountIncome;
        this.accountExpense = accountExpense;
        this.accountBalance = accountBalance;
        this.applicationId = applicationId;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.forWhichYearYouWantToApplyForACertificate = forWhichYearYouWantToApplyForACertificate;
        this.yearOfFoundationzOfSchool = yearOfFoundationzOfSchool;
        this.dateOfFirstOpeningOfSchool = dateOfFirstOpeningOfSchool;
        this.lowerStandard = lowerStandard;
        this.higherStandard = higherStandard;
        this.schoolArea = schoolArea;
        this.mediumOfInstruction = mediumOfInstruction;
        this.schoolBoard = schoolBoard;
        this.sangsthaCompanyName = sangsthaCompanyName;
        this.sansthaCompanyHasPurposeForOnlyEducationService = sansthaCompanyHasPurposeForOnlyEducationService;
        this.isSchoolOpenWhereAddressMentionedInApproval = isSchoolOpenWhereAddressMentionedInApproval;
        this.ifSansthaIsHandoverToSomeone = ifSansthaIsHandoverToSomeone;
        this.doYouHaveMaharastraShashanManyataNo = doYouHaveMaharastraShashanManyataNo;
        this.maharastraShashanApprovalNumber = maharastraShashanApprovalNumber;
        this.maharastraShashanApprovalDate = maharastraShashanApprovalDate;
        this.doYouHaveShikshanUpsanchalakApproval = doYouHaveShikshanUpsanchalakApproval;
        this.shikshanUpsanchalakApprovalDate = shikshanUpsanchalakApprovalDate;
        this.shikshanUpsanchalakApprovalNumber = shikshanUpsanchalakApprovalNumber;
        this.doYouHavePrathamManyataCertificate = doYouHavePrathamManyataCertificate;
        this.prathamManyataNumber = prathamManyataNumber;
        this.prathamManyataDate = prathamManyataDate;
        this.doYouRunOnGovernmentNoObjectionCertificate = doYouRunOnGovernmentNoObjectionCertificate;
        this.noObjectionCertificateNumber = noObjectionCertificateNumber;
        this.noObjectionCertificateDate = noObjectionCertificateDate;
        this.whetherSchoolIsMovedToAnotherLocation = whetherSchoolIsMovedToAnotherLocation;
        this.members = members;
        this.simpleHigherStandard = simpleHigherStandard;
        this.simpleLowerStandard = simpleLowerStandard;
        this.udiseLowerStandard = udiseLowerStandard;
        this.udiseHigherStandard = udiseHigherStandard;
        this.isThereAnAffiliationCertificate = isThereAnAffiliationCertificate;
        this.affiliationCertificateNumber = affiliationCertificateNumber;
        this.affiliationCertificateDate = affiliationCertificateDate;
        this.section1InspectionApproval = section1InspectionApproval;
        this.section2InspectionApproval = section2InspectionApproval;
        this.section3InspectionApproval = section3InspectionApproval;
        this.section1InspectionComment = section1InspectionComment;
        this.section2InspectionComment = section2InspectionComment;
        this.section3InspectionComment = section3InspectionComment;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(Long schoolId) {
		this.schoolId = schoolId;
	}

	public String getSchoolAddress() {
		return schoolAddress;
	}

	public void setSchoolAddress(String schoolAddress) {
		this.schoolAddress = schoolAddress;
	}

	public String getAddressMentionedInGovernmentApprovalDocument() {
		return addressMentionedInGovernmentApprovalDocument;
	}

	public void setAddressMentionedInGovernmentApprovalDocument(String addressMentionedInGovernmentApprovalDocument) {
		this.addressMentionedInGovernmentApprovalDocument = addressMentionedInGovernmentApprovalDocument;
	}

	public String getSchoolEstablishmentYear() {
		return schoolEstablishmentYear;
	}

	public void setSchoolEstablishmentYear(String schoolEstablishmentYear) {
		this.schoolEstablishmentYear = schoolEstablishmentYear;
	}

	public String getDateOfFirstCommencementOfSchool() {
		return dateOfFirstCommencementOfSchool;
	}

	public void setDateOfFirstCommencementOfSchool(String dateOfFirstCommencementOfSchool) {
		this.dateOfFirstCommencementOfSchool = dateOfFirstCommencementOfSchool;
	}

	public String getSchoolAcademicSession() {
		return schoolAcademicSession;
	}

	public void setSchoolAcademicSession(String schoolAcademicSession) {
		this.schoolAcademicSession = schoolAcademicSession;
	}

	public String getSchoolTimeFullTime() {
		return schoolTimeFullTime;
	}

	public void setSchoolTimeFullTime(String schoolTimeFullTime) {
		this.schoolTimeFullTime = schoolTimeFullTime;
	}

	public String getSchoolTimeHalfTime() {
		return schoolTimeHalfTime;
	}

	public void setSchoolTimeHalfTime(String schoolTimeHalfTime) {
		this.schoolTimeHalfTime = schoolTimeHalfTime;
	}

	public String getAcademicLearningTimeForEachClass() {
		return academicLearningTimeForEachClass;
	}

	public void setAcademicLearningTimeForEachClass(String academicLearningTimeForEachClass) {
		this.academicLearningTimeForEachClass = academicLearningTimeForEachClass;
	}

	public String getLunchTimeForEachClass() {
		return lunchTimeForEachClass;
	}

	public void setLunchTimeForEachClass(String lunchTimeForEachClass) {
		this.lunchTimeForEachClass = lunchTimeForEachClass;
	}

	public String getSportsAndPhysicalEducationTimeForEachClass() {
		return sportsAndPhysicalEducationTimeForEachClass;
	}

	public void setSportsAndPhysicalEducationTimeForEachClass(String sportsAndPhysicalEducationTimeForEachClass) {
		this.sportsAndPhysicalEducationTimeForEachClass = sportsAndPhysicalEducationTimeForEachClass;
	}

	public String getNameOfTrustSocietyManagementCommittee() {
		return nameOfTrustSocietyManagementCommittee;
	}

	public void setNameOfTrustSocietyManagementCommittee(String nameOfTrustSocietyManagementCommittee) {
		this.nameOfTrustSocietyManagementCommittee = nameOfTrustSocietyManagementCommittee;
	}

	public String getRegistrationNo() {
		return registrationNo;
	}

	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}

	public String getUnderTheSocietiesRegistrationAct1860() {
		return underTheSocietiesRegistrationAct1860;
	}

	public void setUnderTheSocietiesRegistrationAct1860(String underTheSocietiesRegistrationAct1860) {
		this.underTheSocietiesRegistrationAct1860 = underTheSocietiesRegistrationAct1860;
	}

	public String getUnderTheMumbaiPublicTrusteeSystemAct1950() {
		return underTheMumbaiPublicTrusteeSystemAct1950;
	}

	public void setUnderTheMumbaiPublicTrusteeSystemAct1950(String underTheMumbaiPublicTrusteeSystemAct1950) {
		this.underTheMumbaiPublicTrusteeSystemAct1950 = underTheMumbaiPublicTrusteeSystemAct1950;
	}

	public String getTillWhatPeriodTheRegistrationOfTrust() {
		return tillWhatPeriodTheRegistrationOfTrust;
	}

	public void setTillWhatPeriodTheRegistrationOfTrust(String tillWhatPeriodTheRegistrationOfTrust) {
		this.tillWhatPeriodTheRegistrationOfTrust = tillWhatPeriodTheRegistrationOfTrust;
	}

	public String getIsThereEvidenceThatTheTrust() {
		return isThereEvidenceThatTheTrust;
	}

	public void setIsThereEvidenceThatTheTrust(String isThereEvidenceThatTheTrust) {
		this.isThereEvidenceThatTheTrust = isThereEvidenceThatTheTrust;
	}

	public String getSchoolUserName() {
		return schoolUserName;
	}

	public void setSchoolUserName(String schoolUserName) {
		this.schoolUserName = schoolUserName;
	}

	public String getSchoolUserDegisnation() {
		return schoolUserDegisnation;
	}

	public void setSchoolUserDegisnation(String schoolUserDegisnation) {
		this.schoolUserDegisnation = schoolUserDegisnation;
	}

	public String getSchoolUserAddress() {
		return schoolUserAddress;
	}

	public void setSchoolUserAddress(String schoolUserAddress) {
		this.schoolUserAddress = schoolUserAddress;
	}

	public String getSchoolUserTelephone() {
		return schoolUserTelephone;
	}

	public void setSchoolUserTelephone(String schoolUserTelephone) {
		this.schoolUserTelephone = schoolUserTelephone;
	}

	public String getAccountYear() {
		return accountYear;
	}

	public void setAccountYear(String accountYear) {
		this.accountYear = accountYear;
	}

	public String getAccountIncome() {
		return accountIncome;
	}

	public void setAccountIncome(String accountIncome) {
		this.accountIncome = accountIncome;
	}

	public String getAccountExpense() {
		return accountExpense;
	}

	public void setAccountExpense(String accountExpense) {
		this.accountExpense = accountExpense;
	}

	public String getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(String accountBalance) {
		this.accountBalance = accountBalance;
	}

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public Instant getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}

	public Instant getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Instant updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getForWhichYearYouWantToApplyForACertificate() {
		return forWhichYearYouWantToApplyForACertificate;
	}

	public void setForWhichYearYouWantToApplyForACertificate(String forWhichYearYouWantToApplyForACertificate) {
		this.forWhichYearYouWantToApplyForACertificate = forWhichYearYouWantToApplyForACertificate;
	}

	public String getYearOfFoundationzOfSchool() {
		return yearOfFoundationzOfSchool;
	}

	public void setYearOfFoundationzOfSchool(String yearOfFoundationzOfSchool) {
		this.yearOfFoundationzOfSchool = yearOfFoundationzOfSchool;
	}

	public String getDateOfFirstOpeningOfSchool() {
		return dateOfFirstOpeningOfSchool;
	}

	public void setDateOfFirstOpeningOfSchool(String dateOfFirstOpeningOfSchool) {
		this.dateOfFirstOpeningOfSchool = dateOfFirstOpeningOfSchool;
	}

	public String getLowerStandard() {
		return lowerStandard;
	}

	public void setLowerStandard(String lowerStandard) {
		this.lowerStandard = lowerStandard;
	}

	public String getHigherStandard() {
		return higherStandard;
	}

	public void setHigherStandard(String higherStandard) {
		this.higherStandard = higherStandard;
	}

	public String getSchoolArea() {
		return schoolArea;
	}

	public void setSchoolArea(String schoolArea) {
		this.schoolArea = schoolArea;
	}

	public String getMediumOfInstruction() {
		return mediumOfInstruction;
	}

	public void setMediumOfInstruction(String mediumOfInstruction) {
		this.mediumOfInstruction = mediumOfInstruction;
	}

	public String getSchoolBoard() {
		return schoolBoard;
	}

	public void setSchoolBoard(String schoolBoard) {
		this.schoolBoard = schoolBoard;
	}

	public String getSangsthaCompanyName() {
		return sangsthaCompanyName;
	}

	public void setSangsthaCompanyName(String sangsthaCompanyName) {
		this.sangsthaCompanyName = sangsthaCompanyName;
	}

	public String getSansthaCompanyHasPurposeForOnlyEducationService() {
		return sansthaCompanyHasPurposeForOnlyEducationService;
	}

	public void setSansthaCompanyHasPurposeForOnlyEducationService(String sansthaCompanyHasPurposeForOnlyEducationService) {
		this.sansthaCompanyHasPurposeForOnlyEducationService = sansthaCompanyHasPurposeForOnlyEducationService;
	}

	public String getIsSchoolOpenWhereAddressMentionedInApproval() {
		return isSchoolOpenWhereAddressMentionedInApproval;
	}

	public void setIsSchoolOpenWhereAddressMentionedInApproval(String isSchoolOpenWhereAddressMentionedInApproval) {
		this.isSchoolOpenWhereAddressMentionedInApproval = isSchoolOpenWhereAddressMentionedInApproval;
	}

	public String getIfSansthaIsHandoverToSomeone() {
		return ifSansthaIsHandoverToSomeone;
	}

	public void setIfSansthaIsHandoverToSomeone(String ifSansthaIsHandoverToSomeone) {
		this.ifSansthaIsHandoverToSomeone = ifSansthaIsHandoverToSomeone;
	}

	public String getDoYouHaveMaharastraShashanManyataNo() {
		return doYouHaveMaharastraShashanManyataNo;
	}

	public void setDoYouHaveMaharastraShashanManyataNo(String doYouHaveMaharastraShashanManyataNo) {
		this.doYouHaveMaharastraShashanManyataNo = doYouHaveMaharastraShashanManyataNo;
	}

	public String getMaharastraShashanApprovalNumber() {
		return maharastraShashanApprovalNumber;
	}

	public void setMaharastraShashanApprovalNumber(String maharastraShashanApprovalNumber) {
		this.maharastraShashanApprovalNumber = maharastraShashanApprovalNumber;
	}

	public String getMaharastraShashanApprovalDate() {
		return maharastraShashanApprovalDate;
	}

	public void setMaharastraShashanApprovalDate(String maharastraShashanApprovalDate) {
		this.maharastraShashanApprovalDate = maharastraShashanApprovalDate;
	}

	public String getDoYouHaveShikshanUpsanchalakApproval() {
		return doYouHaveShikshanUpsanchalakApproval;
	}

	public void setDoYouHaveShikshanUpsanchalakApproval(String doYouHaveShikshanUpsanchalakApproval) {
		this.doYouHaveShikshanUpsanchalakApproval = doYouHaveShikshanUpsanchalakApproval;
	}

	public String getShikshanUpsanchalakApprovalDate() {
		return shikshanUpsanchalakApprovalDate;
	}

	public void setShikshanUpsanchalakApprovalDate(String shikshanUpsanchalakApprovalDate) {
		this.shikshanUpsanchalakApprovalDate = shikshanUpsanchalakApprovalDate;
	}

	public String getShikshanUpsanchalakApprovalNumber() {
		return shikshanUpsanchalakApprovalNumber;
	}

	public void setShikshanUpsanchalakApprovalNumber(String shikshanUpsanchalakApprovalNumber) {
		this.shikshanUpsanchalakApprovalNumber = shikshanUpsanchalakApprovalNumber;
	}

	public String getDoYouHavePrathamManyataCertificate() {
		return doYouHavePrathamManyataCertificate;
	}

	public void setDoYouHavePrathamManyataCertificate(String doYouHavePrathamManyataCertificate) {
		this.doYouHavePrathamManyataCertificate = doYouHavePrathamManyataCertificate;
	}

	public String getPrathamManyataNumber() {
		return prathamManyataNumber;
	}

	public void setPrathamManyataNumber(String prathamManyataNumber) {
		this.prathamManyataNumber = prathamManyataNumber;
	}

	public String getPrathamManyataDate() {
		return prathamManyataDate;
	}

	public void setPrathamManyataDate(String prathamManyataDate) {
		this.prathamManyataDate = prathamManyataDate;
	}

	public String getDoYouRunOnGovernmentNoObjectionCertificate() {
		return doYouRunOnGovernmentNoObjectionCertificate;
	}

	public void setDoYouRunOnGovernmentNoObjectionCertificate(String doYouRunOnGovernmentNoObjectionCertificate) {
		this.doYouRunOnGovernmentNoObjectionCertificate = doYouRunOnGovernmentNoObjectionCertificate;
	}

	public String getNoObjectionCertificateNumber() {
		return noObjectionCertificateNumber;
	}

	public void setNoObjectionCertificateNumber(String noObjectionCertificateNumber) {
		this.noObjectionCertificateNumber = noObjectionCertificateNumber;
	}

	public String getNoObjectionCertificateDate() {
		return noObjectionCertificateDate;
	}

	public void setNoObjectionCertificateDate(String noObjectionCertificateDate) {
		this.noObjectionCertificateDate = noObjectionCertificateDate;
	}

	public String getWhetherSchoolIsMovedToAnotherLocation() {
		return whetherSchoolIsMovedToAnotherLocation;
	}

	public void setWhetherSchoolIsMovedToAnotherLocation(String whetherSchoolIsMovedToAnotherLocation) {
		this.whetherSchoolIsMovedToAnotherLocation = whetherSchoolIsMovedToAnotherLocation;
	}

	public String getMembers() {
		return members;
	}

	public void setMembers(String members) {
		this.members = members;
	}

	public String getSimpleHigherStandard() {
		return simpleHigherStandard;
	}

	public void setSimpleHigherStandard(String simpleHigherStandard) {
		this.simpleHigherStandard = simpleHigherStandard;
	}

	public String getSimpleLowerStandard() {
		return simpleLowerStandard;
	}

	public void setSimpleLowerStandard(String simpleLowerStandard) {
		this.simpleLowerStandard = simpleLowerStandard;
	}

	public String getUdiseLowerStandard() {
		return udiseLowerStandard;
	}

	public void setUdiseLowerStandard(String udiseLowerStandard) {
		this.udiseLowerStandard = udiseLowerStandard;
	}

	public String getUdiseHigherStandard() {
		return udiseHigherStandard;
	}

	public void setUdiseHigherStandard(String udiseHigherStandard) {
		this.udiseHigherStandard = udiseHigherStandard;
	}

	public String getIsThereAnAffiliationCertificate() {
		return isThereAnAffiliationCertificate;
	}

	public void setIsThereAnAffiliationCertificate(String isThereAnAffiliationCertificate) {
		this.isThereAnAffiliationCertificate = isThereAnAffiliationCertificate;
	}

	public String getAffiliationCertificateNumber() {
		return affiliationCertificateNumber;
	}

	public void setAffiliationCertificateNumber(String affiliationCertificateNumber) {
		this.affiliationCertificateNumber = affiliationCertificateNumber;
	}

	public String getAffiliationCertificateDate() {
		return affiliationCertificateDate;
	}

	public void setAffiliationCertificateDate(String affiliationCertificateDate) {
		this.affiliationCertificateDate = affiliationCertificateDate;
	}

	public String getSection1InspectionApproval() {
		return section1InspectionApproval;
	}

	public void setSection1InspectionApproval(String section1InspectionApproval) {
		this.section1InspectionApproval = section1InspectionApproval;
	}

	public String getSection2InspectionApproval() {
		return section2InspectionApproval;
	}

	public void setSection2InspectionApproval(String section2InspectionApproval) {
		this.section2InspectionApproval = section2InspectionApproval;
	}

	public String getSection3InspectionApproval() {
		return section3InspectionApproval;
	}

	public void setSection3InspectionApproval(String section3InspectionApproval) {
		this.section3InspectionApproval = section3InspectionApproval;
	}

	public String getSection1InspectionComment() {
		return section1InspectionComment;
	}

	public void setSection1InspectionComment(String section1InspectionComment) {
		this.section1InspectionComment = section1InspectionComment;
	}

	public String getSection2InspectionComment() {
		return section2InspectionComment;
	}

	public void setSection2InspectionComment(String section2InspectionComment) {
		this.section2InspectionComment = section2InspectionComment;
	}

	public String getSection3InspectionComment() {
		return section3InspectionComment;
	}

	public void setSection3InspectionComment(String section3InspectionComment) {
		this.section3InspectionComment = section3InspectionComment;
	}


}
