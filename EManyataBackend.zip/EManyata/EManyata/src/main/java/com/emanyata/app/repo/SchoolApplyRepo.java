package com.emanyata.app.repo;

import com.emanyata.app.dto.StatusCountDTO;
import com.emanyata.app.entity.SchoolApply;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface SchoolApplyRepo extends JpaRepository<SchoolApply, Long> {

    List<SchoolApply> findByUserId(Long userId);

    List<SchoolApply> findBySchoolId(Long schoolId);

    Optional<SchoolApply> findByApplicationNo(String applicationNo);

    boolean existsByApplicationNo(String applicationNo);

    long countByApplicationNoStartingWith(String prefix);

    @Query("SELECT s.udiseNo FROM School s WHERE s.id = :schoolId")
    String findUdiseNoBySchoolId(Long schoolId);
    
    // This is for Status Count
    @Query("SELECT new com.emanyata.app.dto.StatusCountDTO(s.status, COUNT(s)) FROM SchoolApply s GROUP BY s.status")
    List<StatusCountDTO> getStatusCounts();
}