package com.emanyata.app.service;

import java.util.List;
import java.util.Optional;

import com.emanyata.app.dto.VillageDTO;

public interface VillageService {

VillageDTO addVillage(VillageDTO villageDTO);

VillageDTO getByVillageid(Long villageId);

List<VillageDTO> getAllVillages();

boolean deleteVillageById(Long id);

VillageDTO updateVillageById(Long id, VillageDTO dto);

Optional<VillageDTO> getByName(String name); // <--- add this


}