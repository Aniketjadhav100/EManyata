package com.emanyata.app.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.School;

public interface SchoolRepo extends JpaRepository<School,Long> {
	
		Optional<School> findByUdiseNo(String udiseNo);
}
