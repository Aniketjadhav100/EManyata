package com.emanyata.app.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.OtherFacility;

public interface OtherFacilityRepo extends JpaRepository<OtherFacility, Long> {
	Optional<OtherFacility> findBySchoolId(Long id);
}
