package com.emanyata.app.service.secondary;

public interface PreviousFormService {
    Object getFormData(String key, String udiseNumber);
}
