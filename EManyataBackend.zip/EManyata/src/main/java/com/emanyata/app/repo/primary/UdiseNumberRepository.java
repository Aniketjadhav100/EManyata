package com.emanyata.app.repo.primary;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.primary.UdiseNumber;

public interface UdiseNumberRepository extends JpaRepository<UdiseNumber, Long> {
    boolean existsByUdiseNumber(String udiseNumber);
    Optional<UdiseNumber> findByUdiseNumber(String udiseNumber); // This should return Optional

    List<UdiseNumber> findByStatus(String status);
//
//    Optional<UdiseNumber> findByUdiseNumber(Long udiseNumber);
//    
    

}
