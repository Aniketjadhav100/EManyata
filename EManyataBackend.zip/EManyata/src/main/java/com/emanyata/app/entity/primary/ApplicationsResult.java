package com.emanyata.app.entity.primary;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDateTime;

@Entity
@Table(name = "applications_results", schema = "emanyata")
public class ApplicationsResult {
    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "application_id", nullable = false)
    private SchoolApply application;

    @Column(name = "school_info")
    private Byte schoolInfo;

    @Column(name = "general_info")
    private Byte generalInfo;

    @Column(name = "form_and_area")
    private Byte formAndArea;

    @Column(name = "student_count")
    private Byte studentCount;

    @Column(name = "details_of_physical")
    private Byte detailsOfPhysical;

    @Column(name = "other_facilities")
    private Byte otherFacilities;

    @Column(name = "details_of_teaching")
    private Byte detailsOfTeaching;

    @Column(name = "non_granted")
    private Byte nonGranted;

    @Column(name = "granted")
    private Byte granted;

    @Lob
    @Column(name = "comment")
    private String comment;

    @Column(name = "government_decision_of_approval")
    private Byte governmentDecisionOfApproval;

    @Column(name = "approval_order_of_deputy_director_of_education")
    private Byte approvalOrderOfDeputyDirectorOfEducation;

    @Column(name = "first_approval_order")
    private Byte firstApprovalOrder;

    @Column(name = "organizations_requisition_application_in_sample_1")
    private Byte organizationsRequisitionApplicationInSample1;

    @Column(name = "institution_registration_1950_1860_certificate")
    private Byte institutionRegistration19501860Certificate;

    @Column(name = "govt_minority_certificate_if_the_school_is_minority")
    private Byte govtMinorityCertificateIfTheSchoolIsMinority;

    @Column(name = "institutional_undertaking_of_schools_not_charging_any")
    private Byte institutionalUndertakingOfSchoolsNotChargingAny;

    @Column(name = "women_grievance_redressal_committee")
    private Byte womenGrievanceRedressalCommittee;

    @Column(name = "affidavit_on_stamp_of_rs_100")
    private Byte affidavitOnStampOfRs100;

    @Column(name = "school_principal_sign_stamp")
    private Byte schoolPrincipalSignStamp;

    @Column(name = "school_location_changed")
    private Byte schoolLocationChanged;

    @Column(name = "common_order_2013_to_2016")
    private Byte commonOrder2013To2016;

    @Column(name = "common_order_2016_to_2019")
    private Byte commonOrder2016To2019;

    @Column(name = "common_order_2019_to_2022")
    private Byte commonOrder2019To2022;

    @Column(name = "joint_account_retention_receipt_of_institution")
    private Byte jointAccountRetentionReceiptOfInstitution;

    @Column(name = "organization_company_registration_certificate")
    private Byte organizationCompanyRegistrationCertificate;

    @Column(name = "govt_minority_certificate")
    private Byte govtMinorityCertificate;

    @Column(name = "audit_report")
    private Byte auditReport;

    @Column(name = "copy_of_EPTA_approval_minutes")
    private Byte copyOfEptaApprovalMinutes;

    @Column(name = "free_structure_according_to_previous")
    private Byte freeStructureAccordingToPrevious;

    @Column(name = "transport_committee_online_copy")
    private Byte transportCommitteeOnlineCopy;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public SchoolApply getApplication() {
        return application;
    }

    public void setApplication(SchoolApply application) {
        this.application = application;
    }

    public Byte getSchoolInfo() {
        return schoolInfo;
    }

    public void setSchoolInfo(Byte schoolInfo) {
        this.schoolInfo = schoolInfo;
    }

    public Byte getGeneralInfo() {
        return generalInfo;
    }

    public void setGeneralInfo(Byte generalInfo) {
        this.generalInfo = generalInfo;
    }

    public Byte getFormAndArea() {
        return formAndArea;
    }

    public void setFormAndArea(Byte formAndArea) {
        this.formAndArea = formAndArea;
    }

    public Byte getStudentCount() {
        return studentCount;
    }

    public void setStudentCount(Byte studentCount) {
        this.studentCount = studentCount;
    }

    public Byte getDetailsOfPhysical() {
        return detailsOfPhysical;
    }

    public void setDetailsOfPhysical(Byte detailsOfPhysical) {
        this.detailsOfPhysical = detailsOfPhysical;
    }

    public Byte getOtherFacilities() {
        return otherFacilities;
    }

    public void setOtherFacilities(Byte otherFacilities) {
        this.otherFacilities = otherFacilities;
    }

    public Byte getDetailsOfTeaching() {
        return detailsOfTeaching;
    }

    public void setDetailsOfTeaching(Byte detailsOfTeaching) {
        this.detailsOfTeaching = detailsOfTeaching;
    }

    public Byte getNonGranted() {
        return nonGranted;
    }

    public void setNonGranted(Byte nonGranted) {
        this.nonGranted = nonGranted;
    }

    public Byte getGranted() {
        return granted;
    }

    public void setGranted(Byte granted) {
        this.granted = granted;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Byte getGovernmentDecisionOfApproval() {
        return governmentDecisionOfApproval;
    }

    public void setGovernmentDecisionOfApproval(Byte governmentDecisionOfApproval) {
        this.governmentDecisionOfApproval = governmentDecisionOfApproval;
    }

    public Byte getApprovalOrderOfDeputyDirectorOfEducation() {
        return approvalOrderOfDeputyDirectorOfEducation;
    }

    public void setApprovalOrderOfDeputyDirectorOfEducation(Byte approvalOrderOfDeputyDirectorOfEducation) {
        this.approvalOrderOfDeputyDirectorOfEducation = approvalOrderOfDeputyDirectorOfEducation;
    }

    public Byte getFirstApprovalOrder() {
        return firstApprovalOrder;
    }

    public void setFirstApprovalOrder(Byte firstApprovalOrder) {
        this.firstApprovalOrder = firstApprovalOrder;
    }

    public Byte getOrganizationsRequisitionApplicationInSample1() {
        return organizationsRequisitionApplicationInSample1;
    }

    public void setOrganizationsRequisitionApplicationInSample1(Byte organizationsRequisitionApplicationInSample1) {
        this.organizationsRequisitionApplicationInSample1 = organizationsRequisitionApplicationInSample1;
    }

    public Byte getInstitutionRegistration19501860Certificate() {
        return institutionRegistration19501860Certificate;
    }

    public void setInstitutionRegistration19501860Certificate(Byte institutionRegistration19501860Certificate) {
        this.institutionRegistration19501860Certificate = institutionRegistration19501860Certificate;
    }

    public Byte getGovtMinorityCertificateIfTheSchoolIsMinority() {
        return govtMinorityCertificateIfTheSchoolIsMinority;
    }

    public void setGovtMinorityCertificateIfTheSchoolIsMinority(Byte govtMinorityCertificateIfTheSchoolIsMinority) {
        this.govtMinorityCertificateIfTheSchoolIsMinority = govtMinorityCertificateIfTheSchoolIsMinority;
    }

    public Byte getInstitutionalUndertakingOfSchoolsNotChargingAny() {
        return institutionalUndertakingOfSchoolsNotChargingAny;
    }

    public void setInstitutionalUndertakingOfSchoolsNotChargingAny(Byte institutionalUndertakingOfSchoolsNotChargingAny) {
        this.institutionalUndertakingOfSchoolsNotChargingAny = institutionalUndertakingOfSchoolsNotChargingAny;
    }

    public Byte getWomenGrievanceRedressalCommittee() {
        return womenGrievanceRedressalCommittee;
    }

    public void setWomenGrievanceRedressalCommittee(Byte womenGrievanceRedressalCommittee) {
        this.womenGrievanceRedressalCommittee = womenGrievanceRedressalCommittee;
    }

    public Byte getAffidavitOnStampOfRs100() {
        return affidavitOnStampOfRs100;
    }

    public void setAffidavitOnStampOfRs100(Byte affidavitOnStampOfRs100) {
        this.affidavitOnStampOfRs100 = affidavitOnStampOfRs100;
    }

    public Byte getSchoolPrincipalSignStamp() {
        return schoolPrincipalSignStamp;
    }

    public void setSchoolPrincipalSignStamp(Byte schoolPrincipalSignStamp) {
        this.schoolPrincipalSignStamp = schoolPrincipalSignStamp;
    }

    public Byte getSchoolLocationChanged() {
        return schoolLocationChanged;
    }

    public void setSchoolLocationChanged(Byte schoolLocationChanged) {
        this.schoolLocationChanged = schoolLocationChanged;
    }

    public Byte getCommonOrder2013To2016() {
        return commonOrder2013To2016;
    }

    public void setCommonOrder2013To2016(Byte commonOrder2013To2016) {
        this.commonOrder2013To2016 = commonOrder2013To2016;
    }

    public Byte getCommonOrder2016To2019() {
        return commonOrder2016To2019;
    }

    public void setCommonOrder2016To2019(Byte commonOrder2016To2019) {
        this.commonOrder2016To2019 = commonOrder2016To2019;
    }

    public Byte getCommonOrder2019To2022() {
        return commonOrder2019To2022;
    }

    public void setCommonOrder2019To2022(Byte commonOrder2019To2022) {
        this.commonOrder2019To2022 = commonOrder2019To2022;
    }

    public Byte getJointAccountRetentionReceiptOfInstitution() {
        return jointAccountRetentionReceiptOfInstitution;
    }

    public void setJointAccountRetentionReceiptOfInstitution(Byte jointAccountRetentionReceiptOfInstitution) {
        this.jointAccountRetentionReceiptOfInstitution = jointAccountRetentionReceiptOfInstitution;
    }

    public Byte getOrganizationCompanyRegistrationCertificate() {
        return organizationCompanyRegistrationCertificate;
    }

    public void setOrganizationCompanyRegistrationCertificate(Byte organizationCompanyRegistrationCertificate) {
        this.organizationCompanyRegistrationCertificate = organizationCompanyRegistrationCertificate;
    }

    public Byte getGovtMinorityCertificate() {
        return govtMinorityCertificate;
    }

    public void setGovtMinorityCertificate(Byte govtMinorityCertificate) {
        this.govtMinorityCertificate = govtMinorityCertificate;
    }

    public Byte getAuditReport() {
        return auditReport;
    }

    public void setAuditReport(Byte auditReport) {
        this.auditReport = auditReport;
    }

    public Byte getCopyOfEptaApprovalMinutes() {
        return copyOfEptaApprovalMinutes;
    }

    public void setCopyOfEptaApprovalMinutes(Byte copyOfEptaApprovalMinutes) {
        this.copyOfEptaApprovalMinutes = copyOfEptaApprovalMinutes;
    }

    public Byte getFreeStructureAccordingToPrevious() {
        return freeStructureAccordingToPrevious;
    }

    public void setFreeStructureAccordingToPrevious(Byte freeStructureAccordingToPrevious) {
        this.freeStructureAccordingToPrevious = freeStructureAccordingToPrevious;
    }

    public Byte getTransportCommitteeOnlineCopy() {
        return transportCommitteeOnlineCopy;
    }

    public void setTransportCommitteeOnlineCopy(Byte transportCommitteeOnlineCopy) {
        this.transportCommitteeOnlineCopy = transportCommitteeOnlineCopy;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

}