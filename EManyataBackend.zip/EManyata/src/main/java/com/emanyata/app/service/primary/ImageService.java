package com.emanyata.app.service.primary;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import com.emanyata.app.dto.ImageDTO;

public interface ImageService {

	ImageDTO upsertUserImage(Long userId, MultipartFile file) throws Exception;

	Resource loadUserImage(Long userId) throws Exception;

	void deleteUserImage(Long userId);
  
}