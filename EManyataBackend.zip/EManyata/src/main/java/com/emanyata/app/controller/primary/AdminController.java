package com.emanyata.app.controller.primary;

import com.emanyata.app.authdto.AdminRegistrationDTO;
import com.emanyata.app.authdto.AdminUpdateDTO;
import com.emanyata.app.authdto.UserDTO;
import com.emanyata.app.service.primary.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private UserService adminService;


    @PostMapping("/update_admin")
    public ResponseEntity<Map<String, Object>> updateAdmin(@RequestBody AdminUpdateDTO dto) {
        AdminUpdateDTO updatedAdmin = adminService.editAdmin(dto);

        Map<String, Object> response = new HashMap<>();
        response.put("timestamp", LocalDateTime.now());
        response.put("status", "success");
        response.put("message", "Admin updated successfully");
        response.put("data", updatedAdmin);

        return ResponseEntity.ok(response);
    }

    
    @PostMapping("/add_admin")
    public ResponseEntity<Map<String, Object>> registerAdmin(@RequestBody AdminRegistrationDTO dto) {
        AdminRegistrationDTO registeredAdmin = adminService.registerAdmin(dto);

        Map<String, Object> response = new HashMap<>();
        response.put("timestamp", LocalDateTime.now());
        response.put("status", "success");
        response.put("message", "Admin registered successfully");
        response.put("data", registeredAdmin);

        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/getall_admin")
    public ResponseEntity<Map<String, Object>> getAdminsAndSuperadmins() {
        List<UserDTO> admins = adminService.getAllAdmin();

        Map<String, Object> response = new HashMap<>();
        response.put("timestamp", LocalDateTime.now());

        if (admins != null && !admins.isEmpty()) {
            response.put("status", "success");
            response.put("message", "Fetched Admins & Superadmins successfully");
            response.put("data", admins);
            return ResponseEntity.ok(response);
        } else {
            response.put("status", "error");
            response.put("message", "No Admins or Superadmins found");
            response.put("data", Collections.emptyList());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    @PostMapping("/getbyid/{id}")
    public ResponseEntity<Map<String, Object>> getAdminById(@PathVariable Long id) {
        Optional<UserDTO> adminOpt = adminService.getAdminById(id);

        if (adminOpt.isPresent()) {
            Map<String, Object> response = new HashMap<>();
            response.put("timestamp", LocalDateTime.now());
            response.put("status", "success");
            response.put("message", "Admin found");
            response.put("data", adminOpt.get());

            return ResponseEntity.ok(response);
        } else {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("timestamp", LocalDateTime.now());
            errorResponse.put("status", "error");
            errorResponse.put("message", "Admin not found with ID: " + id);

            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
        }
    }

 
}
