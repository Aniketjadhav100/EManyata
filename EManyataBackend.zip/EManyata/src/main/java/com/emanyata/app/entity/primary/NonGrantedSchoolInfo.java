package com.emanyata.app.entity.primary;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "non_granted_school_infos", schema = "emanyata")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class NonGrantedSchoolInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(columnDefinition = "BIGINT NOT NULL AUTO_INCREMENT")
	private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @Size(max = 255)
    @Column(name = "government_decision_of_approval")
    private String governmentDecisionOfApprovall;

    @Size(max = 255)
    @Column(name = "approval_order_of_deputy_director_of_education")
    private String approvalOrderOfDeputyDirectorOfEducation;

    @Size(max = 255)
    @Column(name = "first_approval_order")
    private String firstApprovalOrder;

    @Size(max = 255)
    @Column(name = "organizations_requisition_application_in_sample_1")
    private String organizationsRequisitionApplicationInSample1;

    @Size(max = 255)
    @Column(name = "joint_account_retention_receipt_of_institution")
    private String jointAccountRetentionReceiptOfInstitution;

    @Size(max = 255)
    @Column(name = "organization_company_registration_certificate")
    private String organizationCompanyRegistrationCertificate;

    @Size(max = 255)
    @Column(name = "govt_minority_certificate")
    private String govtMinorityCertificate;

    @Size(max = 255)
    @Column(name = "purchase_deed_lease_agreement_award")
    private String purchaseDeedLeaseAgreementAward;

    @Size(max = 255)
    @Column(name = "audit_report")
    private String auditReport;

    @Size(max = 255)
    @Column(name = "copy_of_EPTA_approval_minutes")
    private String copyOfEptaApprovalMinutes;

    @Size(max = 255)
    @Column(name = "free_structure_according_to_previous")
    private String freeStructureAccordingToPrevious;

    @Size(max = 255)
    @Column(name = "transport_committee_online_copy")
    private String transportCommitteeOnlineCopy;

    @Size(max = 255)
    @Column(name = "women_grievance_redressal_committee")
    private String womenGrievanceRedressalCommittee;

    @Size(max = 255)
    @Column(name = "affidavit_on_stamp_of_rs_100")
    private String affidavitOnStampOfRs100;

    @Size(max = 255)
    @Column(name = "school_principal_sign_stamp")
    private String schoolPrincipalSignStamp;

    @Size(max = 255)
    @Column(name = "namuna_1_hand_written_form")
    private String namuna1HandWrittenForm;

    @Size(max = 255)
    @Column(name = "school_location_changed_bit")
    private String schoolLocationChangedBit;

    @Size(max = 255)
    @Column(name = "school_location_changed")
    private String schoolLocationChanged;

    @Size(max = 100)
    @Column(name = "common_order_2013_to_2016_bit")
    private String commonOrder2013To2016Bit;

    @Size(max = 100)
    @Column(name = "common_order_2016_to_2019_bit")
    private String commonOrder2016To2019Bit;

    @Size(max = 100)
    @Column(name = "common_order_2019_to_2022_bit")
    private String commonOrder2019To2022Bit;
    
    @Size(max = 255)
    @Column(name = "common_order_2022_to_2025_bit")
    private String commonOrder2022To2025Bit;

    @Size(max = 255)
    @Column(name = "common_order_2013_to_2016")
    private String commonOrder2013To2016;

    @Size(max = 255)
    @Column(name = "common_order_2016_to_2019")
    private String commonOrder2016To2019;

    @Size(max = 255)
    @Column(name = "common_order_2019_to_2022")
    private String commonOrder2019To2022;
    
    @Size(max = 255)
    @Column(name = "common_order_2022_to_2025")
    private String commonOrder2022To2025;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "application_id")
    private Long applicationId;
    
    @Column(name="status")
    private Byte status;

    public String getGovernmentDecisionOfApprovall() {
		return governmentDecisionOfApprovall;
	}

	public void setGovernmentDecisionOfApprovall(String governmentDecisionOfApprovall) {
		this.governmentDecisionOfApprovall = governmentDecisionOfApprovall;
	}

	public Byte getStatus() {
		return status;
	}

	public void setStatus(Byte status) {
		this.status = status;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public School getSchool() {
        return school;
    }

    public void setSchool(School school) {
        this.school = school;
    }

    public String getGovernmentDecisionOfApproval() {
        return governmentDecisionOfApprovall;
    }

    public void setGovernmentDecisionOfApproval(String governmentDecisionOfApproval) {
        this.governmentDecisionOfApprovall = governmentDecisionOfApproval;
    }

    public String getApprovalOrderOfDeputyDirectorOfEducation() {
        return approvalOrderOfDeputyDirectorOfEducation;
    }

    public void setApprovalOrderOfDeputyDirectorOfEducation(String approvalOrderOfDeputyDirectorOfEducation) {
        this.approvalOrderOfDeputyDirectorOfEducation = approvalOrderOfDeputyDirectorOfEducation;
    }

    public String getFirstApprovalOrder() {
        return firstApprovalOrder;
    }

    public void setFirstApprovalOrder(String firstApprovalOrder) {
        this.firstApprovalOrder = firstApprovalOrder;
    }

    public String getOrganizationsRequisitionApplicationInSample1() {
        return organizationsRequisitionApplicationInSample1;
    }

    public void setOrganizationsRequisitionApplicationInSample1(String organizationsRequisitionApplicationInSample1) {
        this.organizationsRequisitionApplicationInSample1 = organizationsRequisitionApplicationInSample1;
    }

    public String getJointAccountRetentionReceiptOfInstitution() {
        return jointAccountRetentionReceiptOfInstitution;
    }

    public void setJointAccountRetentionReceiptOfInstitution(String jointAccountRetentionReceiptOfInstitution) {
        this.jointAccountRetentionReceiptOfInstitution = jointAccountRetentionReceiptOfInstitution;
    }

    public String getOrganizationCompanyRegistrationCertificate() {
        return organizationCompanyRegistrationCertificate;
    }

    public void setOrganizationCompanyRegistrationCertificate(String organizationCompanyRegistrationCertificate) {
        this.organizationCompanyRegistrationCertificate = organizationCompanyRegistrationCertificate;
    }

    public String getGovtMinorityCertificate() {
        return govtMinorityCertificate;
    }

    public void setGovtMinorityCertificate(String govtMinorityCertificate) {
        this.govtMinorityCertificate = govtMinorityCertificate;
    }

    public String getPurchaseDeedLeaseAgreementAward() {
        return purchaseDeedLeaseAgreementAward;
    }

    public void setPurchaseDeedLeaseAgreementAward(String purchaseDeedLeaseAgreementAward) {
        this.purchaseDeedLeaseAgreementAward = purchaseDeedLeaseAgreementAward;
    }

    public String getAuditReport() {
        return auditReport;
    }

    public void setAuditReport(String auditReport) {
        this.auditReport = auditReport;
    }

    public String getCopyOfEptaApprovalMinutes() {
        return copyOfEptaApprovalMinutes;
    }

    public void setCopyOfEptaApprovalMinutes(String copyOfEptaApprovalMinutes) {
        this.copyOfEptaApprovalMinutes = copyOfEptaApprovalMinutes;
    }

    public String getFreeStructureAccordingToPrevious() {
        return freeStructureAccordingToPrevious;
    }

    public void setFreeStructureAccordingToPrevious(String freeStructureAccordingToPrevious) {
        this.freeStructureAccordingToPrevious = freeStructureAccordingToPrevious;
    }

    public String getTransportCommitteeOnlineCopy() {
        return transportCommitteeOnlineCopy;
    }

    public void setTransportCommitteeOnlineCopy(String transportCommitteeOnlineCopy) {
        this.transportCommitteeOnlineCopy = transportCommitteeOnlineCopy;
    }

    public String getWomenGrievanceRedressalCommittee() {
        return womenGrievanceRedressalCommittee;
    }

    public void setWomenGrievanceRedressalCommittee(String womenGrievanceRedressalCommittee) {
        this.womenGrievanceRedressalCommittee = womenGrievanceRedressalCommittee;
    }

    public String getAffidavitOnStampOfRs100() {
        return affidavitOnStampOfRs100;
    }

    public void setAffidavitOnStampOfRs100(String affidavitOnStampOfRs100) {
        this.affidavitOnStampOfRs100 = affidavitOnStampOfRs100;
    }

    public String getSchoolPrincipalSignStamp() {
        return schoolPrincipalSignStamp;
    }

    public void setSchoolPrincipalSignStamp(String schoolPrincipalSignStamp) {
        this.schoolPrincipalSignStamp = schoolPrincipalSignStamp;
    }

    public String getNamuna1HandWrittenForm() {
        return namuna1HandWrittenForm;
    }

    public void setNamuna1HandWrittenForm(String namuna1HandWrittenForm) {
        this.namuna1HandWrittenForm = namuna1HandWrittenForm;
    }

    public String getSchoolLocationChangedBit() {
        return schoolLocationChangedBit;
    }

    public void setSchoolLocationChangedBit(String schoolLocationChangedBit) {
        this.schoolLocationChangedBit = schoolLocationChangedBit;
    }

    public String getSchoolLocationChanged() {
        return schoolLocationChanged;
    }

    public void setSchoolLocationChanged(String schoolLocationChanged) {
        this.schoolLocationChanged = schoolLocationChanged;
    }

    public String getCommonOrder2013To2016Bit() {
        return commonOrder2013To2016Bit;
    }

    public void setCommonOrder2013To2016Bit(String commonOrder2013To2016Bit) {
        this.commonOrder2013To2016Bit = commonOrder2013To2016Bit;
    }

    public String getCommonOrder2016To2019Bit() {
        return commonOrder2016To2019Bit;
    }

    public void setCommonOrder2016To2019Bit(String commonOrder2016To2019Bit) {
        this.commonOrder2016To2019Bit = commonOrder2016To2019Bit;
    }

    public String getCommonOrder2019To2022Bit() {
        return commonOrder2019To2022Bit;
    }

    public void setCommonOrder2019To2022Bit(String commonOrder2019To2022Bit) {
        this.commonOrder2019To2022Bit = commonOrder2019To2022Bit;
    }

    public String getCommonOrder2013To2016() {
        return commonOrder2013To2016;
    }

    public void setCommonOrder2013To2016(String commonOrder2013To2016) {
        this.commonOrder2013To2016 = commonOrder2013To2016;
    }

    public String getCommonOrder2016To2019() {
        return commonOrder2016To2019;
    }

    public void setCommonOrder2016To2019(String commonOrder2016To2019) {
        this.commonOrder2016To2019 = commonOrder2016To2019;
    }

    public String getCommonOrder2019To2022() {
        return commonOrder2019To2022;
    }

    public void setCommonOrder2019To2022(String commonOrder2019To2022) {
        this.commonOrder2019To2022 = commonOrder2019To2022;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long applicationId) {
        this.applicationId = applicationId;
    }

	public String getCommonOrder2022To2025Bit() {
		return commonOrder2022To2025Bit;
	}

	public void setCommonOrder2022To2025Bit(String commonOrder2022To2025Bit) {
		this.commonOrder2022To2025Bit = commonOrder2022To2025Bit;
	}

	public String getCommonOrder2022To2025() {
		return commonOrder2022To2025;
	}

	public void setCommonOrder2022To2025(String commonOrder2022To2025) {
		this.commonOrder2022To2025 = commonOrder2022To2025;
	}

    
}