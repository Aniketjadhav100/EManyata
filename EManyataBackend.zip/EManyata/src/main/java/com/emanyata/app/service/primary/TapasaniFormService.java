package com.emanyata.app.service.primary;

import java.util.List;

import com.emanyata.app.dto.TapasaniFormDTO;

public interface TapasaniFormService {
	TapasaniFormDTO saveForm(TapasaniFormDTO form);
    List<TapasaniFormDTO> getAllForms();
    TapasaniFormDTO getFormById(Long id);
    void deleteForm(Long id);
    TapasaniFormDTO updateForm(Long id, TapasaniFormDTO updatedForm);
}
