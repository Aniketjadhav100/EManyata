package com.emanyata.app.repo.primary;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.primary.Village;


public interface VillageRepo extends JpaRepository<Village, Long> {
	Optional<Village> findByNameAndTalukaId(String name, Long talukaId);
    Optional<Village> findByName(String name);
    List<Village> findByTalukaId(Long talukaId);

}