package com.emanyata.app.serviceImpl.primary;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.emanyata.app.dto.UdiseDetailsDTO;
import com.emanyata.app.dto.UdiseNumberDTO;
import com.emanyata.app.entity.primary.ApplicationsResult;
import com.emanyata.app.entity.primary.School;
import com.emanyata.app.entity.primary.SchoolApply;
import com.emanyata.app.entity.primary.UdiseNumber;
import com.emanyata.app.exceptions.ResourceNotFoundException;
import com.emanyata.app.repo.primary.ApplicationResultRepo;
import com.emanyata.app.repo.primary.SchoolApplyRepo;
import com.emanyata.app.repo.primary.SchoolRepo;
import com.emanyata.app.repo.primary.UdiseNumberRepository;
import com.emanyata.app.service.primary.UdiseNumberService;
import com.emanyata.app.util.ExcelFileUploadUtil;

import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class UdiseNumberServiceImpl implements UdiseNumberService {

	private static final Logger logger = LoggerFactory.getLogger(UdiseNumberServiceImpl.class);
	private static final String UPLOAD_SUBDIR = "udiseexcel";
	private static final DecimalFormat decimalFormat = new DecimalFormat("0.00");

	// Column indices
	private static final int COL_UDISE_NUMBER = 0;
	private static final int COL_SCHOOL_NAME = 1;
	private static final int COL_ADDRESS_DD = 2;
	private static final int COL_DISTRICT = 3;
	private static final int COL_TALUKA = 4;
	private static final int COL_VILLAGE = 5;
	private static final int COL_PINCODE = 6;
	private static final int COL_TELEPHONE = 7;
	private static final int COL_MOBILE = 8;
	private static final int COL_EMAIL = 9;
	private static final int COL_SCHOOL_TYPE = 10;
	private static final int COL_APPROVAL_DOCS = 11;
	private static final int COL_ESTABLISHMENT_YEAR = 12;
	private static final int COL_FIRST_COMMENCEMENT = 13;
	private static final int COL_SCHOOL_AREA = 14;
	private static final int COL_MEDIUM = 15;
	private static final int COL_SCHOOL_BOARD = 16;
	private static final int COL_HALF_DAY_SCHEDULE = 17;
	private static final int COL_DAY_SCHEDULE = 18;
	private static final int COL_MIDDAY_MEAL = 19;
	private static final int COL_SOCIETY_COMMITTEE = 20;
	private static final int COL_CLASS_PRESENT = 21;
	private static final int COL_SELF_APPROVAL = 22;
	private static final int COL_NEAR_POLICE_STATION = 23;
	private static final int COL_SCHOOL_ADDRESS = 24;
	private static final int COL_ADDRESS_IN_APPROVAL = 25;
	private static final int COL_ACADEMIC_SESSION = 26;
	private static final int COL_FULL_TIME = 27;
	private static final int COL_HALF_TIME = 28;
	private static final int COL_LEARNING_TIME = 29;
	private static final int COL_LUNCH_TIME = 30;
	private static final int COL_SPORTS_TIME = 31;
	private static final int COL_REGISTRATION_NO = 32;
	private static final int COL_SOCIETIES_ACT = 33;
	private static final int COL_MUMBAI_TRUST_ACT = 34;
	private static final int COL_TRUST_PERIOD = 35;
	private static final int COL_TRUST_EVIDENCE = 36;
	private static final int COL_USER_NAME = 37;
	private static final int COL_USER_DESIGNATION = 38;
	private static final int COL_USER_ADDRESS = 39;
	private static final int COL_USER_TELEPHONE = 40;
	private static final int COL_ACCOUNT_YEAR = 41;
	private static final int COL_ACCOUNT_INCOME = 42;
	private static final int COL_ACCOUNT_EXPENSE = 43;
	private static final int COL_ACCOUNT_BALANCE = 44;
	private static final int COL_APPLY_YEAR = 45;
	private static final int COL_FOUNDATION_YEAR = 46;
	private static final int COL_LOWER_STD = 47;
	private static final int COL_HIGHER_STD = 48;
	private static final int COL_SANGSTHA_NAME = 49;
	private static final int COL_EDUCATION_PURPOSE = 50;
	private static final int COL_OPEN_AT_ADDRESS = 51;
	private static final int COL_HANDOVER_STATUS = 52;
	private static final int COL_MH_SHASHAN = 53;
	private static final int COL_SHASHAN_NO = 54;
	private static final int COL_SHASHAN_DATE = 55;
	private static final int COL_SHIKSHAN_UP = 56;
	private static final int COL_UP_DATE = 57;
	private static final int COL_UP_NUMBER = 58;
	private static final int COL_PRATHAM_MANYATA = 59;
	private static final int COL_PRATHAM_NO = 60;
	private static final int COL_PRATHAM_DATE = 61;
	private static final int COL_NOC = 62;
	private static final int COL_NOC_NO = 63;
	private static final int COL_NOC_DATE = 64;
	private static final int COL_LOCATION_CHANGE = 65;
	private static final int COL_MEMBERS = 66;
	private static final int COL_SIMPLE_LOWER = 67;
	private static final int COL_SIMPLE_HIGHER = 68;
	private static final int COL_UDISE_LOWER = 69;
	private static final int COL_UDISE_HIGHER = 70;
	private static final int COL_AFFILIATION = 71;
	private static final int COL_AFFILIATION_NO = 72;
	private static final int COL_AFFILIATION_DATE = 73;
	private static final int COL_SECTION1_APPROVAL = 74;
	private static final int COL_SECTION2_APPROVAL = 75;
	private static final int COL_SECTION3_APPROVAL = 76;
	private static final int COL_SECTION1_COMMENT = 77;
	private static final int COL_SECTION2_COMMENT = 78;

	@Autowired
	private UdiseNumberRepository udiseNumberRepository;

	@Autowired
	private ExcelFileUploadUtil excelFileUploadUtil;

	@Autowired
	private SchoolRepo schoolRepo;

	@Autowired
	private SchoolApplyRepo applyRepo;

	@Autowired
	private ApplicationResultRepo resultRepo;
	
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public Map<String, Object> saveUdiseFromExcel(MultipartFile file) throws IOException {
		if (file == null || file.isEmpty()) {
			throw new IllegalArgumentException("File is empty or null");
		}

		logger.info("Starting to process Excel file: {}", file.getOriginalFilename());

		// Save the uploaded file
		String filePath = excelFileUploadUtil.saveFile(file, UPLOAD_SUBDIR);

		List<UdiseNumber> savedList = new ArrayList<>();
		Map<String, Integer> udiseNumberRowMap = new HashMap<>();
		List<String> errors = new ArrayList<>();

		try (InputStream inputStream = file.getInputStream(); Workbook workbook = new XSSFWorkbook(inputStream)) {

			Sheet sheet = workbook.getSheetAt(0);
			Iterator<Row> rows = sheet.iterator();

			// Skip header row
			if (rows.hasNext()) {
				rows.next(); // Skip header
			}

			int rowNum = 1;

			while (rows.hasNext()) {
				rowNum++;
				Row currentRow = rows.next();
				if (currentRow == null)
					continue;

				try {
					String udiseNumber = getCellValue(currentRow.getCell(COL_UDISE_NUMBER));
					if (udiseNumber == null || udiseNumber.trim().isEmpty()) {
						logger.warn("Empty UDISE number in row {}, skipping", rowNum);
						errors.add("Empty UDISE number in row " + rowNum);
						continue;
					}

					udiseNumber = cleanUdiseNumber(udiseNumber);
					if (udiseNumber.isEmpty()) {
						logger.warn("No valid UDISE number in row {}, skipping", rowNum);
						errors.add("No valid UDISE number in row " + rowNum);
						continue;
					}

					if (udiseNumber.length() != 11) {
						logger.warn("UDISE number in row {} must be exactly 11 digits, got {}", rowNum,
								udiseNumber.length());
						errors.add(String.format("Invalid UDISE number in row %d: '%s' (must be exactly 11 digits)",
								rowNum, udiseNumber));
						continue;
					}

					if (udiseNumberRowMap.containsKey(udiseNumber)) {
						logger.warn("Skipping duplicate UDISE number {} in row {}", udiseNumber, rowNum);
						errors.add(String.format(
								"Duplicate UDISE number '%s' found in row %d (first occurrence in row %d)", udiseNumber,
								rowNum, udiseNumberRowMap.get(udiseNumber)));
						continue;
					}

					if (udiseNumberRepository.existsByUdiseNumber(udiseNumber)) {
						logger.warn("UDISE number '{}' in row {} already exists in database, skipping", udiseNumber,
								rowNum);
						errors.add(
								"UDISE number '" + udiseNumber + "' in row " + rowNum + " already exists in database");
						continue;
					}

					UdiseNumber udise = createUdiseFromRow(currentRow, udiseNumber, filePath);
					savedList.add(udise);
					udiseNumberRowMap.put(udiseNumber, rowNum);

				} catch (Exception e) {
					logger.error("Error processing row {}: {}", rowNum, e.getMessage(), e);
					errors.add("Error in row " + rowNum + ": " + e.getMessage());
				}
			}

			if (!savedList.isEmpty()) {
				savedList = udiseNumberRepository.saveAll(savedList);
				logger.info("Successfully saved {} UDISE records", savedList.size());
			} else {
				logger.warn("No valid UDISE records found to save");
			}

		} catch (Exception e) {
			logger.error("Error processing Excel file: {}", e.getMessage(), e);
			throw new IOException("Error processing Excel file: " + e.getMessage(), e);
		}

		Map<String, Object> response = new HashMap<>();
		response.put("records", savedList);
		response.put("recordsSaved", savedList.size());
		response.put("message", "File uploaded successfully");
		response.put("errors", errors);
		response.put("filePath", filePath);

		return response;
	}

	@Override
	public UdiseDetailsDTO getUdiseDetails(String udiseNumber) {
		ApplicationsResult appResult;
		if (udiseNumber == null || udiseNumber.trim().isEmpty()) {
			throw new IllegalArgumentException("UDISE number cannot be empty");
		}

		udiseNumber = cleanUdiseNumber(udiseNumber);
		UdiseNumber udise = udiseNumberRepository.findByUdiseNumber(udiseNumber)
				.orElseThrow(() -> new ResourceNotFoundException("UDISE number not found: "));

		School school = schoolRepo.findByUdiseNo(udiseNumber)
				.orElseThrow(() -> new RuntimeException("School not found for UDISE No"));

		List<SchoolApply> lst = applyRepo.findBySchoolId(school.getId());
		if (lst.isEmpty()) {
			throw new RuntimeException("No record found for school id " + school.getId());
		} else {
			appResult = resultRepo.findByApplicationId(lst.get(0).getId())
					.orElseThrow(() -> new RuntimeException("No entry in application result."));

		}

		UdiseDetailsDTO dto = new UdiseDetailsDTO();

		dto.setUdiseNo(udise.getUdiseNumber());
		dto.setName(udise.getName());
		dto.setDistrict(udise.getDistrict());
		dto.setTaluka(udise.getTaluka());
		dto.setVillage(udise.getVillage());
		dto.setPincode(udise.getPincode());
		dto.setTelephoneNumber(udise.getTelephonenumber());
		dto.setMobile(udise.getSchoolMobileNumber());
		dto.setEmail(udise.getSchoolemailid());
		dto.setPoliceStation(udise.getNearpolicestationname());
		dto.setSchoolType(udise.getTypeofschool());
		dto.setTransactionalAddress(udise.getAddressDeputyDirector());

		dto.setStatus(udise.getStatus());
		dto.setGranted(appResult.getGranted());
		dto.setNonGranted(appResult.getNonGranted());
		dto.setDetailsOfPhysicals(appResult.getDetailsOfPhysical());
		dto.setOtherFacilities(appResult.getOtherFacilities());
		dto.setGeneralInfo(appResult.getGeneralInfo());
		dto.setStudentCount(appResult.getStudentCount());
		

		dto.setSchoolAddress(udise.getSchool_address());
		dto.setSchoolBoard(udise.getSchoolBoard());
		dto.setMediumOfInstruction(udise.getMedium());
		dto.setSchoolArea(udise.getSchoolarea());
		dto.setSchoolEstablishmentYear(udise.getSchoolEstablishmentYear());
		dto.setDateOfFirstCommencementOfSchool(udise.getDateoffirstcommencementschool());

		dto.setSchoolTimeHalfTime(udise.getSchoolHalfdaySchedule());
		dto.setSchoolTimeFullTime(udise.getSchoolDaySchedule());
		dto.setAddressMentionedInGovernmentApprovalDocument(udise.getAddressapprovaldocuments());
		dto.setNameOfTrustSocietyManagementCommittee(udise.getNameOfSocietyManagementCommittee());		
		dto.setAddressMentionedInGovernmentApprovalDocument(udise.getAddress_mentioned_in_government_approval_document());
		dto.setSchoolAcademicSession(udise.getSchool_academic_session());
		
		dto.setSchoolTimeFullTime(udise.getSchool_time_full_time());
		dto.setSchoolTimeHalfTime(udise.getSchool_time_half_time());
		dto.setAcademicLearningTimeForEachClass(udise.getAcademic_learning_time_for_each_class());
		dto.setLunchTimeForEachClass(udise.getLunch_time_for_each_class());
		dto.setSportsAndPhysicalEducationTimeForEachClass(udise.getSports_and_physical_education_time_for_each_class());
		dto.setRegistrationNo(udise.getRegistration_no());
		
		dto.setUnderTheSocietiesRegistrationAct1860(udise.getUnder_the_societies_registration_act1860());
		dto.setUnderTheMumbaiPublicTrusteeSystemAct1950(udise.getUnder_the_mumbai_public_trustee_system_act1950());
		dto.setTillWhatPeriodTheRegistrationOfTrust(udise.getTill_what_period_the_registration_of_trust());
		dto.setIsThereEvidenceThatTheTrust(udise.getIs_there_evidence_that_the_trust());
		dto.setSchoolUserName(udise.getSchool_user_name());
		dto.setSchoolUserDegisnation(udise.getSchool_user_degisnation());
		
		dto.setSchoolUserAddress(udise.getSchool_user_address());
		dto.setSchoolUserTelephone(udise.getSchool_user_telephone());
		dto.setAccountYear(udise.getAccount_year());
		dto.setAccountIncome(udise.getAccount_income());
		dto.setAccountExpense(udise.getAccount_expense());
		dto.setAccountBalance(udise.getAccount_balance());

		dto.setForWhichYearYouWantToApplyForACertificate(udise.getFor_which_year_you_want_to_apply_foracertificate());
		dto.setYearOfFoundationzOfSchool(udise.getYear_of_foundationz_of_school());
		dto.setLowerStandard(udise.getLower_standard());
		dto.setHigherStandard(udise.getHigher_standard());
		dto.setSangsthaCompanyName(udise.getSangstha_company_name());
		dto.setSansthaCompanyHasPurposeForOnlyEducationService(udise.getSanstha_company_has_purpose_for_only_education_service());
		
		dto.setIsSchoolOpenWhereAddressMentionedInApproval(udise.getIs_school_open_where_address_mentioned_in_approval());
		dto.setIfSansthaIsHandoverToSomeone(udise.getIf_sanstha_is_handover_to_someone());
		dto.setDoYouHaveMaharastraShashanManyataNo(udise.getDo_you_have_maharastra_shashan_manyata_no());
		dto.setMaharastraShashanApprovalNumber(udise.getMaharastra_shashan_approval_number());
		dto.setMaharastraShashanApprovalDate(udise.getMaharastra_shashan_approval_date());
		dto.setDoYouHaveShikshanUpsanchalakApproval(udise.getDo_you_have_shikshan_upsanchalak_approval());
		
		dto.setShikshanUpsanchalakApprovalDate(udise.getShikshan_upsanchalak_approval_date());
		dto.setShikshanUpsanchalakApprovalNumber(udise.getShikshan_upsanchalak_approval_number());
		dto.setDoYouHavePrathamManyataCertificate(udise.getDo_you_have_pratham_manyata_certificate());
		dto.setPrathamManyataNumber(udise.getPratham_manyata_number());
		dto.setPrathamManyataDate(udise.getPratham_manyata_date());
		dto.setDoYouRunOnGovernmentNoObjectionCertificate(udise.getDo_you_run_on_government_no_objection_certificate());
		
		dto.setNoObjectionCertificateNumber(udise.getNo_objection_certificate_number());
		dto.setNoObjectionCertificateDate(udise.getNo_objection_certificate_date());
		dto.setWhetherSchoolIsMovedToAnotherLocation(udise.getWhether_school_is_moved_to_another_location());
		dto.setMembers(udise.getMembers());
		dto.setSimpleLowerStandard(udise.getSimple_lower_standard());
		dto.setSimpleHigherStandard(udise.getSimple_higher_standard());
		
		dto.setUdiseLowerStandard(udise.getUdise_lower_standard());
		dto.setUdiseHigherStandard(udise.getUdise_higher_standard());
		dto.setIsThereAnAffiliationCertificate(udise.getIs_there_an_affiliation_certificate());
		dto.setAffiliationCertificateNumber(udise.getAffiliation_certificate_number());
		dto.setAffiliationCertificateDate(udise.getAffiliation_certificate_date());
		dto.setSection1InspectionApproval(udise.getSection1inspection_approval());
		
		dto.setSection2InspectionApproval(udise.getSection2inspection_approval());
		dto.setSection3InspectionApproval(udise.getSection3inspection_approval());
		dto.setSection1InspectionComment(udise.getSection1inspection_comment());
		dto.setSection2InspectionComment(udise.getSection2inspection_comment());
		dto.setSection3InspectionComment(udise.getSection3inspection_comment());

		return dto;
	}

	@Override
	public UdiseNumber updateStatus(String udiseNumber, String status) {
		if (udiseNumber == null || udiseNumber.trim().isEmpty()) {
			throw new IllegalArgumentException("UDISE number cannot be empty");
		}
		if (!"1".equals(status) && !"0".equals(status)) {
			throw new IllegalArgumentException("Status must be either '0' or '1'");
		}

		udiseNumber = cleanUdiseNumber(udiseNumber);

		UdiseNumber udise = udiseNumberRepository.findByUdiseNumber(udiseNumber)
				.orElseThrow(() -> new ResourceNotFoundException("UDISE number not found: "));

		String oldStatus = udise.getStatus();
		udise.setStatus(status);

		UdiseNumber updated = udiseNumberRepository.save(udise);
		logger.info("UDISE number {} status changed from {} to {}", udiseNumber, oldStatus, status);

		return updated;
	}

	private UdiseNumber createUdiseFromRow(Row row, String udiseNumber, String filePath) {
		UdiseNumber udise = new UdiseNumber();
		// Basic Information
		udise.setUdiseNumber(udiseNumber);
		udise.setName(getCellValue(row.getCell(COL_SCHOOL_NAME)));
		udise.setAddressDeputyDirector(getCellValue(row.getCell(COL_ADDRESS_DD)));
		udise.setDistrict(getCellValue(row.getCell(COL_DISTRICT)));
		udise.setTaluka(getCellValue(row.getCell(COL_TALUKA)));
		udise.setVillage(getCellValue(row.getCell(COL_VILLAGE)));
		udise.setPincode(getCellValue(row.getCell(COL_PINCODE)));
		udise.setTelephonenumber(getCellValue(row.getCell(COL_TELEPHONE)));
		udise.setSchoolMobileNumber(getCellValue(row.getCell(COL_MOBILE)));
		udise.setSchoolemailid(getCellValue(row.getCell(COL_EMAIL)));
		udise.setTypeofschool(getCellValue(row.getCell(COL_SCHOOL_TYPE)));
		udise.setAddressapprovaldocuments(getCellValue(row.getCell(COL_APPROVAL_DOCS)));
		udise.setSchoolEstablishmentYear(getCellValue(row.getCell(COL_ESTABLISHMENT_YEAR)));
		udise.setDateoffirstcommencementschool(getCellValue(row.getCell(COL_FIRST_COMMENCEMENT)));
		udise.setSchoolarea(getCellValue(row.getCell(COL_SCHOOL_AREA)));
		udise.setMedium(getCellValue(row.getCell(COL_MEDIUM)));
		udise.setSchoolBoard(getCellValue(row.getCell(COL_SCHOOL_BOARD)));
		udise.setSchoolHalfdaySchedule(getCellValue(row.getCell(COL_HALF_DAY_SCHEDULE)));
		udise.setSchoolDaySchedule(getCellValue(row.getCell(COL_DAY_SCHEDULE)));
		udise.setMiddaymealschedule(getCellValue(row.getCell(COL_MIDDAY_MEAL)));
		udise.setNameOfSocietyManagementCommittee(getCellValue(row.getCell(COL_SOCIETY_COMMITTEE)));
		udise.setClasspresentinudise(getCellValue(row.getCell(COL_CLASS_PRESENT)));
		udise.setSelfapprovalcertificate(getCellValue(row.getCell(COL_SELF_APPROVAL)));
		udise.setNearpolicestationname(getCellValue(row.getCell(COL_NEAR_POLICE_STATION)));

		// New Fields
		udise.setSchool_address(getCellValue(row.getCell(COL_SCHOOL_ADDRESS)));
		udise.setAddress_mentioned_in_government_approval_document(getCellValue(row.getCell(COL_ADDRESS_IN_APPROVAL)));
		udise.setSchool_academic_session(getCellValue(row.getCell(COL_ACADEMIC_SESSION)));
		udise.setSchool_time_full_time(getCellValue(row.getCell(COL_FULL_TIME)));
		udise.setSchool_time_half_time(getCellValue(row.getCell(COL_HALF_TIME)));
		udise.setAcademic_learning_time_for_each_class(getCellValue(row.getCell(COL_LEARNING_TIME)));
		udise.setLunch_time_for_each_class(getCellValue(row.getCell(COL_LUNCH_TIME)));
		udise.setSports_and_physical_education_time_for_each_class(getCellValue(row.getCell(COL_SPORTS_TIME)));
		udise.setRegistration_no(getCellValue(row.getCell(COL_REGISTRATION_NO)));
		udise.setUnder_the_societies_registration_act1860(getCellValue(row.getCell(COL_SOCIETIES_ACT)));
		udise.setUnder_the_mumbai_public_trustee_system_act1950(getCellValue(row.getCell(COL_MUMBAI_TRUST_ACT)));
		udise.setTill_what_period_the_registration_of_trust(getCellValue(row.getCell(COL_TRUST_PERIOD)));
		udise.setIs_there_an_affiliation_certificate(getCellValue(row.getCell(COL_TRUST_EVIDENCE)));
		udise.setSchool_user_name(getCellValue(row.getCell(COL_USER_NAME)));
		udise.setSchool_user_degisnation(getCellValue(row.getCell(COL_USER_DESIGNATION)));
		udise.setSchool_user_address(getCellValue(row.getCell(COL_USER_ADDRESS)));
		udise.setSchool_user_telephone(getCellValue(row.getCell(COL_USER_TELEPHONE)));
		udise.setAccount_year(getCellValue(row.getCell(COL_ACCOUNT_YEAR)));
		udise.setAccount_income(getCellValue(row.getCell(COL_ACCOUNT_INCOME)));
		udise.setAccount_expense(getCellValue(row.getCell(COL_ACCOUNT_EXPENSE)));
		udise.setAccount_balance(getCellValue(row.getCell(COL_ACCOUNT_BALANCE)));
		udise.setFor_which_year_you_want_to_apply_foracertificate(getCellValue(row.getCell(COL_APPLY_YEAR)));
		udise.setYear_of_foundationz_of_school(getCellValue(row.getCell(COL_FOUNDATION_YEAR)));
		udise.setLower_standard(getCellValue(row.getCell(COL_LOWER_STD)));
		udise.setHigher_standard(getCellValue(row.getCell(COL_HIGHER_STD)));
		udise.setSangstha_company_name(getCellValue(row.getCell(COL_SANGSTHA_NAME)));
		udise.setIf_sanstha_is_handover_to_someone(getCellValue(row.getCell(COL_EDUCATION_PURPOSE)));
		udise.setIs_school_open_where_address_mentioned_in_approval(getCellValue(row.getCell(COL_OPEN_AT_ADDRESS)));
		udise.setSanstha_company_has_purpose_for_only_education_service(getCellValue(row.getCell(COL_HANDOVER_STATUS)));
		udise.setDo_you_have_maharastra_shashan_manyata_no(getCellValue(row.getCell(COL_MH_SHASHAN)));
		udise.setMaharastra_shashan_approval_number(getCellValue(row.getCell(COL_SHASHAN_NO)));
		udise.setMaharastra_shashan_approval_date(getCellValue(row.getCell(COL_SHASHAN_DATE)));
		udise.setDo_you_have_maharastra_shashan_manyata_no(getCellValue(row.getCell(COL_SHIKSHAN_UP)));
		udise.setShikshan_upsanchalak_approval_date(getCellValue(row.getCell(COL_UP_DATE)));
		udise.setShikshan_upsanchalak_approval_number(getCellValue(row.getCell(COL_UP_NUMBER)));
		udise.setDo_you_have_pratham_manyata_certificate(getCellValue(row.getCell(COL_PRATHAM_MANYATA)));
		udise.setPratham_manyata_number(getCellValue(row.getCell(COL_PRATHAM_NO)));
		udise.setPratham_manyata_date(getCellValue(row.getCell(COL_PRATHAM_DATE)));
		udise.setDo_you_run_on_government_no_objection_certificate(getCellValue(row.getCell(COL_NOC)));
		udise.setNo_objection_certificate_number(getCellValue(row.getCell(COL_NOC_NO)));
		udise.setNo_objection_certificate_date(getCellValue(row.getCell(COL_NOC_DATE)));
		udise.setWhether_school_is_moved_to_another_location(getCellValue(row.getCell(COL_LOCATION_CHANGE)));
		udise.setMembers(getCellValue(row.getCell(COL_MEMBERS)));
		udise.setSimple_lower_standard(getCellValue(row.getCell(COL_SIMPLE_LOWER)));
		udise.setSimple_higher_standard(getCellValue(row.getCell(COL_SIMPLE_HIGHER)));
		udise.setUdise_lower_standard(getCellValue(row.getCell(COL_UDISE_LOWER)));
		udise.setUdise_higher_standard(getCellValue(row.getCell(COL_UDISE_HIGHER)));
		udise.setIs_there_an_affiliation_certificate(getCellValue(row.getCell(COL_AFFILIATION)));
		udise.setAffiliation_certificate_number(getCellValue(row.getCell(COL_AFFILIATION_NO)));
		udise.setAffiliation_certificate_date(getCellValue(row.getCell(COL_AFFILIATION_DATE)));
		udise.setSection1inspection_approval(getCellValue(row.getCell(COL_SECTION1_APPROVAL)));
		udise.setSection2inspection_approval(getCellValue(row.getCell(COL_SECTION2_APPROVAL)));
		udise.setSection3inspection_approval(getCellValue(row.getCell(COL_SECTION3_APPROVAL)));
		udise.setSection1inspection_comment(getCellValue(row.getCell(COL_SECTION1_COMMENT)));
		udise.setSection2inspection_comment(getCellValue(row.getCell(COL_SECTION2_COMMENT)));

		// Default values
		udise.setStatus("0");
		udise.setUploaded_file_path(filePath);

		return udise;
	}

	private String cleanUdiseNumber(String udiseNumber) {
		if (udiseNumber == null) {
			return "";
		}
		// Remove all non-digit characters
		return udiseNumber.replaceAll("\\D+", "");
	}

	private String getCellValue(Cell cell) {
		if (cell == null) {
			return null;
		}

		switch (cell.getCellType()) {
		case STRING:
			return cell.getStringCellValue().trim();
		case NUMERIC:
			if (DateUtil.isCellDateFormatted(cell)) {
				return cell.getDateCellValue().toString();
			}
			// Handle numeric cells to prevent scientific notation
			DataFormatter formatter = new DataFormatter();
			return formatter.formatCellValue(cell).trim();
		case BOOLEAN:
			return String.valueOf(cell.getBooleanCellValue());
		case FORMULA:
			switch (cell.getCachedFormulaResultType()) {
			case NUMERIC:
				DataFormatter df = new DataFormatter();
				return df.formatCellValue(cell).trim();
			case STRING:
				return cell.getStringCellValue().trim();
			default:
				return cell.toString().trim();
			}
		default:
			return cell.toString().trim();
		}
	}

	@Override
	public List<UdiseNumberDTO> getUdiseByStatus(String status) {
		return udiseNumberRepository.findByStatus(status).stream()
				.map(udise -> modelMapper.map(udise, UdiseNumberDTO.class)).collect(Collectors.toList());
	}

	@Override
	public List<UdiseNumberDTO> getAllUdiseNumbers() {
		return udiseNumberRepository.findByStatus("0").stream().map(udise -> modelMapper.map(udise, UdiseNumberDTO.class))
				.collect(Collectors.toList());
	}
}