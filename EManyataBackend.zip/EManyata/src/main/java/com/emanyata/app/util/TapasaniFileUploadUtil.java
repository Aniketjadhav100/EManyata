package com.emanyata.app.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class TapasaniFileUploadUtil {
    private static final Logger logger = LoggerFactory.getLogger(TapasaniFileUploadUtil.class);
    
    @Value("${file.upload-dir}")
    private String uploadDir;
    
    @PostConstruct
    public void init() {
        try {
            // Create the base tapasani upload directory
            Path uploadPath = Paths.get(uploadDir, "tapasani", "profile-photos");
            Files.createDirectories(uploadPath);
            logger.info("Upload directories created: {}", uploadPath);
        } catch (IOException e) {
            logger.error("Error creating upload directories: {}", e.getMessage(), e);
            throw new RuntimeException("Could not initialize storage", e);
        }
    }

    /**
     * Saves an uploaded file to the server
     * @param file The file to save
     * @param subDirectory Optional subdirectory under the main upload directory
     * @return The relative path to the saved file
     * @throws IOException If file operations fail
     */
    public String saveFile(MultipartFile file, String subDirectory) throws IOException {
        // Validate input
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("File cannot be null or empty");
        }

        // Create upload directory with subdirectory if specified
        Path uploadPath = Paths.get(uploadDir, "tapasani");
        if (subDirectory != null && !subDirectory.trim().isEmpty()) {
            uploadPath = uploadPath.resolve(subDirectory.trim());
        }
        Files.createDirectories(uploadPath);

        // Get and validate the original filename
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null || originalFilename.trim().isEmpty()) {
            throw new IllegalArgumentException("File must have a name");
        }

        // Clean the filename
        String cleanFilename = sanitizeFilename(originalFilename);
        
        // Generate a unique identifier for the filename
        String uniqueId = UUID.randomUUID().toString();
        
        // Create a unique filename with the original name
        String uniqueFilename = uniqueId + "_" + cleanFilename;
        
        // Save the file
        Path filePath = uploadPath.resolve(uniqueFilename);
        Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

        // Create and return the relative path
        String relativePath = Paths.get("tapasani", 
                subDirectory != null ? subDirectory : "", 
                uniqueFilename)
            .toString().replace("\\", "/");
        
        logger.info("File saved to: {}", filePath);
        logger.debug("Returning relative path: {}", relativePath);
        
        return relativePath;
    }

    /**
     * Overloaded method for saving files without subdirectory
     */
    public String saveFile(MultipartFile file) throws IOException {
        return saveFile(file, "profile-photos");
    }

    /**
     * Sanitizes a filename by removing or replacing invalid characters
     */
    private String sanitizeFilename(String filename) {
        if (filename == null) {
            return "file";
        }
        // Replace invalid characters with underscore
        return filename
            .replaceAll("[^a-zA-Z0-9._-]", "_")
            .replaceAll("_+", "_")
            .replaceAll("^_|_$", "");
    }

    /**
     * Deletes a file from the server
     * @param filePath The relative path of the file to delete
     */
    public void deleteFile(String filePath) {
        if (filePath == null || filePath.trim().isEmpty()) {
            return;
        }
        
        try {
            // The filePath is relative to the upload directory
            Path fullPath = Paths.get(uploadDir, filePath);
            
            // First try to delete the exact file
            if (Files.exists(fullPath) && !Files.isDirectory(fullPath)) {
                Files.deleteIfExists(fullPath);
                logger.info("Deleted file: {}", fullPath);
                return;
            }
            
            // If exact path doesn't exist, try to find by filename
            Path directory = fullPath.getParent();
            String filename = fullPath.getFileName() != null ? 
                fullPath.getFileName().toString() : "";
            
            if (directory != null && Files.isDirectory(directory)) {
                // Try to find file by exact name first
                Path exactMatch = directory.resolve(filename);
                if (Files.exists(exactMatch)) {
                    Files.deleteIfExists(exactMatch);
                    logger.info("Deleted exact match: {}", exactMatch);
                    return;
                }
                
                // If no exact match, try to find by pattern
                try (var files = Files.list(directory)) {
                    files.filter(path -> {
                            String currentFilename = path.getFileName().toString();
                            // Match files that end with the original filename
                            return currentFilename.endsWith(filename) || 
                                   currentFilename.contains("_" + filename);
                        })
                        .findFirst()
                        .ifPresent(path -> {
                            try {
                                Files.deleteIfExists(path);
                                logger.info("Deleted file by pattern: {}", path);
                            } catch (IOException e) {
                                logger.error("Error deleting file by pattern: {}", e.getMessage(), e);
                            }
                        });
                }
            }
        } catch (IOException e) {
            logger.error("Error deleting file '{}': {}", filePath, e.getMessage(), e);
        }
    }

    /**
     * Gets the absolute path for a given relative path
     */
    public Path getAbsolutePath(String relativePath) {
        if (relativePath == null || relativePath.trim().isEmpty()) {
            throw new IllegalArgumentException("Path cannot be null or empty");
        }
        return Paths.get(uploadDir, relativePath);
    }

    /**
     * Checks if a file exists
     */
    public boolean fileExists(String relativePath) {
        if (relativePath == null || relativePath.trim().isEmpty()) {
            return false;
        }
        Path fullPath = Paths.get(uploadDir, relativePath);
        return Files.exists(fullPath) && !Files.isDirectory(fullPath);
    }
}