package com.emanyata.app.dto;

import java.time.LocalDateTime;

import com.emanyata.app.entity.primary.School;

public class NonGrantedSchoolInfoDTO {

    private Long schoolId;
    private String governmentDecisionOfApprovall;
    private String approvalOrderOfDeputyDirectorOfEducation;
    private String firstApprovalOrder;
    private String organizationsRequisitionApplicationInSample1;
    private String jointAccountRetentionReceiptOfInstitution;
    private String organizationCompanyRegistrationCertificate;
    private String govtMinorityCertificate;
    private String purchaseDeedLeaseAgreementAward;
    private String auditReport;
    private String copyOfEptaApprovalMinutes;
    private String freeStructureAccordingToPrevious;
    private String transportCommitteeOnlineCopy;
    private String womenGrievanceRedressalCommittee;
    private String affidavitOnStampOfRs100;
    private String schoolPrincipalSignStamp;
    private String namuna1HandWrittenForm;
    private String schoolLocationChangedBit;
    private String schoolLocationChanged;
    private String commonOrder2013To2016Bit;
    private String commonOrder2016To2019Bit;
    private String commonOrder2019To2022Bit;
    private String commonOrder2022To2025Bit;
    private String commonOrder2013To2016;
    private String commonOrder2016To2019;
    private String commonOrder2019To2022;
    private String commonOrder2022To2025;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Long applicationId;
    private Byte status;
    
    private Byte generalInfo;
    private Byte detailsOfPhysicals;
    private Byte otherFacility;
    private Byte studentCount;
    private Byte granted;
    private Byte nonGranted;
    
    
    
	public String getCommonOrder2022To2025Bit() {
		return commonOrder2022To2025Bit;
	}
	public void setCommonOrder2022To2025Bit(String commonOrder2022To2025Bit) {
		this.commonOrder2022To2025Bit = commonOrder2022To2025Bit;
	}
	public String getCommonOrder2022To2025() {
		return commonOrder2022To2025;
	}
	public void setCommonOrder2022To2025(String commonOrder2022To2025) {
		this.commonOrder2022To2025 = commonOrder2022To2025;
	}
	public Byte getGeneralInfo() {
		return generalInfo;
	}
	public void setGeneralInfo(Byte generalInfo) {
		this.generalInfo = generalInfo;
	}
	public Byte getDetailsOfPhysicals() {
		return detailsOfPhysicals;
	}
	public void setDetailsOfPhysicals(Byte detailsOfPhysicals) {
		this.detailsOfPhysicals = detailsOfPhysicals;
	}
	public Byte getOtherFacility() {
		return otherFacility;
	}
	public void setOtherFacility(Byte otherFacility) {
		this.otherFacility = otherFacility;
	}
	public Byte getStudentCount() {
		return studentCount;
	}
	public void setStudentCount(Byte studentCount) {
		this.studentCount = studentCount;
	}

	public Byte getGranted() {
		return granted;
	}
	public void setGranted(Byte granted) {
		this.granted = granted;
	}
	public Byte getNonGranted() {
		return nonGranted;
	}
	public void setNonGranted(Byte nonGranted) {
		this.nonGranted = nonGranted;
	}
	public Byte getStatus() {
		return status;
	}
	public void setStatus(Byte status) {
		this.status = status;
	}
	public Long getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(Long schoolId) {
		this.schoolId = schoolId;
	}
	public String getGovernmentDecisionOfApprovall() {
		return governmentDecisionOfApprovall;
	}
	public void setGovernmentDecisionOfApprovall(String governmentDecisionOfApprovall) {
		this.governmentDecisionOfApprovall = governmentDecisionOfApprovall;
	}
	public String getApprovalOrderOfDeputyDirectorOfEducation() {
		return approvalOrderOfDeputyDirectorOfEducation;
	}
	public void setApprovalOrderOfDeputyDirectorOfEducation(String approvalOrderOfDeputyDirectorOfEducation) {
		this.approvalOrderOfDeputyDirectorOfEducation = approvalOrderOfDeputyDirectorOfEducation;
	}
	public String getFirstApprovalOrder() {
		return firstApprovalOrder;
	}
	public void setFirstApprovalOrder(String firstApprovalOrder) {
		this.firstApprovalOrder = firstApprovalOrder;
	}
	public String getOrganizationsRequisitionApplicationInSample1() {
		return organizationsRequisitionApplicationInSample1;
	}
	public void setOrganizationsRequisitionApplicationInSample1(String organizationsRequisitionApplicationInSample1) {
		this.organizationsRequisitionApplicationInSample1 = organizationsRequisitionApplicationInSample1;
	}
	public String getJointAccountRetentionReceiptOfInstitution() {
		return jointAccountRetentionReceiptOfInstitution;
	}
	public void setJointAccountRetentionReceiptOfInstitution(String jointAccountRetentionReceiptOfInstitution) {
		this.jointAccountRetentionReceiptOfInstitution = jointAccountRetentionReceiptOfInstitution;
	}
	public String getOrganizationCompanyRegistrationCertificate() {
		return organizationCompanyRegistrationCertificate;
	}
	public void setOrganizationCompanyRegistrationCertificate(String organizationCompanyRegistrationCertificate) {
		this.organizationCompanyRegistrationCertificate = organizationCompanyRegistrationCertificate;
	}
	public String getGovtMinorityCertificate() {
		return govtMinorityCertificate;
	}
	public void setGovtMinorityCertificate(String govtMinorityCertificate) {
		this.govtMinorityCertificate = govtMinorityCertificate;
	}
	public String getPurchaseDeedLeaseAgreementAward() {
		return purchaseDeedLeaseAgreementAward;
	}
	public void setPurchaseDeedLeaseAgreementAward(String purchaseDeedLeaseAgreementAward) {
		this.purchaseDeedLeaseAgreementAward = purchaseDeedLeaseAgreementAward;
	}
	public String getAuditReport() {
		return auditReport;
	}
	public void setAuditReport(String auditReport) {
		this.auditReport = auditReport;
	}
	public String getCopyOfEptaApprovalMinutes() {
		return copyOfEptaApprovalMinutes;
	}
	public void setCopyOfEptaApprovalMinutes(String copyOfEptaApprovalMinutes) {
		this.copyOfEptaApprovalMinutes = copyOfEptaApprovalMinutes;
	}
	public String getFreeStructureAccordingToPrevious() {
		return freeStructureAccordingToPrevious;
	}
	public void setFreeStructureAccordingToPrevious(String freeStructureAccordingToPrevious) {
		this.freeStructureAccordingToPrevious = freeStructureAccordingToPrevious;
	}
	public String getTransportCommitteeOnlineCopy() {
		return transportCommitteeOnlineCopy;
	}
	public void setTransportCommitteeOnlineCopy(String transportCommitteeOnlineCopy) {
		this.transportCommitteeOnlineCopy = transportCommitteeOnlineCopy;
	}
	public String getWomenGrievanceRedressalCommittee() {
		return womenGrievanceRedressalCommittee;
	}
	public void setWomenGrievanceRedressalCommittee(String womenGrievanceRedressalCommittee) {
		this.womenGrievanceRedressalCommittee = womenGrievanceRedressalCommittee;
	}
	public String getAffidavitOnStampOfRs100() {
		return affidavitOnStampOfRs100;
	}
	public void setAffidavitOnStampOfRs100(String affidavitOnStampOfRs100) {
		this.affidavitOnStampOfRs100 = affidavitOnStampOfRs100;
	}
	public String getSchoolPrincipalSignStamp() {
		return schoolPrincipalSignStamp;
	}
	public void setSchoolPrincipalSignStamp(String schoolPrincipalSignStamp) {
		this.schoolPrincipalSignStamp = schoolPrincipalSignStamp;
	}
	public String getNamuna1HandWrittenForm() {
		return namuna1HandWrittenForm;
	}
	public void setNamuna1HandWrittenForm(String namuna1HandWrittenForm) {
		this.namuna1HandWrittenForm = namuna1HandWrittenForm;
	}
	public String getSchoolLocationChangedBit() {
		return schoolLocationChangedBit;
	}
	public void setSchoolLocationChangedBit(String schoolLocationChangedBit) {
		this.schoolLocationChangedBit = schoolLocationChangedBit;
	}
	public String getSchoolLocationChanged() {
		return schoolLocationChanged;
	}
	public void setSchoolLocationChanged(String schoolLocationChanged) {
		this.schoolLocationChanged = schoolLocationChanged;
	}
	public String getCommonOrder2013To2016Bit() {
		return commonOrder2013To2016Bit;
	}
	public void setCommonOrder2013To2016Bit(String commonOrder2013To2016Bit) {
		this.commonOrder2013To2016Bit = commonOrder2013To2016Bit;
	}
	public String getCommonOrder2016To2019Bit() {
		return commonOrder2016To2019Bit;
	}
	public void setCommonOrder2016To2019Bit(String commonOrder2016To2019Bit) {
		this.commonOrder2016To2019Bit = commonOrder2016To2019Bit;
	}
	public String getCommonOrder2019To2022Bit() {
		return commonOrder2019To2022Bit;
	}
	public void setCommonOrder2019To2022Bit(String commonOrder2019To2022Bit) {
		this.commonOrder2019To2022Bit = commonOrder2019To2022Bit;
	}
	public String getCommonOrder2013To2016() {
		return commonOrder2013To2016;
	}
	public void setCommonOrder2013To2016(String commonOrder2013To2016) {
		this.commonOrder2013To2016 = commonOrder2013To2016;
	}
	public String getCommonOrder2016To2019() {
		return commonOrder2016To2019;
	}
	public void setCommonOrder2016To2019(String commonOrder2016To2019) {
		this.commonOrder2016To2019 = commonOrder2016To2019;
	}
	public String getCommonOrder2019To2022() {
		return commonOrder2019To2022;
	}
	public void setCommonOrder2019To2022(String commonOrder2019To2022) {
		this.commonOrder2019To2022 = commonOrder2019To2022;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
}
