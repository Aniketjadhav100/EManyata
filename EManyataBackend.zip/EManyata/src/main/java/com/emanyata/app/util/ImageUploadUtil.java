package com.emanyata.app.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.*;

@Component
public class ImageUploadUtil {

    private static final Logger logger = LoggerFactory.getLogger(ImageUploadUtil.class);

    @Value("${file.upload-dir}")
    private String uploadDir;

    private Path imageFolderPath;

    @PostConstruct
    public void init() {
        try {
            imageFolderPath = Paths.get(uploadDir, "images");
            Files.createDirectories(imageFolderPath);
            logger.info("Image folder ready at: {}", imageFolderPath.toAbsolutePath());
        } catch (IOException e) {
            logger.error("Failed to create image folder: {}", e.getMessage());
        }
    }

    public String saveImage(MultipartFile file) throws IOException {
        if (file == null || file.isEmpty()) {
            throw new IOException("File is empty");
        }

        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null) {
            throw new IOException("File name is null");
        }

        String sanitizedFilename = originalFilename.replaceAll("[^a-zA-Z0-9\\.\\-_]", "_");

        Path targetPath = imageFolderPath.resolve(sanitizedFilename);
        Files.copy(file.getInputStream(), targetPath, StandardCopyOption.REPLACE_EXISTING);

        // Return relative path for DB
        return "uploads/images/" + sanitizedFilename;
    }

    public boolean deleteImage(String relativePath) {
        try {
            if (relativePath == null || relativePath.isEmpty()) {
                return false;
            }
            Path path = Paths.get(relativePath).normalize();
            return Files.deleteIfExists(path);
        } catch (IOException e) {
            logger.error("Error deleting image: {}", e.getMessage());
            return false;
        }
    }
}
