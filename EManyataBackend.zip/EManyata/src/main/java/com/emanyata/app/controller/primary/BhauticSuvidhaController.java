package com.emanyata.app.controller.primary;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.emanyata.app.dto.BhauticSuvidhaDTO;
import com.emanyata.app.service.primary.BhautikSuvidhaService;

import java.util.*;

@RestController
@RequestMapping("/api/bhautic-suvidha")
public class BhauticSuvidhaController {

    @Autowired
    private BhautikSuvidhaService bhautikSuvidhaService;

    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> create(@RequestBody BhauticSuvidhaDTO dto) {
        Map<String, Object> response = new HashMap<>();
        try {
            BhauticSuvidhaDTO saved = bhautikSuvidhaService.save(dto);
            response.put("status", "success");
            response.put("message", "Record created successfully.");
            response.put("data", saved);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", "Failed to create record: " + e.getMessage());
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);  // Changed here
        }
    }

    @PostMapping("/getBySchoolId/{id}")
    public ResponseEntity<Map<String, Object>> getBySchoolId(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        try {
            BhauticSuvidhaDTO saved = bhautikSuvidhaService.getBySchoolID(id);
            response.put("status", "success");
            response.put("message", "Record fetched successfully by School Id " + id);
            response.put("data", saved);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            response.put("status", "error");
            response.put("message", "No record found for School Id " + id);
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", "Error fetching record: " + e.getMessage());
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);  // Changed here
        }
    }
}
