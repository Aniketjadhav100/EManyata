package com.emanyata.app.dto;


import java.time.LocalDateTime;

public class OldSchoolDTO {
    private Long id;
    private String schoolName;
    private String udiseNo;
    private String transactionalAddress;
    private String district;
    private Long userId;
    private Long talukaId;
    private Long villageId;
    private String pincode;
    private String telephoneNumber;
    private String schoolMobile;
    private String policeStation;
    private String schoolType;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Constructors
    public OldSchoolDTO() {
    }

    public OldSchoolDTO(Long id, String schoolName, String udiseNo, String transactionalAddress, 
                       String district, Long userId, Long talukaId, Long villageId, 
                       String pincode, String telephoneNumber, String schoolMobile, 
                       String policeStation, String schoolType, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.id = id;
        this.schoolName = schoolName;
        this.udiseNo = udiseNo;
        this.transactionalAddress = transactionalAddress;
        this.district = district;
        this.userId = userId;
        this.talukaId = talukaId;
        this.villageId = villageId;
        this.pincode = pincode;
        this.telephoneNumber = telephoneNumber;
        this.schoolMobile = schoolMobile;
        this.policeStation = policeStation;
        this.schoolType = schoolType;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getUdiseNo() {
        return udiseNo;
    }

    public void setUdiseNo(String udiseNo) {
        this.udiseNo = udiseNo;
    }

    public String getTransactionalAddress() {
        return transactionalAddress;
    }

    public void setTransactionalAddress(String transactionalAddress) {
        this.transactionalAddress = transactionalAddress;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getTalukaId() {
        return talukaId;
    }

    public void setTalukaId(Long talukaId) {
        this.talukaId = talukaId;
    }

    public Long getVillageId() {
        return villageId;
    }

    public void setVillageId(Long villageId) {
        this.villageId = villageId;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getSchoolMobile() {
        return schoolMobile;
    }

    public void setSchoolMobile(String schoolMobile) {
        this.schoolMobile = schoolMobile;
    }

    public String getPoliceStation() {
        return policeStation;
    }

    public void setPoliceStation(String policeStation) {
        this.policeStation = policeStation;
    }

    public String getSchoolType() {
        return schoolType;
    }

    public void setSchoolType(String schoolType) {
        this.schoolType = schoolType;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}