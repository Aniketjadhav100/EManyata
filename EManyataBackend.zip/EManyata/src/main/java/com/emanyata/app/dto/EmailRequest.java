package com.emanyata.app.dto;

public class EmailRequest {
	
	

	
	    private String email;

	    // getters & setters
	    public String getEmail() { return email; }
	    public void setEmail(String email) { this.email = email; }
	}


