package com.emanyata.app.repo.primary;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.primary.TrackingLog;

public interface TrackingLogRepo extends JpaRepository<TrackingLog,Long> {
		Optional<TrackingLog> findBySchoolId(Long id);
}
