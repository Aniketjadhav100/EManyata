package com.emanyata.app.serviceImpl.primary;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emanyata.app.dto.StudentCountDTO;
import com.emanyata.app.entity.primary.ApplicationsResult;
import com.emanyata.app.entity.primary.School;
import com.emanyata.app.entity.primary.SchoolApply;
import com.emanyata.app.entity.primary.StudentCount;
import com.emanyata.app.repo.primary.ApplicationResultRepo;
import com.emanyata.app.repo.primary.SchoolApplyRepo;
import com.emanyata.app.repo.primary.SchoolRepo;
import com.emanyata.app.repo.primary.StudentCountRepository;
import com.emanyata.app.service.primary.StudentCountService;
import com.emanyata.app.util.ApplicationFormStepsUtil;

@Service
public class StudentCountServiceImpl implements StudentCountService {

	@Autowired
	private StudentCountRepository studentCountRepo;

	@Autowired
	private SchoolRepo schoolRepo;

	@Autowired
	private SchoolApplyRepo applyRepo;

	@Autowired
	private ApplicationResultRepo applicationResultRepo;

	@Autowired
	private ApplicationFormStepsUtil stepsUtil;

	@Override
	public StudentCountDTO getStudentCountBySchoolId(Long schoolId) {
		StudentCount studentCount = studentCountRepo.findBySchoolId(schoolId)
				.orElseThrow(() -> new RuntimeException("StudentCount not found for school ID: " + schoolId));

		Long applicationId = studentCount.getApplicationId();

		ApplicationsResult applicationResult = applicationResultRepo.findByApplicationId(applicationId).orElseThrow(
				() -> new RuntimeException("Application result not found for application ID: " + applicationId));

		StudentCountDTO dto = new StudentCountDTO();

		// Manual mapping from entity to DTO
		dto.setId(studentCount.getId());
		dto.setSchoolId(studentCount.getSchool().getId());
		dto.setTotalBoys(studentCount.getTotalBoys());
		dto.setTotalGirls(studentCount.getTotalGirls());
		dto.setTotal(studentCount.getTotal());
		dto.setLower(studentCount.getLower());
		dto.setHigher(studentCount.getHigher());
		dto.setCreatedAt(studentCount.getCreatedAt());
		dto.setUpdatedAt(studentCount.getUpdatedAt());
		dto.setApplicationId(studentCount.getApplicationId());
		dto.setInspectionAppoval(studentCount.getInspectionAppoval());
		dto.setInspectionComment(studentCount.getInspectionComment());

		// 🔥 Enrich with ApplicationsResult data
		dto.setGeneralInfo(applicationResult.getGeneralInfo());
		dto.setDetailsOfPhysicals(applicationResult.getDetailsOfPhysical());
		dto.setGrantedSchool(applicationResult.getGranted());
		dto.setStudentCount(applicationResult.getStudentCount());
		dto.setNonGrantedSchool(applicationResult.getNonGranted());
		dto.setOtherFacility(applicationResult.getOtherFacilities());

		return dto;
	}

	private StudentCountDTO toDTO(StudentCount entity) {
		StudentCountDTO dto = new StudentCountDTO();
		dto.setId(entity.getId());
		dto.setSchoolId(entity.getSchool().getId());
		dto.setTotalBoys(entity.getTotalBoys());
		dto.setTotalGirls(entity.getTotalGirls());
		dto.setTotal(entity.getTotal());
		dto.setLower(entity.getLower());
		dto.setHigher(entity.getHigher());
		dto.setCreatedAt(entity.getCreatedAt());
		dto.setUpdatedAt(entity.getUpdatedAt());
		dto.setApplicationId(entity.getApplicationId());
		dto.setInspectionAppoval(entity.getInspectionAppoval());
		dto.setInspectionComment(entity.getInspectionComment());
		return dto;
	}

	@Override
	public StudentCountDTO createStudentCount(StudentCountDTO dto) {

		if (dto.getApplicationId() != null && dto.getSchoolId() != null) {

			Optional<StudentCount> studentCountOpt = studentCountRepo.findBySchoolId(dto.getSchoolId());
			Optional<SchoolApply> opt = applyRepo.findById(dto.getApplicationId());

			if (opt.isPresent()) {
				if (studentCountOpt.isPresent()) {

					if (studentCountOpt.get().getApplicationId().equals(dto.getApplicationId())) {
						StudentCount existing = studentCountOpt.get();

						if (dto.getTotalBoys() != null)
							existing.setTotalBoys(dto.getTotalBoys());
						if (dto.getTotalGirls() != null)
							existing.setTotalGirls(dto.getTotalGirls());
						if (dto.getTotal() != null)
							existing.setTotal(dto.getTotal());
						if (dto.getLower() != null)
							existing.setLower(dto.getLower());
						if (dto.getHigher() != null)
							existing.setHigher(dto.getHigher());
						if (dto.getInspectionAppoval() != null)
							existing.setInspectionAppoval(dto.getInspectionAppoval());
						if (dto.getInspectionComment() != null)
							existing.setInspectionComment(dto.getInspectionComment());

						existing.setUpdatedAt(LocalDateTime.now());
						StudentCount std = studentCountRepo.save(existing);
						StudentCountDTO dto2 = toDTO(std);
						ApplicationsResult rs = applicationResultRepo.findByApplicationId(dto2.getApplicationId())
								.orElseThrow(() -> new RuntimeException("No ecords found in appliation result"));
						dto2.setGeneralInfo(rs.getGeneralInfo());
						dto2.setStudentCount(rs.getStudentCount());
						dto2.setDetailsOfPhysicals(rs.getDetailsOfPhysical());
						dto2.setOtherFacility(rs.getOtherFacilities());
						dto2.setGrantedSchool(rs.getGranted());
						dto2.setNonGrantedSchool(rs.getNonGranted());
						return dto2;
					} else {
						throw new RuntimeException("Application Id mistmatched..");
					}
				} else {
					School school = schoolRepo.findById(dto.getSchoolId())
							.orElseThrow(() -> new RuntimeException("School not found with ID: " + dto.getSchoolId()));

					StudentCount newStudentCount = new StudentCount();
					newStudentCount.setSchool(school);
					newStudentCount.setApplicationId(dto.getApplicationId());
					newStudentCount.setTotalBoys(dto.getTotalBoys());
					newStudentCount.setTotalGirls(dto.getTotalGirls());
					newStudentCount.setTotal(dto.getTotal());
					newStudentCount.setLower(dto.getLower());
					newStudentCount.setHigher(dto.getHigher());
					newStudentCount.setInspectionAppoval(dto.getInspectionAppoval());
					newStudentCount.setInspectionComment(dto.getInspectionComment());
					newStudentCount.setCreatedAt(LocalDateTime.now());
					newStudentCount.setUpdatedAt(LocalDateTime.now());
					newStudentCount.setStatus((byte) 1);

					StudentCount std = studentCountRepo.save(newStudentCount);

					applyRepo.findById(dto.getApplicationId()).ifPresent(apply -> {
						String updatedSteps = stepsUtil.updateStepsJson(apply.getSteps(), "student-count");
						apply.setSteps(updatedSteps);
						applyRepo.save(apply);
					});

					Optional<ApplicationsResult> resultOpt = applicationResultRepo
							.findByApplicationId(dto.getApplicationId());

					if (resultOpt.isPresent()) {
						ApplicationsResult result = resultOpt.get();
						result.setStudentCount((byte) 1);
						applicationResultRepo.save(result);
					} else {
						throw new RuntimeException("Application Id not present in application result.");
					}

					StudentCountDTO dto2 = toDTO(std);
					ApplicationsResult rs = applicationResultRepo.findByApplicationId(dto2.getApplicationId())
							.orElseThrow(() -> new RuntimeException("No ecords found in appliation result"));
					dto2.setGeneralInfo(rs.getGeneralInfo());
					dto2.setStudentCount(rs.getStudentCount());
					dto2.setDetailsOfPhysicals(rs.getDetailsOfPhysical());
					dto2.setOtherFacility(rs.getOtherFacilities());
					dto2.setGrantedSchool(rs.getGranted());
					dto2.setNonGrantedSchool(rs.getNonGranted());
					return dto2;
				}

			} else {
				throw new RuntimeException(
						"Application not found for Application ID " + dto.getApplicationId() + " in School Applies.");
			}
		} else {
			throw new RuntimeException("Application ID and School ID must be provided.");
		}
	}

}