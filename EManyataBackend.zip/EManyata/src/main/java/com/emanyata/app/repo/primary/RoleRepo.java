package com.emanyata.app.repo.primary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.primary.Role;

public interface RoleRepo extends JpaRepository<Role, Long>{

}
