package com.emanyata.app.serviceImpl.primary;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emanyata.app.repo.primary.UserRepo;
import com.emanyata.app.repo.secondary.OldUserRepo;
import com.emanyata.app.service.primary.ValidationService;

@Service
public class ValidationServiceImpl implements ValidationService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private OldUserRepo oldUserRepo;

    @Override
    public boolean emailExists(String email) {
        // Check email in both new and old user tables
        return userRepo.findByEmail(email).isPresent() || oldUserRepo.findByEmail(email).isPresent();
    }

    @Override
    public boolean mobileExists(String mobile) {
        // Check mobile in both new and old user tables
        return userRepo.findByMobile(mobile).isPresent() || oldUserRepo.findByPhone(mobile).isPresent();
    }
}
