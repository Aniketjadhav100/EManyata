package com.emanyata.app.serviceImpl.primary;

import com.emanyata.app.authdto.*;
import com.emanyata.app.entity.primary.ApplicationsResult;
import com.emanyata.app.entity.primary.Image;
import com.emanyata.app.entity.primary.Role;
import com.emanyata.app.entity.primary.School;
import com.emanyata.app.entity.primary.SchoolApply;
import com.emanyata.app.entity.primary.Taluka;
import com.emanyata.app.entity.primary.UdiseNumber;
import com.emanyata.app.entity.primary.User;
import com.emanyata.app.entity.primary.Village;
import com.emanyata.app.entity.secondary.OldSchool;
import com.emanyata.app.entity.secondary.OldSchoolApply;
import com.emanyata.app.entity.secondary.OldUser;
import com.emanyata.app.repo.primary.ApplicationResultRepo;
import com.emanyata.app.repo.primary.ImageRepo;
import com.emanyata.app.repo.primary.RoleRepo;
import com.emanyata.app.repo.primary.SchoolApplyRepo;
import com.emanyata.app.repo.primary.SchoolRepo;
import com.emanyata.app.repo.primary.TalukaRepo;
import com.emanyata.app.repo.primary.UdiseNumberRepository;
import com.emanyata.app.repo.primary.UserRepo;
import com.emanyata.app.repo.primary.VillageRepo;
import com.emanyata.app.repo.secondary.OldSchoolApplyRepo;
import com.emanyata.app.repo.secondary.OldSchoolRepository;
import com.emanyata.app.repo.secondary.OldUserRepo;
import com.emanyata.app.service.primary.SmsService;
import com.emanyata.app.service.primary.UserService;
import com.emanyata.app.util.ImageUploadUtil;
import com.emanyata.app.util.JwtUtil;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import jakarta.transaction.Transactional;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.Year;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private JwtUtil jwtUtil;
	@Autowired
	private JavaMailSender mailSender;
	@Autowired
	private UserRepo userRepo;
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	private TalukaRepo talukaRepo;
	@Autowired
	private VillageRepo villageRepo;
	@Autowired
	private ImageRepo imageRepo;
	@Autowired
	private SchoolApplyRepo schoolApplyRepo;
	@Autowired
	private RoleRepo roleRepo;
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private UdiseNumberRepository udiseNumberRepo;
	@Autowired
	private SchoolRepo schoolRepo;
	@Autowired
	private ApplicationResultRepo applicationResultRepo;
	@Autowired
	private OldSchoolRepository oldSchoolRepo;
	@Autowired
	private OldUserRepo oldUserRepo;
	@Autowired
	private OldSchoolApplyRepo oldSchoolApplyRepo;
	@Autowired
	private ImageUploadUtil imageUploadUtil;
	@Autowired
	private SmsService smsService;

	private String generateOtp() {
		return String.format("%06d", new Random().nextInt(999999));
	}

	@Override
	@Transactional
	public String register(UserDTO dto) {
	    // Check in new user table
	    boolean emailExists = userRepo.findByEmail(dto.getEmail()).isPresent();
	    boolean mobileExists = userRepo.findByMobile(dto.getMobile()).isPresent();
	    boolean udiseExists = userRepo.findBySchools_UdiseNo(dto.getUdiseNo()).isPresent();

	    // Check in old user table
	    boolean oldEmailExists = oldUserRepo.findByEmail(dto.getEmail()).isPresent();
	    boolean oldMobileExists = oldUserRepo.findByPhone(dto.getMobile()).isPresent();
	  

	    boolean combinedEmailExists = emailExists || oldEmailExists;
	    boolean combinedMobileExists = mobileExists || oldMobileExists;

	    if (combinedEmailExists && combinedMobileExists && udiseExists) {
	        throw new RuntimeException("email, mobile and UDISE number already registered");
	    } else if (combinedEmailExists && combinedMobileExists) {
	        throw new RuntimeException("email and mobile already registered");
	    } else if (combinedEmailExists && udiseExists) {
	        throw new RuntimeException("email and UDISE number already registered");
	    } else if (combinedMobileExists && udiseExists) {
	        throw new RuntimeException("mobile and UDISE number already registered");
	    } else if (combinedEmailExists) {
	        throw new RuntimeException("Email already registered");
	    } else if (combinedMobileExists) {
	        throw new RuntimeException("Mobile number already registered");
	    }

	    if (udiseExists) {
	        Optional<User> existingUserOpt = userRepo.findBySchools_UdiseNo(dto.getUdiseNo());
	        if (existingUserOpt.isPresent() && "1".equals(existingUserOpt.get().getOtpverified())) {
	            throw new RuntimeException("UDISE number already registered and verified");
	        }
	    }

	    if (udiseExists) {
	        Optional<UdiseNumber> udiseOpt = udiseNumberRepo.findByUdiseNumber(dto.getUdiseNo());
	        udiseOpt.ifPresent(udise -> {
	            udise.setStatus("1");
	            udiseNumberRepo.save(udise);
	        });

	        Optional<School> existingSchoolOpt = schoolRepo.findByUdiseNo(dto.getUdiseNo());
	        if (existingSchoolOpt.isPresent()) {
	            School existingSchool = existingSchoolOpt.get();
	            User existingUser = existingSchool.getUser_id();
	            applicationResultRepo.deleteByApplication_School(existingSchool);
	            schoolApplyRepo.deleteBySchool(existingSchool);
	            schoolRepo.delete(existingSchool);
	            userRepo.delete(existingUser);
	        }
	    }

	    User user = new User();
	    user.setEmail(dto.getEmail());
	    user.setMobile(dto.getMobile());
	    user.setUdiseNo(dto.getUdiseNo());
	    user.setName(dto.getName());
	    user.setPassword(passwordEncoder.encode(dto.getPassword()));
	    user.setDesignation(dto.getDesignation());
	    user.setPermissions(dto.getPermissions());
	    user.setStatus((byte) 1);
	    user.setDesignationId(dto.getDesignationId());
	    String otp = generateOtp();
	    user.setOtp(otp);
	    user.setMobile_otp(otp);
	    user.setOtpverified("0");
	    user.setCreatedAt(LocalDateTime.now());

	    Optional<Role> roleOpt = roleRepo.findById(4L);
	    if (roleOpt.isPresent()) {
	        user.setRole(roleOpt.get());
	    } else {
	        throw new RuntimeException("Role with ID 4 not found");
	    }

	    if (dto.getImage() != null && dto.getImage().getPath() != null) {
	        Image img = new Image();
	        img.setPath(dto.getImage().getPath());
	        img.setCreatedAt(LocalDateTime.now());
	        img.setUpdatedAt(LocalDateTime.now());
	        Image savedImg = imageRepo.save(img);
	        user.setImage(savedImg);
	    }

	    if (dto.getDigitalSignature() != null && dto.getDigitalSignature().getPath() != null) {
	        Image sign = new Image();
	        sign.setPath(dto.getDigitalSignature().getPath());
	        sign.setCreatedAt(LocalDateTime.now());
	        sign.setUpdatedAt(LocalDateTime.now());
	        Image savedSign = imageRepo.save(sign);
	        user.setDigitalSignature(savedSign);
	    }

	    Taluka taluka = getOrCreateTaluka(dto.getTaluka().getName());
	    Village village = getOrCreateVillage(dto.getVillage().getName(), taluka);

	    School school = new School();
	    school.setSchoolName(dto.getName());
	    school.setUdiseNo(dto.getUdiseNo());
	    school.setSchoolEmail(dto.getEmail());
	    school.setTransactionalAddress(dto.getTransactionalAddress());
	    school.setDistrict(dto.getDistrict());
	    school.setTaluka(taluka);
	    school.setVillage(village);
	    school.setPincode(dto.getPincode());
	    school.setTelephoneNumber(dto.getTelephoneNumber());
	    school.setSchoolMobile(dto.getMobile());
	    school.setPoliceStation(dto.getPoliceStation());
	    school.setSchoolType(dto.getSchoolType());
	    school.setUser_id(user);
	    school.setCreatedat(LocalDateTime.now());

	    user.setSchools(List.of(school));
	    userRepo.save(user);

	    String applicationNo = generateApplicationNo(user);
	    SchoolApply schoolApply = new SchoolApply();
	    schoolApply.setApplyStatus("pending");
	    schoolApply.setSchool(school);
	    schoolApply.setUser(user);
	    schoolApply.setApplicationNo(applicationNo);
	    SchoolApply apply = schoolApplyRepo.save(schoolApply);

	    ApplicationsResult result = new ApplicationsResult();
	    result.setApplication(apply);
	    result.setSchoolInfo(null);
	    result.setGeneralInfo((byte)0);
	    result.setFormAndArea(null);
	    result.setStudentCount((byte)0);
	    result.setDetailsOfPhysical((byte)0);
	    result.setOtherFacilities((byte)0);
	    result.setDetailsOfTeaching(null);
	    result.setNonGranted((byte)0);
	    result.setGranted((byte)0);
	    result.setComment(null);
	    result.setGovernmentDecisionOfApproval(null);
	    result.setApprovalOrderOfDeputyDirectorOfEducation(null);
	    result.setFirstApprovalOrder(null);
	    result.setOrganizationsRequisitionApplicationInSample1(null);
	    result.setInstitutionRegistration19501860Certificate(null);
	    result.setGovtMinorityCertificateIfTheSchoolIsMinority(null);
	    result.setInstitutionalUndertakingOfSchoolsNotChargingAny(null);
	    result.setWomenGrievanceRedressalCommittee(null);
	    result.setAffidavitOnStampOfRs100(null);
	    result.setSchoolPrincipalSignStamp(null);
	    result.setSchoolLocationChanged(null);
	    result.setCommonOrder2013To2016(null);
	    result.setCommonOrder2016To2019(null);
	    result.setCommonOrder2019To2022(null);
	    result.setJointAccountRetentionReceiptOfInstitution(null);
	    result.setOrganizationCompanyRegistrationCertificate(null);
	    result.setGovtMinorityCertificate(null);
	    result.setAuditReport(null);
	    result.setCopyOfEptaApprovalMinutes(null);
	    result.setFreeStructureAccordingToPrevious(null);
	    result.setTransportCommitteeOnlineCopy(null);
	    result.setCreatedAt(LocalDateTime.now());

	    applicationResultRepo.save(result);

	    sendEmail(user.getEmail(), "OTP Verification", user.getOtp(), user.getName());
	    smsService.sendOtpSms("91" + user.getMobile(), user.getMobile_otp());

	    return "OTP sent to registered email and mobile, please verify the OTP";
	}


	private String generateApplicationNo(User user) {
	    if (user.getSchools() == null || user.getSchools().isEmpty()) {
	        throw new IllegalArgumentException("User has no associated schools.");
	    }

	    String udiseNo = user.getSchools().get(0).getUdiseNo();
	    if (udiseNo == null || udiseNo.length() < 4) {
	        throw new IllegalArgumentException("Invalid UdiseNo: must be at least 4 characters long.");
	    }

	    String year = String.valueOf(Year.now().getValue());
	    String udiseSuffix = user.getSchools().get(0).getUdiseNo().substring(user.getSchools().get(0).getUdiseNo().length() - 4);

	    // Use only year as prefix for global per-year sequence
	    String prefix = year;

	    Optional<SchoolApply> lastApply = schoolApplyRepo
	            .findTopByApplicationNoStartingWithOrderByApplicationNoDesc(prefix);

	    long nextSuffix = 1;
	    if (lastApply.isPresent()) {
	        String lastAppNo = lastApply.get().getApplicationNo();
	        if (lastAppNo.length() < 4) {
	            throw new IllegalStateException("Invalid application number format in database: " + lastAppNo);
	        }
	        String lastSuffixStr = lastAppNo.substring(lastAppNo.length() - 4); // last 4 digits
	        try {
	            long lastSuffix = Long.parseLong(lastSuffixStr);
	            nextSuffix = lastSuffix + 1;
	        } catch (NumberFormatException e) {
	            throw new IllegalStateException("Invalid numeric suffix in application number: " + lastAppNo);
	        }
	    }

	    // final format: year + udiseSuffix + counter (ensures uniqueness per year)
	    return year + udiseSuffix + String.format("%04d", nextSuffix);
 
	}

	@Override
	@Transactional
	public String verifyOtp(OtpRequest otpRequest) {
	    String contact = otpRequest.getEmailOrMobile() != null ? otpRequest.getEmailOrMobile().trim() : null;
	    String otp = otpRequest.getOtpOrMobileOtp() != null ? otpRequest.getOtpOrMobileOtp().trim() : null;

	    if (contact == null || contact.isEmpty() || otp == null || otp.isEmpty()) {
	        throw new RuntimeException("Contact and OTP must be provided.");
	    }

	    boolean isEmail = contact.contains("@");

	    Optional<User> optionalUser = isEmail
	            ? userRepo.findByEmail(contact)
	            : userRepo.findByMobile(contact);

	    if (optionalUser.isEmpty()) {
	        throw new RuntimeException(isEmail ? "Email not found." : "Mobile number not found.");
	    }

	    User user = optionalUser.get();

	    if (isEmail) {
	        if (otp.equals(user.getOtp())) {
	            user.setOtp(null);
	            user.setMobile_otp(null);
	            user.setOtpverified("1");
	            userRepo.save(user);

	            if (!user.getSchools().isEmpty()) {
	                String udiseNo = user.getSchools().get(0).getUdiseNo();
	                Optional<UdiseNumber> udiseOpt = udiseNumberRepo.findByUdiseNumber(udiseNo);
	                if (udiseOpt.isPresent()) {
	                    UdiseNumber udise = udiseOpt.get();
	                    udise.setStatus("1");
	                    udiseNumberRepo.save(udise);
	                }
	            }

	            return "Email OTP verified successfully.";
	        } else {
	            throw new RuntimeException("Invalid OTP. Please check the OTP sent to your registered email.");
	        }
	    } else {
	        if (otp.equals(user.getMobile_otp())) {
	            user.setMobile_otp(null);
	            user.setOtp(null);
	            user.setMverified(LocalDateTime.now());
	            user.setOtpverified("1");
	            userRepo.save(user);

	            if (!user.getSchools().isEmpty()) {
	                String udiseNo = user.getSchools().get(0).getUdiseNo();
	                Optional<UdiseNumber> udiseOpt = udiseNumberRepo.findByUdiseNumber(udiseNo);
	                if (udiseOpt.isPresent()) {
	                    UdiseNumber udise = udiseOpt.get();
	                    udise.setStatus("1");
	                    udiseNumberRepo.save(udise);
	                }
	            }

	            return "Mobile OTP verified successfully.";
	        } else {
	            throw new RuntimeException("Invalid OTP. Please check the OTP sent to your registered mobile number.");
	        }
	    }
	}

	@Override
	public String resendOtp(String emailOrMobile) {
	    if (emailOrMobile == null || emailOrMobile.trim().isEmpty()) {
	        throw new RuntimeException("Email or mobile must be provided.");
	    }

	    String contact = emailOrMobile.trim();
	    Optional<User> optionalUser;

	    boolean isEmail = contact.contains("@");
	    boolean isMobile = contact.matches("\\d{10}");

	    if (isEmail) {
	        optionalUser = userRepo.findByEmail(contact);
	        if (optionalUser.isEmpty()) {
	            throw new RuntimeException("Please provide a registered email.");
	        }
	    } else if (isMobile) {
	        optionalUser = userRepo.findByMobile(contact);
	        if (optionalUser.isEmpty()) {
	            throw new RuntimeException("Please provide a registered mobile number.");
	        }
	    } else {
	        throw new RuntimeException("Invalid email or mobile number format.");
	    }

	    User user = optionalUser.get();

	    if ("1".equals(user.getOtpverified())) {
	        throw new RuntimeException("User already verified.");
	    }

	    String otp = generateOtp();
	    user.setOtp(otp);
	    user.setMobile_otp(otp);
	    userRepo.save(user);

	    try {
	        sendEmail(user.getEmail(), "OTP Verification", otp, user.getName());
	        smsService.sendOtpSms("91" + user.getMobile(), otp);

	        return "OTP sent to your registered email and mobile number.";

	    } catch (Exception e) {
	        e.printStackTrace(); 
	        throw new RuntimeException("Failed to send OTP. Please try again later.");
	    }
	}


	@Override
	public String login(LoginRequest request) {
	    String identifier = request.getEmailOrMobile();

	    Optional<User> userOptional = userRepo.findByEmail(identifier).isPresent() 
	            ? userRepo.findByEmail(identifier) 
	            : userRepo.findByMobile(identifier);

	    Optional<OldUser> oldUserOptional = oldUserRepo.findByEmail(identifier).isPresent()
	            ? oldUserRepo.findByEmail(identifier)
	            : oldUserRepo.findByPhone(identifier);

	    if (!userOptional.isPresent() && !oldUserOptional.isPresent()) {
	        return "{\"message\": \"User not found.\"}";
	    }

	    if (userOptional.isPresent()) {
	        User user = userOptional.get();
	        
	        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
	        	return "{\"message\": \"Invalid password.\"}";
	        }
	        
	        if ("0".equals(user.getOtpverified())) {
	            String newOtp = generateOtp();
	            user.setOtp(newOtp);
	            user.setMobile_otp(newOtp);
	            userRepo.save(user);
	            
	            sendEmail(user.getEmail(), "OTP Verification", user.getOtp(), user.getName());
	            smsService.sendOtpSms("91" + user.getMobile(), user.getMobile_otp());
	            
	            return "{\"message\": \"Please verify your email first. OTP sent again.\"}";
	        }
	        
	        if (user.getStatus() != 1) {
	            return "{\"message\": \"User is inactive. Please contact administrator.\"}";
	        }


	        String token = jwtUtil.generateToken(user.getEmail());
	        user.setRememberToken(token);
	        user.setLastLogin(LocalDateTime.now());
	        User savedUser = userRepo.save(user);

	        Long schoolId = null;
	        Long applicationId = null;
	        String schoolType = null;

	        Optional<School> schoolOpt = schoolRepo.findByUdiseNo(savedUser.getUdiseNo());
	        if (schoolOpt.isPresent()) {
	            School school = schoolOpt.get();
	            schoolId = school.getId();
	            schoolType = school.getSchoolType();

	            List<SchoolApply> schoolApplyList = schoolApplyRepo.findBySchoolId(schoolId);
	            if (!schoolApplyList.isEmpty()) {
	                applicationId = schoolApplyList.get(0).getId();
	            }
	        }

	        return "{" +
	                "\"message\": \"Login successful!\"," +
	                "\"token\": \"" + token + "\"," +
	                "\"user\": {" +
	                "\"id\": " + savedUser.getId() + "," +
	                "\"email\": \"" + savedUser.getEmail() + "\"," +
	                "\"mobile\": \"" + savedUser.getMobile() + "\"," +
	                "\"name\": \"" + savedUser.getName() + "\"," +
	                "\"mobileOtp\": \"" + savedUser.getMobile_otp() + "\"," +
	                "\"otp\": \"" + savedUser.getOtp() + "\"," +
	                "\"udiseNo\": \"" + savedUser.getUdiseNo() + "\"," +
	                "\"schoolId\": " + (schoolId != null ? schoolId : "null") + "," +
	                "\"applicationId\": " + (applicationId != null ? applicationId : "null") + "," +
	                "\"schoolType\": \"" + (schoolType != null ? schoolType : "") + "\"" +
	                "}" +
	                "}";
	    } 
	    // Handle old user
	    else {
	        OldUser oldUser = oldUserOptional.get();
	        
	        if (oldUser.getStatus() != 1) {
	            return "{\"message\": \"User is inactive. Please contact administrator.\"}";
	        }

	        if (!passwordEncoder.matches(request.getPassword(), oldUser.getPassword())) {
	            return "{\"message\": \"Invalid password.\"}";
	        }

	        String token = jwtUtil.generateToken(
	                oldUser.getEmail() != null ? oldUser.getEmail() : oldUser.getPhone()
	        );

	        Long schoolId = null;
	        Long applicationId = null;
	        String schoolType = null;
	        String udiseNo = null;

	        Optional<OldSchool> schoolOpt = oldSchoolRepo.findBySchoolMobile(oldUser.getPhone());
	        if (schoolOpt.isPresent()) {
	            OldSchool school = schoolOpt.get();
	            schoolId = school.getId();
	            schoolType = school.getSchoolType();
	            udiseNo = school.getUdiseNo();

	            Optional<OldSchoolApply> schoolApplyOpt = oldSchoolApplyRepo.findBySchoolId(schoolId);
	            if (schoolApplyOpt.isPresent()) {
	                applicationId = schoolApplyOpt.get().getId();
	            }
	        }

	        return "{" +
	                "\"message\": \"Login successful (old user)!\"," +
	                "\"token\": \"" + token + "\"," +
	                "\"user\": {" +
	                "\"id\": " + oldUser.getId() + "," +
	                "\"email\": \"" + (oldUser.getEmail() != null ? oldUser.getEmail() : "") + "\"," +
	                "\"mobile\": \"" + (oldUser.getPhone() != null ? oldUser.getPhone() : "") + "\"," +
	                "\"token\": \"" + oldUser.getToken() + "\"," +
	                "\"mobileOtp\": \"" + oldUser.getMobileOtp() + "\"," +
	                "\"name\": \"" + oldUser.getName() + "\"," +
	                "\"udiseNo\": \"" + (udiseNo != null ? udiseNo : "") + "\"," +
	                "\"schoolId\": " + (schoolId != null ? schoolId : "null") + "," +
	                "\"applicationId\": " + (applicationId != null ? applicationId : "null") + "," +
	                "\"schoolType\": \"" + (schoolType != null ? schoolType : "") + "\"" +
	                "}" +
	                "}";
	    }
	}
	
	@Override
	public String logout(String emailOrMobile) {

	    if (emailOrMobile == null || emailOrMobile.trim().isEmpty()) {
	        throw new RuntimeException("Email or mobile number must be provided.");
	    }

	    String contact = emailOrMobile.trim();
	    
	    Optional<User> userOptional = contact.contains("@") 
	        ? userRepo.findByEmail(contact)
	        : userRepo.findByMobile(contact);

	    if (!userOptional.isPresent()) {
	        if (contact.contains("@")) {
	            throw new RuntimeException("Email is incorrect.");
	        } else {
	            throw new RuntimeException("Mobile number is incorrect.");
	        }
	    }

	    User user = userOptional.get();
	    
	    if (user.getRememberToken() == null) {
	        throw new RuntimeException("No active session found.");
	    }
	    
	    user.setRememberToken(null);
	    userRepo.save(user);
	    
	    return "Logout successful.";
	}
	
	@Override
	public String verifyEmailOrMobile(ForgotPasswordRequest request) {

	    if (request == null || request.getEmailOrMobile() == null || request.getEmailOrMobile().trim().isEmpty()) {
	        throw new RuntimeException("Email or mobile number must be provided.");
	    }

	    String contact = request.getEmailOrMobile().trim();
	    boolean isEmail = contact.contains("@");

	    Optional<User> userOptional = isEmail 
	        ? userRepo.findByEmail(contact)
	        : userRepo.findByMobile(contact);

	    if (!userOptional.isPresent()) {
	        if (isEmail) {
	            throw new RuntimeException("Email is not registered.");
	        } else {
	            throw new RuntimeException("Mobile number is not registered.");
	        }
	    }

	    return "User verified. Proceed to reset password";
	}

	@Override
	public String updatePassword(UpdatePasswordRequest request) {
	    if (request.getUserId() == null) {
	        throw new RuntimeException("User ID is required.");
	    }
	    if (request.getEmail() == null || request.getEmail().trim().isEmpty()) {
	        throw new RuntimeException("Email is required.");
	    }
	    if (request.getMobile() == null || request.getMobile().trim().isEmpty()) {
	        throw new RuntimeException("Mobile number is required.");
	    }

	    Optional<User> userByEmail = userRepo.findByEmail(request.getEmail().trim());
	    if (userByEmail.isEmpty()) {
	        throw new RuntimeException("Email not found.");
	    }

	    Optional<User> userByMobile = userRepo.findByMobile(request.getMobile().trim());
	    if (userByMobile.isEmpty()) {
	        throw new RuntimeException("Mobile number not found.");
	    }

	    Optional<User> userOptional = userRepo.findById(request.getUserId());
	    if (userOptional.isEmpty()) {
	        throw new RuntimeException("User ID not found.");
	    }

	    User user = userOptional.get();

	    if (!user.getEmail().equalsIgnoreCase(request.getEmail().trim())) {
	        throw new RuntimeException("Email does not match user ID.");
	    }
	    if (!user.getMobile().equals(request.getMobile().trim())) {
	        throw new RuntimeException("Mobile number does not match user ID.");
	    }

	    if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPassword())) {
	        throw new RuntimeException("Current password is incorrect.");
	    }

	    user.setPassword(passwordEncoder.encode(request.getNewPassword()));
	    userRepo.save(user);
	    
	    return "Password updated successfully.";
	}

	@Override
	@Transactional
	public UserDTO getUserByUserId(Long userId) {
	    User user = userRepo.findById(userId)
	            .orElseThrow(() -> new RuntimeException("User not found."));

	    UserDTO dto = new UserDTO();
	    dto.setId(user.getId());

	    if (!user.getSchools().isEmpty()) {
	        School school = user.getSchools().get(0);

	        dto.setSchoolName(school.getSchoolName());
	        dto.setSchoolEmail(school.getSchoolEmail());
	        dto.setSchoolMobile(school.getSchoolMobile());
	        dto.setTransactionalAddress(school.getTransactionalAddress());
	        dto.setDistrict(school.getDistrict());
	        dto.setTaluka(school.getTaluka());
	        dto.setVillage(school.getVillage());
	        dto.setPincode(school.getPincode());
	        dto.setTelephoneNumber(school.getTelephoneNumber());
	        dto.setPoliceStation(school.getPoliceStation());
	        dto.setSchoolType(school.getSchoolType());
	    }
	    return dto;
	}
	
	@Override
	@Transactional
	public String updateUser(Long userId, UserDTO dto, MultipartFile imageFile) {
	    User user = userRepo.findById(userId)
	        .orElseThrow(() -> new RuntimeException("User not found"));

	    // Validate email and mobile uniqueness
	    boolean emailExists = !user.getEmail().equals(dto.getEmail()) && 
	                         userRepo.findByEmail(dto.getEmail()).isPresent();
	    boolean mobileExists = !user.getMobile().equals(dto.getMobile()) && 
	                          userRepo.findByMobile(dto.getMobile()).isPresent();

	    if (emailExists && mobileExists) {
	        throw new RuntimeException("Email and Mobile number already registered.");
	    } else if (emailExists) {
	        throw new RuntimeException("Email already registered.");
	    } else if (mobileExists) {
	        throw new RuntimeException("Mobile already registered.");
	    }

	    // Handle image upload/update
	    if (imageFile != null && !imageFile.isEmpty()) {
	        try {
	            String imagePath = imageUploadUtil.saveImage(imageFile);
	            Image userImage = imageRepo.findByUser(user)
	                .map(existingImage -> {
	                    // Update existing image
	                    existingImage.setPath(imagePath);
	                    existingImage.setUpdatedAt(LocalDateTime.now());
	                    return existingImage;
	                })
	                .orElseGet(() -> {
	                    // Create new image
	                    Image newImage = new Image();
	                    newImage.setPath(imagePath);
	                    newImage.setUser(user);
	                    newImage.setCreatedAt(LocalDateTime.now());
	                    newImage.setUpdatedAt(LocalDateTime.now());
	                    return newImage;
	                });
	            
	            imageRepo.save(userImage);
	            user.setImage(userImage);  // Ensure the user references the image
	        } catch (IOException e) {
	            throw new RuntimeException("Failed to process image: " + e.getMessage());
	        }
	    }

	    // Update basic user info
	    user.setName(dto.getName());
	    user.setEmail(dto.getEmail());
	    user.setMobile(dto.getMobile());
	    user.setUpdatedAt(LocalDateTime.now());

	    // Update school information
	    if (!user.getSchools().isEmpty()) {
	        School school = user.getSchools().get(0);
	        if (school != null) {
	            school.setSchoolName(dto.getName());
	            school.setSchoolEmail(dto.getEmail());
	            school.setSchoolMobile(dto.getMobile());
	            school.setTransactionalAddress(dto.getTransactionalAddress());
	            school.setDistrict(dto.getDistrict());

	            Taluka taluka = getOrCreateTaluka(dto.getTaluka().getName());
	            Village village = getOrCreateVillage(dto.getVillage().getName(), taluka);

	            school.setTaluka(taluka);
	            school.setVillage(village);
	            school.setPincode(dto.getPincode());
	            school.setTelephoneNumber(dto.getTelephoneNumber());
	            school.setPoliceStation(dto.getPoliceStation());
	            school.setSchoolType(dto.getSchoolType());
	            school.setUpdatedat(LocalDateTime.now());
	            
	            schoolRepo.save(school);
	        }
	    }

	    userRepo.save(user);
	    return "User updated successfully with image.";
	}



	@Override
	@Transactional
	public void updateEmailorMobile(Long userId, UserDTO dto) {
	    Optional<User> userOpt = userRepo.findById(userId);
	    if (userOpt.isEmpty()) {
	        throw new RuntimeException("User not found.");
	    }
	    User user = userOpt.get();

	    boolean emailExists = !user.getEmail().equals(dto.getEmail()) && userRepo.findByEmail(dto.getEmail()).isPresent();
	    boolean mobileExists = !user.getMobile().equals(dto.getMobile()) && userRepo.findByMobile(dto.getMobile()).isPresent();

	    if (emailExists && mobileExists) {
	        throw new RuntimeException("Both email and mobile number are already registered.");
	    } else if (emailExists) {
	        throw new RuntimeException("Email already registered.");
	    } else if (mobileExists) {
	        throw new RuntimeException("Mobile number already registered.");
	    }

	    user.setEmail(dto.getEmail());
	    user.setMobile(dto.getMobile());
	    user.setUpdatedAt(LocalDateTime.now());;

	    if (!user.getSchools().isEmpty()) {
	        School school = user.getSchools().get(0);
	        school.setSchoolEmail(dto.getEmail());
	        school.setSchoolMobile(dto.getMobile());
	        school.setUpdatedat(LocalDateTime.now());;
	        schoolRepo.save(school);
	    }

	    userRepo.save(user);
	}

	@Transactional
	public String forgotPassword(String emailOrMobile) {
	    if (emailOrMobile == null || emailOrMobile.trim().isEmpty()) {
	        throw new RuntimeException("Email or mobile number must be provided.");
	    }

	    String contact = emailOrMobile.trim();
	    Optional<User> userOpt = userRepo.findByEmailOrMobile(contact, contact);

	    if (!userOpt.isPresent()) {
	        throw new RuntimeException("Please provide a registered email or mobile number.");
	    }

	    User user = userOpt.get();
	    String otp = generateOtp();
	    user.setToken(otp);
	    userRepo.save(user);

	    try {
	        sendEmail(user.getEmail(), "OTP Verification", user.getToken(), user.getName());
	        smsService.sendOtpSms("91" + user.getMobile(), user.getToken());

	        return "OTP sent to your registered email and mobile number.";

	    } catch (Exception e) {
	        throw new RuntimeException("Failed to send OTP. Please try again later.");
	    }
	}

	@Transactional
	public String forgotPasswordResendOtp(String emailOrMobile) {
	    if (emailOrMobile == null || emailOrMobile.trim().isEmpty()) {
	        throw new RuntimeException("Email or mobile number must be provided.");
	    }

	    String contact = emailOrMobile.trim();
	    Optional<User> userOpt = userRepo.findByEmailOrMobile(contact, contact);

	    if (!userOpt.isPresent()) {
	        if (contact.contains("@")) {
	            throw new RuntimeException("Please provide a registered email.");
	        } else if (contact.matches("\\d+")) {
	            if (contact.length() != 10) {
	                throw new RuntimeException("Please provide a valid 10-digit registered mobile number.");
	            } else {
	                throw new RuntimeException("Please provide a registered mobile.");
	            }
	        } else {
	            throw new RuntimeException("Invalid email or mobile number format.");
	        }
	    }

	    User user = userOpt.get();
	    String otp = generateOtp();
	    user.setToken(otp);
	    userRepo.save(user);

	    try {
	        sendEmail(user.getEmail(), "OTP Verification", user.getToken(), user.getName());
	        smsService.sendOtpSms("91" + user.getMobile(), user.getToken());

	        return "OTP sent to your registered email and mobile number.";

	    } catch (Exception e) {
	        throw new RuntimeException("Failed to send OTP. Please try again later.");
	    }
	}


	public void verifyForgotOtp(String emailOrMobile, String otp) {
	    if (emailOrMobile == null || emailOrMobile.trim().isEmpty() || otp == null || otp.trim().isEmpty()) {
	        throw new RuntimeException("Email/Mobile and OTP must be provided.");
	    }

	    String contact = emailOrMobile.trim();
	    String trimmedOtp = otp.trim();

	    Optional<User> userOpt = userRepo.findByEmailOrMobile(contact, contact);

	    System.out.println("Looking for user with email/mobile: " + contact);
	    if (userOpt.isEmpty()) {
	        System.out.println("User not found for: " + contact);
	        if (contact.contains("@")) {
	            throw new RuntimeException("Email not found .");
	        }  else if (contact.matches("\\d+")) {
	            if (contact.length() != 10) {
	                throw new RuntimeException("Please provide a valid 10-digit registered mobile number.");
	            } else {
	                throw new RuntimeException("Please provide a registered mobile.");
	            }
	        }
	    }

	    User user = userOpt.get();
	    String storedOtp = user.getToken() != null ? user.getToken().trim() : null;

	    if (storedOtp == null) {
	        throw new RuntimeException("No OTP found for the user. Please request a new one.");
	    }

	    if (!trimmedOtp.equals(storedOtp)) {
	        if (contact.contains("@")) {
	            throw new RuntimeException("Please provide valid OTP, sent to registered email.");
	        } else {
	            throw new RuntimeException("Please provide valid OTP, sent to registered mobile.");
	        }
	    }

	    user.setToken(null);
	    userRepo.save(user);
	}


	@Transactional
	public void resetPassword(String emailOrMobile, String newPassword) {
	    Optional<User> userOpt = userRepo.findByEmailOrMobile(emailOrMobile, emailOrMobile);

	    if (userOpt.isEmpty()) {
	        if (emailOrMobile.contains("@")) {
	            throw new RuntimeException("Email not found");
	        }  else if (emailOrMobile.matches("\\d+")) {
	            if (emailOrMobile.length() != 10) {
	                throw new RuntimeException("Please provide a valid 10-digit registered mobile number.");
	            } else {
	                throw new RuntimeException("Please provide a registered mobile.");
	            }
	        } else {
	            throw new RuntimeException("Email or Mobile not found");
	        }
	    }

	    User user = userOpt.get();

	    if (user.getToken() != null) {
	        throw new RuntimeException("OTP not verified. Please verify OTP before resetting password.");
	    }

	    user.setPassword(passwordEncoder.encode(newPassword));
	    userRepo.save(user);
	    user.setUpdatedAt(LocalDateTime.now());;
	    
	    if (!user.getSchools().isEmpty()) {
	        School school = user.getSchools().get(0);
	        school.setUpdatedat(LocalDateTime.now());;
	        schoolRepo.save(school);
	    }
	}
	
	public Taluka getOrCreateTaluka(String name) {
		Optional<Taluka> optional = talukaRepo.findByName(name);
		if (optional.isPresent()) {
			return optional.get();
		}

		Taluka newTaluka = new Taluka();
		newTaluka.setName(name);
		newTaluka.setStatus("Active"); // 👈 important
		newTaluka.setCreatedAt(LocalDateTime.now());
		return talukaRepo.save(newTaluka);
	}

	private Village getOrCreateVillage(String villageName, Taluka taluka) {
		Optional<Village> existing = villageRepo.findByNameAndTalukaId(villageName, taluka.getId());
		if (existing.isPresent()) {
			return existing.get();
		} else {
			Village village = new Village();
			village.setName(villageName);
			village.setTaluka(taluka);
			village.setStatus("ACTIVE"); // <- THIS LINE is key, set a valid non-null status
			return villageRepo.save(village);
		}
	}

	public void sendEmail(String to, String subject, String otp, String name) {
	    MimeMessage message = mailSender.createMimeMessage();

	    try {
	        MimeMessageHelper helper = new MimeMessageHelper(message, true);

	        helper.setTo(to);
	        helper.setSubject(subject);

	        // Load HTML template from classpath
	        ClassPathResource resource = new ClassPathResource("templates/email-template.html");
	        String htmlTemplate = new String(resource.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

	        // Replace placeholders
	        String htmlContent = htmlTemplate
	                .replace("{{OTP}}", otp)
	                .replace("{{schoolName}}", name);

	        // Set email content
	        helper.setText(htmlContent, true);

	        // Embed the logo (remove "static/" from path)
	        ClassPathResource logo = new ClassPathResource("static/logo.png");
	        helper.addInline("logo", logo);

	        // Send email
	        mailSender.send(message);

	    } catch (IOException | MessagingException e) {
	        e.printStackTrace();
	        throw new RuntimeException("Failed to send styled email", e);
	    }
	}



	// ============================================ BELOW CODE IS FOR SUPER ADMIN
	// ==========================================

//  This Admin Registration only do by Super Admin... So make logic like that in SecurityConfig
	@Override
	public AdminRegistrationDTO registerAdmin(AdminRegistrationDTO dto) {
		if (userRepo.findByEmail(dto.getEmail()).isPresent()) {
			throw new RuntimeException("Email already exists.");
		} else if (userRepo.findByMobile(dto.getPhoneNumber()).isPresent()) {
			throw new RuntimeException("Phone number already exists.");
		}

		// Create Admin User
		User admin = new User();
		admin.setName(dto.getName());

		Optional<Role> role = roleRepo.findById(dto.getRole());
		if (role.isEmpty()) {
			throw new RuntimeException("Role not found for ID: " + dto.getRole());
		}
		admin.setRole(role.get());

		admin.setEmail(dto.getEmail());
		admin.setPassword(passwordEncoder.encode(dto.getPassword()));
		admin.setMobile(dto.getPhoneNumber());
		admin.setStatus(dto.getStatus());
		admin.setCreatedAt(LocalDateTime.now());
		admin.setUpdatedAt(LocalDateTime.now());
		admin.setDesignationId(5L); // Optional: Make it dynamic if needed
		admin.setUdiseNo(""); // Admins don’t need UDISE

		if (dto.getPhoto() != null) {
			Image savedImage = imageRepo.save(dto.getPhoto());
			admin.setImage(savedImage);
		} else {
			throw new RuntimeException("Upload the photo.");
		}

		User savedUser = userRepo.save(admin);

		// Prepare Response DTO
		AdminRegistrationDTO response = new AdminRegistrationDTO();
		response.setId(savedUser.getId());
		response.setName(savedUser.getName());
		response.setEmail(savedUser.getEmail());
		response.setPhoneNumber(savedUser.getPhone());
		response.setRole(savedUser.getRole().getId());
		response.setStatus(savedUser.getStatus());
		response.setPhoto(savedUser.getImage());

		return response;
	}

	@Override
	public AdminUpdateDTO editAdmin(AdminUpdateDTO dto) {
		User user = userRepo.findById(dto.getId())
				.orElseThrow(() -> new RuntimeException("Admin not found with ID: " + dto.getId()));

		Optional<User> optEmail = userRepo.findByEmail(dto.getEmail());
		if (optEmail.isPresent() && !optEmail.get().getId().equals(dto.getId())) {
			throw new RuntimeException("Email already present in database.");
		} else {
			user.setEmail(dto.getEmail());
		}

		Optional<User> optPhone = userRepo.findByMobile(dto.getPhoneNumber());
		if (optPhone.isPresent() && !optPhone.get().getId().equals(dto.getId())) {
			throw new RuntimeException("Mobile already present in database.");
		} else {
			user.setPhone(dto.getPhoneNumber());
		}

		user.setName(dto.getName());
		if (dto.getStatus() == 1 || dto.getStatus() == 0) {
			user.setStatus(dto.getStatus());
		} else {
			throw new RuntimeException("Status should be 0 or 1.");
		}

		if (dto.getRole() != null && dto.getRole() != 3 && dto.getRole() != 4 && dto.getRole() != 5) {
			Role role = roleRepo.findById(dto.getRole())
					.orElseThrow(() -> new RuntimeException("Role not found for ID: " + dto.getRole()));
			user.setRole(role);
		}

		if (dto.getPassword() != null && dto.getPassword().equals(dto.getConfirmPassword())) {
			user.setPassword(passwordEncoder.encode(dto.getPassword()));
		}

		if (dto.getPhoto() != null) {
			Image savedImage = imageRepo.save(dto.getPhoto());
			user.setImage(savedImage);
		}

		user.setUpdatedAt(LocalDateTime.now());
		userRepo.save(user);

		// Prepare safe response DTO
		AdminUpdateDTO response = new AdminUpdateDTO();
		response.setId(user.getId());
		response.setName(user.getName());
		response.setEmail(user.getEmail());
		response.setPhoneNumber(user.getPhone());
		response.setStatus(user.getStatus());
		response.setRole(user.getRole().getId());
		response.setPhoto(user.getImage());

		return response;
	}

	@Override
	public List<UserDTO> getAllAdmin() {
		List<User> adminsAndSuperadmins = userRepo.findByRoleIdIn(List.of(1, 2));

		if (adminsAndSuperadmins.isEmpty())
			throw new RuntimeException("No Admins, SuperAdmins found in database.");

		return adminsAndSuperadmins.stream().map(user -> modelMapper.map(user, UserDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public Optional<UserDTO> getAdminById(Long id) {
		Optional<User> user = userRepo.findById(id);

		if (user.isPresent()) {
			return user.map(user2 -> modelMapper.map(user2, UserDTO.class));
		} else {
			throw new RuntimeException("No Admin found for ID " + id);
		}
	}

}