package com.emanyata.app.dto;


public class YearWiseFormDataRequest {
	
    private String udiseNo;
    private Long schoolId;
    private Long applicationId;
    private String email;
    private String mobile;
    private String schoolType;
    
    
	public String getSchoolType() {
		return schoolType;
	}
	public void setSchoolType(String schoolType) {
		this.schoolType = schoolType;
	}
	
	public String getUdiseNo() {
		return udiseNo;
	}
	public void setUdiseNo(String udiseNo) {
		this.udiseNo = udiseNo;
	}
	public Long getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(Long schoolId) {
		this.schoolId = schoolId;
	}
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

}
