package com.emanyata.app.controller.primary;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.emanyata.app.dto.NonGrantedSchoolInfoDTO;
import com.emanyata.app.service.primary.NonGrantedSchoolInfoService;
import com.emanyata.app.util.NonGrantedSchoolUtil;

//import jakarta.annotation.Resource;
@RestController
@RequestMapping("/api/non-granted-school-info")
@CrossOrigin(origins = "http://localhost:3000")
public class NonGrantedSchoolInfoController {

    @Autowired
    private NonGrantedSchoolInfoService nonGrantedSchoolInfoService;

    @Autowired
    private NonGrantedSchoolUtil nonGrantedSchoolUtil;

    @PostMapping(value = "/save-or-update", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, Object>> saveOrUpdate(
            @RequestParam("schoolId") Long schoolId,
            @RequestParam("applicationId") Long applicationId,
            @RequestPart(value = "governmentDecisionOfApprovall", required = false) MultipartFile governmentDecisionOfApprovall,
            @RequestPart(value = "approvalOrderOfDeputyDirectorOfEducation", required = false) MultipartFile approvalOrderOfDeputyDirectorOfEducation,
            @RequestPart(value = "firstApprovalOrder", required = false) MultipartFile firstApprovalOrder,
            @RequestPart(value = "organizationsRequisitionApplicationInSample1", required = false) MultipartFile organizationsRequisitionApplicationInSample1,
            @RequestPart(value = "jointAccountRetentionReceiptOfInstitution", required = false) MultipartFile jointAccountRetentionReceiptOfInstitution,
            @RequestPart(value = "organizationCompanyRegistrationCertificate", required = false) MultipartFile organizationCompanyRegistrationCertificate,
            @RequestPart(value = "govtMinorityCertificate", required = false) MultipartFile govtMinorityCertificate,
            @RequestPart(value = "purchaseDeedLeaseAgreementAward", required = false) MultipartFile purchaseDeedLeaseAgreementAward,
            @RequestPart(value = "auditReport", required = false) MultipartFile auditReport,
            @RequestPart(value = "copyOfEptaApprovalMinutes", required = false) MultipartFile copyOfEptaApprovalMinutes,
            @RequestPart(value = "freeStructureAccordingToPrevious", required = false) MultipartFile freeStructureAccordingToPrevious,
            @RequestPart(value = "transportCommitteeOnlineCopy", required = false) MultipartFile transportCommitteeOnlineCopy,
            @RequestPart(value = "womenGrievanceRedressalCommittee", required = false) MultipartFile womenGrievanceRedressalCommittee,
            @RequestPart(value = "affidavitOnStampOfRs100", required = false) MultipartFile affidavitOnStampOfRs100,
            @RequestPart(value = "schoolPrincipalSignStamp", required = false) MultipartFile schoolPrincipalSignStamp,
            @RequestPart(value = "namuna1HandWrittenForm", required = false) MultipartFile namuna1HandWrittenForm,
            @RequestPart(value = "schoolLocationChanged", required = false) MultipartFile schoolLocationChangedFile,
            @RequestPart(value = "commonOrder2013To2016", required = false) MultipartFile commonOrder2013To2016File,
            @RequestPart(value = "commonOrder2016To2019", required = false) MultipartFile commonOrder2016To2019File,
            @RequestPart(value = "commonOrder2019To2022", required = false) MultipartFile commonOrder2019To2022File,
            @RequestPart(value = "commonOrder2022To2025", required = false) MultipartFile commonOrder2022To2025File,
            @RequestParam(value = "schoolLocationChangedBit", required = false) String schoolLocationChangedBit,
            @RequestParam(value = "commonOrder2013To2016Bit", required = false) String commonOrder2013To2016Bit,
            @RequestParam(value = "commonOrder2016To2019Bit", required = false) String commonOrder2016To2019Bit,
            @RequestParam(value = "commonOrder2019To2022Bit", required = false) String commonOrder2019To2022Bit,
            @RequestParam(value = "commonOrder2022To2025Bit", required = false) String commonOrder2022To2025Bit,
            @RequestParam(value = "status", required = false) Byte status
    ) {
        Map<String, Object> response = new HashMap<>();

        if (schoolId == null || applicationId == null) {
            Map<String, Object> response1 = new HashMap<>();
            response1.put("data", null);
            response1.put("message", "Both schoolId and applicationId are required");
            response1.put("status", "error");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }


        try {
            NonGrantedSchoolInfoDTO dto = new NonGrantedSchoolInfoDTO();
            dto.setSchoolId(schoolId);
            dto.setApplicationId(applicationId);

            // File uploads
            dto.setGovernmentDecisionOfApprovall(saveFile(governmentDecisionOfApprovall));
            dto.setApprovalOrderOfDeputyDirectorOfEducation(saveFile(approvalOrderOfDeputyDirectorOfEducation));
            dto.setFirstApprovalOrder(saveFile(firstApprovalOrder));
            dto.setOrganizationsRequisitionApplicationInSample1(saveFile(organizationsRequisitionApplicationInSample1));
            dto.setJointAccountRetentionReceiptOfInstitution(saveFile(jointAccountRetentionReceiptOfInstitution));
            dto.setOrganizationCompanyRegistrationCertificate(saveFile(organizationCompanyRegistrationCertificate));
            dto.setGovtMinorityCertificate(saveFile(govtMinorityCertificate));
            dto.setPurchaseDeedLeaseAgreementAward(saveFile(purchaseDeedLeaseAgreementAward));
            dto.setAuditReport(saveFile(auditReport));
            dto.setCopyOfEptaApprovalMinutes(saveFile(copyOfEptaApprovalMinutes));
            dto.setFreeStructureAccordingToPrevious(saveFile(freeStructureAccordingToPrevious));
            dto.setTransportCommitteeOnlineCopy(saveFile(transportCommitteeOnlineCopy));
            dto.setWomenGrievanceRedressalCommittee(saveFile(womenGrievanceRedressalCommittee));
            dto.setAffidavitOnStampOfRs100(saveFile(affidavitOnStampOfRs100));
            dto.setSchoolPrincipalSignStamp(saveFile(schoolPrincipalSignStamp));
            dto.setNamuna1HandWrittenForm(saveFile(namuna1HandWrittenForm));
            dto.setSchoolLocationChanged(saveFile(schoolLocationChangedFile));
            dto.setCommonOrder2013To2016(saveFile(commonOrder2013To2016File));
            dto.setCommonOrder2016To2019(saveFile(commonOrder2016To2019File));
            dto.setCommonOrder2019To2022(saveFile(commonOrder2019To2022File));
            dto.setCommonOrder2022To2025(saveFile(commonOrder2022To2025File));

            // Optional bits
            dto.setSchoolLocationChangedBit(schoolLocationChangedBit);
            dto.setCommonOrder2013To2016Bit(commonOrder2013To2016Bit);
            dto.setCommonOrder2016To2019Bit(commonOrder2016To2019Bit);
            dto.setCommonOrder2019To2022Bit(commonOrder2019To2022Bit);
            dto.setCommonOrder2022To2025Bit(commonOrder2022To2025Bit);

            // Optional
            dto.setStatus(status);
            dto.setCreatedAt(LocalDateTime.now());
            dto.setUpdatedAt(LocalDateTime.now());

            NonGrantedSchoolInfoDTO savedDto = nonGrantedSchoolInfoService.saveOrUpdate(dto);

            response.put("success", true);
            response.put("message", "Data saved successfully");
            response.put("data", savedDto);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error saving data");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    @PostMapping("/get-by-school-id/{schoolId}")
    public ResponseEntity<Map<String, Object>> getBySchoolId(@PathVariable Long schoolId) {
        Map<String, Object> response = new HashMap<>();
        try {
            NonGrantedSchoolInfoDTO info = nonGrantedSchoolInfoService.getBySchoolId(schoolId);
            if (info != null) {
                response.put("success", true);
                response.put("data", info);
                return ResponseEntity.ok(response);
            } else {
                response.put("success", false);
                response.put("message", "No data found for the given schoolId");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Failed to retrieve data");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    private String saveFile(MultipartFile file) throws IOException {
        return (file != null && !file.isEmpty()) ? nonGrantedSchoolUtil.saveFile(file) : null;
    }
    
    @PostMapping("/uploads/nonGrantedDocuments/{fileName:.+}")
    public ResponseEntity<Resource> viewNonGrantedDocument(@PathVariable String fileName) throws Exception {
        Resource file = nonGrantedSchoolInfoService.loadFileAsResource(fileName);

        // Detect actual content type
        Path filePath = file.getFile().toPath();
        String contentType = Files.probeContentType(filePath);

        if (contentType == null) {
            contentType = "application/octet-stream"; // fallback
        }

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + file.getFilename() + "\"")
                .body(file);
    }

    
}