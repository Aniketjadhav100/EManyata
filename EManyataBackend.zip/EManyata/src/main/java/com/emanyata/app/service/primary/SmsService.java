package com.emanyata.app.service.primary;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
public class SmsService {

    private final RestTemplate restTemplate;

    public SmsService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String sendOtpSms(String mobileNumber, String otp) {
        String message = "Dear User, Your OTP for Swamanyata Portal is " + otp + ". Do not share with anyone. Team ZP Pune Education Department.";

        String url = UriComponentsBuilder
                .fromHttpUrl("http://login.bulksmsservice.net.in/api/mt/SendSMS")
                .queryParam("user", "Arinozz")
                .queryParam("password", "Arinoz@123")
                .queryParam("senderid", "ZPPEDU")
                .queryParam("channel", "TRANS")
                .queryParam("DCS", "0")
                .queryParam("flashsms", "0")
                .queryParam("number", mobileNumber)
                .queryParam("text", message)
                .queryParam("route", "14")
                .build(false) 
                .toUriString();

        RestTemplate restTemplate = new RestTemplate();
        String response = restTemplate.getForObject(url, String.class);
        System.out.println("SMS API Response: " + response);
        return response;
    }

}