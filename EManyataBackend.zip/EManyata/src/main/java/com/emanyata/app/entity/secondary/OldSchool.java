package com.emanyata.app.entity.secondary;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

@Entity
@Table(name = "schools", schema = "emanyata")
public class OldSchool {
    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @Size(max = 255)
    @NotNull
    @Column(name = "school_name", nullable = false)
    private String schoolName;

    @Size(max = 255)
    @NotNull
    @Column(name = "udise_no", nullable = false)
    private String udiseNo;

    @Size(max = 255)
    @NotNull
    @Column(name = "transactional_address", nullable = false)
    private String transactionalAddress;

    @Size(max = 255)
    @NotNull
    @Column(name = "district", nullable = false)
    private String district;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private OldUser user;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "taluka_id", nullable = false)
    private OldTaluka taluka;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "village_id", nullable = false)
    private OldVillage village;

    @Size(max = 255)
    @NotNull
    @Column(name = "pincode", nullable = false)
    private String pincode;

    @Size(max = 255)
    @NotNull
    @Column(name = "telephone_number", nullable = false)
    private String telephoneNumber;

    @Size(max = 255)
    @NotNull
    @Column(name = "school_mobile", nullable = false)
    private String schoolMobile;

    @Size(max = 255)
    @NotNull
    @Column(name = "police_station", nullable = false)
    private String policeStation;

    @Size(max = 255)
    @NotNull
    @Column(name = "school_type", nullable = false)
    private String schoolType;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getUdiseNo() {
        return udiseNo;
    }

    public void setUdiseNo(String udiseNo) {
        this.udiseNo = udiseNo;
    }

    public String getTransactionalAddress() {
        return transactionalAddress;
    }

    public void setTransactionalAddress(String transactionalAddress) {
        this.transactionalAddress = transactionalAddress;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public OldUser getUser() {
        return user;
    }

    public void setUser(OldUser user) {
        this.user = user;
    }

    public OldTaluka getTaluka() {
        return taluka;
    }

    public void setTaluka(OldTaluka taluka) {
        this.taluka = taluka;
    }

    public OldVillage getVillage() {
        return village;
    }

    public void setVillage(OldVillage village) {
        this.village = village;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getSchoolMobile() {
        return schoolMobile;
    }

    public void setSchoolMobile(String schoolMobile) {
        this.schoolMobile = schoolMobile;
    }

    public String getPoliceStation() {
        return policeStation;
    }

    public void setPoliceStation(String policeStation) {
        this.policeStation = policeStation;
    }

    public String getSchoolType() {
        return schoolType;
    }

    public void setSchoolType(String schoolType) {
        this.schoolType = schoolType;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

}