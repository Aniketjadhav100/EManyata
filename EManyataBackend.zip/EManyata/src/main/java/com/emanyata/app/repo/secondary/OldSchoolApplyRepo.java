package com.emanyata.app.repo.secondary;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.emanyata.app.dto.StatusCountDTO;
import com.emanyata.app.entity.secondary.OldSchoolApply;

@Repository
public interface OldSchoolApplyRepo extends JpaRepository<OldSchoolApply, Long> {

	Optional<OldSchoolApply> findFirstBySchoolIdAndStatusIn(Long schoolId, List<String> statusList);
	Optional<OldSchoolApply> findBySchoolId(Long id);
	List<OldSchoolApply> findAllBySchoolId(Long id);
	
    // This is for Status Count
    @Query("SELECT new com.emanyata.app.dto.StatusCountDTO(s.status, COUNT(s)) FROM OldSchoolApply s GROUP BY s.status")
    List<StatusCountDTO> getStatusCounts();
	List<OldSchoolApply> findByStatus(String string);
}
