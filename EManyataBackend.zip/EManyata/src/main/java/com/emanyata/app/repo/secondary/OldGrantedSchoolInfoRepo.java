package com.emanyata.app.repo.secondary;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.secondary.OldGrantedSchoolInfo;

public interface OldGrantedSchoolInfoRepo extends JpaRepository<OldGrantedSchoolInfo,Long> {

	Optional<OldGrantedSchoolInfo> findByApplicationId(Long id);

	List<OldGrantedSchoolInfo> findBySchoolId(Long id);
}
