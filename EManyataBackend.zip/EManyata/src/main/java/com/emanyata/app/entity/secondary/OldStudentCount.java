package com.emanyata.app.entity.secondary;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

@Entity
@Table(name = "student_counts", schema = "emanyata")
public class OldStudentCount {
    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "school_id", nullable = false)
    private OldSchool school;

    
    @Column(name = "total_boys")
    private String totalBoys;

    
    @Column(name = "total_girls")
    private String totalGirls;

    
    @Column(name = "total")
    private String total;

    @Size(max = 500)
    @Column(name = "lower", length = 500)
    private String lower;

    @Size(max = 500)
    @Column(name = "higher", length = 500)
    private String higher;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "application_id")
    private Long applicationId;

    @Size(max = 50)
    @Column(name = "inspection_appoval", length = 50)
    private String inspectionAppoval;

    @Size(max = 255)
    @Column(name = "inspection_comment")
    private String inspectionComment;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public OldSchool getSchool() {
        return school;
    }

    public void setSchool(OldSchool school) {
        this.school = school;
    }

    public String getTotalBoys() {
        return totalBoys;
    }

    public void setTotalBoys(String totalBoys) {
        this.totalBoys = totalBoys;
    }

    public String getTotalGirls() {
        return totalGirls;
    }

    public void setTotalGirls(String totalGirls) {
        this.totalGirls = totalGirls;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getLower() {
        return lower;
    }

    public void setLower(String lower) {
        this.lower = lower;
    }

    public String getHigher() {
        return higher;
    }

    public void setHigher(String higher) {
        this.higher = higher;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long applicationId) {
        this.applicationId = applicationId;
    }

    public String getInspectionAppoval() {
        return inspectionAppoval;
    }

    public void setInspectionAppoval(String inspectionAppoval) {
        this.inspectionAppoval = inspectionAppoval;
    }

    public String getInspectionComment() {
        return inspectionComment;
    }

    public void setInspectionComment(String inspectionComment) {
        this.inspectionComment = inspectionComment;
    }

}