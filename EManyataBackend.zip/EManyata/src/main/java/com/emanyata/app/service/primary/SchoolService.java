package com.emanyata.app.service.primary;

import com.emanyata.app.dto.SchoolDTO;
import com.emanyata.app.entity.primary.School;

public interface SchoolService {
    School save(School school);
    SchoolDTO getSchoolByUdiseNo(String udiseNo);
}
