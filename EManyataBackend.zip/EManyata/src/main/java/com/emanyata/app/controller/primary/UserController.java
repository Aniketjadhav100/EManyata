package com.emanyata.app.controller.primary;

import com.emanyata.app.authdto.*;
import com.emanyata.app.serviceImpl.primary.UserServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserServiceImpl userService;

    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(@RequestBody UserDTO dto) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            String result = userService.register(dto);

            response.put("code", 200);
            response.put("message", "Success");
            response.put("data", result);
            return ResponseEntity.ok(response);
            
        } catch (RuntimeException e) {
            response.put("code", 400);
            response.put("message", "Registration Failed");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            
        } catch (Exception e) {
            response.put("code", 500);
            response.put("message", "Internal Server Error");
            response.put("error", "Registration process failed");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<Map<String, Object>> verifyOtp(@RequestBody OtpRequest otpRequest) {
        Map<String, Object> response = new HashMap<>();
        try {
            String result = userService.verifyOtp(otpRequest);
            response.put("code", 200);
            response.put("message", "Success");
            response.put("data", result);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            String errorMsg = e.getMessage();
            response.put("code", 400);
            response.put("message", "OTP Verification Failed");
            response.put("error", errorMsg);
            return ResponseEntity.badRequest().body(response);
        }
    }

    @PostMapping("/resend-otp")
    public ResponseEntity<Map<String, Object>> resendOtp(@RequestBody Map<String, String> request) {
        Map<String, Object> response = new HashMap<>();
        try {
            String email = request.get("email");
            String result = userService.resendOtp(email);
            response.put("code", 200);
            response.put("message", "Success");
            response.put("data", result);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            response.put("code", 400);
            response.put("message", "OTP Resend Failed");
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }


    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody LoginRequest request) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            String result = userService.login(request);
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> resultMap = mapper.readValue(result, Map.class);
            String message = (String) resultMap.get("message");

            if ("User not found.".equals(message)) {
                response.put("code", 401);
                response.put("message", "Login Failed");
                response.put("error", "User not found");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }

            if ("Invalid password.".equals(message)) {
                response.put("code", 402);
                response.put("message", "Login Failed");
                response.put("error", "Invalid password");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }

            if ("Please verify your email first. OTP sent again.".equals(message)) {
                response.put("code", 403);
                response.put("message", "OTP Verification Required");
                response.put("data", resultMap);
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
            }

            if ("User is inactive. Please contact administrator.".equals(message)) {
                response.put("code", 404);
                response.put("message", "Login Failed");
                response.put("error", "Account inactive");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }

            response.put("code", 200);
            response.put("message", "Login Successful");
            response.put("data", resultMap);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("code", 500);
            response.put("message", "Internal Server Error");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
    
    @PostMapping("/logout")
    public ResponseEntity<Map<String, Object>> logout(@RequestBody Map<String, String> request) {
        Map<String, Object> response = new HashMap<>();
        try {
            String emailOrMobile = request.get("emailOrMobile");
            String result = userService.logout(emailOrMobile);
            response.put("code", 200);
            response.put("message", "Success");
            response.put("data", result);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            response.put("code", 404);
            response.put("message", "Failed");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    @PostMapping("/update-password")
    public ResponseEntity<Map<String, Object>> updatePassword(@RequestBody UpdatePasswordRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            String result = userService.updatePassword(request);
            response.put("code", 200);
            response.put("message", "Password Updated");
            response.put("data", result);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            response.put("code", 400);
            response.put("message", "Update Failed");
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
    
    @PostMapping("/get-user/{userId}")
    public ResponseEntity<Map<String, Object>> getUserById(@PathVariable Long userId) {
        Map<String, Object> response = new HashMap<>();
        try {
            UserDTO dto = userService.getUserByUserId(userId);
            response.put("code", 200);
            response.put("message", "User fetched successfully.");
            response.put("data", dto);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
        	 response.put("code", 400);
             response.put("message", "Failed");
             response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }


    @PostMapping(value = "/update/{userId}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, Object>> updateUser(
            @PathVariable Long userId,
            @RequestPart("user") String userDTOString,
            @RequestPart(value = "image", required = false) MultipartFile imageFile) {
        
        Map<String, Object> response = new HashMap<>();
        try {
            // Convert JSON string to UserDTO
            ObjectMapper objectMapper = new ObjectMapper();
            UserDTO userDTO = objectMapper.readValue(userDTOString, UserDTO.class);
            
            String result = userService.updateUser(userId, userDTO, imageFile);
            response.put("code", HttpStatus.OK.value());
            response.put("message", "User updated successfully");
            response.put("data", result);
            return ResponseEntity.ok(response);
        } catch (JsonProcessingException e) {
            response.put("code", HttpStatus.BAD_REQUEST.value());
            response.put("message", "Invalid user data format");
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (RuntimeException e) {
            response.put("code", HttpStatus.BAD_REQUEST.value());
            response.put("message", "User update failed");
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            response.put("code", HttpStatus.INTERNAL_SERVER_ERROR.value());
            response.put("message", "Internal server error");
            response.put("error", e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    @PostMapping("/update_email/{userId}")
    public ResponseEntity<Map<String, Object>> updateEmailOrMobile(
            @PathVariable Long userId, 
            @RequestBody UserDTO userDTO) {
        Map<String, Object> response = new HashMap<>();
        try {
            userService.updateEmailorMobile(userId, userDTO);
            response.put("code", 200);
            response.put("message", "Email or Mobile Updated");
            response.put("data", "Email and Mobile updated successfully.");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            response.put("code", 400);
            response.put("message", "Update Failed");
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }


    @PostMapping("/forgot-password")
    public ResponseEntity<Map<String, Object>> forgotPassword(@RequestBody Map<String, String> request) {
        String emailOrMobile = request.get("emailOrMobile");
        Map<String, Object> response = new HashMap<>();
        try {
            String message = userService.forgotPassword(emailOrMobile);
            response.put("code", 200);
            response.put("message", message);
            response.put("data", "success");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            response.put("code", 400);
            response.put("message", "Failed");
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
    
    @PostMapping("/forgot-password/resend-otp")
    public ResponseEntity<Map<String, Object>> forgotPasswordResendOtp(@RequestBody Map<String, String> request) {
        String emailOrMobile = request.get("emailOrMobile");
        Map<String, Object> response = new HashMap<>();
        try {
            String message = userService.forgotPassword(emailOrMobile);
            response.put("code", 200);
            response.put("message", message);
            response.put("data", "success");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            response.put("code", 400);
            response.put("message", "Failed");
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    @PostMapping("/verify-forgot-otp")
    public ResponseEntity<Map<String, Object>> verifyForgotOtp(@RequestBody Map<String, String> request) {
        String emailOrMobile = request.get("emailOrMobile");
        String otp = request.get("otp");
        Map<String, Object> response = new HashMap<>();
        try {
            userService.verifyForgotOtp(emailOrMobile, otp);
            response.put("code", 200);
            response.put("message", "OTP verified successfully");
            response.put("data", "success");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            response.put("code", 400);
            response.put("message", "Failed");
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
    
    @PostMapping("/verify-forgot")
    public ResponseEntity<Map<String, Object>> verifyEmailOrMobile(@RequestBody ForgotPasswordRequest request) {
        String result = userService.verifyEmailOrMobile(request);
        Map<String, Object> response = new HashMap<>();
        response.put("code", 200);
        response.put("message", "Success");
        response.put("data", result);
        return ResponseEntity.ok(response);
    }
    

    @PostMapping("/reset-password")
    public ResponseEntity<Map<String, Object>> resetPassword(@RequestBody Map<String, String> request) {
        String emailOrMobile = request.get("emailOrMobile");
        String newPassword = request.get("newPassword");
        Map<String, Object> response = new HashMap<>();
        try {
            userService.resetPassword(emailOrMobile, newPassword);
            response.put("code", 200);
            response.put("message", "Password reset successfully");
            response.put("data", null);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            response.put("code", 400);
            response.put("message", "Failed");
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }   
}