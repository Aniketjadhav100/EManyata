package com.emanyata.app.dto;


import com.emanyata.app.entity.primary.Village;

import jakarta.validation.constraints.NotNull;


public class VillageDTO {

    private Long id;

    @NotNull
    private String name;

    private String status = "1";

    @NotNull
    private Long talukaId;

    private String createdAt;
    private String updatedAt;

    // Constructor to convert Village entity to DTO
    public VillageDTO(Village village) {
        this.id = village.getId();  // Assigning from the Village entity
        this.name = village.getName();
        this.status = village.getStatus();
        this.talukaId = village.getTaluka() != null ? village.getTaluka().getId() : null;
        this.createdAt = village.getCreatedAt() != null ? village.getCreatedAt().toString() : null;
        this.updatedAt = village.getUpdatedAt() != null ? village.getUpdatedAt().toString() : null;
    }

    // Default constructor (for deserialization)
    public VillageDTO() {}

    // Getters & Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getTalukaId() {
        return talukaId;
    }

    public void setTalukaId(Long talukaId) {
        this.talukaId = talukaId;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }
}