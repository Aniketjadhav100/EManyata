package com.emanyata.app.service.primary;


import com.emanyata.app.dto.SchoolGeneralInfoDTO;
import com.emanyata.app.entity.primary.SchoolGeneralInfo;

public interface SchoolGeneralInfoService {
    SchoolGeneralInfoDTO getSchoolById(Long id);
    SchoolGeneralInfoDTO createSchoolInfo(SchoolGeneralInfoDTO schoolInfo);
}
