package com.emanyata.app.controller.primary;

import com.emanyata.app.dto.SchoolDTO;
import com.emanyata.app.entity.primary.School;
import com.emanyata.app.service.primary.SchoolService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/schools")
public class SchoolController {

    @Autowired
    private SchoolService schoolService;

    // Save (Create)
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createSchool(@RequestBody School school) {
        School savedSchool = schoolService.save(school);

        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", "School created successfully.");
        response.put("data", savedSchool);

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    // Get School by UDISE No (returns DTO)
    @PostMapping("/get/{udise}")
    public ResponseEntity<Map<String, Object>> getSchoolByUdise(@PathVariable String udise) {
        SchoolDTO schoolDTO = schoolService.getSchoolByUdiseNo(udise);

        Map<String, Object> response = new HashMap<>();

        if (schoolDTO == null) {
            response.put("status", "failure");
            response.put("message", "No school found for the given UDISE number.");
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }

        response.put("status", "success");
        response.put("message", "School fetched successfully for UDISE number: " + udise);
        response.put("data", schoolDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
