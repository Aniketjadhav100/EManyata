package com.emanyata.app.repo.primary;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.emanyata.app.entity.primary.NonGrantedSchoolInfo;


@Repository
public interface NonGrantedSchoolInfoRepo extends JpaRepository<NonGrantedSchoolInfo, Long> {
    Optional<NonGrantedSchoolInfo> findBySchoolId(Long schoolId);
}
