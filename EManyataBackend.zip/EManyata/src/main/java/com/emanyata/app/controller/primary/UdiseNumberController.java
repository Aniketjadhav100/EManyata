package com.emanyata.app.controller.primary;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.emanyata.app.dto.UdiseDetailsDTO;
import com.emanyata.app.dto.UdiseNumberDTO;
import com.emanyata.app.entity.primary.UdiseNumber;
import com.emanyata.app.exceptions.ResourceNotFoundException;
import com.emanyata.app.service.primary.UdiseNumberService;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/udise")
public class UdiseNumberController {

    private final UdiseNumberService udiseNumberService;

    public UdiseNumberController(UdiseNumberService udiseNumberService) {
        this.udiseNumberService = udiseNumberService;
    }

    @PostMapping("/upload")
    public ResponseEntity<?> uploadUdiseNumbers(@RequestParam("file") MultipartFile file) {
        try {
            // Call the service method
            Map<String, Object> response = udiseNumberService.saveUdiseFromExcel(file);
            
            // Return the response with appropriate status
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            // Handle any exceptions that might occur
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of( 	
                        "message", "Error processing file",
                        "error", e.getMessage()
                    ));
        }
    }
    
    @PostMapping("/getbyudisedata/{udiseNumber}")
    public ResponseEntity<Map<String, Object>> getUdiseDetails(@PathVariable String udiseNumber) {
        Map<String, Object> response = new HashMap<>();
        try {
            UdiseDetailsDTO details = udiseNumberService.getUdiseDetails(udiseNumber);

            if (details == null) {
                throw new NoSuchElementException("No UDISE data found for UDISE number: " + udiseNumber);
            }

            response.put("status", "success");
            response.put("message", "School UDISE details fetched successfully.");
            response.put("data", details);
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (ResourceNotFoundException | NoSuchElementException e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);

        } catch (IllegalArgumentException e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", "An unexpected error occurred: " + e.getMessage());
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @PostMapping("/{udiseNumber}/status")
    public ResponseEntity<?> updateStatus(
            @PathVariable String udiseNumber,
            @RequestParam(defaultValue = "1") String status) {
        try {
            UdiseNumber updated = udiseNumberService.updateStatus(udiseNumber, status);
            return ResponseEntity.ok(updated);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of(
                "error", "Invalid request",
                "message", e.getMessage()
            ));
        } catch (ResourceNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PostMapping("/status/{status}")
    public ResponseEntity<List<UdiseNumberDTO>> getUdiseByStatus(@PathVariable String status) {
        List<UdiseNumberDTO> result = udiseNumberService.getUdiseByStatus(status);

        if (result.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(Collections.emptyList());
        }

        return ResponseEntity.ok(result);
    }

    @PostMapping("/all")
    public ResponseEntity<List<UdiseNumberDTO>> getAllUdiseNumbers() {
        List<UdiseNumberDTO> result = udiseNumberService.getAllUdiseNumbers();

        if (result.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT)
                .body(Collections.emptyList());
        }

        return ResponseEntity.ok(result);
    }
    
}

   