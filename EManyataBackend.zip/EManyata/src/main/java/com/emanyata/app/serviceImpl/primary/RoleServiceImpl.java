package com.emanyata.app.serviceImpl.primary;

import com.emanyata.app.service.primary.RoleService;

public class RoleServiceImpl implements RoleService {

}
