package com.emanyata.app.repo.secondary;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.primary.User;
import com.emanyata.app.entity.secondary.OldSchool;
import com.emanyata.app.entity.secondary.OldUser;

public interface OldUserRepo extends JpaRepository<OldUser, Long> {
	Optional<OldUser> findByEmail(String email);
    Optional<OldUser> findByPhone(String mobile);
	Optional<OldUser> findByEmailAndPhone(String email, String phone);
	
}
