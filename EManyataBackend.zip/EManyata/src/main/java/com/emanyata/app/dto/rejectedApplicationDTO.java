package com.emanyata.app.dto;


public class rejectedApplicationDTO {
	 private String applicationNo;
	    private String schoolName;
	    private String transactionalAddress;
	    private String district;
	    private String taluka;
	    private String village;
	    private String pincode;
	    private String telephoneNumber;
	    private String schoolMobile;
	    private String schoolEmail;
	    private String policeStation;
	    private String schoolType;
	    private String udiseNo;

	    // General Info
	    private String forWhichYearYouWantToApplyForACertificate;
	    private String addressMentionedInGovernmentApprovalDocument;
	    private String schoolEstablishmentYear;
	    private String dateOfFirstOpeningOfSchool;
	    private String lowerStandard;
	    private String higherStandard;
	    private String schoolArea;
	    private String simpleHigherStandard;
	    private String simpleLowerStandard;
	    private String mediumOfInstruction;
	    private String udiseLowerStandard;
	    private String udiseHigherStandard;
	    private String schoolBoard;
	    private String schoolTimeFullTime;
	    private String schoolTimeHalfTime;
	    private String lunchTimeForEachClass;
	    private String sangsthaCompanyName;
	    private String sansthaCompanyHasPurposeForOnlyEducationService;
	    private String isSchoolOpenWhereAddressMentionedInApproval;
	    private String whetherSchoolIsMovedToAnotherLocation;
	    private String ifSansthaIsHandoverToSomeone;
	    private String doYouHaveMaharastraShashanManyataNo;
	    private String maharastraShashanApprovalNumber;
	    private String maharastraShashanApprovalDate;
	    private String doYouHaveShikshanUpsanchalakApproval;
	    private String shikshanUpsanchalakApprovalNumber;
	    private String shikshanUpsanchalakApprovalDate;
	    private String doYouHavePrathamManyataCertificate;
	    private String prathamManyataNumber;
	    private String prathamManyataDate;
	    private String doYouRunOnGovernmentNoObjectionCertificate;
	    private String noObjectionCertificateNumber;
	    private String noObjectionCertificateDate;
	    private String isThereAnAffiliationCertificate;
	    private String affiliationCertificateNumber;
	    private String affiliationCertificateDate;

	    // School User Info
	    private String schoolUserName;
	    private String schoolUserDesignation;
	    private String schoolUserAddress;
	    private String schoolUserTelephone;

	    // Bouthik Suvidha (Infrastructure)
	    private String typeOfProofAvailableAndItsDate;
	    private String forYouTakePropertyDocumentType;
	    private String areaSqM;
	    private String totalAreaSqM;
	    private String schoolTotalAreaSqM;

	    private String principalCount;
	    private String principalArea;
	    private String officeCount;
	    private String officeArea;
	    private String staffCount;
	    private String staffArea;
	    private String storageCount;
	    private String storageArea;
	    private String classroom;
	    private String classroomArea;
	    private String labCount;
	    private String labArea;
	    private String compCount;
	    private String compArea;
	    private String libraryCount;
	    private String libraryArea;
	    private String schoolTotalCount;
	    private String schoolTotalArea;

	    // Sanitation Facilities
	    private String westernToiletCount;
	    private String toiletAvailableFacilityDetails;
	    private String seperateBoysToiletCount;
	    private String seperateBoysToiletFacilityDetails;
	    private String seperateBoysWashroomCount;
	    private String seperateBoysWashroomFacilityDetails;
	    private String seperateBoysDrinkingWaterCount;
	    private String seperateBoysDrinkingWaterFacilityDetails;
	    private String seperateGirlsToiletCount;
	    private String seperateGirlsToiletFacilityDetails;
	    private String seperateGirlsWashroomCount;
	    private String seperateGirlsWashroomFacilityDetails;
	    private String seperateGirlsDrinkingWaterCount;
	    private String seperateGirlsDrinkingWaterFacilityDetails;

	    // Water & Play Area
	    private String waterTapCount;
	    private String waterTankCapacity;
	    private String actualAvailableFacilityDetailsTap;
	    private String actualAvailableFacilityDetailsWater;
	    private String areaOfPlaygroundDetails;
	    private String areaOfPlayground;
	    private String retainingWallCompound;
	    private String entranceWithProtectiveWallAndIronGate;
	    private String kitchenShed;
	    private String aRampForBarrierFreeAccess;
	    private String rocksOnTheSideOfTheRamp;
	    private String classroomCount;
	    private String kitchenShedDetails;
	    private String theRoofIsSolidRcc;
	    private String fireWarrantyCylinderNo;
	    private String medicalPrimaryBoxNumber;
	    private String plaquesInFacadesOfSchoolRecognition;
	    private String cctvNo;
	   

	    // Other Facilities
	    private String minimum200DaysOf800ClockHoursForPrimaryAndHigher;
	    private String hoursOfTeachingPerWeek;
	    private String sufficientEducationalMaterialInEachClassAsRequired;
	    private String numberOfReferenceBooksAvailableForTeacherTraining;
	    private String numberOfBooksAvailableForStudentReadingInTheLibrary;
	    private String magzinBooksCount;
	    private String newspaperAndTotalCount;
	    private String numberOfSportsAndSportsLiterature;

	    // Granted School Fields
	    private String grantedGovernmentDecisionOfApproval;
	    private String grantedApprovalOrderOfDeputyDirectorOfEducation;
	    private String grantedFirstApprovalOrder;
	    private String grantedOrganizationsRequisitionApplicationInSample1;
	    private String grantedInstitutionRegistration19501860Certificate;
	    private String grantedGovtMinorityCertificateIfTheSchoolIsMinority;
	    private String grantedPurchaseDeedLeaseAgreementAwardDeed;
	    private String grantedCertificationOfJoiningIfAdditionalTeacher;
	    private String grantedInstitutionalUndertakingOfSchoolsNotChargingAny;
	    private String grantedWomenGrievanceRedressalCommittee;
	    private String institutionRegistration19501860Certificate;
	    private String grantedAffidavitOnStampOfRs100;
	    private String grantedSchoolPrincipalSignStamp;
	    private String grantedCommonOrder2013To2016Bit;
	    private String grantedCommonOrder2016To2019Bit;
	    private String grantedCommonOrder2019To2022Bit;

	    // Non-Granted School Fields
	    private String nonGrantedGovernmentDecisionOfApproval;
	    private String nonGrantedApprovalOrderOfDeputyDirectorOfEducation;
	    private String nonGrantedFirstApprovalOrder;
	    private String nonGrantedOrganizationsRequisitionApplicationInSample1;
	    private String nonGrantedJointAccountRetentionReceiptOfInstitution;
	    private String nonGrantedOrganizationCompanyRegistrationCertificate;
	    private String nonGrantedGovtMinorityCertificate;
	    private String nonGrantedPurchaseDeedLeaseAgreementAward;
	    private String nonGrantedAuditReport;
	    private String nonGrantedCopyOfEptaApprovalMinutes;
	    private String nonGrantedFreeStructureAccordingToPrevious;
	    private String nonGrantedTransportCommitteeOnlineCopy;
	    private String nonGrantedWomenGrievanceRedressalCommittee;
	    private String nonGrantedAffidavitOnStampOfRs100;
	    private String nonGrantedSchoolPrincipalSignStamp;
	    private String nonGrantedCommonOrder2013To2016Bit;
	    private String nonGrantedCommonOrder2016To2019Bit;
	    private String nonGrantedCommonOrder2019To2022Bit;
	    
	    // Add Payment Fields if required
	    
		public String getApplicationNo() {
			return applicationNo;
		}
		public void setApplicationNo(String applicationNo) {
			this.applicationNo = applicationNo;
		}
		public String getSchoolName() {
			return schoolName;
		}
		public void setSchoolName(String schoolName) {
			this.schoolName = schoolName;
		}
		public String getTransactionalAddress() {
			return transactionalAddress;
		}
		public void setTransactionalAddress(String transactionalAddress) {
			this.transactionalAddress = transactionalAddress;
		}
		public String getDistrict() {
			return district;
		}
		public void setDistrict(String district) {
			this.district = district;
		}
		public String getTaluka() {
			return taluka;
		}
		public void setTaluka(String taluka) {
			this.taluka = taluka;
		}
		public String getVillage() {
			return village;
		}
		public void setVillage(String village) {
			this.village = village;
		}
		public String getPincode() {
			return pincode;
		}
		public void setPincode(String pincode) {
			this.pincode = pincode;
		}
		public String getTelephoneNumber() {
			return telephoneNumber;
		}
		public void setTelephoneNumber(String telephoneNumber) {
			this.telephoneNumber = telephoneNumber;
		}
		public String getSchoolMobile() {
			return schoolMobile;
		}
		public void setSchoolMobile(String schoolMobile) {
			this.schoolMobile = schoolMobile;
		}
		public String getSchoolEmail() {
			return schoolEmail;
		}
		public void setSchoolEmail(String schoolEmail) {
			this.schoolEmail = schoolEmail;
		}
		public String getPoliceStation() {
			return policeStation;
		}
		public void setPoliceStation(String policeStation) {
			this.policeStation = policeStation;
		}
		public String getSchoolType() {
			return schoolType;
		}
		public void setSchoolType(String schoolType) {
			this.schoolType = schoolType;
		}
		public String getUdiseNo() {
			return udiseNo;
		}
		public void setUdiseNo(String udiseNo) {
			this.udiseNo = udiseNo;
		}
		public String getForWhichYearYouWantToApplyForACertificate() {
			return forWhichYearYouWantToApplyForACertificate;
		}
		public void setForWhichYearYouWantToApplyForACertificate(String forWhichYearYouWantToApplyForACertificate) {
			this.forWhichYearYouWantToApplyForACertificate = forWhichYearYouWantToApplyForACertificate;
		}
		public String getAddressMentionedInGovernmentApprovalDocument() {
			return addressMentionedInGovernmentApprovalDocument;
		}
		public void setAddressMentionedInGovernmentApprovalDocument(String addressMentionedInGovernmentApprovalDocument) {
			this.addressMentionedInGovernmentApprovalDocument = addressMentionedInGovernmentApprovalDocument;
		}
		public String getSchoolEstablishmentYear() {
			return schoolEstablishmentYear;
		}
		public void setSchoolEstablishmentYear(String schoolEstablishmentYear) {
			this.schoolEstablishmentYear = schoolEstablishmentYear;
		}
		public String getDateOfFirstOpeningOfSchool() {
			return dateOfFirstOpeningOfSchool;
		}
		public void setDateOfFirstOpeningOfSchool(String dateOfFirstOpeningOfSchool) {
			this.dateOfFirstOpeningOfSchool = dateOfFirstOpeningOfSchool;
		}
		public String getLowerStandard() {
			return lowerStandard;
		}
		public void setLowerStandard(String lowerStandard) {
			this.lowerStandard = lowerStandard;
		}
		public String getHigherStandard() {
			return higherStandard;
		}
		public void setHigherStandard(String higherStandard) {
			this.higherStandard = higherStandard;
		}
		public String getSchoolArea() {
			return schoolArea;
		}
		public void setSchoolArea(String schoolArea) {
			this.schoolArea = schoolArea;
		}
		public String getSimpleHigherStandard() {
			return simpleHigherStandard;
		}
		public void setSimpleHigherStandard(String simpleHigherStandard) {
			this.simpleHigherStandard = simpleHigherStandard;
		}
		public String getSimpleLowerStandard() {
			return simpleLowerStandard;
		}
		public void setSimpleLowerStandard(String simpleLowerStandard) {
			this.simpleLowerStandard = simpleLowerStandard;
		}
		public String getMediumOfInstruction() {
			return mediumOfInstruction;
		}
		public void setMediumOfInstruction(String mediumOfInstruction) {
			this.mediumOfInstruction = mediumOfInstruction;
		}
		public String getUdiseLowerStandard() {
			return udiseLowerStandard;
		}
		public void setUdiseLowerStandard(String udiseLowerStandard) {
			this.udiseLowerStandard = udiseLowerStandard;
		}
		public String getUdiseHigherStandard() {
			return udiseHigherStandard;
		}
		public void setUdiseHigherStandard(String udiseHigherStandard) {
			this.udiseHigherStandard = udiseHigherStandard;
		}
		public String getSchoolBoard() {
			return schoolBoard;
		}
		public void setSchoolBoard(String schoolBoard) {
			this.schoolBoard = schoolBoard;
		}
		public String getSchoolTimeFullTime() {
			return schoolTimeFullTime;
		}
		public void setSchoolTimeFullTime(String schoolTimeFullTime) {
			this.schoolTimeFullTime = schoolTimeFullTime;
		}
		public String getSchoolTimeHalfTime() {
			return schoolTimeHalfTime;
		}
		public void setSchoolTimeHalfTime(String schoolTimeHalfTime) {
			this.schoolTimeHalfTime = schoolTimeHalfTime;
		}
		public String getLunchTimeForEachClass() {
			return lunchTimeForEachClass;
		}
		public void setLunchTimeForEachClass(String lunchTimeForEachClass) {
			this.lunchTimeForEachClass = lunchTimeForEachClass;
		}
		public String getSangsthaCompanyName() {
			return sangsthaCompanyName;
		}
		public void setSangsthaCompanyName(String sangsthaCompanyName) {
			this.sangsthaCompanyName = sangsthaCompanyName;
		}
		public String getSansthaCompanyHasPurposeForOnlyEducationService() {
			return sansthaCompanyHasPurposeForOnlyEducationService;
		}
		public void setSansthaCompanyHasPurposeForOnlyEducationService(String sansthaCompanyHasPurposeForOnlyEducationService) {
			this.sansthaCompanyHasPurposeForOnlyEducationService = sansthaCompanyHasPurposeForOnlyEducationService;
		}
		public String getIsSchoolOpenWhereAddressMentionedInApproval() {
			return isSchoolOpenWhereAddressMentionedInApproval;
		}
		public void setIsSchoolOpenWhereAddressMentionedInApproval(String isSchoolOpenWhereAddressMentionedInApproval) {
			this.isSchoolOpenWhereAddressMentionedInApproval = isSchoolOpenWhereAddressMentionedInApproval;
		}
		public String getWhetherSchoolIsMovedToAnotherLocation() {
			return whetherSchoolIsMovedToAnotherLocation;
		}
		public void setWhetherSchoolIsMovedToAnotherLocation(String whetherSchoolIsMovedToAnotherLocation) {
			this.whetherSchoolIsMovedToAnotherLocation = whetherSchoolIsMovedToAnotherLocation;
		}
		public String getIfSansthaIsHandoverToSomeone() {
			return ifSansthaIsHandoverToSomeone;
		}
		public void setIfSansthaIsHandoverToSomeone(String ifSansthaIsHandoverToSomeone) {
			this.ifSansthaIsHandoverToSomeone = ifSansthaIsHandoverToSomeone;
		}
		public String getDoYouHaveMaharastraShashanManyataNo() {
			return doYouHaveMaharastraShashanManyataNo;
		}
		public void setDoYouHaveMaharastraShashanManyataNo(String doYouHaveMaharastraShashanManyataNo) {
			this.doYouHaveMaharastraShashanManyataNo = doYouHaveMaharastraShashanManyataNo;
		}
		public String getMaharastraShashanApprovalNumber() {
			return maharastraShashanApprovalNumber;
		}
		public void setMaharastraShashanApprovalNumber(String maharastraShashanApprovalNumber) {
			this.maharastraShashanApprovalNumber = maharastraShashanApprovalNumber;
		}
		public String getMaharastraShashanApprovalDate() {
			return maharastraShashanApprovalDate;
		}
		public void setMaharastraShashanApprovalDate(String maharastraShashanApprovalDate) {
			this.maharastraShashanApprovalDate = maharastraShashanApprovalDate;
		}
		public String getDoYouHaveShikshanUpsanchalakApproval() {
			return doYouHaveShikshanUpsanchalakApproval;
		}
		public void setDoYouHaveShikshanUpsanchalakApproval(String doYouHaveShikshanUpsanchalakApproval) {
			this.doYouHaveShikshanUpsanchalakApproval = doYouHaveShikshanUpsanchalakApproval;
		}
		public String getShikshanUpsanchalakApprovalNumber() {
			return shikshanUpsanchalakApprovalNumber;
		}
		public void setShikshanUpsanchalakApprovalNumber(String shikshanUpsanchalakApprovalNumber) {
			this.shikshanUpsanchalakApprovalNumber = shikshanUpsanchalakApprovalNumber;
		}
		public String getShikshanUpsanchalakApprovalDate() {
			return shikshanUpsanchalakApprovalDate;
		}
		public void setShikshanUpsanchalakApprovalDate(String shikshanUpsanchalakApprovalDate) {
			this.shikshanUpsanchalakApprovalDate = shikshanUpsanchalakApprovalDate;
		}
		public String getDoYouHavePrathamManyataCertificate() {
			return doYouHavePrathamManyataCertificate;
		}
		public void setDoYouHavePrathamManyataCertificate(String doYouHavePrathamManyataCertificate) {
			this.doYouHavePrathamManyataCertificate = doYouHavePrathamManyataCertificate;
		}
		public String getPrathamManyataNumber() {
			return prathamManyataNumber;
		}
		public void setPrathamManyataNumber(String prathamManyataNumber) {
			this.prathamManyataNumber = prathamManyataNumber;
		}
		public String getPrathamManyataDate() {
			return prathamManyataDate;
		}
		public void setPrathamManyataDate(String prathamManyataDate) {
			this.prathamManyataDate = prathamManyataDate;
		}
		public String getDoYouRunOnGovernmentNoObjectionCertificate() {
			return doYouRunOnGovernmentNoObjectionCertificate;
		}
		public void setDoYouRunOnGovernmentNoObjectionCertificate(String doYouRunOnGovernmentNoObjectionCertificate) {
			this.doYouRunOnGovernmentNoObjectionCertificate = doYouRunOnGovernmentNoObjectionCertificate;
		}
		public String getNoObjectionCertificateNumber() {
			return noObjectionCertificateNumber;
		}
		public void setNoObjectionCertificateNumber(String noObjectionCertificateNumber) {
			this.noObjectionCertificateNumber = noObjectionCertificateNumber;
		}
		public String getNoObjectionCertificateDate() {
			return noObjectionCertificateDate;
		}
		public void setNoObjectionCertificateDate(String noObjectionCertificateDate) {
			this.noObjectionCertificateDate = noObjectionCertificateDate;
		}
		public String getIsThereAnAffiliationCertificate() {
			return isThereAnAffiliationCertificate;
		}
		public void setIsThereAnAffiliationCertificate(String isThereAnAffiliationCertificate) {
			this.isThereAnAffiliationCertificate = isThereAnAffiliationCertificate;
		}
		public String getAffiliationCertificateNumber() {
			return affiliationCertificateNumber;
		}
		public void setAffiliationCertificateNumber(String affiliationCertificateNumber) {
			this.affiliationCertificateNumber = affiliationCertificateNumber;
		}
		public String getAffiliationCertificateDate() {
			return affiliationCertificateDate;
		}
		public void setAffiliationCertificateDate(String affiliationCertificateDate) {
			this.affiliationCertificateDate = affiliationCertificateDate;
		}
		public String getSchoolUserName() {
			return schoolUserName;
		}
		public void setSchoolUserName(String schoolUserName) {
			this.schoolUserName = schoolUserName;
		}
		public String getSchoolUserDesignation() {
			return schoolUserDesignation;
		}
		public void setSchoolUserDesignation(String schoolUserDesignation) {
			this.schoolUserDesignation = schoolUserDesignation;
		}
		public String getSchoolUserAddress() {
			return schoolUserAddress;
		}
		public void setSchoolUserAddress(String schoolUserAddress) {
			this.schoolUserAddress = schoolUserAddress;
		}
		public String getSchoolUserTelephone() {
			return schoolUserTelephone;
		}
		public void setSchoolUserTelephone(String schoolUserTelephone) {
			this.schoolUserTelephone = schoolUserTelephone;
		}
		public String getTypeOfProofAvailableAndItsDate() {
			return typeOfProofAvailableAndItsDate;
		}
		public void setTypeOfProofAvailableAndItsDate(String typeOfProofAvailableAndItsDate) {
			this.typeOfProofAvailableAndItsDate = typeOfProofAvailableAndItsDate;
		}
		public String getForYouTakePropertyDocumentType() {
			return forYouTakePropertyDocumentType;
		}
		public void setForYouTakePropertyDocumentType(String forYouTakePropertyDocumentType) {
			this.forYouTakePropertyDocumentType = forYouTakePropertyDocumentType;
		}
		public String getAreaSqM() {
			return areaSqM;
		}
		public void setAreaSqM(String areaSqM) {
			this.areaSqM = areaSqM;
		}
		public String getTotalAreaSqM() {
			return totalAreaSqM;
		}
		public void setTotalAreaSqM(String totalAreaSqM) {
			this.totalAreaSqM = totalAreaSqM;
		}
		public String getSchoolTotalAreaSqM() {
			return schoolTotalAreaSqM;
		}
		public void setSchoolTotalAreaSqM(String schoolTotalAreaSqM) {
			this.schoolTotalAreaSqM = schoolTotalAreaSqM;
		}
		public String getPrincipalCount() {
			return principalCount;
		}
		public void setPrincipalCount(String principalCount) {
			this.principalCount = principalCount;
		}
		public String getPrincipalArea() {
			return principalArea;
		}
		public void setPrincipalArea(String principalArea) {
			this.principalArea = principalArea;
		}
		public String getOfficeCount() {
			return officeCount;
		}
		public void setOfficeCount(String officeCount) {
			this.officeCount = officeCount;
		}
		public String getOfficeArea() {
			return officeArea;
		}
		public void setOfficeArea(String officeArea) {
			this.officeArea = officeArea;
		}
		public String getStaffCount() {
			return staffCount;
		}
		public void setStaffCount(String staffCount) {
			this.staffCount = staffCount;
		}
		public String getStaffArea() {
			return staffArea;
		}
		public void setStaffArea(String staffArea) {
			this.staffArea = staffArea;
		}
		public String getStorageCount() {
			return storageCount;
		}
		public void setStorageCount(String storageCount) {
			this.storageCount = storageCount;
		}
		public String getStorageArea() {
			return storageArea;
		}
		public void setStorageArea(String storageArea) {
			this.storageArea = storageArea;
		}
		public String getClassroom() {
			return classroom;
		}
		public void setClassroom(String classroom) {
			this.classroom = classroom;
		}
		public String getClassroomArea() {
			return classroomArea;
		}
		public void setClassroomArea(String classroomArea) {
			this.classroomArea = classroomArea;
		}
		public String getLabCount() {
			return labCount;
		}
		public void setLabCount(String labCount) {
			this.labCount = labCount;
		}
		public String getLabArea() {
			return labArea;
		}
		public void setLabArea(String labArea) {
			this.labArea = labArea;
		}
		public String getCompCount() {
			return compCount;
		}
		public void setCompCount(String compCount) {
			this.compCount = compCount;
		}
		public String getCompArea() {
			return compArea;
		}
		public void setCompArea(String compArea) {
			this.compArea = compArea;
		}
		public String getLibraryCount() {
			return libraryCount;
		}
		public void setLibraryCount(String libraryCount) {
			this.libraryCount = libraryCount;
		}
		public String getLibraryArea() {
			return libraryArea;
		}
		public void setLibraryArea(String libraryArea) {
			this.libraryArea = libraryArea;
		}
		public String getSchoolTotalCount() {
			return schoolTotalCount;
		}
		public void setSchoolTotalCount(String schoolTotalCount) {
			this.schoolTotalCount = schoolTotalCount;
		}
		public String getSchoolTotalArea() {
			return schoolTotalArea;
		}
		public void setSchoolTotalArea(String schoolTotalArea) {
			this.schoolTotalArea = schoolTotalArea;
		}
		public String getWesternToiletCount() {
			return westernToiletCount;
		}
		public void setWesternToiletCount(String westernToiletCount) {
			this.westernToiletCount = westernToiletCount;
		}
		public String getToiletAvailableFacilityDetails() {
			return toiletAvailableFacilityDetails;
		}
		public void setToiletAvailableFacilityDetails(String toiletAvailableFacilityDetails) {
			this.toiletAvailableFacilityDetails = toiletAvailableFacilityDetails;
		}
		public String getSeperateBoysToiletCount() {
			return seperateBoysToiletCount;
		}
		public void setSeperateBoysToiletCount(String seperateBoysToiletCount) {
			this.seperateBoysToiletCount = seperateBoysToiletCount;
		}
		public String getSeperateBoysToiletFacilityDetails() {
			return seperateBoysToiletFacilityDetails;
		}
		public void setSeperateBoysToiletFacilityDetails(String seperateBoysToiletFacilityDetails) {
			this.seperateBoysToiletFacilityDetails = seperateBoysToiletFacilityDetails;
		}
		public String getSeperateBoysWashroomCount() {
			return seperateBoysWashroomCount;
		}
		public void setSeperateBoysWashroomCount(String seperateBoysWashroomCount) {
			this.seperateBoysWashroomCount = seperateBoysWashroomCount;
		}
		public String getSeperateBoysWashroomFacilityDetails() {
			return seperateBoysWashroomFacilityDetails;
		}
		public void setSeperateBoysWashroomFacilityDetails(String seperateBoysWashroomFacilityDetails) {
			this.seperateBoysWashroomFacilityDetails = seperateBoysWashroomFacilityDetails;
		}
		public String getSeperateBoysDrinkingWaterCount() {
			return seperateBoysDrinkingWaterCount;
		}
		public void setSeperateBoysDrinkingWaterCount(String seperateBoysDrinkingWaterCount) {
			this.seperateBoysDrinkingWaterCount = seperateBoysDrinkingWaterCount;
		}
		public String getSeperateBoysDrinkingWaterFacilityDetails() {
			return seperateBoysDrinkingWaterFacilityDetails;
		}
		public void setSeperateBoysDrinkingWaterFacilityDetails(String seperateBoysDrinkingWaterFacilityDetails) {
			this.seperateBoysDrinkingWaterFacilityDetails = seperateBoysDrinkingWaterFacilityDetails;
		}
		public String getSeperateGirlsToiletCount() {
			return seperateGirlsToiletCount;
		}
		public void setSeperateGirlsToiletCount(String seperateGirlsToiletCount) {
			this.seperateGirlsToiletCount = seperateGirlsToiletCount;
		}
		public String getSeperateGirlsToiletFacilityDetails() {
			return seperateGirlsToiletFacilityDetails;
		}
		public void setSeperateGirlsToiletFacilityDetails(String seperateGirlsToiletFacilityDetails) {
			this.seperateGirlsToiletFacilityDetails = seperateGirlsToiletFacilityDetails;
		}
		public String getSeperateGirlsWashroomCount() {
			return seperateGirlsWashroomCount;
		}
		public void setSeperateGirlsWashroomCount(String seperateGirlsWashroomCount) {
			this.seperateGirlsWashroomCount = seperateGirlsWashroomCount;
		}
		public String getSeperateGirlsWashroomFacilityDetails() {
			return seperateGirlsWashroomFacilityDetails;
		}
		public void setSeperateGirlsWashroomFacilityDetails(String seperateGirlsWashroomFacilityDetails) {
			this.seperateGirlsWashroomFacilityDetails = seperateGirlsWashroomFacilityDetails;
		}
		public String getSeperateGirlsDrinkingWaterCount() {
			return seperateGirlsDrinkingWaterCount;
		}
		public void setSeperateGirlsDrinkingWaterCount(String seperateGirlsDrinkingWaterCount) {
			this.seperateGirlsDrinkingWaterCount = seperateGirlsDrinkingWaterCount;
		}
		public String getSeperateGirlsDrinkingWaterFacilityDetails() {
			return seperateGirlsDrinkingWaterFacilityDetails;
		}
		public void setSeperateGirlsDrinkingWaterFacilityDetails(String seperateGirlsDrinkingWaterFacilityDetails) {
			this.seperateGirlsDrinkingWaterFacilityDetails = seperateGirlsDrinkingWaterFacilityDetails;
		}
		public String getWaterTapCount() {
			return waterTapCount;
		}
		public void setWaterTapCount(String waterTapCount) {
			this.waterTapCount = waterTapCount;
		}
		public String getWaterTankCapacity() {
			return waterTankCapacity;
		}
		public void setWaterTankCapacity(String waterTankCapacity) {
			this.waterTankCapacity = waterTankCapacity;
		}
		public String getActualAvailableFacilityDetailsTap() {
			return actualAvailableFacilityDetailsTap;
		}
		public void setActualAvailableFacilityDetailsTap(String actualAvailableFacilityDetailsTap) {
			this.actualAvailableFacilityDetailsTap = actualAvailableFacilityDetailsTap;
		}
		public String getActualAvailableFacilityDetailsWater() {
			return actualAvailableFacilityDetailsWater;
		}
		public void setActualAvailableFacilityDetailsWater(String actualAvailableFacilityDetailsWater) {
			this.actualAvailableFacilityDetailsWater = actualAvailableFacilityDetailsWater;
		}
		public String getAreaOfPlaygroundDetails() {
			return areaOfPlaygroundDetails;
		}
		public void setAreaOfPlaygroundDetails(String areaOfPlaygroundDetails) {
			this.areaOfPlaygroundDetails = areaOfPlaygroundDetails;
		}
		public String getAreaOfPlayground() {
			return areaOfPlayground;
		}
		public void setAreaOfPlayground(String areaOfPlayground) {
			this.areaOfPlayground = areaOfPlayground;
		}
		public String getRetainingWallCompound() {
			return retainingWallCompound;
		}
		public void setRetainingWallCompound(String retainingWallCompound) {
			this.retainingWallCompound = retainingWallCompound;
		}
		public String getEntranceWithProtectiveWallAndIronGate() {
			return entranceWithProtectiveWallAndIronGate;
		}
		public void setEntranceWithProtectiveWallAndIronGate(String entranceWithProtectiveWallAndIronGate) {
			this.entranceWithProtectiveWallAndIronGate = entranceWithProtectiveWallAndIronGate;
		}
		public String getKitchenShed() {
			return kitchenShed;
		}
		public void setKitchenShed(String kitchenShed) {
			this.kitchenShed = kitchenShed;
		}
		public String getaRampForBarrierFreeAccess() {
			return aRampForBarrierFreeAccess;
		}
		public void setaRampForBarrierFreeAccess(String aRampForBarrierFreeAccess) {
			this.aRampForBarrierFreeAccess = aRampForBarrierFreeAccess;
		}
		public String getRocksOnTheSideOfTheRamp() {
			return rocksOnTheSideOfTheRamp;
		}
		public void setRocksOnTheSideOfTheRamp(String rocksOnTheSideOfTheRamp) {
			this.rocksOnTheSideOfTheRamp = rocksOnTheSideOfTheRamp;
		}
		public String getClassroomCount() {
			return classroomCount;
		}
		public void setClassroomCount(String classroomCount) {
			this.classroomCount = classroomCount;
		}
		public String getKitchenShedDetails() {
			return kitchenShedDetails;
		}
		public void setKitchenShedDetails(String kitchenShedDetails) {
			this.kitchenShedDetails = kitchenShedDetails;
		}
		public String getTheRoofIsSolidRcc() {
			return theRoofIsSolidRcc;
		}
		public void setTheRoofIsSolidRcc(String theRoofIsSolidRcc) {
			this.theRoofIsSolidRcc = theRoofIsSolidRcc;
		}
		public String getFireWarrantyCylinderNo() {
			return fireWarrantyCylinderNo;
		}
		public void setFireWarrantyCylinderNo(String fireWarrantyCylinderNo) {
			this.fireWarrantyCylinderNo = fireWarrantyCylinderNo;
		}
		public String getMedicalPrimaryBoxNumber() {
			return medicalPrimaryBoxNumber;
		}
		public void setMedicalPrimaryBoxNumber(String medicalPrimaryBoxNumber) {
			this.medicalPrimaryBoxNumber = medicalPrimaryBoxNumber;
		}
		public String getPlaquesInFacadesOfSchoolRecognition() {
			return plaquesInFacadesOfSchoolRecognition;
		}
		public void setPlaquesInFacadesOfSchoolRecognition(String plaquesInFacadesOfSchoolRecognition) {
			this.plaquesInFacadesOfSchoolRecognition = plaquesInFacadesOfSchoolRecognition;
		}
		public String getMinimum200DaysOf800ClockHoursForPrimaryAndHigher() {
			return minimum200DaysOf800ClockHoursForPrimaryAndHigher;
		}
		public void setMinimum200DaysOf800ClockHoursForPrimaryAndHigher(
				String minimum200DaysOf800ClockHoursForPrimaryAndHigher) {
			this.minimum200DaysOf800ClockHoursForPrimaryAndHigher = minimum200DaysOf800ClockHoursForPrimaryAndHigher;
		}
		public String getHoursOfTeachingPerWeek() {
			return hoursOfTeachingPerWeek;
		}
		public void setHoursOfTeachingPerWeek(String hoursOfTeachingPerWeek) {
			this.hoursOfTeachingPerWeek = hoursOfTeachingPerWeek;
		}
		public String getSufficientEducationalMaterialInEachClassAsRequired() {
			return sufficientEducationalMaterialInEachClassAsRequired;
		}
		public void setSufficientEducationalMaterialInEachClassAsRequired(
				String sufficientEducationalMaterialInEachClassAsRequired) {
			this.sufficientEducationalMaterialInEachClassAsRequired = sufficientEducationalMaterialInEachClassAsRequired;
		}
		public String getNumberOfReferenceBooksAvailableForTeacherTraining() {
			return numberOfReferenceBooksAvailableForTeacherTraining;
		}
		public void setNumberOfReferenceBooksAvailableForTeacherTraining(
				String numberOfReferenceBooksAvailableForTeacherTraining) {
			this.numberOfReferenceBooksAvailableForTeacherTraining = numberOfReferenceBooksAvailableForTeacherTraining;
		}
		public String getNumberOfBooksAvailableForStudentReadingInTheLibrary() {
			return numberOfBooksAvailableForStudentReadingInTheLibrary;
		}
		public void setNumberOfBooksAvailableForStudentReadingInTheLibrary(
				String numberOfBooksAvailableForStudentReadingInTheLibrary) {
			this.numberOfBooksAvailableForStudentReadingInTheLibrary = numberOfBooksAvailableForStudentReadingInTheLibrary;
		}
		public String getMagzinBooksCount() {
			return magzinBooksCount;
		}
		public void setMagzinBooksCount(String magzinBooksCount) {
			this.magzinBooksCount = magzinBooksCount;
		}
		public String getNewspaperAndTotalCount() {
			return newspaperAndTotalCount;
		}
		public void setNewspaperAndTotalCount(String newspaperAndTotalCount) {
			this.newspaperAndTotalCount = newspaperAndTotalCount;
		}
		public String getGrantedGovernmentDecisionOfApproval() {
			return grantedGovernmentDecisionOfApproval;
		}
		public void setGrantedGovernmentDecisionOfApproval(String grantedGovernmentDecisionOfApproval) {
			this.grantedGovernmentDecisionOfApproval = grantedGovernmentDecisionOfApproval;
		}
		public String getGrantedApprovalOrderOfDeputyDirectorOfEducation() {
			return grantedApprovalOrderOfDeputyDirectorOfEducation;
		}
		public void setGrantedApprovalOrderOfDeputyDirectorOfEducation(String grantedApprovalOrderOfDeputyDirectorOfEducation) {
			this.grantedApprovalOrderOfDeputyDirectorOfEducation = grantedApprovalOrderOfDeputyDirectorOfEducation;
		}
		public String getGrantedFirstApprovalOrder() {
			return grantedFirstApprovalOrder;
		}
		public void setGrantedFirstApprovalOrder(String grantedFirstApprovalOrder) {
			this.grantedFirstApprovalOrder = grantedFirstApprovalOrder;
		}
		public String getGrantedOrganizationsRequisitionApplicationInSample1() {
			return grantedOrganizationsRequisitionApplicationInSample1;
		}
		public void setGrantedOrganizationsRequisitionApplicationInSample1(
				String grantedOrganizationsRequisitionApplicationInSample1) {
			this.grantedOrganizationsRequisitionApplicationInSample1 = grantedOrganizationsRequisitionApplicationInSample1;
		}
		public String getGrantedInstitutionRegistration19501860Certificate() {
			return grantedInstitutionRegistration19501860Certificate;
		}
		public void setGrantedInstitutionRegistration19501860Certificate(
				String grantedInstitutionRegistration19501860Certificate) {
			this.grantedInstitutionRegistration19501860Certificate = grantedInstitutionRegistration19501860Certificate;
		}
		public String getGrantedGovtMinorityCertificateIfTheSchoolIsMinority() {
			return grantedGovtMinorityCertificateIfTheSchoolIsMinority;
		}
		public void setGrantedGovtMinorityCertificateIfTheSchoolIsMinority(
				String grantedGovtMinorityCertificateIfTheSchoolIsMinority) {
			this.grantedGovtMinorityCertificateIfTheSchoolIsMinority = grantedGovtMinorityCertificateIfTheSchoolIsMinority;
		}
		public String getGrantedPurchaseDeedLeaseAgreementAwardDeed() {
			return grantedPurchaseDeedLeaseAgreementAwardDeed;
		}
		public void setGrantedPurchaseDeedLeaseAgreementAwardDeed(String grantedPurchaseDeedLeaseAgreementAwardDeed) {
			this.grantedPurchaseDeedLeaseAgreementAwardDeed = grantedPurchaseDeedLeaseAgreementAwardDeed;
		}
		public String getGrantedCertificationOfJoiningIfAdditionalTeacher() {
			return grantedCertificationOfJoiningIfAdditionalTeacher;
		}
		public void setGrantedCertificationOfJoiningIfAdditionalTeacher(
				String grantedCertificationOfJoiningIfAdditionalTeacher) {
			this.grantedCertificationOfJoiningIfAdditionalTeacher = grantedCertificationOfJoiningIfAdditionalTeacher;
		}
		public String getGrantedInstitutionalUndertakingOfSchoolsNotChargingAny() {
			return grantedInstitutionalUndertakingOfSchoolsNotChargingAny;
		}
		public void setGrantedInstitutionalUndertakingOfSchoolsNotChargingAny(
				String grantedInstitutionalUndertakingOfSchoolsNotChargingAny) {
			this.grantedInstitutionalUndertakingOfSchoolsNotChargingAny = grantedInstitutionalUndertakingOfSchoolsNotChargingAny;
		}
		public String getGrantedWomenGrievanceRedressalCommittee() {
			return grantedWomenGrievanceRedressalCommittee;
		}
		public void setGrantedWomenGrievanceRedressalCommittee(String grantedWomenGrievanceRedressalCommittee) {
			this.grantedWomenGrievanceRedressalCommittee = grantedWomenGrievanceRedressalCommittee;
		}
		public String getGrantedAffidavitOnStampOfRs100() {
			return grantedAffidavitOnStampOfRs100;
		}
		public void setGrantedAffidavitOnStampOfRs100(String grantedAffidavitOnStampOfRs100) {
			this.grantedAffidavitOnStampOfRs100 = grantedAffidavitOnStampOfRs100;
		}
		public String getGrantedSchoolPrincipalSignStamp() {
			return grantedSchoolPrincipalSignStamp;
		}
		public void setGrantedSchoolPrincipalSignStamp(String grantedSchoolPrincipalSignStamp) {
			this.grantedSchoolPrincipalSignStamp = grantedSchoolPrincipalSignStamp;
		}
		public String getGrantedCommonOrder2013To2016Bit() {
			return grantedCommonOrder2013To2016Bit;
		}
		public void setGrantedCommonOrder2013To2016Bit(String grantedCommonOrder2013To2016Bit) {
			this.grantedCommonOrder2013To2016Bit = grantedCommonOrder2013To2016Bit;
		}
		public String getGrantedCommonOrder2016To2019Bit() {
			return grantedCommonOrder2016To2019Bit;
		}
		public void setGrantedCommonOrder2016To2019Bit(String grantedCommonOrder2016To2019Bit) {
			this.grantedCommonOrder2016To2019Bit = grantedCommonOrder2016To2019Bit;
		}
		public String getGrantedCommonOrder2019To2022Bit() {
			return grantedCommonOrder2019To2022Bit;
		}
		public void setGrantedCommonOrder2019To2022Bit(String grantedCommonOrder2019To2022Bit) {
			this.grantedCommonOrder2019To2022Bit = grantedCommonOrder2019To2022Bit;
		}
		public String getNonGrantedGovernmentDecisionOfApproval() {
			return nonGrantedGovernmentDecisionOfApproval;
		}
		public void setNonGrantedGovernmentDecisionOfApproval(String nonGrantedGovernmentDecisionOfApproval) {
			this.nonGrantedGovernmentDecisionOfApproval = nonGrantedGovernmentDecisionOfApproval;
		}
		public String getNonGrantedApprovalOrderOfDeputyDirectorOfEducation() {
			return nonGrantedApprovalOrderOfDeputyDirectorOfEducation;
		}
		public void setNonGrantedApprovalOrderOfDeputyDirectorOfEducation(
				String nonGrantedApprovalOrderOfDeputyDirectorOfEducation) {
			this.nonGrantedApprovalOrderOfDeputyDirectorOfEducation = nonGrantedApprovalOrderOfDeputyDirectorOfEducation;
		}
		public String getNonGrantedFirstApprovalOrder() {
			return nonGrantedFirstApprovalOrder;
		}
		public void setNonGrantedFirstApprovalOrder(String nonGrantedFirstApprovalOrder) {
			this.nonGrantedFirstApprovalOrder = nonGrantedFirstApprovalOrder;
		}
		public String getNonGrantedOrganizationsRequisitionApplicationInSample1() {
			return nonGrantedOrganizationsRequisitionApplicationInSample1;
		}
		public void setNonGrantedOrganizationsRequisitionApplicationInSample1(
				String nonGrantedOrganizationsRequisitionApplicationInSample1) {
			this.nonGrantedOrganizationsRequisitionApplicationInSample1 = nonGrantedOrganizationsRequisitionApplicationInSample1;
		}
		public String getNonGrantedJointAccountRetentionReceiptOfInstitution() {
			return nonGrantedJointAccountRetentionReceiptOfInstitution;
		}
		public void setNonGrantedJointAccountRetentionReceiptOfInstitution(
				String nonGrantedJointAccountRetentionReceiptOfInstitution) {
			this.nonGrantedJointAccountRetentionReceiptOfInstitution = nonGrantedJointAccountRetentionReceiptOfInstitution;
		}
		public String getNonGrantedOrganizationCompanyRegistrationCertificate() {
			return nonGrantedOrganizationCompanyRegistrationCertificate;
		}
		public void setNonGrantedOrganizationCompanyRegistrationCertificate(
				String nonGrantedOrganizationCompanyRegistrationCertificate) {
			this.nonGrantedOrganizationCompanyRegistrationCertificate = nonGrantedOrganizationCompanyRegistrationCertificate;
		}
		public String getNonGrantedGovtMinorityCertificate() {
			return nonGrantedGovtMinorityCertificate;
		}
		public void setNonGrantedGovtMinorityCertificate(String nonGrantedGovtMinorityCertificate) {
			this.nonGrantedGovtMinorityCertificate = nonGrantedGovtMinorityCertificate;
		}
		public String getNonGrantedPurchaseDeedLeaseAgreementAward() {
			return nonGrantedPurchaseDeedLeaseAgreementAward;
		}
		public void setNonGrantedPurchaseDeedLeaseAgreementAward(String nonGrantedPurchaseDeedLeaseAgreementAward) {
			this.nonGrantedPurchaseDeedLeaseAgreementAward = nonGrantedPurchaseDeedLeaseAgreementAward;
		}
		public String getNonGrantedAuditReport() {
			return nonGrantedAuditReport;
		}
		public void setNonGrantedAuditReport(String nonGrantedAuditReport) {
			this.nonGrantedAuditReport = nonGrantedAuditReport;
		}
		public String getNonGrantedCopyOfEptaApprovalMinutes() {
			return nonGrantedCopyOfEptaApprovalMinutes;
		}
		public void setNonGrantedCopyOfEptaApprovalMinutes(String nonGrantedCopyOfEptaApprovalMinutes) {
			this.nonGrantedCopyOfEptaApprovalMinutes = nonGrantedCopyOfEptaApprovalMinutes;
		}
		public String getNonGrantedFreeStructureAccordingToPrevious() {
			return nonGrantedFreeStructureAccordingToPrevious;
		}
		public void setNonGrantedFreeStructureAccordingToPrevious(String nonGrantedFreeStructureAccordingToPrevious) {
			this.nonGrantedFreeStructureAccordingToPrevious = nonGrantedFreeStructureAccordingToPrevious;
		}
		public String getNonGrantedTransportCommitteeOnlineCopy() {
			return nonGrantedTransportCommitteeOnlineCopy;
		}
		public void setNonGrantedTransportCommitteeOnlineCopy(String nonGrantedTransportCommitteeOnlineCopy) {
			this.nonGrantedTransportCommitteeOnlineCopy = nonGrantedTransportCommitteeOnlineCopy;
		}
		public String getNonGrantedWomenGrievanceRedressalCommittee() {
			return nonGrantedWomenGrievanceRedressalCommittee;
		}
		public void setNonGrantedWomenGrievanceRedressalCommittee(String nonGrantedWomenGrievanceRedressalCommittee) {
			this.nonGrantedWomenGrievanceRedressalCommittee = nonGrantedWomenGrievanceRedressalCommittee;
		}
		public String getNonGrantedAffidavitOnStampOfRs100() {
			return nonGrantedAffidavitOnStampOfRs100;
		}
		public void setNonGrantedAffidavitOnStampOfRs100(String nonGrantedAffidavitOnStampOfRs100) {
			this.nonGrantedAffidavitOnStampOfRs100 = nonGrantedAffidavitOnStampOfRs100;
		}
		public String getNonGrantedSchoolPrincipalSignStamp() {
			return nonGrantedSchoolPrincipalSignStamp;
		}
		public void setNonGrantedSchoolPrincipalSignStamp(String nonGrantedSchoolPrincipalSignStamp) {
			this.nonGrantedSchoolPrincipalSignStamp = nonGrantedSchoolPrincipalSignStamp;
		}
		public String getNonGrantedCommonOrder2013To2016Bit() {
			return nonGrantedCommonOrder2013To2016Bit;
		}
		public void setNonGrantedCommonOrder2013To2016Bit(String nonGrantedCommonOrder2013To2016Bit) {
			this.nonGrantedCommonOrder2013To2016Bit = nonGrantedCommonOrder2013To2016Bit;
		}
		public String getNonGrantedCommonOrder2016To2019Bit() {
			return nonGrantedCommonOrder2016To2019Bit;
		}
		public void setNonGrantedCommonOrder2016To2019Bit(String nonGrantedCommonOrder2016To2019Bit) {
			this.nonGrantedCommonOrder2016To2019Bit = nonGrantedCommonOrder2016To2019Bit;
		}
		public String getNonGrantedCommonOrder2019To2022Bit() {
			return nonGrantedCommonOrder2019To2022Bit;
		}
		public void setNonGrantedCommonOrder2019To2022Bit(String nonGrantedCommonOrder2019To2022Bit) {
			this.nonGrantedCommonOrder2019To2022Bit = nonGrantedCommonOrder2019To2022Bit;
		}
		public String getCctvNo() {
			return cctvNo;
		}
		public void setCctvNo(String cctvNo) {
			this.cctvNo = cctvNo;
		}
		public String getInstitutionRegistration19501860Certificate() {
			return institutionRegistration19501860Certificate;
		}
		public void setInstitutionRegistration19501860Certificate(String institutionRegistration19501860Certificate) {
			this.institutionRegistration19501860Certificate = institutionRegistration19501860Certificate;
		}
		public String getNumberOfSportsAndSportsLiterature() {
			return numberOfSportsAndSportsLiterature;
		}
		public void setNumberOfSportsAndSportsLiterature(String numberOfSportsAndSportsLiterature) {
			this.numberOfSportsAndSportsLiterature = numberOfSportsAndSportsLiterature;
		}
	}
