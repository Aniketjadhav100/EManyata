package com.emanyata.app.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ApplicationFormStepsUtil {

    private final ObjectMapper mapper = new ObjectMapper();

    public String updateStepsJson(String existingStepsJson, String formKey) {
        Map<String, String> stepsMap = new HashMap<>();

        // Parse existing JSON if available
        if (existingStepsJson != null && !existingStepsJson.isBlank()) {
            try {
                stepsMap = mapper.readValue(existingStepsJson, new TypeReference<>() {});
            } catch (Exception e) {
                // optional: log error
            }
        }

        // Format: 23 Jan, 2024 05:35
        String timestamp = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("dd MMM, yyyy HH:mm"));

        stepsMap.put(formKey, timestamp);

        try {
            return mapper.writeValueAsString(stepsMap);
        } catch (JsonProcessingException e) {
            return existingStepsJson; // fallback
        }
    }
}
