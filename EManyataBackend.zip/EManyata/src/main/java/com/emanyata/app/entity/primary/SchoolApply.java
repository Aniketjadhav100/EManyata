package com.emanyata.app.entity.primary;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.hibernate.annotations.ColumnDefault;

import java.time.LocalDateTime;
import java.time.LocalDate;

@Entity
@Table(name = "school_applies", schema = "emanyata", uniqueConstraints = {
        @UniqueConstraint(name = "school_applies_application_no_unique", columnNames = {"application_no"})
})
public class SchoolApply {
    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

    @NotNull
    @Lob
    @Column(name = "apply_status", nullable = false)
    private String applyStatus;

    @Size(max = 255)
    @Column(name = "token")
    private String token;

    @Size(max = 255)
    @Column(name = "status")
    private String status;

    @Size(max = 255)
    @Column(name = "inspection_status")
    private String inspectionStatus;

    @Column(name = "inspection_completion_date")
    private LocalDate inspectionCompletionDate;

    @Size(max = 191)
    @NotNull
    @Column(name = "application_no", nullable = false, length = 191)
    private String applicationNo;

    @Size(max = 255)
    @ColumnDefault("'2023-06-22'")
    @Column(name = "visiting_date")
    private String visitingDate;

    @Column(name = "inspection_office_id")
    private Integer inspectionOfficeId;

    @Column(name = "submitted_date")
    private LocalDate submittedDate;

    @Size(max = 255)
    @Column(name = "approved_date")
    private String approvedDate;

    @Size(max = 255)
    @Column(name = "expired_date")
    private String expiredDate;

    @Column(name = "renew_date")
    private LocalDate renewDate;

    @Lob
    @Column(name = "steps")
    private String steps;

    @Size(max = 255)
    @Column(name = "turti_pdf")
    private String turtiPdf;

    @Size(max = 255)
    @Column(name = "tipani_pdf")
    private String tipaniPdf;

    @Size(max = 255)
    @Column(name = "school_inspection_pdf")
    private String schoolInspectionPdf;

    @Column(name = "doc_available_verified")
    private Boolean docAvailableVerified;

    @Column(name = "RTE_2009_followed")
    private Boolean rte2009Followed;

    @Column(name = "Namuna_2_doc")
    private Boolean namuna2Doc;

    @Lob
    @Column(name = "officer_comment")
    private String officerComment;

    @Lob
    @Column(name = "abhipray_pdf")
    private String abhiprayPdf;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public School getSchool() {
        return school;
    }

    public void setSchool(School school) {
        this.school = school;
    }

    public String getApplyStatus() {
        return applyStatus;
    }

    public void setApplyStatus(String applyStatus) {
        this.applyStatus = applyStatus;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getInspectionStatus() {
        return inspectionStatus;
    }

    public void setInspectionStatus(String inspectionStatus) {
        this.inspectionStatus = inspectionStatus;
    }

    public LocalDate getInspectionCompletionDate() {
        return inspectionCompletionDate;
    }

    public void setInspectionCompletionDate(LocalDate inspectionCompletionDate) {
        this.inspectionCompletionDate = inspectionCompletionDate;
    }

    public String getApplicationNo() {
        return applicationNo;
    }

    public void setApplicationNo(String applicationNo) {
        this.applicationNo = applicationNo;
    }

    public String getVisitingDate() {
        return visitingDate;
    }

    public void setVisitingDate(String visitingDate) {
        this.visitingDate = visitingDate;
    }

    public Integer getInspectionOfficeId() {
        return inspectionOfficeId;
    }

    public void setInspectionOfficeId(Integer inspectionOfficeId) {
        this.inspectionOfficeId = inspectionOfficeId;
    }

    public LocalDate getSubmittedDate() {
        return submittedDate;
    }

    public void setSubmittedDate(LocalDate submittedDate) {
        this.submittedDate = submittedDate;
    }

    public String getApprovedDate() {
        return approvedDate;
    }

    public void setApprovedDate(String approvedDate) {
        this.approvedDate = approvedDate;
    }

    public String getExpiredDate() {
        return expiredDate;
    }

    public void setExpiredDate(String expiredDate) {
        this.expiredDate = expiredDate;
    }

    public LocalDate getRenewDate() {
        return renewDate;
    }

    public void setRenewDate(LocalDate renewDate) {
        this.renewDate = renewDate;
    }

    public String getSteps() {
        return steps;
    }

    public void setSteps(String steps) {
        this.steps = steps;
    }

    public String getTurtiPdf() {
        return turtiPdf;
    }

    public void setTurtiPdf(String turtiPdf) {
        this.turtiPdf = turtiPdf;
    }

    public String getTipaniPdf() {
        return tipaniPdf;
    }

    public void setTipaniPdf(String tipaniPdf) {
        this.tipaniPdf = tipaniPdf;
    }

    public String getSchoolInspectionPdf() {
        return schoolInspectionPdf;
    }

    public void setSchoolInspectionPdf(String schoolInspectionPdf) {
        this.schoolInspectionPdf = schoolInspectionPdf;
    }

    public Boolean getDocAvailableVerified() {
        return docAvailableVerified;
    }

    public void setDocAvailableVerified(Boolean docAvailableVerified) {
        this.docAvailableVerified = docAvailableVerified;
    }

    public Boolean getRte2009Followed() {
        return rte2009Followed;
    }

    public void setRte2009Followed(Boolean rte2009Followed) {
        this.rte2009Followed = rte2009Followed;
    }

    public Boolean getNamuna2Doc() {
        return namuna2Doc;
    }

    public void setNamuna2Doc(Boolean namuna2Doc) {
        this.namuna2Doc = namuna2Doc;
    }

    public String getOfficerComment() {
        return officerComment;
    }

    public void setOfficerComment(String officerComment) {
        this.officerComment = officerComment;
    }

    public String getAbhiprayPdf() {
        return abhiprayPdf;
    }

    public void setAbhiprayPdf(String abhiprayPdf) {
        this.abhiprayPdf = abhiprayPdf;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

}