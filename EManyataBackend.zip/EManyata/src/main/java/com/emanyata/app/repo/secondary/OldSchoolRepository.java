package com.emanyata.app.repo.secondary;

import com.emanyata.app.entity.secondary.OldSchool;
import com.emanyata.app.entity.secondary.OldSchoolApply;
import com.emanyata.app.entity.secondary.OldUser;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface OldSchoolRepository extends JpaRepository<OldSchool, Long> {
    List<OldSchool> findByUdiseNo(String udiseNo);
    Optional<OldSchool> findByUserId(Long id);
    Optional<OldSchool> findBySchoolMobile(String mobile);
	Optional<OldSchool> findByUdiseNoAndSchoolMobile(String udiseNo, String phone);
}