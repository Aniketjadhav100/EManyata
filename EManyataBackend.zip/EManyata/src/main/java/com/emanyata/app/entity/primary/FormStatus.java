package com.emanyata.app.entity.primary;

public enum FormStatus {
	ACTIVE,
    INACTIVE
}
