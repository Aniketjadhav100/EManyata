package com.emanyata.app.dto;

public class GrantedSchoolInfoDTO {
	
    public Long schoolId;
    public String governmentDecisionOfApproval;
    public String approvalOrderOfDeputyDirectorOfEducation;
    public String firstApprovalOrder;
    public String organizationsRequisitionApplicationInSample1;
    public String institutionRegistration19501860Certificate;
    public String govtMinorityCertificateIfTheSchoolIsMinority;
    public String purchaseDeedLeaseAgreementAwardDeed;
    public String certificationOfJoiningIfJoiningIfAdditionalTeacher;
    public String institutionalUndertakingOfSchoolsNotChargingAny;
    public String womenGrievanceRedressalCommittee;
    public String affidavitOnStampOfRs100;
    public String schoolPrincipalSignStamp;
    public Long applicationId;
    public String schoolLocationChanged;
    public String commonOrder2013To2016;
    public String commonOrder2016To2019;
    public String commonOrder2019To2022;
    public String commonOrder2022To2025;
    public String schoolLocationChangedBit;
    public String commonOrder2013To2016Bit;
    public String commonOrder2016To2019Bit;
    public String commonOrder2019To2022Bit;
    public String commonOrder2022To2025Bit;
    
    private Byte generalInfo;
    private Byte detailsOfPhysicals;
    private Byte otherFacility;
    private Byte studentCount;
    private Byte granted;
    private Byte nonGranted;
    
    private Byte status;
    
    
    
	public Byte getStatus() {
		return status;
	}
	public void setStatus(Byte status) {
		this.status = status;
	}

    
    
    
	public Byte getGeneralInfo() {
		return generalInfo;
	}
	public void setGeneralInfo(Byte generalInfo) {
		this.generalInfo = generalInfo;
	}
	public Byte getDetailsOfPhysicals() {
		return detailsOfPhysicals;
	}
	public void setDetailsOfPhysicals(Byte detailsOfPhysicals) {
		this.detailsOfPhysicals = detailsOfPhysicals;
	}
	public Byte getOtherFacility() {
		return otherFacility;
	}
	public void setOtherFacility(Byte otherFacility) {
		this.otherFacility = otherFacility;
	}
	public Byte getStudentCount() {
		return studentCount;
	}
	public void setStudentCount(Byte studentCount) {
		this.studentCount = studentCount;
	}
    
	public Byte getGranted() {
		return granted;
	}
	public void setGranted(Byte granted) {
		this.granted = granted;
	}
	
	public String getCommonOrder2022To2025() {
		return commonOrder2022To2025;
	}
	public void setCommonOrder2022To2025(String commonOrder2022To2025) {
		this.commonOrder2022To2025 = commonOrder2022To2025;
	}
	public String getCommonOrder2022To2025Bit() {
		return commonOrder2022To2025Bit;
	}
	public void setCommonOrder2022To2025Bit(String commonOrder2022To2025Bit) {
		this.commonOrder2022To2025Bit = commonOrder2022To2025Bit;
	}
	public Byte getNonGranted() {
		return nonGranted;
	}
	public void setNonGranted(Byte nonGranted) {
		this.nonGranted = nonGranted;
	}
	public Long getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(Long schoolId) {
		this.schoolId = schoolId;
	}
	public String getGovernmentDecisionOfApproval() {
		return governmentDecisionOfApproval;
	}
	public void setGovernmentDecisionOfApproval(String governmentDecisionOfApproval) {
		this.governmentDecisionOfApproval = governmentDecisionOfApproval;
	}
	public String getApprovalOrderOfDeputyDirectorOfEducation() {
		return approvalOrderOfDeputyDirectorOfEducation;
	}
	public void setApprovalOrderOfDeputyDirectorOfEducation(String approvalOrderOfDeputyDirectorOfEducation) {
		this.approvalOrderOfDeputyDirectorOfEducation = approvalOrderOfDeputyDirectorOfEducation;
	}
	public String getFirstApprovalOrder() {
		return firstApprovalOrder;
	}
	public void setFirstApprovalOrder(String firstApprovalOrder) {
		this.firstApprovalOrder = firstApprovalOrder;
	}
	public String getOrganizationsRequisitionApplicationInSample1() {
		return organizationsRequisitionApplicationInSample1;
	}
	public void setOrganizationsRequisitionApplicationInSample1(String organizationsRequisitionApplicationInSample1) {
		this.organizationsRequisitionApplicationInSample1 = organizationsRequisitionApplicationInSample1;
	}
	public String getInstitutionRegistration19501860Certificate() {
		return institutionRegistration19501860Certificate;
	}
	public void setInstitutionRegistration19501860Certificate(String institutionRegistration19501860Certificate) {
		this.institutionRegistration19501860Certificate = institutionRegistration19501860Certificate;
	}
	public String getGovtMinorityCertificateIfTheSchoolIsMinority() {
		return govtMinorityCertificateIfTheSchoolIsMinority;
	}
	public void setGovtMinorityCertificateIfTheSchoolIsMinority(String govtMinorityCertificateIfTheSchoolIsMinority) {
		this.govtMinorityCertificateIfTheSchoolIsMinority = govtMinorityCertificateIfTheSchoolIsMinority;
	}
	public String getPurchaseDeedLeaseAgreementAwardDeed() {
		return purchaseDeedLeaseAgreementAwardDeed;
	}
	public void setPurchaseDeedLeaseAgreementAwardDeed(String purchaseDeedLeaseAgreementAwardDeed) {
		this.purchaseDeedLeaseAgreementAwardDeed = purchaseDeedLeaseAgreementAwardDeed;
	}
	public String getCertificationOfJoiningIfJoiningIfAdditionalTeacher() {
		return certificationOfJoiningIfJoiningIfAdditionalTeacher;
	}
	public void setCertificationOfJoiningIfJoiningIfAdditionalTeacher(
			String certificationOfJoiningIfJoiningIfAdditionalTeacher) {
		this.certificationOfJoiningIfJoiningIfAdditionalTeacher = certificationOfJoiningIfJoiningIfAdditionalTeacher;
	}
	public String getInstitutionalUndertakingOfSchoolsNotChargingAny() {
		return institutionalUndertakingOfSchoolsNotChargingAny;
	}
	public void setInstitutionalUndertakingOfSchoolsNotChargingAny(String institutionalUndertakingOfSchoolsNotChargingAny) {
		this.institutionalUndertakingOfSchoolsNotChargingAny = institutionalUndertakingOfSchoolsNotChargingAny;
	}
	public String getWomenGrievanceRedressalCommittee() {
		return womenGrievanceRedressalCommittee;
	}
	public void setWomenGrievanceRedressalCommittee(String womenGrievanceRedressalCommittee) {
		this.womenGrievanceRedressalCommittee = womenGrievanceRedressalCommittee;
	}
	public String getAffidavitOnStampOfRs100() {
		return affidavitOnStampOfRs100;
	}
	public void setAffidavitOnStampOfRs100(String affidavitOnStampOfRs100) {
		this.affidavitOnStampOfRs100 = affidavitOnStampOfRs100;
	}
	public String getSchoolPrincipalSignStamp() {
		return schoolPrincipalSignStamp;
	}
	public void setSchoolPrincipalSignStamp(String schoolPrincipalSignStamp) {
		this.schoolPrincipalSignStamp = schoolPrincipalSignStamp;
	}
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	public String getSchoolLocationChanged() {
		return schoolLocationChanged;
	}
	public void setSchoolLocationChanged(String schoolLocationChanged) {
		this.schoolLocationChanged = schoolLocationChanged;
	}
	public String getCommonOrder2013To2016() {
		return commonOrder2013To2016;
	}
	public void setCommonOrder2013To2016(String commonOrder2013To2016) {
		this.commonOrder2013To2016 = commonOrder2013To2016;
	}
	public String getCommonOrder2016To2019() {
		return commonOrder2016To2019;
	}
	public void setCommonOrder2016To2019(String commonOrder2016To2019) {
		this.commonOrder2016To2019 = commonOrder2016To2019;
	}
	public String getCommonOrder2019To2022() {
		return commonOrder2019To2022;
	}
	public void setCommonOrder2019To2022(String commonOrder2019To2022) {
		this.commonOrder2019To2022 = commonOrder2019To2022;
	}
	public String getSchoolLocationChangedBit() {
		return schoolLocationChangedBit;
	}
	public void setSchoolLocationChangedBit(String schoolLocationChangedBit) {
		this.schoolLocationChangedBit = schoolLocationChangedBit;
	}
	public String getCommonOrder2013To2016Bit() {
		return commonOrder2013To2016Bit;
	}
	public void setCommonOrder2013To2016Bit(String commonOrder2013To2016Bit) {
		this.commonOrder2013To2016Bit = commonOrder2013To2016Bit;
	}
	public String getCommonOrder2016To2019Bit() {
		return commonOrder2016To2019Bit;
	}
	public void setCommonOrder2016To2019Bit(String commonOrder2016To2019Bit) {
		this.commonOrder2016To2019Bit = commonOrder2016To2019Bit;
	}
	public String getCommonOrder2019To2022Bit() {
		return commonOrder2019To2022Bit;
	}
	public void setCommonOrder2019To2022Bit(String commonOrder2019To2022Bit) {
		this.commonOrder2019To2022Bit = commonOrder2019To2022Bit;
	}
        
}