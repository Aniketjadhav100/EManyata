package com.emanyata.app.controller.primary;

import com.emanyata.app.dto.OtherFacilityDTO;
import com.emanyata.app.serviceImpl.primary.OtherFacilityServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/other-facility")
public class OtherfaclityController {

    @Autowired
    private OtherFacilityServiceImpl otherFacilityService;

    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createOtherFacility(@RequestBody OtherFacilityDTO dto) {
        Map<String, Object> response = new HashMap<>();
        try {
            OtherFacilityDTO saved = otherFacilityService.saveOtherFacility(dto);
            response.put("status", "success");
            response.put("message", "Record created successfully.");
            response.put("data", saved);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", "Failed to create record: " + e.getMessage());
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/get/{id}")
    public ResponseEntity<Map<String, Object>> getOtherFacility(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        try {
            OtherFacilityDTO dto = otherFacilityService.getOtherFacility(id);
            if (dto == null) {
                throw new NoSuchElementException("No record found with ID: " + id);
            }
            response.put("status", "success");
            response.put("message", "Record fetched successfully.");
            response.put("data", dto);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", "Error fetching record: " + e.getMessage());
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }
}
