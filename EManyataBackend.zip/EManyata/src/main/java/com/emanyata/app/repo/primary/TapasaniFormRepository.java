package com.emanyata.app.repo.primary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.primary.User;

public interface TapasaniFormRepository extends JpaRepository<User, Long> {
    // Additional query methods (if needed) can be declared here
}

