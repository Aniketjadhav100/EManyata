package com.emanyata.app.service.primary;

import com.emanyata.app.authdto.AdminUpdateDTO;

import java.util.List;
import java.util.Optional;

import org.springframework.web.multipart.MultipartFile;

import com.emanyata.app.authdto.AdminRegistrationDTO;
import com.emanyata.app.authdto.ForgotPasswordRequest;
import com.emanyata.app.authdto.LoginRequest;
import com.emanyata.app.authdto.OtpRequest;
import com.emanyata.app.authdto.UpdatePasswordRequest;
import com.emanyata.app.authdto.UserDTO;

public interface UserService {

	String register(UserDTO userDto);

    String verifyOtp(OtpRequest otpRequest);

    String resendOtp(String email);

    String login(LoginRequest request);

    String logout(String emailOrMobile);

    String verifyEmailOrMobile(ForgotPasswordRequest request);

    UserDTO getUserByUserId(Long userId);

	String updatePassword(UpdatePasswordRequest request);

	void updateEmailorMobile(Long userId, UserDTO dto);

    	
	//========= Admin Registration Services ========
	
	AdminRegistrationDTO registerAdmin(AdminRegistrationDTO dto);
	
	AdminUpdateDTO editAdmin(AdminUpdateDTO dto);
	
	List<UserDTO> getAllAdmin();
	
	Optional<UserDTO> getAdminById(Long id);

	String updateUser(Long userId, UserDTO dto, MultipartFile imageFile);
    
}