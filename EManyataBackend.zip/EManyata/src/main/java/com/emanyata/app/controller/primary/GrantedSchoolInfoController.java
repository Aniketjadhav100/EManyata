package com.emanyata.app.controller.primary;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.emanyata.app.dto.GrantedSchoolInfoDTO;
import com.emanyata.app.service.primary.GrantedSchoolInfoService;
import com.emanyata.app.util.FileUploadUtil;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/granted-school-info")
@CrossOrigin(origins = "http://localhost:3000")
public class GrantedSchoolInfoController {

    @Autowired
    private GrantedSchoolInfoService grantedSchoolInfoService;
    
    @Autowired
    private FileUploadUtil fileUploadUtil;

    @PostMapping(value = "/save-or-update", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, Object>> saveOrUpdate(
            @RequestParam("schoolId") Long schoolId,
            @RequestParam("applicationId") Long applicationId,
            @RequestPart(value = "governmentDecisionOfApproval", required = false) MultipartFile governmentDecisionOfApproval,
            @RequestPart(value = "approvalOrderOfDeputyDirectorOfEducation", required = false) MultipartFile approvalOrderOfDeputyDirectorOfEducation,
            @RequestPart(value = "firstApprovalOrder", required = false) MultipartFile firstApprovalOrder,
            @RequestPart(value = "organizationsRequisitionApplicationInSample1", required = false) MultipartFile organizationsRequisitionApplicationInSample1,
            @RequestPart(value = "institutionRegistration19501860Certificate", required = false) MultipartFile institutionRegistration19501860Certificate,
            @RequestPart(value = "govtMinorityCertificateIfTheSchoolIsMinority", required = false) MultipartFile govtMinorityCertificateIfTheSchoolIsMinority,
            @RequestPart(value = "purchaseDeedLeaseAgreementAwardDeed", required = false) MultipartFile purchaseDeedLeaseAgreementAwardDeed,
            @RequestPart(value = "certificationOfJoiningIfJoiningIfAdditionalTeacher", required = false) MultipartFile certificationOfJoiningIfJoiningIfAdditionalTeacher,
            @RequestPart(value = "institutionalUndertakingOfSchoolsNotChargingAny", required = false) MultipartFile institutionalUndertakingOfSchoolsNotChargingAny,
            @RequestPart(value = "womenGrievanceRedressalCommittee", required = false) MultipartFile womenGrievanceRedressalCommittee,
            @RequestPart(value = "affidavitOnStampOfRs100", required = false) MultipartFile affidavitOnStampOfRs100,
            @RequestPart(value = "schoolPrincipalSignStamp", required = false) MultipartFile schoolPrincipalSignStamp,
            @RequestPart(value = "schoolLocationChanged", required = false) MultipartFile schoolLocationChanged,
            @RequestPart(value = "commonOrder2013To2016", required = false) MultipartFile commonOrder2013To2016,
            @RequestPart(value = "commonOrder2016To2019", required = false) MultipartFile commonOrder2016To2019,
            @RequestPart(value = "commonOrder2019To2022", required = false) MultipartFile commonOrder2019To2022,
            @RequestPart(value = "commonOrder2022To2025", required = false) MultipartFile commonOrder2022To2025,
            @RequestParam(value = "schoolLocationChangedBit", required = false) String schoolLocationChangedBit,
            @RequestParam(value = "commonOrder2013To2016Bit", required = false) String commonOrder2013To2016Bit,
            @RequestParam(value = "commonOrder2016To2019Bit", required = false) String commonOrder2016To2019Bit,
            @RequestParam(value = "commonOrder2019To2022Bit", required = false) String commonOrder2019To2022Bit,
            @RequestParam(value = "commonOrder2022To2025Bit", required = false) String commonOrder2022To2025Bit
    ) {
        Map<String, Object> response = new HashMap<>();
        try {
            if (schoolId == null || applicationId == null) {
                response.put("status", "error");
                response.put("message", "Both schoolId and applicationId are required");
                response.put("data", null);
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }

            GrantedSchoolInfoDTO dto = new GrantedSchoolInfoDTO();
            dto.schoolId = schoolId;
            dto.applicationId = applicationId;

            dto.governmentDecisionOfApproval = saveFileAndGetName(governmentDecisionOfApproval);
            dto.approvalOrderOfDeputyDirectorOfEducation = saveFileAndGetName(approvalOrderOfDeputyDirectorOfEducation);
            dto.firstApprovalOrder = saveFileAndGetName(firstApprovalOrder);
            dto.organizationsRequisitionApplicationInSample1 = saveFileAndGetName(organizationsRequisitionApplicationInSample1);
            dto.institutionRegistration19501860Certificate = saveFileAndGetName(institutionRegistration19501860Certificate);
            dto.govtMinorityCertificateIfTheSchoolIsMinority = saveFileAndGetName(govtMinorityCertificateIfTheSchoolIsMinority);
            dto.purchaseDeedLeaseAgreementAwardDeed = saveFileAndGetName(purchaseDeedLeaseAgreementAwardDeed);
            dto.certificationOfJoiningIfJoiningIfAdditionalTeacher = saveFileAndGetName(certificationOfJoiningIfJoiningIfAdditionalTeacher);
            dto.institutionalUndertakingOfSchoolsNotChargingAny = saveFileAndGetName(institutionalUndertakingOfSchoolsNotChargingAny);
            dto.womenGrievanceRedressalCommittee = saveFileAndGetName(womenGrievanceRedressalCommittee);
            dto.affidavitOnStampOfRs100 = saveFileAndGetName(affidavitOnStampOfRs100);
            dto.schoolPrincipalSignStamp = saveFileAndGetName(schoolPrincipalSignStamp);
            dto.schoolLocationChanged = saveFileAndGetName(schoolLocationChanged);
            dto.commonOrder2013To2016 = saveFileAndGetName(commonOrder2013To2016);
            dto.commonOrder2016To2019 = saveFileAndGetName(commonOrder2016To2019);
            dto.commonOrder2019To2022 = saveFileAndGetName(commonOrder2019To2022);
            dto.commonOrder2022To2025 = saveFileAndGetName(commonOrder2022To2025);

            dto.schoolLocationChangedBit = schoolLocationChangedBit;
            dto.commonOrder2013To2016Bit = commonOrder2013To2016Bit;
            dto.commonOrder2016To2019Bit = commonOrder2016To2019Bit;
            dto.commonOrder2019To2022Bit = commonOrder2019To2022Bit;
            dto.commonOrder2022To2025Bit = commonOrder2022To2025Bit;

            GrantedSchoolInfoDTO saved = grantedSchoolInfoService.saveOrUpdate(dto);

            response.put("status", "success");
            response.put("message", "Record saved successfully");
            response.put("data", saved);
            return new ResponseEntity<>(response, HttpStatus.OK);

        } catch (Exception e) {
            e.printStackTrace();
            response.put("status", "error");
            response.put("message", "Error processing request: " + e.getMessage());
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }

    private String saveFileAndGetName(MultipartFile file) throws IOException {
        if (file != null && !file.isEmpty()) {
            System.out.println("Saving file: " + file.getOriginalFilename());
            String fileName = fileUploadUtil.saveFile(file);
            System.out.println("Saved as: " + fileName);
            return fileName;
        }
        System.out.println("No file provided or file is empty");
        return null;
    }
    
    @PostMapping("/get-by-school-id/{id}")
    public ResponseEntity<Map<String, Object>> getBySchoolId(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        try {
            GrantedSchoolInfoDTO info = grantedSchoolInfoService.getBySchoolId(id);
            if (info == null) {
                response.put("status", "error");
                response.put("message", "No record found with schoolId: " + id);
                response.put("data", null);
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
            response.put("status", "success");
            response.put("message", "Record fetched successfully");
            response.put("data", info);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            response.put("status", "error");
            response.put("message", "Error fetching record: " + e.getMessage());
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }
    
    @PostMapping("/uploads/grantedSchoolDocuments/view/{filename:.+}")
    public ResponseEntity<Resource> viewDocument(@PathVariable String filename) throws Exception {
        Resource file = grantedSchoolInfoService.loadFileAsResource(filename);

        // Detect the actual content type
        Path filePath = file.getFile().toPath();
        String contentType = Files.probeContentType(filePath);

        if (contentType == null) {
            contentType = "application/octet-stream"; // fallback
        }

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + file.getFilename() + "\"")
                .body(file);
    }
}