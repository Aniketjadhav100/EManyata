package com.emanyata.app.entity.primary;

import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "users")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    @JsonIgnore
    private Long id;
  
    @Size(max = 255)
    @Column(name = "name")
    private String name;
    
    @NotNull
    @Column(name = "otp_verified", nullable = false)
    private String otpverified;
    
    @Size(max = 255)
    @NotNull
    @Column(name = "udise_no", nullable = false)
    private String UdiseNo;

	@Size(max = 255)
    @Column(name = "email", nullable = false,unique = true)
    private String email;
    
    @Size(max = 255)
    @Column(name = "email_otp")
    private String otp;
    
    @Column(name = "email_otp_verified_at", nullable = true, unique = true)
    private LocalDateTime Verified;
    
    @Size(max = 255)
    @Column(name = "mobile", nullable = false, unique = true)
    private String mobile;
    
    @Size(max = 255)
    @Column(name = "mobile_otp")
    private String mobile_otp;
    
    @Column(name = "mobile_otp_verified_at", nullable = true, unique = true)  
    private LocalDateTime mverified;
   
    @Size(max = 255)
    @Column(name = "phone",unique = true)
    private String phone;
    
    @Size(max = 512)
    @Column(name = "remember_token", length = 512, nullable = true)
    private String rememberToken;

    @Size(max = 512)
    @Column(name = "token", length = 512, nullable = true)
    private String token;



    @Size(max = 255)
    @Column(name = "designation")
    private String designation;

    @Size(max = 255)
    @NotNull
    @Column(name = "password", nullable = false)
    private String password;

    @Lob
    @Column(name = "permissions")
    private String permissions;

    @Column(name = "last_login")
    private LocalDateTime lastLogin;

    @NotNull
    @ColumnDefault("1")
    @Column(name = "status", nullable = false)
    private Byte status;

    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private Image image;

    @ManyToOne(fetch = FetchType.EAGER)
    @OnDelete(action = OnDeleteAction.SET_NULL)
    @JoinColumn(name = "digital_signature_id")
    private Image digitalSignature;

    @ManyToOne(fetch = FetchType.EAGER)
    @OnDelete(action = OnDeleteAction.SET_NULL)
    @JoinColumn(name = "role_id")
    private Role role;

    @Column(name = "designation_id")
    private Long designationId;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @OneToMany(mappedBy = "user_id", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<School> schools;

    public List<School> getSchools() {
        return schools;
    }

    public void setSchools(List<School> schools) {
        this.schools = schools;
        for (School school : schools) {
            school.setUser_id(this);
        }
    }
    
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	

    public String getUdiseNo() {
		return UdiseNo;
	}

	public void setUdiseNo(String udiseNo) {
		UdiseNo = udiseNo;
	}


	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}


	public LocalDateTime getVerified() {
		return Verified;
	}

	public void setVerified(LocalDateTime verified) {
		Verified = verified;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getMobile_otp() {
		return mobile_otp;
	}

	public void setMobile_otp(String mobile_otp) {
		this.mobile_otp = mobile_otp;
	}

	public LocalDateTime getMverified() {
		return mverified;
	}

	public void setMverified(LocalDateTime mverified) {
		this.mverified = mverified;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getRememberToken() {
		return rememberToken;
	}

	public void setRememberToken(String rememberToken) {
		this.rememberToken = rememberToken;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPermissions() {
		return permissions;
	}

	public void setPermissions(String permissions) {
		this.permissions = permissions;
	}

	public LocalDateTime getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(LocalDateTime lastLogin) {
		this.lastLogin = lastLogin;
	}

	public Byte getStatus() {
		return status;
	}

	public void setStatus(Byte status) {
		this.status = status;
	}

	public Image getImage() {
		return image;
	}

	public void setImage(Image image) {
		this.image = image;
	}

	public Image getDigitalSignature() {
		return digitalSignature;
	}

	public void setDigitalSignature(Image digitalSignature) {
		this.digitalSignature = digitalSignature;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Long getDesignationId() {
		return designationId;
		
	}

	
	
	public String getOtpverified() {
		return otpverified;
	}

	public void setOtpverified(String otpverified) {
		this.otpverified = otpverified;
	}

	public void setDesignationId(Long designationId) {
		this.designationId = designationId;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}   
}
