package com.emanyata.app.entity.primary;

import jakarta.persistence.*;


import java.math.BigDecimal;

@Entity
@Table(name = "udise_numbers")
public class UdiseNumber {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "udise_number", unique = true, nullable = false, length = 11)
    private String udiseNumber;

    @Column(name = "schoolname", length = 255)
    private String name;

    @Column(name = "address_deputydirector", columnDefinition = "TEXT")
    private String addressDeputyDirector;

    @Column(length = 100)
    private String district;

    @Column(length = 100)
    private String taluka;

    @Column(length = 100)
    private String village;

    @Column(length = 10)
    private String pincode;

    @Column(length = 20)
    private String telephonenumber;

    @Column(name = "school_mobilenumber", length = 20)
    private String schoolMobileNumber;

    @Column(length = 100)
    private String schoolemailid;

    @Column(length = 50)
    private String typeofschool;

    @Column(columnDefinition = "TEXT")
    private String addressapprovaldocuments;

    @Column(name = "school_establishment_year", length = 10)
    private String schoolEstablishmentYear;

    @Column(length = 50)
    private String dateoffirstcommencementschool;

    @Column(length = 50)
    private String schoolarea;

    @Column(length = 50)
    private String medium;

    @Column(name = "school_board", length = 100)
    private String schoolBoard;

    @Column(name = "school_halfday_schedule", length = 50)
    private String schoolHalfdaySchedule;

    @Column(name = "school_day_schedule", length = 50)
    private String schoolDaySchedule;

    @Column(length = 50)
    private String middaymealschedule;

    @Column(name = "nameoft_society_management_committee", columnDefinition = "TEXT")
    private String nameOfSocietyManagementCommittee;

    @Column(length = 100)
    private String classpresentinudise;

    @Column(columnDefinition = "TEXT")
    private String selfapprovalcertificate;

    @Column(length = 100)
    private String nearpolicestationname;

    @Column(columnDefinition = "TEXT")
    private String school_address;

    @Column(columnDefinition = "TEXT")
    private String address_mentioned_in_government_approval_document;

    @Column(length = 50)
    private String school_academic_session;

    @Column(length = 50)
    private String school_time_full_time;

    @Column(length = 50)
    private String school_time_half_time;

    @Column(columnDefinition = "TEXT")
    private String academic_learning_time_for_each_class;

    @Column(columnDefinition = "TEXT")
    private String lunch_time_for_each_class;

    @Column(columnDefinition = "TEXT")
    private String sports_and_physical_education_time_for_each_class;

    @Column(length = 50)
    private String registration_no;

    @Column(length = 100)
    private String under_the_societies_registration_act1860;

    @Column(length = 100)
    private String under_the_mumbai_public_trustee_system_act1950;

    @Column(columnDefinition = "TEXT")
    private String till_what_period_the_registration_of_trust;

    @Column(columnDefinition = "TEXT")
    private String is_there_evidence_that_the_trust;

    @Column(length = 100)
    private String school_user_name;

    @Column(length = 100)
    private String school_user_degisnation;

    @Column(columnDefinition = "TEXT")
    private String school_user_address;

    @Column(length = 20)
    private String school_user_telephone;

    @Column(length = 255)
    private String account_year;

    @Column(length = 50)
    private String account_income;

    @Column(length = 50)
    private String account_expense;

    @Column(length = 50)
    private String account_balance;

    @Column(length = 50)
    private String for_which_year_you_want_to_apply_foracertificate;

    @Column(length = 10)
    private String year_of_foundationz_of_school;

    @Column(length = 20)
    private String lower_standard;

    @Column(length = 20)
    private String higher_standard;

    @Column(length = 100)
    private String sangstha_company_name;

    @Column(length = 255)
    private String sanstha_company_has_purpose_for_only_education_service;

    @Column(length = 255)
    private String is_school_open_where_address_mentioned_in_approval;

    @Column(name = "if_sanstha_is_handover_to_someone", length = 255)
    private String ifSansthaIsHandoverToSomeone;

    @Column(length = 255)
    private String do_you_have_maharastra_shashan_manyata_no;

    @Column(length = 255)
    private String maharastra_shashan_approval_number;

    @Column(length = 255)
    private String maharastra_shashan_approval_date;

    @Column(length = 255)
    private String do_you_have_shikshan_upsanchalak_approval;

    @Column(length = 255)
    private String shikshan_upsanchalak_approval_date;

    @Column(length = 255)
    private String shikshan_upsanchalak_approval_number;

    @Column(length = 255)
    private String do_you_have_pratham_manyata_certificate;

    @Column(length = 255)
    private String pratham_manyata_number;

    @Column(length = 255)
    private String pratham_manyata_date;

    @Column(length = 255)
    private String do_you_run_on_government_no_objection_certificate;

    @Column(length = 255)
    private String no_objection_certificate_number;

    @Column(length = 255)
    private String no_objection_certificate_date;

    @Column(length = 255)
    private String whether_school_is_moved_to_another_location;

    @Column(columnDefinition = "TEXT")
    private String members;

    @Column(length = 255)
    private String simple_lower_standard;

    @Column(length = 255)
    private String simple_higher_standard;

    @Column(length = 255)
    private String udise_lower_standard;

    @Column(length = 255)
    private String udise_higher_standard;

    @Column(length = 255)
    private String is_there_an_affiliation_certificate;

    @Column(length = 255)
    private String affiliation_certificate_number;

    @Column(length = 255)
    private String affiliation_certificate_date;

    @Column(length = 255)
    private String section1inspection_approval;

    @Column(length = 255)
    private String section2inspection_approval;

    @Column(length = 255)
    private String section3inspection_approval;

    @Column(columnDefinition = "TEXT")
    private String section1inspection_comment;

    @Column(columnDefinition = "TEXT")
    private String section2inspection_comment;

    @Column(columnDefinition = "TEXT")
    private String section3inspection_comment;

    @Column(length = 1)
    private String status = "0";

    @Column(columnDefinition = "TEXT")
    private String uploaded_file_path;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUdiseNumber() {
		return udiseNumber;
	}

	public void setUdiseNumber(String udiseNumber) {
		this.udiseNumber = udiseNumber;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIfSansthaIsHandoverToSomeone() {
		return ifSansthaIsHandoverToSomeone;
	}

	public void setIfSansthaIsHandoverToSomeone(String ifSansthaIsHandoverToSomeone) {
		this.ifSansthaIsHandoverToSomeone = ifSansthaIsHandoverToSomeone;
	}

	public String getAddressDeputyDirector() {
		return addressDeputyDirector;
	}

	public void setAddressDeputyDirector(String addressDeputyDirector) {
		this.addressDeputyDirector = addressDeputyDirector;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getTaluka() {
		return taluka;
	}

	public void setTaluka(String taluka) {
		this.taluka = taluka;
	}

	public String getVillage() {
		return village;
	}

	public void setVillage(String village) {
		this.village = village;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getTelephonenumber() {
		return telephonenumber;
	}

	public void setTelephonenumber(String telephonenumber) {
		this.telephonenumber = telephonenumber;
	}

	public String getSchoolMobileNumber() {
		return schoolMobileNumber;
	}

	public void setSchoolMobileNumber(String schoolMobileNumber) {
		this.schoolMobileNumber = schoolMobileNumber;
	}

	public String getSchoolemailid() {
		return schoolemailid;
	}

	public void setSchoolemailid(String schoolemailid) {
		this.schoolemailid = schoolemailid;
	}

	public String getTypeofschool() {
		return typeofschool;
	}

	public void setTypeofschool(String typeofschool) {
		this.typeofschool = typeofschool;
	}

	public String getAddressapprovaldocuments() {
		return addressapprovaldocuments;
	}

	public void setAddressapprovaldocuments(String addressapprovaldocuments) {
		this.addressapprovaldocuments = addressapprovaldocuments;
	}

	public String getSchoolEstablishmentYear() {
		return schoolEstablishmentYear;
	}

	public void setSchoolEstablishmentYear(String schoolEstablishmentYear) {
		this.schoolEstablishmentYear = schoolEstablishmentYear;
	}

	public String getDateoffirstcommencementschool() {
		return dateoffirstcommencementschool;
	}

	public void setDateoffirstcommencementschool(String dateoffirstcommencementschool) {
		this.dateoffirstcommencementschool = dateoffirstcommencementschool;
	}

	public String getSchoolarea() {
		return schoolarea;
	}

	public void setSchoolarea(String schoolarea) {
		this.schoolarea = schoolarea;
	}

	public String getMedium() {
		return medium;
	}

	public void setMedium(String medium) {
		this.medium = medium;
	}

	public String getSchoolBoard() {
		return schoolBoard;
	}

	public void setSchoolBoard(String schoolBoard) {
		this.schoolBoard = schoolBoard;
	}

	public String getSchoolHalfdaySchedule() {
		return schoolHalfdaySchedule;
	}

	public void setSchoolHalfdaySchedule(String schoolHalfdaySchedule) {
		this.schoolHalfdaySchedule = schoolHalfdaySchedule;
	}

	public String getSchoolDaySchedule() {
		return schoolDaySchedule;
	}

	public void setSchoolDaySchedule(String schoolDaySchedule) {
		this.schoolDaySchedule = schoolDaySchedule;
	}

	public String getMiddaymealschedule() {
		return middaymealschedule;
	}

	public void setMiddaymealschedule(String middaymealschedule) {
		this.middaymealschedule = middaymealschedule;
	}

	public String getNameOfSocietyManagementCommittee() {
		return nameOfSocietyManagementCommittee;
	}

	public void setNameOfSocietyManagementCommittee(String nameOfSocietyManagementCommittee) {
		this.nameOfSocietyManagementCommittee = nameOfSocietyManagementCommittee;
	}

	public String getClasspresentinudise() {
		return classpresentinudise;
	}

	public void setClasspresentinudise(String classpresentinudise) {
		this.classpresentinudise = classpresentinudise;
	}

	public String getSelfapprovalcertificate() {
		return selfapprovalcertificate;
	}

	public void setSelfapprovalcertificate(String selfapprovalcertificate) {
		this.selfapprovalcertificate = selfapprovalcertificate;
	}

	public String getNearpolicestationname() {
		return nearpolicestationname;
	}

	public void setNearpolicestationname(String nearpolicestationname) {
		this.nearpolicestationname = nearpolicestationname;
	}

	public String getSchool_address() {
		return school_address;
	}

	public void setSchool_address(String school_address) {
		this.school_address = school_address;
	}

	public String getAddress_mentioned_in_government_approval_document() {
		return address_mentioned_in_government_approval_document;
	}

	public void setAddress_mentioned_in_government_approval_document(
			String address_mentioned_in_government_approval_document) {
		this.address_mentioned_in_government_approval_document = address_mentioned_in_government_approval_document;
	}

	public String getSchool_academic_session() {
		return school_academic_session;
	}

	public void setSchool_academic_session(String school_academic_session) {
		this.school_academic_session = school_academic_session;
	}

	public String getSchool_time_full_time() {
		return school_time_full_time;
	}

	public void setSchool_time_full_time(String school_time_full_time) {
		this.school_time_full_time = school_time_full_time;
	}

	public String getSchool_time_half_time() {
		return school_time_half_time;
	}

	public void setSchool_time_half_time(String school_time_half_time) {
		this.school_time_half_time = school_time_half_time;
	}

	public String getAcademic_learning_time_for_each_class() {
		return academic_learning_time_for_each_class;
	}

	public void setAcademic_learning_time_for_each_class(String academic_learning_time_for_each_class) {
		this.academic_learning_time_for_each_class = academic_learning_time_for_each_class;
	}

	public String getLunch_time_for_each_class() {
		return lunch_time_for_each_class;
	}

	public void setLunch_time_for_each_class(String lunch_time_for_each_class) {
		this.lunch_time_for_each_class = lunch_time_for_each_class;
	}

	public String getSports_and_physical_education_time_for_each_class() {
		return sports_and_physical_education_time_for_each_class;
	}

	public void setSports_and_physical_education_time_for_each_class(
			String sports_and_physical_education_time_for_each_class) {
		this.sports_and_physical_education_time_for_each_class = sports_and_physical_education_time_for_each_class;
	}

	public String getRegistration_no() {
		return registration_no;
	}

	public void setRegistration_no(String registration_no) {
		this.registration_no = registration_no;
	}

	public String getUnder_the_societies_registration_act1860() {
		return under_the_societies_registration_act1860;
	}

	public void setUnder_the_societies_registration_act1860(String under_the_societies_registration_act1860) {
		this.under_the_societies_registration_act1860 = under_the_societies_registration_act1860;
	}

	public String getUnder_the_mumbai_public_trustee_system_act1950() {
		return under_the_mumbai_public_trustee_system_act1950;
	}

	public void setUnder_the_mumbai_public_trustee_system_act1950(String under_the_mumbai_public_trustee_system_act1950) {
		this.under_the_mumbai_public_trustee_system_act1950 = under_the_mumbai_public_trustee_system_act1950;
	}

	public String getTill_what_period_the_registration_of_trust() {
		return till_what_period_the_registration_of_trust;
	}

	public void setTill_what_period_the_registration_of_trust(String till_what_period_the_registration_of_trust) {
		this.till_what_period_the_registration_of_trust = till_what_period_the_registration_of_trust;
	}

	public String getIs_there_evidence_that_the_trust() {
		return is_there_evidence_that_the_trust;
	}

	public void setIs_there_evidence_that_the_trust(String is_there_evidence_that_the_trust) {
		this.is_there_evidence_that_the_trust = is_there_evidence_that_the_trust;
	}

	public String getSchool_user_name() {
		return school_user_name;
	}

	public void setSchool_user_name(String school_user_name) {
		this.school_user_name = school_user_name;
	}

	public String getSchool_user_degisnation() {
		return school_user_degisnation;
	}

	public void setSchool_user_degisnation(String school_user_degisnation) {
		this.school_user_degisnation = school_user_degisnation;
	}

	public String getSchool_user_address() {
		return school_user_address;
	}

	public void setSchool_user_address(String school_user_address) {
		this.school_user_address = school_user_address;
	}

	public String getSchool_user_telephone() {
		return school_user_telephone;
	}

	public void setSchool_user_telephone(String school_user_telephone) {
		this.school_user_telephone = school_user_telephone;
	}

	public String getAccount_year() {
		return account_year;
	}

	public void setAccount_year(String account_year) {
		this.account_year = account_year;
	}

	public String getAccount_income() {
		return account_income;
	}

	public void setAccount_income(String account_income) {
		this.account_income = account_income;
	}

	public String getAccount_expense() {
		return account_expense;
	}

	public void setAccount_expense(String account_expense) {
		this.account_expense = account_expense;
	}

	public String getAccount_balance() {
		return account_balance;
	}

	public void setAccount_balance(String account_balance) {
		this.account_balance = account_balance;
	}

	public String getFor_which_year_you_want_to_apply_foracertificate() {
		return for_which_year_you_want_to_apply_foracertificate;
	}

	public void setFor_which_year_you_want_to_apply_foracertificate(
			String for_which_year_you_want_to_apply_foracertificate) {
		this.for_which_year_you_want_to_apply_foracertificate = for_which_year_you_want_to_apply_foracertificate;
	}

	public String getYear_of_foundationz_of_school() {
		return year_of_foundationz_of_school;
	}

	public void setYear_of_foundationz_of_school(String year_of_foundationz_of_school) {
		this.year_of_foundationz_of_school = year_of_foundationz_of_school;
	}

	public String getLower_standard() {
		return lower_standard;
	}

	public void setLower_standard(String lower_standard) {
		this.lower_standard = lower_standard;
	}

	public String getHigher_standard() {
		return higher_standard;
	}

	public void setHigher_standard(String higher_standard) {
		this.higher_standard = higher_standard;
	}

	public String getSangstha_company_name() {
		return sangstha_company_name;
	}

	public void setSangstha_company_name(String sangstha_company_name) {
		this.sangstha_company_name = sangstha_company_name;
	}

	public String getSanstha_company_has_purpose_for_only_education_service() {
		return sanstha_company_has_purpose_for_only_education_service;
	}

	public void setSanstha_company_has_purpose_for_only_education_service(
			String sanstha_company_has_purpose_for_only_education_service) {
		this.sanstha_company_has_purpose_for_only_education_service = sanstha_company_has_purpose_for_only_education_service;
	}

	public String getIs_school_open_where_address_mentioned_in_approval() {
		return is_school_open_where_address_mentioned_in_approval;
	}

	public void setIs_school_open_where_address_mentioned_in_approval(
			String is_school_open_where_address_mentioned_in_approval) {
		this.is_school_open_where_address_mentioned_in_approval = is_school_open_where_address_mentioned_in_approval;
	}

	public String getIf_sanstha_is_handover_to_someone() {
		return ifSansthaIsHandoverToSomeone;
	}

	public void setIf_sanstha_is_handover_to_someone(String if_sanstha_is_handover_to_someone) {
		this.ifSansthaIsHandoverToSomeone = if_sanstha_is_handover_to_someone;
	}

	public String getDo_you_have_maharastra_shashan_manyata_no() {
		return do_you_have_maharastra_shashan_manyata_no;
	}

	public void setDo_you_have_maharastra_shashan_manyata_no(String do_you_have_maharastra_shashan_manyata_no) {
		this.do_you_have_maharastra_shashan_manyata_no = do_you_have_maharastra_shashan_manyata_no;
	}

	public String getMaharastra_shashan_approval_number() {
		return maharastra_shashan_approval_number;
	}

	public void setMaharastra_shashan_approval_number(String maharastra_shashan_approval_number) {
		this.maharastra_shashan_approval_number = maharastra_shashan_approval_number;
	}

	public String getMaharastra_shashan_approval_date() {
		return maharastra_shashan_approval_date;
	}

	public void setMaharastra_shashan_approval_date(String maharastra_shashan_approval_date) {
		this.maharastra_shashan_approval_date = maharastra_shashan_approval_date;
	}

	public String getDo_you_have_shikshan_upsanchalak_approval() {
		return do_you_have_shikshan_upsanchalak_approval;
	}

	public void setDo_you_have_shikshan_upsanchalak_approval(String do_you_have_shikshan_upsanchalak_approval) {
		this.do_you_have_shikshan_upsanchalak_approval = do_you_have_shikshan_upsanchalak_approval;
	}

	public String getShikshan_upsanchalak_approval_date() {
		return shikshan_upsanchalak_approval_date;
	}

	public void setShikshan_upsanchalak_approval_date(String shikshan_upsanchalak_approval_date) {
		this.shikshan_upsanchalak_approval_date = shikshan_upsanchalak_approval_date;
	}

	public String getShikshan_upsanchalak_approval_number() {
		return shikshan_upsanchalak_approval_number;
	}

	public void setShikshan_upsanchalak_approval_number(String shikshan_upsanchalak_approval_number) {
		this.shikshan_upsanchalak_approval_number = shikshan_upsanchalak_approval_number;
	}

	public String getDo_you_have_pratham_manyata_certificate() {
		return do_you_have_pratham_manyata_certificate;
	}

	public void setDo_you_have_pratham_manyata_certificate(String do_you_have_pratham_manyata_certificate) {
		this.do_you_have_pratham_manyata_certificate = do_you_have_pratham_manyata_certificate;
	}

	public String getPratham_manyata_number() {
		return pratham_manyata_number;
	}

	public void setPratham_manyata_number(String pratham_manyata_number) {
		this.pratham_manyata_number = pratham_manyata_number;
	}

	public String getPratham_manyata_date() {
		return pratham_manyata_date;
	}

	public void setPratham_manyata_date(String pratham_manyata_date) {
		this.pratham_manyata_date = pratham_manyata_date;
	}

	public String getDo_you_run_on_government_no_objection_certificate() {
		return do_you_run_on_government_no_objection_certificate;
	}

	public void setDo_you_run_on_government_no_objection_certificate(
			String do_you_run_on_government_no_objection_certificate) {
		this.do_you_run_on_government_no_objection_certificate = do_you_run_on_government_no_objection_certificate;
	}

	public String getNo_objection_certificate_number() {
		return no_objection_certificate_number;
	}

	public void setNo_objection_certificate_number(String no_objection_certificate_number) {
		this.no_objection_certificate_number = no_objection_certificate_number;
	}

	public String getNo_objection_certificate_date() {
		return no_objection_certificate_date;
	}

	public void setNo_objection_certificate_date(String no_objection_certificate_date) {
		this.no_objection_certificate_date = no_objection_certificate_date;
	}

	public String getWhether_school_is_moved_to_another_location() {
		return whether_school_is_moved_to_another_location;
	}

	public void setWhether_school_is_moved_to_another_location(String whether_school_is_moved_to_another_location) {
		this.whether_school_is_moved_to_another_location = whether_school_is_moved_to_another_location;
	}

	public String getMembers() {
		return members;
	}

	public void setMembers(String members) {
		this.members = members;
	}

	public String getSimple_lower_standard() {
		return simple_lower_standard;
	}

	public void setSimple_lower_standard(String simple_lower_standard) {
		this.simple_lower_standard = simple_lower_standard;
	}

	public String getSimple_higher_standard() {
		return simple_higher_standard;
	}

	public void setSimple_higher_standard(String simple_higher_standard) {
		this.simple_higher_standard = simple_higher_standard;
	}

	public String getUdise_lower_standard() {
		return udise_lower_standard;
	}

	public void setUdise_lower_standard(String udise_lower_standard) {
		this.udise_lower_standard = udise_lower_standard;
	}

	public String getUdise_higher_standard() {
		return udise_higher_standard;
	}

	public void setUdise_higher_standard(String udise_higher_standard) {
		this.udise_higher_standard = udise_higher_standard;
	}

	public String getIs_there_an_affiliation_certificate() {
		return is_there_an_affiliation_certificate;
	}

	public void setIs_there_an_affiliation_certificate(String is_there_an_affiliation_certificate) {
		this.is_there_an_affiliation_certificate = is_there_an_affiliation_certificate;
	}

	public String getAffiliation_certificate_number() {
		return affiliation_certificate_number;
	}

	public void setAffiliation_certificate_number(String affiliation_certificate_number) {
		this.affiliation_certificate_number = affiliation_certificate_number;
	}

	public String getAffiliation_certificate_date() {
		return affiliation_certificate_date;
	}

	public void setAffiliation_certificate_date(String affiliation_certificate_date) {
		this.affiliation_certificate_date = affiliation_certificate_date;
	}

	public String getSection1inspection_approval() {
		return section1inspection_approval;
	}

	public void setSection1inspection_approval(String section1inspection_approval) {
		this.section1inspection_approval = section1inspection_approval;
	}

	public String getSection2inspection_approval() {
		return section2inspection_approval;
	}

	public void setSection2inspection_approval(String section2inspection_approval) {
		this.section2inspection_approval = section2inspection_approval;
	}

	public String getSection3inspection_approval() {
		return section3inspection_approval;
	}

	public void setSection3inspection_approval(String section3inspection_approval) {
		this.section3inspection_approval = section3inspection_approval;
	}

	public String getSection1inspection_comment() {
		return section1inspection_comment;
	}

	public void setSection1inspection_comment(String section1inspection_comment) {
		this.section1inspection_comment = section1inspection_comment;
	}

	public String getSection2inspection_comment() {
		return section2inspection_comment;
	}

	public void setSection2inspection_comment(String section2inspection_comment) {
		this.section2inspection_comment = section2inspection_comment;
	}

	public String getSection3inspection_comment() {
		return section3inspection_comment;
	}

	public void setSection3inspection_comment(String section3inspection_comment) {
		this.section3inspection_comment = section3inspection_comment;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUploaded_file_path() {
		return uploaded_file_path;
	}

	public void setUploaded_file_path(String uploaded_file_path) {
		this.uploaded_file_path = uploaded_file_path;
	}

	@Override
	public String toString() {
		return "UdiseNumber [id=" + id + ", udiseNumber=" + udiseNumber + ", name=" + name
				+ ", addressDeputyDirector=" + addressDeputyDirector + ", district=" + district + ", taluka=" + taluka
				+ ", village=" + village + ", pincode=" + pincode + ", telephonenumber=" + telephonenumber
				+ ", schoolMobileNumber=" + schoolMobileNumber + ", schoolemailid=" + schoolemailid + ", typeofschool="
				+ typeofschool + ", addressapprovaldocuments=" + addressapprovaldocuments + ", schoolEstablishmentYear="
				+ schoolEstablishmentYear + ", dateoffirstcommencementschool=" + dateoffirstcommencementschool
				+ ", schoolarea=" + schoolarea + ", medium=" + medium + ", schoolBoard=" + schoolBoard
				+ ", schoolHalfdaySchedule=" + schoolHalfdaySchedule + ", schoolDaySchedule=" + schoolDaySchedule
				+ ", middaymealschedule=" + middaymealschedule + ", nameOfSocietyManagementCommittee="
				+ nameOfSocietyManagementCommittee + ", classpresentinudise=" + classpresentinudise
				+ ", selfapprovalcertificate=" + selfapprovalcertificate + ", nearpolicestationname="
				+ nearpolicestationname + ", school_address=" + school_address
				+ ", address_mentioned_in_government_approval_document="
				+ address_mentioned_in_government_approval_document + ", school_academic_session="
				+ school_academic_session + ", school_time_full_time=" + school_time_full_time
				+ ", school_time_half_time=" + school_time_half_time + ", academic_learning_time_for_each_class="
				+ academic_learning_time_for_each_class + ", lunch_time_for_each_class=" + lunch_time_for_each_class
				+ ", sports_and_physical_education_time_for_each_class="
				+ sports_and_physical_education_time_for_each_class + ", registration_no=" + registration_no
				+ ", under_the_societies_registration_act1860=" + under_the_societies_registration_act1860
				+ ", under_the_mumbai_public_trustee_system_act1950=" + under_the_mumbai_public_trustee_system_act1950
				+ ", till_what_period_the_registration_of_trust=" + till_what_period_the_registration_of_trust
				+ ", is_there_evidence_that_the_trust=" + is_there_evidence_that_the_trust + ", school_user_name="
				+ school_user_name + ", school_user_degisnation=" + school_user_degisnation + ", school_user_address="
				+ school_user_address + ", school_user_telephone=" + school_user_telephone + ", account_year="
				+ account_year + ", account_income=" + account_income + ", account_expense=" + account_expense
				+ ", account_balance=" + account_balance + ", for_which_year_you_want_to_apply_foracertificate="
				+ for_which_year_you_want_to_apply_foracertificate + ", year_of_foundationz_of_school="
				+ year_of_foundationz_of_school + ", lower_standard=" + lower_standard + ", higher_standard="
				+ higher_standard + ", sangstha_company_name=" + sangstha_company_name
				+ ", sanstha_company_has_purpose_for_only_education_service="
				+ sanstha_company_has_purpose_for_only_education_service
				+ ", is_school_open_where_address_mentioned_in_approval="
				+ is_school_open_where_address_mentioned_in_approval + ", if_sanstha_is_handover_to_someone="
				+ ifSansthaIsHandoverToSomeone + ", do_you_have_maharastra_shashan_manyata_no="
				+ do_you_have_maharastra_shashan_manyata_no + ", maharastra_shashan_approval_number="
				+ maharastra_shashan_approval_number + ", maharastra_shashan_approval_date="
				+ maharastra_shashan_approval_date + ", do_you_have_shikshan_upsanchalak_approval="
				+ do_you_have_shikshan_upsanchalak_approval + ", shikshan_upsanchalak_approval_date="
				+ shikshan_upsanchalak_approval_date + ", shikshan_upsanchalak_approval_number="
				+ shikshan_upsanchalak_approval_number + ", do_you_have_pratham_manyata_certificate="
				+ do_you_have_pratham_manyata_certificate + ", pratham_manyata_number=" + pratham_manyata_number
				+ ", pratham_manyata_date=" + pratham_manyata_date
				+ ", do_you_run_on_government_no_objection_certificate="
				+ do_you_run_on_government_no_objection_certificate + ", no_objection_certificate_number="
				+ no_objection_certificate_number + ", no_objection_certificate_date=" + no_objection_certificate_date
				+ ", whether_school_is_moved_to_another_location=" + whether_school_is_moved_to_another_location
				+ ", members=" + members + ", simple_lower_standard=" + simple_lower_standard
				+ ", simple_higher_standard=" + simple_higher_standard + ", udise_lower_standard="
				+ udise_lower_standard + ", udise_higher_standard=" + udise_higher_standard
				+ ", is_there_an_affiliation_certificate=" + is_there_an_affiliation_certificate
				+ ", affiliation_certificate_number=" + affiliation_certificate_number
				+ ", affiliation_certificate_date=" + affiliation_certificate_date + ", section1inspection_approval="
				+ section1inspection_approval + ", section2inspection_approval=" + section2inspection_approval
				+ ", section3inspection_approval=" + section3inspection_approval + ", section1inspection_comment="
				+ section1inspection_comment + ", section2inspection_comment=" + section2inspection_comment
				+ ", section3inspection_comment=" + section3inspection_comment + ", status=" + status
				+ ", uploaded_file_path=" + uploaded_file_path + "]";
	}

	public UdiseNumber(Long id, String udiseNumber, String schoolName, String addressDeputyDirector, String district,
			String taluka, String village, String pincode, String telephonenumber, String schoolMobileNumber,
			String schoolemailid, String typeofschool, String addressapprovaldocuments, String schoolEstablishmentYear,
			String dateoffirstcommencementschool, String schoolarea, String medium, String schoolBoard,
			String schoolHalfdaySchedule, String schoolDaySchedule, String middaymealschedule,
			String nameOfSocietyManagementCommittee, String classpresentinudise, String selfapprovalcertificate,
			String nearpolicestationname, String school_address,
			String address_mentioned_in_government_approval_document, String school_academic_session,
			String school_time_full_time, String school_time_half_time, String academic_learning_time_for_each_class,
			String lunch_time_for_each_class, String sports_and_physical_education_time_for_each_class,
			String registration_no, String under_the_societies_registration_act1860,
			String under_the_mumbai_public_trustee_system_act1950, String till_what_period_the_registration_of_trust,
			String is_there_evidence_that_the_trust, String school_user_name, String school_user_degisnation,
			String school_user_address, String school_user_telephone, String account_year, String account_income,
			String account_expense, String account_balance, String for_which_year_you_want_to_apply_foracertificate,
			String year_of_foundationz_of_school, String lower_standard, String higher_standard,
			String sangstha_company_name, String sanstha_company_has_purpose_for_only_education_service,
			String is_school_open_where_address_mentioned_in_approval, String if_sanstha_is_handover_to_someone,
			String do_you_have_maharastra_shashan_manyata_no, String maharastra_shashan_approval_number,
			String maharastra_shashan_approval_date, String do_you_have_shikshan_upsanchalak_approval,
			String shikshan_upsanchalak_approval_date, String shikshan_upsanchalak_approval_number,
			String do_you_have_pratham_manyata_certificate, String pratham_manyata_number, String pratham_manyata_date,
			String do_you_run_on_government_no_objection_certificate, String no_objection_certificate_number,
			String no_objection_certificate_date, String whether_school_is_moved_to_another_location, String members,
			String simple_lower_standard, String simple_higher_standard, String udise_lower_standard,
			String udise_higher_standard, String is_there_an_affiliation_certificate,
			String affiliation_certificate_number, String affiliation_certificate_date,
			String section1inspection_approval, String section2inspection_approval, String section3inspection_approval,
			String section1inspection_comment, String section2inspection_comment, String section3inspection_comment,
			String status, String uploaded_file_path) {
		super();
		this.id = id;
		this.udiseNumber = udiseNumber;
		this.name = name;
		this.addressDeputyDirector = addressDeputyDirector;
		this.district = district;
		this.taluka = taluka;
		this.village = village;
		this.pincode = pincode;
		this.telephonenumber = telephonenumber;
		this.schoolMobileNumber = schoolMobileNumber;
		this.schoolemailid = schoolemailid;
		this.typeofschool = typeofschool;
		this.addressapprovaldocuments = addressapprovaldocuments;
		this.schoolEstablishmentYear = schoolEstablishmentYear;
		this.dateoffirstcommencementschool = dateoffirstcommencementschool;
		this.schoolarea = schoolarea;
		this.medium = medium;
		this.schoolBoard = schoolBoard;
		this.schoolHalfdaySchedule = schoolHalfdaySchedule;
		this.schoolDaySchedule = schoolDaySchedule;
		this.middaymealschedule = middaymealschedule;
		this.nameOfSocietyManagementCommittee = nameOfSocietyManagementCommittee;
		this.classpresentinudise = classpresentinudise;
		this.selfapprovalcertificate = selfapprovalcertificate;
		this.nearpolicestationname = nearpolicestationname;
		this.school_address = school_address;
		this.address_mentioned_in_government_approval_document = address_mentioned_in_government_approval_document;
		this.school_academic_session = school_academic_session;
		this.school_time_full_time = school_time_full_time;
		this.school_time_half_time = school_time_half_time;
		this.academic_learning_time_for_each_class = academic_learning_time_for_each_class;
		this.lunch_time_for_each_class = lunch_time_for_each_class;
		this.sports_and_physical_education_time_for_each_class = sports_and_physical_education_time_for_each_class;
		this.registration_no = registration_no;
		this.under_the_societies_registration_act1860 = under_the_societies_registration_act1860;
		this.under_the_mumbai_public_trustee_system_act1950 = under_the_mumbai_public_trustee_system_act1950;
		this.till_what_period_the_registration_of_trust = till_what_period_the_registration_of_trust;
		this.is_there_evidence_that_the_trust = is_there_evidence_that_the_trust;
		this.school_user_name = school_user_name;
		this.school_user_degisnation = school_user_degisnation;
		this.school_user_address = school_user_address;
		this.school_user_telephone = school_user_telephone;
		this.account_year = account_year;
		this.account_income = account_income;
		this.account_expense = account_expense;
		this.account_balance = account_balance;
		this.for_which_year_you_want_to_apply_foracertificate = for_which_year_you_want_to_apply_foracertificate;
		this.year_of_foundationz_of_school = year_of_foundationz_of_school;
		this.lower_standard = lower_standard;
		this.higher_standard = higher_standard;
		this.sangstha_company_name = sangstha_company_name;
		this.sanstha_company_has_purpose_for_only_education_service = sanstha_company_has_purpose_for_only_education_service;
		this.is_school_open_where_address_mentioned_in_approval = is_school_open_where_address_mentioned_in_approval;
		this.ifSansthaIsHandoverToSomeone = if_sanstha_is_handover_to_someone;
		this.do_you_have_maharastra_shashan_manyata_no = do_you_have_maharastra_shashan_manyata_no;
		this.maharastra_shashan_approval_number = maharastra_shashan_approval_number;
		this.maharastra_shashan_approval_date = maharastra_shashan_approval_date;
		this.do_you_have_shikshan_upsanchalak_approval = do_you_have_shikshan_upsanchalak_approval;
		this.shikshan_upsanchalak_approval_date = shikshan_upsanchalak_approval_date;
		this.shikshan_upsanchalak_approval_number = shikshan_upsanchalak_approval_number;
		this.do_you_have_pratham_manyata_certificate = do_you_have_pratham_manyata_certificate;
		this.pratham_manyata_number = pratham_manyata_number;
		this.pratham_manyata_date = pratham_manyata_date;
		this.do_you_run_on_government_no_objection_certificate = do_you_run_on_government_no_objection_certificate;
		this.no_objection_certificate_number = no_objection_certificate_number;
		this.no_objection_certificate_date = no_objection_certificate_date;
		this.whether_school_is_moved_to_another_location = whether_school_is_moved_to_another_location;
		this.members = members;
		this.simple_lower_standard = simple_lower_standard;
		this.simple_higher_standard = simple_higher_standard;
		this.udise_lower_standard = udise_lower_standard;
		this.udise_higher_standard = udise_higher_standard;
		this.is_there_an_affiliation_certificate = is_there_an_affiliation_certificate;
		this.affiliation_certificate_number = affiliation_certificate_number;
		this.affiliation_certificate_date = affiliation_certificate_date;
		this.section1inspection_approval = section1inspection_approval;
		this.section2inspection_approval = section2inspection_approval;
		this.section3inspection_approval = section3inspection_approval;
		this.section1inspection_comment = section1inspection_comment;
		this.section2inspection_comment = section2inspection_comment;
		this.section3inspection_comment = section3inspection_comment;
		this.status = status;
		this.uploaded_file_path = uploaded_file_path;
	}

	public UdiseNumber() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}