package com.emanyata.app.serviceImpl.primary;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.emanyata.app.dto.BhauticSuvidhaDTO;
import com.emanyata.app.entity.primary.ApplicationsResult;
import com.emanyata.app.entity.primary.BhauticSuvidha;
import com.emanyata.app.entity.primary.School;
import com.emanyata.app.entity.primary.SchoolApply;
import com.emanyata.app.repo.primary.ApplicationResultRepo;
import com.emanyata.app.repo.primary.BhautikSuvidhaRepository;
import com.emanyata.app.repo.primary.SchoolApplyRepo;
import com.emanyata.app.repo.primary.SchoolRepo;
import com.emanyata.app.service.primary.BhautikSuvidhaService;
import com.emanyata.app.util.ApplicationFormStepsUtil;

import jakarta.transaction.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class BhautikSuvidhaServiceImpl implements BhautikSuvidhaService {

    @Autowired
    private BhautikSuvidhaRepository repository;

    @Autowired
    private SchoolRepo schoolRepository;

    @Autowired
    private SchoolApplyRepo applyRepo;

    @Autowired
    private ApplicationResultRepo applicationResultRepo;
    
    @Autowired
    private ApplicationFormStepsUtil stepsUtil;

    @Override
    public BhauticSuvidhaDTO getById(Long id) {
    	
        return repository.findById(id)
                .map(this::mapToDto)
                .orElseThrow(() -> new RuntimeException("BhauticSuvidha not found with ID: " + id));
    }

    @Override
    public BhauticSuvidhaDTO getBySchoolID(Long schoolId) {
        BhauticSuvidha bhauticSuvidha = repository.getBySchoolId(schoolId)
                .orElseThrow(() -> new RuntimeException("No Bhautic Suvidha found for school ID: " + schoolId));

        Long applicationId = bhauticSuvidha.getApplicationId();
        
        ApplicationsResult applicationResult = applicationResultRepo.findByApplicationId(applicationId)
                .orElseThrow(() -> new RuntimeException("Application result not found for application ID: " + applicationId));

        BhauticSuvidhaDTO dto = mapToDto(bhauticSuvidha);
        
        // Populate additional details from ApplicationsResult
        dto.setGeneralInfo(applicationResult.getGeneralInfo());
        dto.setDetailsOfPhysicals(applicationResult.getDetailsOfPhysical());
        dto.setGrantedSchool(applicationResult.getGranted());
        dto.setStudentCount(applicationResult.getStudentCount());
        dto.setNonGrantedSchool(applicationResult.getNonGranted());
        dto.setOtherFacility(applicationResult.getOtherFacilities());

        return dto;
    }


    
    @Override
    @Transactional
    public BhauticSuvidhaDTO save(BhauticSuvidhaDTO dto) {
        validateDto(dto);
        
        SchoolApply application = applyRepo.findById(dto.getApplicationId())
                .orElseThrow(() -> new RuntimeException("Application not found with ID: " + dto.getApplicationId()));
        
        Optional<BhauticSuvidha> existingEntity = repository.findBySchoolId(dto.getSchoolId());
        
        if (existingEntity.isPresent()) {
            validateApplicationMatch(existingEntity.get(), dto.getApplicationId());
            updateEntityFields(existingEntity.get(), dto);
            
            BhauticSuvidhaDTO dto2= mapToDto(repository.save(existingEntity.get()));
            ApplicationsResult rs = applicationResultRepo.findByApplicationId(dto2.getApplicationId()).orElseThrow(()->new RuntimeException("No result found in application result."));
            dto2.setGeneralInfo(rs.getGeneralInfo());
            dto2.setStudentCount(rs.getStudentCount());
            dto2.setDetailsOfPhysicals(rs.getDetailsOfPhysical());
            dto2.setOtherFacility(rs.getOtherFacilities());
            dto2.setGrantedSchool(rs.getGranted());
            dto2.setNonGrantedSchool(rs.getNonGranted());
            return dto2;
        } else {
            School school = schoolRepository.findById(dto.getSchoolId())
                    .orElseThrow(() -> new RuntimeException("School not found with ID: " + dto.getSchoolId()));
            
            BhauticSuvidha newEntity = createNewEntity(dto, school);
            updateEntityFields(newEntity, dto);
            
            applyRepo.findById(dto.getApplicationId()).ifPresent(apply -> {
                String updatedSteps = stepsUtil.updateStepsJson(apply.getSteps(), "details_of_physicals");
                apply.setSteps(updatedSteps);
                applyRepo.save(apply);
            });

            
            BhauticSuvidha savedEntity = repository.save(newEntity);
            
            Optional<ApplicationsResult> resultOpt = applicationResultRepo
					.findByApplicationId(dto.getApplicationId());
            ApplicationsResult rs;
			if (resultOpt.isPresent()) {
				ApplicationsResult result = resultOpt.get();
				result.setDetailsOfPhysical((byte) 1);
				rs= applicationResultRepo.save(result);
			} else {
				throw new RuntimeException("Application Id not present in application result.");
			}
            
            updateApplicationResult(dto.getApplicationId());
            BhauticSuvidhaDTO dto2=mapToDto(savedEntity);
            dto2.setGeneralInfo(rs.getGeneralInfo());
            dto2.setStudentCount(rs.getStudentCount());
            dto2.setDetailsOfPhysicals(rs.getDetailsOfPhysical());
            dto2.setOtherFacility(rs.getOtherFacilities());
            dto2.setGrantedSchool(rs.getGranted());
            dto2.setNonGrantedSchool(rs.getNonGranted());
            return dto2;
        }
    }

    private void validateDto(BhauticSuvidhaDTO dto) {
        if (dto.getSchoolId() == null || dto.getApplicationId() == null) {
            throw new IllegalArgumentException("SchoolId and ApplicationId are required");
        }
    }

    private void validateApplicationMatch(BhauticSuvidha entity, Long applicationId) {
        if (!entity.getApplicationId().equals(applicationId)) {
            throw new RuntimeException("Application ID mismatched for BhauticSuvidha with ID: " + entity.getId());
        }
    }

    private BhauticSuvidha createNewEntity(BhauticSuvidhaDTO dto, School school) {
        BhauticSuvidha entity = new BhauticSuvidha();
        entity.setSchool(school);
        entity.setApplicationId(dto.getApplicationId());
        entity.setStatus((byte) 1);
        entity.setCreatedAt(dto.getCreatedAt() != null ? dto.getCreatedAt() : LocalDateTime.now());
        return entity;
    }

    private void updateEntityFields(BhauticSuvidha entity, BhauticSuvidhaDTO dto) {
        // Basic fields
        if (dto.getClassroom() != null) entity.setClassroom(dto.getClassroom());
        if (dto.getOfficeRoom() != null) entity.setOfficeRoom(dto.getOfficeRoom());
        if (dto.getKitchen() != null) entity.setKitchen(dto.getKitchen());
        
        // Sanitation fields
        if (dto.getSeparateToiletsForBoysAndGirls() != null) 
            entity.setSeparateToiletsForBoysAndGirls(dto.getSeparateToiletsForBoysAndGirls());
        if (dto.getDrinkingWaterFacility() != null) 
            entity.setDrinkingWaterFacility(dto.getDrinkingWaterFacility());
        
        // Area fields
        if (dto.getAreaSqM() != null) entity.setAreaSqM(dto.getAreaSqM());
        if (dto.getTotalAreaSqM() != null) entity.setTotalAreaSqM(dto.getTotalAreaSqM());
        if (dto.getSchoolTotalAreaSqM() != null) entity.setSchoolTotalAreaSqM(dto.getSchoolTotalAreaSqM());
        
        // Count fields
        if (dto.getPrincipalCount() != null) entity.setPrincipalCount(dto.getPrincipalCount());
        if (dto.getOfficeCount() != null) entity.setOfficeCount(dto.getOfficeCount());
        if (dto.getStaffCount() != null) entity.setStaffCount(dto.getStaffCount());
        if (dto.getStorageCount() != null) entity.setStorageCount(dto.getStorageCount());
        if (dto.getClassroomCount() != null) entity.setClassroomCount(dto.getClassroomCount());
        if (dto.getLabCount() != null) entity.setLabCount(dto.getLabCount());
        if (dto.getCompCount() != null) entity.setCompCount(dto.getCompCount());
        if (dto.getLibraryCount() != null) entity.setLibraryCount(dto.getLibraryCount());
        if (dto.getSchoolTotalCount() != null) entity.setSchoolTotalCount(dto.getSchoolTotalCount());
        if (dto.getWesternToiletCount() != null) entity.setWesternToiletCount(dto.getWesternToiletCount());
        
        // Area fields
        if (dto.getPrincipalArea() != null) entity.setPrincipalArea(dto.getPrincipalArea());
        if (dto.getOfficeArea() != null) entity.setOfficeArea(dto.getOfficeArea());
        if (dto.getStaffArea() != null) entity.setStaffArea(dto.getStaffArea());
        if (dto.getStorageArea() != null) entity.setStorageArea(dto.getStorageArea());
        if (dto.getClassroomArea() != null) entity.setClassroomArea(dto.getClassroomArea());
        if (dto.getLabArea() != null) entity.setLabArea(dto.getLabArea());
        if (dto.getCompArea() != null) entity.setCompArea(dto.getCompArea());
        if (dto.getLibraryArea() != null) entity.setLibraryArea(dto.getLibraryArea());
        if (dto.getSchoolTotalArea() != null) entity.setSchoolTotalArea(dto.getSchoolTotalArea());
        
        // Toilet facilities
        if (dto.getToiletAvailableFacilityDetails() != null) 
            entity.setToiletAvailableFacilityDetails(dto.getToiletAvailableFacilityDetails());
        
        // Boys facilities
        if (dto.getSeperateBoysToiletCount() != null) 
            entity.setSeperateBoysToiletCount(dto.getSeperateBoysToiletCount());
        if (dto.getSeperateBoysToiletFacilityDetails() != null) 
            entity.setSeperateBoysToiletFacilityDetails(dto.getSeperateBoysToiletFacilityDetails());
        if (dto.getSeperateBoysWashroomCount() != null) 
            entity.setSeperateBoysWashroomCount(dto.getSeperateBoysWashroomCount());
        if (dto.getSeperateBoysWashroomFacilityDetails() != null) 
            entity.setSeperateBoysWashroomFacilityDetails(dto.getSeperateBoysWashroomFacilityDetails());
        if (dto.getSeperateBoysDrinkingWaterCount() != null) 
            entity.setSeperateBoysDrinkingWaterCount(dto.getSeperateBoysDrinkingWaterCount());
        if (dto.getSeperateBoysDrinkingWaterFacilityDetails() != null) 
            entity.setSeperateBoysDrinkingWaterFacilityDetails(dto.getSeperateBoysDrinkingWaterFacilityDetails());
        
        // Girls facilities
        if (dto.getSeperateGirlsToiletCount() != null) 
            entity.setSeperateGirlsToiletCount(dto.getSeperateGirlsToiletCount());
        if (dto.getSeperateGirlsToiletFacilityDetails() != null) 
            entity.setSeperateGirlsToiletFacilityDetails(dto.getSeperateGirlsToiletFacilityDetails());
        if (dto.getSeperateGirlsWashroomCount() != null) 
            entity.setSeperateGirlsWashroomCount(dto.getSeperateGirlsWashroomCount());
        if (dto.getSeperateGirlsWashroomFacilityDetails() != null) 
            entity.setSeperateGirlsWashroomFacilityDetails(dto.getSeperateGirlsWashroomFacilityDetails());
        if (dto.getSeperateGirlsDrinkingWaterCount() != null) 
            entity.setSeperateGirlsDrinkingWaterCount(dto.getSeperateGirlsDrinkingWaterCount());
        if (dto.getSeperateGirlsDrinkingWaterFacilityDetails() != null) 
            entity.setSeperateGirlsDrinkingWaterFacilityDetails(dto.getSeperateGirlsDrinkingWaterFacilityDetails());
        
        // Accessibility
        if (dto.getRampRoad() != null) entity.setRampRoad(dto.getRampRoad());
        if (dto.getRocksOnTheSideOfTheRamp() != null) 
            entity.setRocksOnTheSideOfTheRamp(dto.getRocksOnTheSideOfTheRamp());
        if (dto.getRampFacilityDetails() != null) 
            entity.setRampFacilityDetails(dto.getRampFacilityDetails());
        if (dto.getaRampForBarrierFreeAccess() != null) 
            entity.setARampForBarrierFreeAccess(dto.getaRampForBarrierFreeAccess());
        
        // Safety + Infra
        if (dto.getRoomNumber() != null) entity.setRoomNumber(dto.getRoomNumber());
        if (dto.getTheRoofIsSolidRcc() != null) entity.setTheRoofIsSolidRcc(dto.getTheRoofIsSolidRcc());
        if (dto.getFireWarrantyCylinderNo() != null) 
            entity.setFireWarrantyCylinderNo(dto.getFireWarrantyCylinderNo());
        if (dto.getMedicalPrimaryBoxNumber() != null) 
            entity.setMedicalPrimaryBoxNumber(dto.getMedicalPrimaryBoxNumber());
        if (dto.getCctvNo() != null) entity.setCctvNo(dto.getCctvNo());
        if (dto.getPlaquesInFacadesOfSchoolRecognition() != null) 
            entity.setPlaquesInFacadesOfSchoolRecognition(dto.getPlaquesInFacadesOfSchoolRecognition());
        
        // Playground
        if (dto.getAreaOfPlayground() != null) entity.setAreaOfPlayground(dto.getAreaOfPlayground());
        if (dto.getAreaOfPlaygroundDetails() != null) 
            entity.setAreaOfPlaygroundDetails(dto.getAreaOfPlaygroundDetails());
        
        // Security + Kitchen
        if (dto.getRetainingWallCompound() != null) 
            entity.setRetainingWallCompound(dto.getRetainingWallCompound());
        if (dto.getEntranceWithProtectiveWallAndIronGate() != null) 
            entity.setEntranceWithProtectiveWallAndIronGate(dto.getEntranceWithProtectiveWallAndIronGate());
        if (dto.getKitchenShed() != null) entity.setKitchenShed(dto.getKitchenShed());
        if (dto.getKitchenShedDetails() != null) entity.setKitchenShedDetails(dto.getKitchenShedDetails());
        
        // Water infra
        if (dto.getWaterTapCount() != null) entity.setWaterTapCount(dto.getWaterTapCount());
        if (dto.getWaterTankCapacity() != null) entity.setWaterTankCapacity(dto.getWaterTankCapacity());
        if (dto.getActualAvailableFacilityDetailsTap() != null) 
            entity.setActualAvailableFacilityDetailsTap(dto.getActualAvailableFacilityDetailsTap());
        if (dto.getActualAvailableFacilityDetailsWater() != null) 
            entity.setActualAvailableFacilityDetailsWater(dto.getActualAvailableFacilityDetailsWater());
        
        // Location info
        if (dto.getWhetherSchoolIsMovedToAnotherLocation() != null) 
            entity.setWhetherSchoolIsMovedToAnotherLocation(dto.getWhetherSchoolIsMovedToAnotherLocation());
        if (dto.getTypeOfProofAvailableAndItsDate() != null) 
            entity.setTypeOfProofAvailableAndItsDate(dto.getTypeOfProofAvailableAndItsDate());
        if (dto.getForYouTakePropertyDocumentType() != null) 
            entity.setForYouTakePropertyDocumentType(dto.getForYouTakePropertyDocumentType());
        
        // Inspection approvals
        if (dto.getSection1InspectionApproval() != null) 
            entity.setSection1InspectionApproval(dto.getSection1InspectionApproval());
        if (dto.getSection2InspectionApproval() != null) 
            entity.setSection2InspectionApproval(dto.getSection2InspectionApproval());
        if (dto.getSection3InspectionApproval() != null) 
            entity.setSection3InspectionApproval(dto.getSection3InspectionApproval());
        if (dto.getSection4InspectionApproval() != null) 
            entity.setSection4InspectionApproval(dto.getSection4InspectionApproval());
        if (dto.getSection5InspectionApproval() != null) 
            entity.setSection5InspectionApproval(dto.getSection5InspectionApproval());
        if (dto.getSection6InspectionApproval() != null) 
            entity.setSection6InspectionApproval(dto.getSection6InspectionApproval());
        
        // Inspection comments
        if (dto.getSection1InspectionComment() != null) 
            entity.setSection1InspectionComment(dto.getSection1InspectionComment());
        if (dto.getSection2InspectionComment() != null) 
            entity.setSection2InspectionComment(dto.getSection2InspectionComment());
        if (dto.getSection3InspectionComment() != null) 
            entity.setSection3InspectionComment(dto.getSection3InspectionComment());
        if (dto.getSection4InspectionComment() != null) 
            entity.setSection4InspectionComment(dto.getSection4InspectionComment());
        if (dto.getSection5InspectionComment() != null) 
            entity.setSection5InspectionComment(dto.getSection5InspectionComment());
        if (dto.getSection6InspectionComment() != null) 
            entity.setSection6InspectionComment(dto.getSection6InspectionComment());
        
        // Timestamps
        entity.setUpdatedAt(LocalDateTime.now());
    }

    private void updateApplicationResult(Long applicationId) {
        ApplicationsResult result = applicationResultRepo.findByApplicationId(applicationId)
                .orElseThrow(() -> new RuntimeException("Application result not found for ID: " + applicationId));
        result.setDetailsOfPhysical((byte) 1);
        applicationResultRepo.save(result);
    }

    private BhauticSuvidhaDTO mapToDto(BhauticSuvidha entity) {
        BhauticSuvidhaDTO dto = new BhauticSuvidhaDTO();
        dto.setId(entity.getId());
        dto.setSchoolId(entity.getSchool().getId());
        dto.setClassroom(entity.getClassroom());
        dto.setOfficeRoom(entity.getOfficeRoom());
        dto.setKitchen(entity.getKitchen());
        dto.setSeparateToiletsForBoysAndGirls(entity.getSeparateToiletsForBoysAndGirls());
        dto.setDrinkingWaterFacility(entity.getDrinkingWaterFacility());
        dto.setUpdatedAt(entity.getUpdatedAt());
        dto.setApplicationId(entity.getApplicationId());
        dto.setWhetherSchoolIsMovedToAnotherLocation(entity.getWhetherSchoolIsMovedToAnotherLocation());
        dto.setTypeOfProofAvailableAndItsDate(entity.getTypeOfProofAvailableAndItsDate());
        dto.setForYouTakePropertyDocumentType(entity.getForYouTakePropertyDocumentType());
        dto.setAreaSqM(entity.getAreaSqM());
        dto.setTotalAreaSqM(entity.getTotalAreaSqM());
        dto.setSchoolTotalAreaSqM(entity.getSchoolTotalAreaSqM());
        dto.setPrincipalCount(entity.getPrincipalCount());
        dto.setPrincipalArea(entity.getPrincipalArea());
        dto.setOfficeCount(entity.getOfficeCount());
        dto.setOfficeArea(entity.getOfficeArea());
        dto.setStaffCount(entity.getStaffCount());
        dto.setStaffArea(entity.getStaffArea());
        dto.setStorageCount(entity.getStorageCount());
        dto.setStorageArea(entity.getStorageArea());
        dto.setClassroomCount(entity.getClassroomCount());
        dto.setClassroomArea(entity.getClassroomArea());
        dto.setLabCount(entity.getLabCount());
        dto.setLabArea(entity.getLabArea());
        dto.setCompCount(entity.getCompCount());
        dto.setCompArea(entity.getCompArea());
        dto.setLibraryCount(entity.getLibraryCount());
        dto.setLibraryArea(entity.getLibraryArea());
        dto.setSchoolTotalCount(entity.getSchoolTotalCount());
        dto.setSchoolTotalArea(entity.getSchoolTotalArea());
        dto.setWesternToiletCount(entity.getWesternToiletCount());
        dto.setToiletAvailableFacilityDetails(entity.getToiletAvailableFacilityDetails());
        dto.setSeperateBoysToiletCount(entity.getSeperateBoysToiletCount());
        dto.setSeperateBoysToiletFacilityDetails(entity.getSeperateBoysToiletFacilityDetails());
        dto.setSeperateBoysWashroomCount(entity.getSeperateBoysWashroomCount());
        dto.setSeperateBoysWashroomFacilityDetails(entity.getSeperateBoysWashroomFacilityDetails());
        dto.setSeperateBoysDrinkingWaterCount(entity.getSeperateBoysDrinkingWaterCount());
        dto.setSeperateBoysDrinkingWaterFacilityDetails(entity.getSeperateBoysDrinkingWaterFacilityDetails());
        dto.setSeperateGirlsToiletCount(entity.getSeperateGirlsToiletCount());
        dto.setSeperateGirlsToiletFacilityDetails(entity.getSeperateGirlsToiletFacilityDetails());
        dto.setSeperateGirlsWashroomCount(entity.getSeperateGirlsWashroomCount());
        dto.setSeperateGirlsWashroomFacilityDetails(entity.getSeperateGirlsWashroomFacilityDetails());
        dto.setSeperateGirlsDrinkingWaterCount(entity.getSeperateGirlsDrinkingWaterCount());
        dto.setSeperateGirlsDrinkingWaterFacilityDetails(entity.getSeperateGirlsDrinkingWaterFacilityDetails());
        dto.setRampRoad(entity.getRampRoad());
        dto.setRocksOnTheSideOfTheRamp(entity.getRocksOnTheSideOfTheRamp());
        dto.setRampFacilityDetails(entity.getRampFacilityDetails());
        dto.setRoomNumber(entity.getRoomNumber());
        dto.setTheRoofIsSolidRcc(entity.getTheRoofIsSolidRcc());
        dto.setFireWarrantyCylinderNo(entity.getFireWarrantyCylinderNo());
        dto.setMedicalPrimaryBoxNumber(entity.getMedicalPrimaryBoxNumber());
        dto.setCctvNo(entity.getCctvNo());
        dto.setPlaquesInFacadesOfSchoolRecognition(entity.getPlaquesInFacadesOfSchoolRecognition());
        dto.setaRampForBarrierFreeAccess(entity.getARampForBarrierFreeAccess());
        dto.setAreaOfPlayground(entity.getAreaOfPlayground());
        dto.setAreaOfPlaygroundDetails(entity.getAreaOfPlaygroundDetails());
        dto.setRetainingWallCompound(entity.getRetainingWallCompound());
        dto.setEntranceWithProtectiveWallAndIronGate(entity.getEntranceWithProtectiveWallAndIronGate());
        dto.setKitchenShed(entity.getKitchenShed());
        dto.setKitchenShedDetails(entity.getKitchenShedDetails());
        dto.setWaterTapCount(entity.getWaterTapCount());
        dto.setWaterTankCapacity(entity.getWaterTankCapacity());
        dto.setActualAvailableFacilityDetailsTap(entity.getActualAvailableFacilityDetailsTap());
        dto.setActualAvailableFacilityDetailsWater(entity.getActualAvailableFacilityDetailsWater());
        dto.setSection1InspectionApproval(entity.getSection1InspectionApproval());
        dto.setSection2InspectionApproval(entity.getSection2InspectionApproval());
        dto.setSection3InspectionApproval(entity.getSection3InspectionApproval());
        dto.setSection4InspectionApproval(entity.getSection4InspectionApproval());
        dto.setSection5InspectionApproval(entity.getSection5InspectionApproval());
        dto.setSection6InspectionApproval(entity.getSection6InspectionApproval());
        dto.setSection1InspectionComment(entity.getSection1InspectionComment());
        dto.setSection2InspectionComment(entity.getSection2InspectionComment());
        dto.setSection3InspectionComment(entity.getSection3InspectionComment());
        dto.setSection4InspectionComment(entity.getSection4InspectionComment());
        dto.setSection5InspectionComment(entity.getSection5InspectionComment());
        dto.setSection6InspectionComment(entity.getSection6InspectionComment());
        
        dto.setCreatedAt(LocalDateTime.now());
        return dto;
    }
}