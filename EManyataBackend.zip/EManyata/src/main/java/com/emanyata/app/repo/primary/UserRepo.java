package com.emanyata.app.repo.primary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.primary.School;
import com.emanyata.app.entity.primary.User;

import java.util.List;
import java.util.Optional;

public interface UserRepo extends JpaRepository<User, Long> {

	Optional<User> findByEmail(String email);

	Optional<User> findByMobile(String mobile);
 
    Optional<User> findBySchools_UdiseNo(String udiseNo);

	void save(School school);
	
	Optional<User> findByIdAndEmailAndMobile(Long userId, String email, String mobile);
	
	//=================== ADMIN METHODS =========================
	
	List<User> findByRoleIdIn(List<Integer> roleIds);
	List<User> findByRoleId(Long id);

	Optional<User> findByEmailOrMobile(String emailOrMobile, String emailOrMobile2);






	

}