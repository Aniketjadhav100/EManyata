package com.emanyata.app.dto;

import java.time.LocalDateTime;
import java.time.LocalDate;

public class SchoolApplyDTO {
    private Long id;
    private Long userId;
    private Long schoolId;
    private String applyStatus;
    private String token;
    private String status;
    private String inspectionStatus;
    private LocalDate inspectionCompletionDate;
    private String applicationNo;
    private String visitingDate;
    private Integer inspectionOfficeId;
    private LocalDate submittedDate;
    private String approvedDate;
    private String expiredDate;
    private LocalDate renewDate;
    private String steps;
    private String turtiPdf;
    private String tipaniPdf;
    private String schoolInspectionPdf;
    private Boolean docAvailableVerified;
    private Boolean rte2009Followed;
    private Boolean namuna2Doc;
    private String officerComment;
    private String abhiprayPdf;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
	public Long getId() {
		return id;
	}
	public SchoolApplyDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(Long schoolId) {
		this.schoolId = schoolId;
	}
	public String getApplyStatus() {
		return applyStatus;
	}
	public void setApplyStatus(String applyStatus) {
		this.applyStatus = applyStatus;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getInspectionStatus() {
		return inspectionStatus;
	}
	public void setInspectionStatus(String inspectionStatus) {
		this.inspectionStatus = inspectionStatus;
	}
	public LocalDate getInspectionCompletionDate() {
		return inspectionCompletionDate;
	}
	public void setInspectionCompletionDate(LocalDate inspectionCompletionDate) {
		this.inspectionCompletionDate = inspectionCompletionDate;
	}
	public String getApplicationNo() {
		return applicationNo;
	}
	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}
	public String getVisitingDate() {
		return visitingDate;
	}
	public void setVisitingDate(String visitingDate) {
		this.visitingDate = visitingDate;
	}
	public Integer getInspectionOfficeId() {
		return inspectionOfficeId;
	}
	public void setInspectionOfficeId(Integer inspectionOfficeId) {
		this.inspectionOfficeId = inspectionOfficeId;
	}
	public LocalDate getSubmittedDate() {
		return submittedDate;
	}
	public void setSubmittedDate(LocalDate submittedDate) {
		this.submittedDate = submittedDate;
	}
	public String getApprovedDate() {
		return approvedDate;
	}
	public void setApprovedDate(String approvedDate) {
		this.approvedDate = approvedDate;
	}
	public String getExpiredDate() {
		return expiredDate;
	}
	public void setExpiredDate(String expiredDate) {
		this.expiredDate = expiredDate;
	}
	public LocalDate getRenewDate() {
		return renewDate;
	}
	public void setRenewDate(LocalDate renewDate) {
		this.renewDate = renewDate;
	}
	public String getSteps() {
		return steps;
	}
	public void setSteps(String steps) {
		this.steps = steps;
	}
	public String getTurtiPdf() {
		return turtiPdf;
	}
	public void setTurtiPdf(String turtiPdf) {
		this.turtiPdf = turtiPdf;
	}
	public String getTipaniPdf() {
		return tipaniPdf;
	}
	public void setTipaniPdf(String tipaniPdf) {
		this.tipaniPdf = tipaniPdf;
	}
	public String getSchoolInspectionPdf() {
		return schoolInspectionPdf;
	}
	public void setSchoolInspectionPdf(String schoolInspectionPdf) {
		this.schoolInspectionPdf = schoolInspectionPdf;
	}
	public Boolean getDocAvailableVerified() {
		return docAvailableVerified;
	}
	public void setDocAvailableVerified(Boolean docAvailableVerified) {
		this.docAvailableVerified = docAvailableVerified;
	}
	public Boolean getRte2009Followed() {
		return rte2009Followed;
	}
	public void setRte2009Followed(Boolean rte2009Followed) {
		this.rte2009Followed = rte2009Followed;
	}
	public Boolean getNamuna2Doc() {
		return namuna2Doc;
	}
	public void setNamuna2Doc(Boolean namuna2Doc) {
		this.namuna2Doc = namuna2Doc;
	}
	public String getOfficerComment() {
		return officerComment;
	}
	public void setOfficerComment(String officerComment) {
		this.officerComment = officerComment;
	}
	public String getAbhiprayPdf() {
		return abhiprayPdf;
	}
	public void setAbhiprayPdf(String abhiprayPdf) {
		this.abhiprayPdf = abhiprayPdf;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
	public SchoolApplyDTO(Long id, Long userId, Long schoolId, String applyStatus, String token, String status,
			String inspectionStatus, LocalDate inspectionCompletionDate, String applicationNo, String visitingDate,
			Integer inspectionOfficeId, LocalDate submittedDate, String approvedDate, String expiredDate,
			LocalDate renewDate, String steps, String turtiPdf, String tipaniPdf, String schoolInspectionPdf,
			Boolean docAvailableVerified, Boolean rte2009Followed, Boolean namuna2Doc, String officerComment,
			String abhiprayPdf, LocalDateTime createdAt, LocalDateTime updatedAt) {
		super();
		this.id = id;
		this.userId = userId;
		this.schoolId = schoolId;
		this.applyStatus = applyStatus;
		this.token = token;
		this.status = status;
		this.inspectionStatus = inspectionStatus;
		this.inspectionCompletionDate = inspectionCompletionDate;
		this.applicationNo = applicationNo;
		this.visitingDate = visitingDate;
		this.inspectionOfficeId = inspectionOfficeId;
		this.submittedDate = submittedDate;
		this.approvedDate = approvedDate;
		this.expiredDate = expiredDate;
		this.renewDate = renewDate;
		this.steps = steps;
		this.turtiPdf = turtiPdf;
		this.tipaniPdf = tipaniPdf;
		this.schoolInspectionPdf = schoolInspectionPdf;
		this.docAvailableVerified = docAvailableVerified;
		this.rte2009Followed = rte2009Followed;
		this.namuna2Doc = namuna2Doc;
		this.officerComment = officerComment;
		this.abhiprayPdf = abhiprayPdf;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
	}

    // Getters and Setters
    // You can use Lombok @Data or @Getter/@Setter for brevity if preferred
    
    
    
}
