package com.emanyata.app.serviceImpl.secondary;

import java.util.*;

import com.emanyata.app.dto.YearWiseFormDataRequest;
import com.emanyata.app.entity.secondary.*;
import com.emanyata.app.repo.secondary.*;
import com.emanyata.app.service.secondary.FormDataService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FormDataServiceImpl implements FormDataService {

    @Autowired
    private OldSchoolRepository schoolRepo;

    @Autowired
    private OldSchoolApplyRepo applyRepo;

    @Autowired
    private OldUserRepo userRepo;

    @Autowired
    private OldSchoolGeneralInfoRepository generalInfoRepo;
//
//    @Autowired
//    private OldOtherFacilityRepo otherFacilityRepo;
//
//    @Autowired
//    private StudentCountRepository studentCountRepo;
//
//    @Autowired
//    private OldDetailOfPhysicalRepository physicalsRepo;
//
//    @Autowired
//    private OldGrantedSchoolInfoRepo grantedRepo;
//
//    @Autowired
//    private OldNonGrantedSchoolInfoRepo nonGrantedRepo;

    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public Map<String, Object> getYearWiseData(YearWiseFormDataRequest req) {
        Map<String, Object> response = new LinkedHashMap<>();

        var user = userRepo.findByEmailAndPhone(req.getEmail(), req.getMobile())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Long userId = user.getId();

        OldSchool school = schoolRepo.findByUdiseNoAndSchoolMobile(req.getUdiseNo(), user.getPhone())
                .orElseThrow(() -> new RuntimeException("School not found for given UDISE and mobile"));
        
        OldSchoolApply apply = applyRepo.findById(req.getApplicationId())
                .orElseThrow(() -> new RuntimeException("Application not found"));

        OldSchoolGeneralInfo generalInfo = generalInfoRepo.findByApplicationId(req.getApplicationId())
                .orElseThrow(() -> new RuntimeException("SchoolGeneralInfo not found"));

        List<String> selectedYears;
        try {
            selectedYears = objectMapper.readValue(
                    generalInfo.getForWhichYearYouWantToApplyForACertificate(),
                    new TypeReference<List<String>>() {});
        } catch (Exception e) {
            throw new RuntimeException("Invalid year JSON in general info", e);
        }

        List<String> allYears = Arrays.asList("2016-2019", "2019-2022", "2022-2025");
        int i = 1;
        int count = 0;

        for (String year : allYears) {
            if (selectedYears.contains(year)) {
                response.put("year" + i, year);
                count++;
            } else {
                response.put("year" + i, null);
            }
            i++;
        }

        response.put("yearCount", count);
        response.put("udiseNo", school.getUdiseNo()); // ✅ New
        response.put("schoolName", school.getSchoolName()); // ✅ New
        response.put("turtiPdf", apply.getTurtiPdf());
        response.put("tipaniPdf", apply.getTipaniPdf());
        response.put("schoolInspectionPdf", apply.getSchoolInspectionPdf());

     
//        // ✅ Step 7: Add all form data
//        response.put("school-general-info", generalInfo);
//        response.put("other-facility", otherFacilityRepo.findByApplicationId(req.getApplicationId()));
//        response.put("student-count", studentCountRepo.findByApplicationId(req.getApplicationId()));
//        response.put("details-of-physical", physicalsRepo.findByApplicationId(req.getApplicationId()));
//
//        if ("granted".equalsIgnoreCase(school.getSchoolType())) {
//            response.put("granted-school", grantedRepo.findByApplicationId(req.getApplicationId()));
//        } else {
//            response.put("non-granted-school", nonGrantedRepo.findByApplicationId(req.getApplicationId()));
//        }

        return response;
    }
}
