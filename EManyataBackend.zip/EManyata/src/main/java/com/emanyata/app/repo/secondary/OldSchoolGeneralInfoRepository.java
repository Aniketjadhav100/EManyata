package com.emanyata.app.repo.secondary;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.emanyata.app.entity.secondary.OldSchoolGeneralInfo;

@Repository
public interface OldSchoolGeneralInfoRepository extends JpaRepository<OldSchoolGeneralInfo, Long> {
    List<OldSchoolGeneralInfo> findBySchoolId(Long schoolId);
    Optional<OldSchoolGeneralInfo> findByApplicationId(Long applicationId);
}