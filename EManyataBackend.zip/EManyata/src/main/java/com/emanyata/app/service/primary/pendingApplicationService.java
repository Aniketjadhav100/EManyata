package com.emanyata.app.service.primary;

import java.util.List;

import com.emanyata.app.dto.pendingApplicationDTO;

public interface pendingApplicationService {

	List<pendingApplicationDTO> getAllPendingApplications();

}
