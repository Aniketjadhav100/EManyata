package com.emanyata.app.serviceImpl.primary;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emanyata.app.dto.rejectedApplicationDTO;
import com.emanyata.app.entity.primary.BhauticSuvidha;
import com.emanyata.app.entity.primary.GrantedSchoolInfo;
import com.emanyata.app.entity.primary.NonGrantedSchoolInfo;
import com.emanyata.app.entity.primary.OtherFacility;
import com.emanyata.app.entity.primary.School;
import com.emanyata.app.entity.primary.SchoolApply;
import com.emanyata.app.entity.primary.SchoolGeneralInfo;
import com.emanyata.app.repo.primary.BhautikSuvidhaRepository;
import com.emanyata.app.repo.primary.GrantedSchoolInfoRepository;
import com.emanyata.app.repo.primary.NonGrantedSchoolInfoRepo;
import com.emanyata.app.repo.primary.OtherFacilityRepo;
import com.emanyata.app.repo.primary.SchoolApplyRepo;
import com.emanyata.app.repo.primary.SchoolGeneralInfoRepo;
import com.emanyata.app.service.primary.rejectedApplicationService;

@Service
public class rejectedApplicationServiceImpl implements rejectedApplicationService {

	 @Autowired private SchoolApplyRepo schoolApplyRepo;
	    @Autowired private SchoolGeneralInfoRepo schoolGeneralInfoRepo;
	    @Autowired private BhautikSuvidhaRepository bhautikSuvidhaRepository;
	    @Autowired private OtherFacilityRepo otherFacilityRepo;
	    @Autowired private GrantedSchoolInfoRepository grantedSchoolInfoRepository;
	    @Autowired private NonGrantedSchoolInfoRepo nonGrantedSchoolInfoRepo;

    @Override
    public List<rejectedApplicationDTO> getAllRejectedApplications() {
        List<SchoolApply> rejectedApplications = schoolApplyRepo.findByStatus("rejected");
        List<rejectedApplicationDTO> result = new ArrayList<>();

        for (SchoolApply application : rejectedApplications) {
            School school = application.getSchool();

            if (school != null) {
                rejectedApplicationDTO dto = new rejectedApplicationDTO();
                
                dto.setApplicationNo(application.getApplicationNo());

                // Set School details
                dto.setSchoolName(school.getSchoolName());
                dto.setSchoolEmail(school.getSchoolEmail());
                dto.setSchoolMobile(school.getSchoolMobile());
                dto.setUdiseNo(school.getUdiseNo());
                dto.setDistrict(school.getDistrict());
                dto.setTaluka(school.getTaluka() != null ? school.getTaluka().getName() : null);
                dto.setVillage(school.getVillage() != null ? school.getVillage().getName() : null);	 
                dto.setSchoolType(school.getSchoolType());
                dto.setPincode(school.getPincode());
                dto.setPoliceStation(school.getPoliceStation());
                dto.setTelephoneNumber(school.getTelephoneNumber());
                dto.setTransactionalAddress(school.getTransactionalAddress());

                // Set SchoolGeneralInfo details
                Optional<SchoolGeneralInfo> generalInfoOpt = schoolGeneralInfoRepo.findBySchoolId(school.getId());
                if (generalInfoOpt.isPresent()) {
                	SchoolGeneralInfo generalInfo=generalInfoOpt.get();
                	
                    dto.setForWhichYearYouWantToApplyForACertificate(generalInfo.getForWhichYearYouWantToApplyForACertificate());
                    dto.setAddressMentionedInGovernmentApprovalDocument(generalInfo.getAddressMentionedInGovernmentApprovalDocument());
                    dto.setSchoolEstablishmentYear(generalInfo.getSchoolEstablishmentYear());
                    dto.setDateOfFirstOpeningOfSchool(generalInfo.getDateOfFirstOpeningOfSchool());
                    dto.setLowerStandard(generalInfo.getLowerStandard());
                    dto.setHigherStandard(generalInfo.getHigherStandard());
                    dto.setSchoolArea(generalInfo.getSchoolArea());
                    dto.setSimpleHigherStandard(generalInfo.getSimpleHigherStandard());
                    dto.setSimpleLowerStandard(generalInfo.getSimpleLowerStandard());
                    dto.setMediumOfInstruction(generalInfo.getMediumOfInstruction());
                    dto.setUdiseLowerStandard(generalInfo.getUdiseLowerStandard());
                    dto.setUdiseHigherStandard(generalInfo.getUdiseHigherStandard());
                    dto.setSchoolBoard(generalInfo.getSchoolBoard());
                    dto.setSchoolTimeFullTime(generalInfo.getSchoolTimeFullTime());
                    dto.setSchoolTimeHalfTime(generalInfo.getSchoolTimeHalfTime());
                    dto.setLunchTimeForEachClass(generalInfo.getLunchTimeForEachClass());
                    dto.setSangsthaCompanyName(generalInfo.getSangsthaCompanyName());
                    dto.setSansthaCompanyHasPurposeForOnlyEducationService(generalInfo.getSansthaCompanyHasPurposeForOnlyEducationService());
                    dto.setIsSchoolOpenWhereAddressMentionedInApproval(generalInfo.getIsSchoolOpenWhereAddressMentionedInApproval());
                    dto.setWhetherSchoolIsMovedToAnotherLocation(generalInfo.getWhetherSchoolIsMovedToAnotherLocation());
                    dto.setIfSansthaIsHandoverToSomeone(generalInfo.getIfSansthaIsHandoverToSomeone());
                    dto.setDoYouHaveMaharastraShashanManyataNo(generalInfo.getDoYouHaveMaharastraShashanManyataNo());
                    dto.setMaharastraShashanApprovalNumber(generalInfo.getMaharastraShashanApprovalNumber());
                    dto.setMaharastraShashanApprovalDate(generalInfo.getMaharastraShashanApprovalDate());
                    dto.setDoYouHaveShikshanUpsanchalakApproval(generalInfo.getDoYouHaveShikshanUpsanchalakApproval());
                    dto.setShikshanUpsanchalakApprovalNumber(generalInfo.getShikshanUpsanchalakApprovalNumber());
                    dto.setShikshanUpsanchalakApprovalDate(generalInfo.getShikshanUpsanchalakApprovalDate());
                    dto.setDoYouHavePrathamManyataCertificate(generalInfo.getDoYouHavePrathamManyataCertificate());
                    dto.setPrathamManyataNumber(generalInfo.getPrathamManyataNumber());
                    dto.setPrathamManyataDate(generalInfo.getPrathamManyataDate());
                    dto.setDoYouRunOnGovernmentNoObjectionCertificate(generalInfo.getDoYouRunOnGovernmentNoObjectionCertificate());
                    dto.setNoObjectionCertificateNumber(generalInfo.getNoObjectionCertificateNumber());
                    dto.setNoObjectionCertificateDate(generalInfo.getNoObjectionCertificateDate());
                    dto.setIsThereAnAffiliationCertificate(generalInfo.getIsThereAnAffiliationCertificate());
                    dto.setAffiliationCertificateNumber(generalInfo.getAffiliationCertificateNumber());
                    dto.setAffiliationCertificateDate(generalInfo.getAffiliationCertificateDate());
                    dto.setSchoolUserName(generalInfo.getSchoolUserName());
                    dto.setSchoolUserDesignation(generalInfo.getSchoolUserDegisnation());
                    dto.setSchoolUserAddress(generalInfo.getSchoolUserAddress());
                    dto.setSchoolUserTelephone(generalInfo.getSchoolUserTelephone());
                }

                // Set BhautikSuvidha details
                Optional<BhauticSuvidha> bhautikOpt = bhautikSuvidhaRepository.findBySchoolId(school.getId());
                if (bhautikOpt.isPresent()) {
                	
                	BhauticSuvidha bhautik = bhautikOpt.get();
                	
                    dto.setTypeOfProofAvailableAndItsDate(bhautik.getTypeOfProofAvailableAndItsDate());
                    dto.setForYouTakePropertyDocumentType(bhautik.getForYouTakePropertyDocumentType());
                    dto.setAreaSqM(bhautik.getAreaSqM());
                    dto.setTotalAreaSqM(bhautik.getTotalAreaSqM());
                    dto.setSchoolTotalAreaSqM(bhautik.getSchoolTotalAreaSqM());

                    dto.setPrincipalCount(bhautik.getPrincipalCount());
                    dto.setPrincipalArea(bhautik.getPrincipalArea());
                    dto.setOfficeCount(bhautik.getOfficeCount());
                    dto.setOfficeArea(bhautik.getOfficeArea());
                    dto.setStaffCount(bhautik.getStaffCount());
                    dto.setStaffArea(bhautik.getStaffArea());
                    dto.setStorageCount(bhautik.getStorageCount());
                    dto.setStorageArea(bhautik.getStorageArea());
                    dto.setClassroom(bhautik.getClassroom());
                    dto.setClassroomArea(bhautik.getClassroomArea());
                    dto.setLabCount(bhautik.getLabCount());
                    dto.setLabArea(bhautik.getLabArea());
                    dto.setCompCount(bhautik.getCompCount());
                    dto.setCompArea(bhautik.getCompArea());
                    dto.setLibraryCount(bhautik.getLibraryCount());
                    dto.setLibraryArea(bhautik.getLibraryArea());
                    dto.setSchoolTotalCount(bhautik.getSchoolTotalCount());
                    dto.setSchoolTotalArea(bhautik.getSchoolTotalArea());
                    dto.setWesternToiletCount(bhautik.getWesternToiletCount());
                    dto.setToiletAvailableFacilityDetails(bhautik.getToiletAvailableFacilityDetails());

                    dto.setSeperateBoysToiletCount(bhautik.getSeperateBoysToiletCount());
                    dto.setSeperateBoysToiletFacilityDetails(bhautik.getSeperateBoysToiletFacilityDetails());
                    dto.setSeperateBoysWashroomCount(bhautik.getSeperateBoysWashroomCount());
                    dto.setSeperateBoysWashroomFacilityDetails(bhautik.getSeperateBoysWashroomFacilityDetails());
                    dto.setSeperateBoysDrinkingWaterCount(bhautik.getSeperateBoysDrinkingWaterCount());
                    dto.setSeperateBoysDrinkingWaterFacilityDetails(bhautik.getSeperateBoysDrinkingWaterFacilityDetails());

                    dto.setSeperateGirlsToiletCount(bhautik.getSeperateGirlsToiletCount());
                    dto.setSeperateGirlsToiletFacilityDetails(bhautik.getSeperateGirlsToiletFacilityDetails());
                    dto.setSeperateGirlsWashroomCount(bhautik.getSeperateGirlsWashroomCount());
                    dto.setSeperateGirlsWashroomFacilityDetails(bhautik.getSeperateGirlsWashroomFacilityDetails());
                    dto.setSeperateGirlsDrinkingWaterCount(bhautik.getSeperateGirlsDrinkingWaterCount());
                    dto.setSeperateGirlsDrinkingWaterFacilityDetails(bhautik.getSeperateGirlsDrinkingWaterFacilityDetails());

                    dto.setWaterTapCount(bhautik.getWaterTapCount());
                    dto.setWaterTankCapacity(bhautik.getWaterTankCapacity());
                    dto.setActualAvailableFacilityDetailsTap(bhautik.getActualAvailableFacilityDetailsTap());
                    dto.setActualAvailableFacilityDetailsWater(bhautik.getActualAvailableFacilityDetailsWater());
                    dto.setAreaOfPlaygroundDetails(bhautik.getAreaOfPlaygroundDetails());
                    dto.setAreaOfPlayground(bhautik.getAreaOfPlayground());
                    dto.setRetainingWallCompound(bhautik.getRetainingWallCompound());
                    dto.setEntranceWithProtectiveWallAndIronGate(bhautik.getEntranceWithProtectiveWallAndIronGate());
                    dto.setKitchenShed(bhautik.getKitchenShed());
                    dto.setaRampForBarrierFreeAccess(bhautik.getARampForBarrierFreeAccess());
                    dto.setRocksOnTheSideOfTheRamp(bhautik.getRocksOnTheSideOfTheRamp());

                    dto.setClassroomCount(bhautik.getClassroomCount());
                    dto.setKitchenShedDetails(bhautik.getKitchenShedDetails());
                    dto.setTheRoofIsSolidRcc(bhautik.getTheRoofIsSolidRcc());
                    dto.setFireWarrantyCylinderNo(bhautik.getFireWarrantyCylinderNo());
                    dto.setMedicalPrimaryBoxNumber(bhautik.getMedicalPrimaryBoxNumber());
                    dto.setPlaquesInFacadesOfSchoolRecognition(bhautik.getPlaquesInFacadesOfSchoolRecognition());
                    dto.setCctvNo(bhautik.getCctvNo());
                }

                // Set OtherFacility details
                Optional<OtherFacility> otherFacilityOpt = otherFacilityRepo.findBySchoolId(school.getId());
                if (otherFacilityOpt.isPresent()) {
                	OtherFacility otherFacility = otherFacilityOpt.get();
                	
                    dto.setMinimum200DaysOf800ClockHoursForPrimaryAndHigher(otherFacility.getMinimum200DaysOf800ClockHoursForPrimaryAndHigher());
                    dto.setHoursOfTeachingPerWeek(otherFacility.getHoursOfTeachingPerWeek());
                    dto.setSufficientEducationalMaterialInEachClassAsRequired(otherFacility.getSufficientEducationalMaterialInEachClassAsRequired());
                    dto.setNumberOfReferenceBooksAvailableForTeacherTraining(otherFacility.getNumberOfReferenceBooksAvailableForTeacherTraining());
                    dto.setNumberOfBooksAvailableForStudentReadingInTheLibrary(otherFacility.getNumberOfBooksAvailableForStudentReadingInTheLibrary());
                    dto.setMagzinBooksCount(otherFacility.getMagzinBooksCount());
                    dto.setNewspaperAndTotalCount(otherFacility.getNewspaperAndTotalCount());
                    dto.setNumberOfSportsAndSportsLiterature(otherFacility.getNumberOfSportsAndSportsLiterature());
                }
                
                if ("Granted".equalsIgnoreCase(school.getSchoolType())) {
                    Optional<GrantedSchoolInfo> grantedInfoOpt = grantedSchoolInfoRepository.findBySchoolId(school.getId());
                    if (grantedInfoOpt.isPresent()) {
                        GrantedSchoolInfo grantedInfo = grantedInfoOpt.get();
                        dto.setGrantedGovernmentDecisionOfApproval(grantedInfo.getGovernmentDecisionOfApproval());
                        dto.setGrantedApprovalOrderOfDeputyDirectorOfEducation(grantedInfo.getApprovalOrderOfDeputyDirectorOfEducation());
                        dto.setGrantedFirstApprovalOrder(grantedInfo.getFirstApprovalOrder());
                        dto.setGrantedOrganizationsRequisitionApplicationInSample1(grantedInfo.getOrganizationsRequisitionApplicationInSample1());
                        dto.setGrantedInstitutionRegistration19501860Certificate(grantedInfo.getInstitutionRegistration19501860Certificate());
                        dto.setGrantedGovtMinorityCertificateIfTheSchoolIsMinority(grantedInfo.getGovtMinorityCertificateIfTheSchoolIsMinority());
                        dto.setGrantedPurchaseDeedLeaseAgreementAwardDeed(grantedInfo.getPurchaseDeedLeaseAgreementAwardDeed());
                        dto.setGrantedCertificationOfJoiningIfAdditionalTeacher(grantedInfo.getCertificationOfJoiningIfJoiningIfAdditionalTeacher());
                        dto.setGrantedInstitutionalUndertakingOfSchoolsNotChargingAny(grantedInfo.getInstitutionalUndertakingOfSchoolsNotChargingAny());
                        dto.setGrantedWomenGrievanceRedressalCommittee(grantedInfo.getWomenGrievanceRedressalCommittee());
                        dto.setGrantedAffidavitOnStampOfRs100(grantedInfo.getAffidavitOnStampOfRs100());
                        dto.setGrantedSchoolPrincipalSignStamp(grantedInfo.getSchoolPrincipalSignStamp());
                        dto.setGrantedCommonOrder2013To2016Bit(grantedInfo.getCommonOrder2013To2016Bit());
                        dto.setGrantedCommonOrder2016To2019Bit(grantedInfo.getCommonOrder2016To2019Bit());
                        dto.setGrantedCommonOrder2019To2022Bit(grantedInfo.getCommonOrder2019To2022Bit());
                    }
                } else if ("Non_Granted".equalsIgnoreCase(school.getSchoolType())) {
                    Optional<NonGrantedSchoolInfo> nonGrantedInfoOpt = nonGrantedSchoolInfoRepo.findBySchoolId(school.getId());
                    if (nonGrantedInfoOpt.isPresent()) {
                        NonGrantedSchoolInfo nonGrantedInfo = nonGrantedInfoOpt.get();
                        dto.setNonGrantedGovernmentDecisionOfApproval(nonGrantedInfo.getGovernmentDecisionOfApproval());
                        dto.setNonGrantedApprovalOrderOfDeputyDirectorOfEducation(nonGrantedInfo.getApprovalOrderOfDeputyDirectorOfEducation());
                        dto.setNonGrantedFirstApprovalOrder(nonGrantedInfo.getFirstApprovalOrder());
                        dto.setNonGrantedOrganizationsRequisitionApplicationInSample1(nonGrantedInfo.getOrganizationsRequisitionApplicationInSample1());
                        dto.setNonGrantedJointAccountRetentionReceiptOfInstitution(nonGrantedInfo.getJointAccountRetentionReceiptOfInstitution());
                        dto.setNonGrantedOrganizationCompanyRegistrationCertificate(nonGrantedInfo.getOrganizationCompanyRegistrationCertificate());
                        dto.setNonGrantedGovtMinorityCertificate(nonGrantedInfo.getGovtMinorityCertificate());
                        dto.setNonGrantedPurchaseDeedLeaseAgreementAward(nonGrantedInfo.getPurchaseDeedLeaseAgreementAward());
                        dto.setNonGrantedAuditReport(nonGrantedInfo.getAuditReport());
                        dto.setNonGrantedCopyOfEptaApprovalMinutes(nonGrantedInfo.getCopyOfEptaApprovalMinutes());
                        dto.setNonGrantedFreeStructureAccordingToPrevious(nonGrantedInfo.getFreeStructureAccordingToPrevious());
                        dto.setNonGrantedTransportCommitteeOnlineCopy(nonGrantedInfo.getTransportCommitteeOnlineCopy());
                        dto.setNonGrantedWomenGrievanceRedressalCommittee(nonGrantedInfo.getWomenGrievanceRedressalCommittee());
                        dto.setNonGrantedAffidavitOnStampOfRs100(nonGrantedInfo.getAffidavitOnStampOfRs100());
                        dto.setNonGrantedSchoolPrincipalSignStamp(nonGrantedInfo.getSchoolPrincipalSignStamp());
                        dto.setNonGrantedCommonOrder2013To2016Bit(nonGrantedInfo.getCommonOrder2013To2016Bit());
                        dto.setNonGrantedCommonOrder2016To2019Bit(nonGrantedInfo.getCommonOrder2016To2019Bit());
                        dto.setNonGrantedCommonOrder2019To2022Bit(nonGrantedInfo.getCommonOrder2019To2022Bit());
                    }
                }
                result.add(dto);
            }
            }
        return result;
    }
  
}