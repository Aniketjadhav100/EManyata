package com.emanyata.app.controller.primary;

import com.emanyata.app.dto.G_PaymentRequestDTO;
import com.emanyata.app.dto.G_PaymentResponseDTO;
import com.emanyata.app.service.primary.G_PaymentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/payment")
@CrossOrigin
public class G_PaymentController {

    @Autowired
    private G_PaymentService paymentService;

    @PostMapping("/initiate-payment")
    public Map<String, Object> initiatePayment(@RequestBody G_PaymentRequestDTO request) {
        G_PaymentResponseDTO responseDTO = paymentService.initiatePayment(request);

        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", "Payment hash generated successfully");
        response.put("data", responseDTO);

        return response;
    }
}
