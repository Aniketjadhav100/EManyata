package com.emanyata.app.repo.primary;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.primary.School;

public interface SchoolRepo extends JpaRepository<School,Long> {
	
		Optional<School> findByUdiseNo(String udiseNo);
}
