package com.emanyata.app.controller.primary;

import com.emanyata.app.dto.ImageDTO;
import com.emanyata.app.service.primary.ImageService;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@RestController
@RequestMapping("/api/users")
public class ImageController {

    private final ImageService imageService;

    public ImageController(ImageService imageService) {
        this.imageService = imageService;
    }

    @PostMapping("/upload/{userId}")
    public ResponseEntity<Map<String, Object>> uploadUserImage(
            @PathVariable Long userId,
            @RequestParam("file") MultipartFile file) {
        Map<String, Object> response = new HashMap<>();

        try {
            ImageDTO dto = imageService.upsertUserImage(userId, file);
            response.put("code", 200);
            response.put("message", "Image uploaded successfully");
            response.put("data", dto);
            return ResponseEntity.ok(response);

        } catch (RuntimeException e) {
            response.put("code", 404);
            response.put("message", "Upload failed");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);

        } catch (Exception e) {
            response.put("code", 500);
            response.put("message", "Internal server error during image upload");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping("/image/view/{userId}")
    public ResponseEntity<?> getUserImageFile(@PathVariable Long userId) {
        try {
            Resource resource = imageService.loadUserImage(userId);
            Path path = Paths.get(resource.getURI());
            String contentType = Files.probeContentType(path);

            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType != null ? contentType : "application/octet-stream"))
                    .body(resource);

        } catch (RuntimeException e) {
            Map<String, Object> response = new HashMap<>();
            response.put("code", 404);
            response.put("message", "Image not found");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);

        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("code", 500);
            response.put("message", "Internal server error while retrieving image");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @PostMapping("/image/delete/{userId}")
    public ResponseEntity<Map<String, Object>> deleteUserImage(@PathVariable Long userId) {
        Map<String, Object> response = new HashMap<>();
        try {
            imageService.deleteUserImage(userId);
            response.put("code", 200);
            response.put("message", "Image deleted successfully");
            return ResponseEntity.ok(response);

        } catch (RuntimeException e) {
            response.put("code", 404);
            response.put("message", "Deletion failed");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);

        } catch (Exception e) {
            response.put("code", 500);
            response.put("message", "Internal server error during image deletion");
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
}