package com.emanyata.app.serviceImpl.primary;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emanyata.app.dto.FinalizedApplicationDTO;
import com.emanyata.app.entity.primary.School;
import com.emanyata.app.entity.primary.SchoolApply;
import com.emanyata.app.entity.secondary.OldDetailOfPhysical;
import com.emanyata.app.entity.secondary.OldGrantedSchoolInfo;
import com.emanyata.app.entity.secondary.OldNonGrantedSchoolInfo;
import com.emanyata.app.entity.secondary.OldOtherFacility;
import com.emanyata.app.entity.secondary.OldSchool;
import com.emanyata.app.entity.secondary.OldSchoolApply;
import com.emanyata.app.entity.secondary.OldSchoolGeneralInfo;
import com.emanyata.app.repo.primary.BhautikSuvidhaRepository;
import com.emanyata.app.repo.primary.GrantedSchoolInfoRepository;
import com.emanyata.app.repo.primary.NonGrantedSchoolInfoRepo;
import com.emanyata.app.repo.primary.OtherFacilityRepo;
import com.emanyata.app.repo.primary.SchoolApplyRepo;
import com.emanyata.app.repo.primary.SchoolGeneralInfoRepo;
import com.emanyata.app.repo.secondary.OldDetailOfPhysicalRepository;
import com.emanyata.app.repo.secondary.OldGrantedSchoolInfoRepo;
import com.emanyata.app.repo.secondary.OldNonGrantedSchoolInfoRepo;
import com.emanyata.app.repo.secondary.OldOtherFacilityRepo;
import com.emanyata.app.repo.secondary.OldSchoolApplyRepo;
import com.emanyata.app.repo.secondary.OldSchoolGeneralInfoRepository;
import com.emanyata.app.repo.secondary.OldSchoolRepository;
import com.emanyata.app.service.primary.FinalizedApplicationService;


@Service
public class FinalizedApplicationServiceImpl implements FinalizedApplicationService {

    @Autowired private SchoolApplyRepo schoolApplyRepo;
    @Autowired private SchoolGeneralInfoRepo schoolGeneralInfoRepo;
    @Autowired private BhautikSuvidhaRepository bhautikSuvidhaRepository;
    @Autowired private OtherFacilityRepo otherFacilityRepo;
    @Autowired private GrantedSchoolInfoRepository grantedSchoolInfoRepository;
    @Autowired private NonGrantedSchoolInfoRepo nonGrantedSchoolInfoRepo;

    // Old Database
    @Autowired private OldSchoolRepository oldSchoolRepo;
    @Autowired private OldSchoolApplyRepo oldSchoolApplyRepo;
    @Autowired private OldSchoolGeneralInfoRepository oldGeneralInfoRepo;
    @Autowired private OldDetailOfPhysicalRepository oldDetailOfRepo;
    @Autowired private OldOtherFacilityRepo oldOtherFacilityRepo;
    @Autowired private OldGrantedSchoolInfoRepo oldGrantedSchoolInfoRepo;
    @Autowired private OldNonGrantedSchoolInfoRepo oldNonGrantedSchoolInfoRepo;

    @Override
    public List<FinalizedApplicationDTO> getAllFinalizedApplications() {
        List<FinalizedApplicationDTO> result = new ArrayList<>();
        
        // Process current database applications
        processCurrentApplications(result);
        
        // Process old database applications
        processOldApplications(result);
        
        return result;
    }

    private void processCurrentApplications(List<FinalizedApplicationDTO> result) {
        List<SchoolApply> applications = schoolApplyRepo.findByStatus("final_submit");
        for (SchoolApply application : applications) {
            School school = application.getSchool();
            if (school != null) {
                FinalizedApplicationDTO dto = new FinalizedApplicationDTO();
                mapCurrentApplicationToDto(application, school, dto);
                result.add(dto);
            }
        }
    }

    private void processOldApplications(List<FinalizedApplicationDTO> result) {
        List<OldSchoolApply> oldApplications = oldSchoolApplyRepo.findByStatus("final_submit");
        for (OldSchoolApply oldApplication : oldApplications) {
        	Optional<OldSchool> oldSchoolOpt = oldSchoolRepo.findById(oldApplication.getSchool().getId());
            if (oldSchoolOpt.isPresent()) {
                FinalizedApplicationDTO dto = new FinalizedApplicationDTO();
                mapOldApplicationToDto(oldApplication, oldSchoolOpt.get(), dto);
                result.add(dto);
            }
        }
    }

    private void mapCurrentApplicationToDto(SchoolApply application, School school, FinalizedApplicationDTO dto) {
        // Set basic application and school info
        dto.setApplicationNo(application.getApplicationNo());
        dto.setSchoolName(school.getSchoolName());
        dto.setSchoolEmail(school.getSchoolEmail());
        dto.setSchoolMobile(school.getSchoolMobile());
        dto.setUdiseNo(school.getUdiseNo());
        dto.setDistrict(school.getDistrict());
        dto.setTaluka(school.getTaluka() != null ? school.getTaluka().getName() : null);
        dto.setVillage(school.getVillage() != null ? school.getVillage().getName() : null);
        dto.setSchoolType(school.getSchoolType());
        dto.setPincode(school.getPincode());
        dto.setPoliceStation(school.getPoliceStation());
        dto.setTelephoneNumber(school.getTelephoneNumber());
        dto.setTransactionalAddress(school.getTransactionalAddress());

        // Set SchoolGeneralInfo
        schoolGeneralInfoRepo.findBySchoolId(school.getId()).ifPresent(generalInfo -> {
            dto.setForWhichYearYouWantToApplyForACertificate(generalInfo.getForWhichYearYouWantToApplyForACertificate());
            dto.setAddressMentionedInGovernmentApprovalDocument(generalInfo.getAddressMentionedInGovernmentApprovalDocument());
            dto.setSchoolEstablishmentYear(generalInfo.getSchoolEstablishmentYear());
            dto.setDateOfFirstOpeningOfSchool(generalInfo.getDateOfFirstOpeningOfSchool());
            dto.setLowerStandard(generalInfo.getLowerStandard());
            dto.setHigherStandard(generalInfo.getHigherStandard());
            dto.setSchoolArea(generalInfo.getSchoolArea());
            dto.setSimpleHigherStandard(generalInfo.getSimpleHigherStandard());
            dto.setSimpleLowerStandard(generalInfo.getSimpleLowerStandard());
            dto.setMediumOfInstruction(generalInfo.getMediumOfInstruction());
            dto.setUdiseLowerStandard(generalInfo.getUdiseLowerStandard());
            dto.setUdiseHigherStandard(generalInfo.getUdiseHigherStandard());
            dto.setSchoolBoard(generalInfo.getSchoolBoard());
            dto.setSchoolTimeFullTime(generalInfo.getSchoolTimeFullTime());
            dto.setSchoolTimeHalfTime(generalInfo.getSchoolTimeHalfTime());
            dto.setLunchTimeForEachClass(generalInfo.getLunchTimeForEachClass());
            dto.setSangsthaCompanyName(generalInfo.getSangsthaCompanyName());
            dto.setSansthaCompanyHasPurposeForOnlyEducationService(generalInfo.getSansthaCompanyHasPurposeForOnlyEducationService());
            dto.setIsSchoolOpenWhereAddressMentionedInApproval(generalInfo.getIsSchoolOpenWhereAddressMentionedInApproval());
            dto.setWhetherSchoolIsMovedToAnotherLocation(generalInfo.getWhetherSchoolIsMovedToAnotherLocation());
            dto.setIfSansthaIsHandoverToSomeone(generalInfo.getIfSansthaIsHandoverToSomeone());
            dto.setDoYouHaveMaharastraShashanManyataNo(generalInfo.getDoYouHaveMaharastraShashanManyataNo());
            dto.setMaharastraShashanApprovalNumber(generalInfo.getMaharastraShashanApprovalNumber());
            dto.setMaharastraShashanApprovalDate(generalInfo.getMaharastraShashanApprovalDate());
            dto.setDoYouHaveShikshanUpsanchalakApproval(generalInfo.getDoYouHaveShikshanUpsanchalakApproval());
            dto.setShikshanUpsanchalakApprovalNumber(generalInfo.getShikshanUpsanchalakApprovalNumber());
            dto.setShikshanUpsanchalakApprovalDate(generalInfo.getShikshanUpsanchalakApprovalDate());
            dto.setDoYouHavePrathamManyataCertificate(generalInfo.getDoYouHavePrathamManyataCertificate());
            dto.setPrathamManyataNumber(generalInfo.getPrathamManyataNumber());
            dto.setPrathamManyataDate(generalInfo.getPrathamManyataDate());
            dto.setDoYouRunOnGovernmentNoObjectionCertificate(generalInfo.getDoYouRunOnGovernmentNoObjectionCertificate());
            dto.setNoObjectionCertificateNumber(generalInfo.getNoObjectionCertificateNumber());
            dto.setNoObjectionCertificateDate(generalInfo.getNoObjectionCertificateDate());
            dto.setIsThereAnAffiliationCertificate(generalInfo.getIsThereAnAffiliationCertificate());
            dto.setAffiliationCertificateNumber(generalInfo.getAffiliationCertificateNumber());
            dto.setAffiliationCertificateDate(generalInfo.getAffiliationCertificateDate());
            dto.setSchoolUserName(generalInfo.getSchoolUserName());
            dto.setSchoolUserDesignation(generalInfo.getSchoolUserDegisnation());
            dto.setSchoolUserAddress(generalInfo.getSchoolUserAddress());
            dto.setSchoolUserTelephone(generalInfo.getSchoolUserTelephone());
        });

        // Set BhautikSuvidha
        bhautikSuvidhaRepository.findBySchoolId(school.getId()).ifPresent(bhautik -> {
            dto.setTypeOfProofAvailableAndItsDate(bhautik.getTypeOfProofAvailableAndItsDate());
            dto.setForYouTakePropertyDocumentType(bhautik.getForYouTakePropertyDocumentType());
            dto.setAreaSqM(bhautik.getAreaSqM());
            dto.setTotalAreaSqM(bhautik.getTotalAreaSqM());
            dto.setSchoolTotalAreaSqM(bhautik.getSchoolTotalAreaSqM());
            dto.setPrincipalCount(bhautik.getPrincipalCount());
            dto.setPrincipalArea(bhautik.getPrincipalArea());
            dto.setOfficeCount(bhautik.getOfficeCount());
            dto.setOfficeArea(bhautik.getOfficeArea());
            dto.setStaffCount(bhautik.getStaffCount());
            dto.setStaffArea(bhautik.getStaffArea());
            dto.setStorageCount(bhautik.getStorageCount());
            dto.setStorageArea(bhautik.getStorageArea());
            dto.setClassroom(bhautik.getClassroom());
            dto.setClassroomArea(bhautik.getClassroomArea());
            dto.setLabCount(bhautik.getLabCount());
            dto.setLabArea(bhautik.getLabArea());
            dto.setCompCount(bhautik.getCompCount());
            dto.setCompArea(bhautik.getCompArea());
            dto.setLibraryCount(bhautik.getLibraryCount());
            dto.setLibraryArea(bhautik.getLibraryArea());
            dto.setSchoolTotalCount(bhautik.getSchoolTotalCount());
            dto.setSchoolTotalArea(bhautik.getSchoolTotalArea());
            dto.setWesternToiletCount(bhautik.getWesternToiletCount());
            dto.setToiletAvailableFacilityDetails(bhautik.getToiletAvailableFacilityDetails());
            dto.setSeperateBoysToiletCount(bhautik.getSeperateBoysToiletCount());
            dto.setSeperateBoysToiletFacilityDetails(bhautik.getSeperateBoysToiletFacilityDetails());
            dto.setSeperateBoysWashroomCount(bhautik.getSeperateBoysWashroomCount());
            dto.setSeperateBoysWashroomFacilityDetails(bhautik.getSeperateBoysWashroomFacilityDetails());
            dto.setSeperateBoysDrinkingWaterCount(bhautik.getSeperateBoysDrinkingWaterCount());
            dto.setSeperateBoysDrinkingWaterFacilityDetails(bhautik.getSeperateBoysDrinkingWaterFacilityDetails());
            dto.setSeperateGirlsToiletCount(bhautik.getSeperateGirlsToiletCount());
            dto.setSeperateGirlsToiletFacilityDetails(bhautik.getSeperateGirlsToiletFacilityDetails());
            dto.setSeperateGirlsWashroomCount(bhautik.getSeperateGirlsWashroomCount());
            dto.setSeperateGirlsWashroomFacilityDetails(bhautik.getSeperateGirlsWashroomFacilityDetails());
            dto.setSeperateGirlsDrinkingWaterCount(bhautik.getSeperateGirlsDrinkingWaterCount());
            dto.setSeperateGirlsDrinkingWaterFacilityDetails(bhautik.getSeperateGirlsDrinkingWaterFacilityDetails());
            dto.setWaterTapCount(bhautik.getWaterTapCount());
            dto.setWaterTankCapacity(bhautik.getWaterTankCapacity());
            dto.setActualAvailableFacilityDetailsTap(bhautik.getActualAvailableFacilityDetailsTap());
            dto.setActualAvailableFacilityDetailsWater(bhautik.getActualAvailableFacilityDetailsWater());
            dto.setAreaOfPlaygroundDetails(bhautik.getAreaOfPlaygroundDetails());
            dto.setAreaOfPlayground(bhautik.getAreaOfPlayground());
            dto.setRetainingWallCompound(bhautik.getRetainingWallCompound());
            dto.setEntranceWithProtectiveWallAndIronGate(bhautik.getEntranceWithProtectiveWallAndIronGate());
            dto.setKitchenShed(bhautik.getKitchenShed());
            dto.setaRampForBarrierFreeAccess(bhautik.getARampForBarrierFreeAccess());
            dto.setRocksOnTheSideOfTheRamp(bhautik.getRocksOnTheSideOfTheRamp());
            dto.setClassroomCount(bhautik.getClassroomCount());
            dto.setKitchenShedDetails(bhautik.getKitchenShedDetails());
            dto.setTheRoofIsSolidRcc(bhautik.getTheRoofIsSolidRcc());
            dto.setFireWarrantyCylinderNo(bhautik.getFireWarrantyCylinderNo());
            dto.setMedicalPrimaryBoxNumber(bhautik.getMedicalPrimaryBoxNumber());
            dto.setPlaquesInFacadesOfSchoolRecognition(bhautik.getPlaquesInFacadesOfSchoolRecognition());
            dto.setCctvNo(bhautik.getCctvNo());
        });

        // Set OtherFacility
        otherFacilityRepo.findBySchoolId(school.getId()).ifPresent(otherFacility -> {
            dto.setMinimum200DaysOf800ClockHoursForPrimaryAndHigher(otherFacility.getMinimum200DaysOf800ClockHoursForPrimaryAndHigher());
            dto.setHoursOfTeachingPerWeek(otherFacility.getHoursOfTeachingPerWeek());
            dto.setSufficientEducationalMaterialInEachClassAsRequired(otherFacility.getSufficientEducationalMaterialInEachClassAsRequired());
            dto.setNumberOfReferenceBooksAvailableForTeacherTraining(otherFacility.getNumberOfReferenceBooksAvailableForTeacherTraining());
            dto.setNumberOfBooksAvailableForStudentReadingInTheLibrary(otherFacility.getNumberOfBooksAvailableForStudentReadingInTheLibrary());
            dto.setMagzinBooksCount(otherFacility.getMagzinBooksCount());
            dto.setNewspaperAndTotalCount(otherFacility.getNewspaperAndTotalCount());
            dto.setNumberOfSportsAndSportsLiterature(otherFacility.getNumberOfSportsAndSportsLiterature());
        });

        // Set Granted/Non-Granted specific info
        if ("Granted".equalsIgnoreCase(school.getSchoolType())) {
            grantedSchoolInfoRepository.findBySchoolId(school.getId()).ifPresent(grantedInfo -> {
                dto.setGrantedGovernmentDecisionOfApproval(grantedInfo.getGovernmentDecisionOfApproval());
                dto.setGrantedApprovalOrderOfDeputyDirectorOfEducation(grantedInfo.getApprovalOrderOfDeputyDirectorOfEducation());
                dto.setGrantedFirstApprovalOrder(grantedInfo.getFirstApprovalOrder());
                dto.setGrantedOrganizationsRequisitionApplicationInSample1(grantedInfo.getOrganizationsRequisitionApplicationInSample1());
                dto.setGrantedInstitutionRegistration19501860Certificate(grantedInfo.getInstitutionRegistration19501860Certificate());
                dto.setGrantedGovtMinorityCertificateIfTheSchoolIsMinority(grantedInfo.getGovtMinorityCertificateIfTheSchoolIsMinority());
                dto.setGrantedPurchaseDeedLeaseAgreementAwardDeed(grantedInfo.getPurchaseDeedLeaseAgreementAwardDeed());
                dto.setGrantedCertificationOfJoiningIfAdditionalTeacher(grantedInfo.getCertificationOfJoiningIfJoiningIfAdditionalTeacher());
                dto.setGrantedInstitutionalUndertakingOfSchoolsNotChargingAny(grantedInfo.getInstitutionalUndertakingOfSchoolsNotChargingAny());
                dto.setGrantedWomenGrievanceRedressalCommittee(grantedInfo.getWomenGrievanceRedressalCommittee());
                dto.setGrantedAffidavitOnStampOfRs100(grantedInfo.getAffidavitOnStampOfRs100());
                dto.setGrantedSchoolPrincipalSignStamp(grantedInfo.getSchoolPrincipalSignStamp());
                dto.setGrantedCommonOrder2013To2016Bit(grantedInfo.getCommonOrder2013To2016Bit());
                dto.setGrantedCommonOrder2016To2019Bit(grantedInfo.getCommonOrder2016To2019Bit());
                dto.setGrantedCommonOrder2019To2022Bit(grantedInfo.getCommonOrder2019To2022Bit());
            });
        } else if ("Non_Granted".equalsIgnoreCase(school.getSchoolType())) {
            nonGrantedSchoolInfoRepo.findBySchoolId(school.getId()).ifPresent(nonGrantedInfo -> {
                dto.setNonGrantedGovernmentDecisionOfApproval(nonGrantedInfo.getGovernmentDecisionOfApproval());
                dto.setNonGrantedApprovalOrderOfDeputyDirectorOfEducation(nonGrantedInfo.getApprovalOrderOfDeputyDirectorOfEducation());
                dto.setNonGrantedFirstApprovalOrder(nonGrantedInfo.getFirstApprovalOrder());
                dto.setNonGrantedOrganizationsRequisitionApplicationInSample1(nonGrantedInfo.getOrganizationsRequisitionApplicationInSample1());
                dto.setNonGrantedJointAccountRetentionReceiptOfInstitution(nonGrantedInfo.getJointAccountRetentionReceiptOfInstitution());
                dto.setNonGrantedOrganizationCompanyRegistrationCertificate(nonGrantedInfo.getOrganizationCompanyRegistrationCertificate());
                dto.setNonGrantedGovtMinorityCertificate(nonGrantedInfo.getGovtMinorityCertificate());
                dto.setNonGrantedPurchaseDeedLeaseAgreementAward(nonGrantedInfo.getPurchaseDeedLeaseAgreementAward());
                dto.setNonGrantedAuditReport(nonGrantedInfo.getAuditReport());
                dto.setNonGrantedCopyOfEptaApprovalMinutes(nonGrantedInfo.getCopyOfEptaApprovalMinutes());
                dto.setNonGrantedFreeStructureAccordingToPrevious(nonGrantedInfo.getFreeStructureAccordingToPrevious());
                dto.setNonGrantedTransportCommitteeOnlineCopy(nonGrantedInfo.getTransportCommitteeOnlineCopy());
                dto.setNonGrantedWomenGrievanceRedressalCommittee(nonGrantedInfo.getWomenGrievanceRedressalCommittee());
                dto.setNonGrantedAffidavitOnStampOfRs100(nonGrantedInfo.getAffidavitOnStampOfRs100());
                dto.setNonGrantedSchoolPrincipalSignStamp(nonGrantedInfo.getSchoolPrincipalSignStamp());
                dto.setNonGrantedCommonOrder2013To2016Bit(nonGrantedInfo.getCommonOrder2013To2016Bit());
                dto.setNonGrantedCommonOrder2016To2019Bit(nonGrantedInfo.getCommonOrder2016To2019Bit());
                dto.setNonGrantedCommonOrder2019To2022Bit(nonGrantedInfo.getCommonOrder2019To2022Bit());
            });
        }
    }

    private void mapOldApplicationToDto(OldSchoolApply application, OldSchool school, FinalizedApplicationDTO dto) {
        // Set basic application and school info
    	 dto.setApplicationNo(application.getApplicationNo());
         dto.setSchoolName(school.getSchoolName());
         dto.setSchoolMobile(school.getSchoolMobile());
         dto.setUdiseNo(school.getUdiseNo());
         dto.setDistrict(school.getDistrict());
         dto.setTaluka(school.getTaluka() != null ? school.getTaluka().getName() : null);
         dto.setVillage(school.getVillage() != null ? school.getVillage().getName() : null);
         dto.setSchoolType(school.getSchoolType());
         dto.setPincode(school.getPincode());
         dto.setPoliceStation(school.getPoliceStation());
         dto.setTelephoneNumber(school.getTelephoneNumber());
         dto.setTransactionalAddress(school.getTransactionalAddress());
         
         
        // Set OldSchoolGeneralInfo
         List<OldSchoolGeneralInfo> generalInfoList = oldGeneralInfoRepo.findBySchoolId(school.getId());

         if (!generalInfoList.isEmpty()) {
             OldSchoolGeneralInfo generalInfo = generalInfoList.get(0);

             dto.setForWhichYearYouWantToApplyForACertificate(generalInfo.getForWhichYearYouWantToApplyForACertificate());
             dto.setAddressMentionedInGovernmentApprovalDocument(generalInfo.getAddressMentionedInGovernmentApprovalDocument());
             dto.setSchoolEstablishmentYear(generalInfo.getSchoolEstablishmentYear());
             dto.setDateOfFirstOpeningOfSchool(generalInfo.getDateOfFirstOpeningOfSchool());
             dto.setLowerStandard(generalInfo.getLowerStandard());
             dto.setHigherStandard(generalInfo.getHigherStandard());
             dto.setSchoolArea(generalInfo.getSchoolArea());
             dto.setSimpleHigherStandard(generalInfo.getSimpleHigherStandard());
             dto.setSimpleLowerStandard(generalInfo.getSimpleLowerStandard());
             dto.setMediumOfInstruction(generalInfo.getMediumOfInstruction());
             dto.setUdiseLowerStandard(generalInfo.getUdiseLowerStandard());
             dto.setUdiseHigherStandard(generalInfo.getUdiseHigherStandard());
             dto.setSchoolBoard(generalInfo.getSchoolBoard());
             dto.setSchoolTimeFullTime(generalInfo.getSchoolTimeFullTime());
             dto.setSchoolTimeHalfTime(generalInfo.getSchoolTimeHalfTime());
             dto.setLunchTimeForEachClass(generalInfo.getLunchTimeForEachClass());
             dto.setSangsthaCompanyName(generalInfo.getSangsthaCompanyName());
             dto.setSansthaCompanyHasPurposeForOnlyEducationService(generalInfo.getSansthaCompanyHasPurposeForOnlyEducationService());
             dto.setIsSchoolOpenWhereAddressMentionedInApproval(generalInfo.getIsSchoolOpenWhereAddressMentionedInApproval());
             dto.setWhetherSchoolIsMovedToAnotherLocation(generalInfo.getWhetherSchoolIsMovedToAnotherLocation());
             dto.setIfSansthaIsHandoverToSomeone(generalInfo.getIfSansthaIsHandoverToSomeone());
             dto.setDoYouHaveMaharastraShashanManyataNo(generalInfo.getDoYouHaveMaharastraShashanManyataNo());
             dto.setMaharastraShashanApprovalNumber(generalInfo.getMaharastraShashanApprovalNumber());
             dto.setMaharastraShashanApprovalDate(generalInfo.getMaharastraShashanApprovalDate());
             dto.setDoYouHaveShikshanUpsanchalakApproval(generalInfo.getDoYouHaveShikshanUpsanchalakApproval());
             dto.setShikshanUpsanchalakApprovalNumber(generalInfo.getShikshanUpsanchalakApprovalNumber());
             dto.setShikshanUpsanchalakApprovalDate(generalInfo.getShikshanUpsanchalakApprovalDate());
             dto.setDoYouHavePrathamManyataCertificate(generalInfo.getDoYouHavePrathamManyataCertificate());
             dto.setPrathamManyataNumber(generalInfo.getPrathamManyataNumber());
             dto.setPrathamManyataDate(generalInfo.getPrathamManyataDate());
             dto.setDoYouRunOnGovernmentNoObjectionCertificate(generalInfo.getDoYouRunOnGovernmentNoObjectionCertificate());
             dto.setNoObjectionCertificateNumber(generalInfo.getNoObjectionCertificateNumber());
             dto.setNoObjectionCertificateDate(generalInfo.getNoObjectionCertificateDate());
             dto.setIsThereAnAffiliationCertificate(generalInfo.getIsThereAnAffiliationCertificate());
             dto.setAffiliationCertificateNumber(generalInfo.getAffiliationCertificateNumber());
             dto.setAffiliationCertificateDate(generalInfo.getAffiliationCertificateDate());
             dto.setSchoolUserName(generalInfo.getSchoolUserName());
             dto.setSchoolUserDesignation(generalInfo.getSchoolUserDegisnation());
             dto.setSchoolUserAddress(generalInfo.getSchoolUserAddress());
             dto.setSchoolUserTelephone(generalInfo.getSchoolUserTelephone());
         }

         List<OldDetailOfPhysical> detailList = oldDetailOfRepo.findBySchoolId(school.getId());
         if (!detailList.isEmpty()) {
             OldDetailOfPhysical detail = detailList.get(detailList.size() - 1); // or .get(0) for first

             dto.setTypeOfProofAvailableAndItsDate(detail.getTypeOfProofAvailableAndItsDate());
             dto.setForYouTakePropertyDocumentType(detail.getForYouTakePropertyDocumentType());
             dto.setAreaSqM(detail.getAreaSqM());
             dto.setTotalAreaSqM(detail.getTotalAreaSqM());
             dto.setSchoolTotalAreaSqM(detail.getSchoolTotalAreaSqM());
             dto.setPrincipalCount(detail.getPrincipalCount());
             dto.setPrincipalArea(detail.getPrincipalArea());
             dto.setOfficeCount(detail.getOfficeCount());
             dto.setOfficeArea(detail.getOfficeArea());
             dto.setStaffCount(detail.getStaffCount());
             dto.setStaffArea(detail.getStaffArea());
             dto.setStorageCount(detail.getStorageCount());
             dto.setStorageArea(detail.getStorageArea());
             dto.setClassroom(detail.getClassroom());
             dto.setClassroomArea(detail.getClassroomArea());
             dto.setLabCount(detail.getLabCount());
             dto.setLabArea(detail.getLabArea());
             dto.setCompCount(detail.getCompCount());
             dto.setCompArea(detail.getCompArea());
             dto.setLibraryCount(detail.getLibraryCount());
             dto.setLibraryArea(detail.getLibraryArea());
             dto.setSchoolTotalCount(detail.getSchoolTotalCount());
             dto.setSchoolTotalArea(detail.getSchoolTotalArea());
             dto.setWesternToiletCount(detail.getWesternToiletCount());
             dto.setToiletAvailableFacilityDetails(detail.getToiletAvailableFacilityDetails());

             dto.setSeperateGirlsToiletCount(detail.getSeperateGirlsToiletCount());
             dto.setSeperateGirlsToiletFacilityDetails(detail.getSeperateGirlsToiletFacilityDetails());
             dto.setSeperateGirlsWashroomCount(detail.getSeperateGirlsWashroomCount());
             dto.setSeperateGirlsWashroomFacilityDetails(detail.getSeperateGirlsWashroomFacilityDetails());
             dto.setSeperateGirlsDrinkingWaterCount(detail.getSeperateGirlsDrinkingWaterCount());
             dto.setSeperateGirlsDrinkingWaterFacilityDetails(detail.getGirlsDrinkingWaterFacilityDetails()); // mapped from: girls_drinking_water_facility_details

             dto.setWaterTapCount(detail.getWaterTapCount()); // You must confirm this field exists in the entity
             dto.setWaterTankCapacity(detail.getWaterTankCapacity()); // You must confirm this field exists in the entity
             dto.setActualAvailableFacilityDetailsTap(detail.getActualAvailableFacilityDetailsTap()); // Check presence
             dto.setActualAvailableFacilityDetailsWater(detail.getActualAvailableFacilityDetailsWater()); // Check presence
             dto.setAreaOfPlaygroundDetails(detail.getAreaOfPlaygroundDetails()); // Check presence
             dto.setAreaOfPlayground(detail.getAreaOfPlayground()); // Check presence
             dto.setRetainingWallCompound(detail.getRetainingWallCompound()); // Check presence
             dto.setEntranceWithProtectiveWallAndIronGate(detail.getEntranceWithProtectiveWallAndIronGate()); // Check presence
             dto.setKitchenShed(detail.getKitchenShed()); // Check presence
             dto.setaRampForBarrierFreeAccess(detail.getRampRoad()); // mapped from: ramp_road
             dto.setRocksOnTheSideOfTheRamp(detail.getRocksOnTheSideOfTheRamp());
             dto.setClassroomCount(detail.getClassroomCount());
             dto.setKitchenShedDetails(detail.getKitchen()); // maybe this is same as kitchen
             dto.setTheRoofIsSolidRcc(detail.getTheRoofIsSolidRcc());
             dto.setFireWarrantyCylinderNo(detail.getFireWarrantyCylinderNo());
             dto.setMedicalPrimaryBoxNumber(detail.getMedicalPrimaryBoxNumber()); // confirm presence
             dto.setPlaquesInFacadesOfSchoolRecognition(detail.getPlaquesInFacadesOfSchoolRecognition()); // confirm presence
             dto.setCctvNo(detail.getCctvNo()); // confirm presence
         }


         // Set OldOtherFacility
         List<OldOtherFacility> facilityList = oldOtherFacilityRepo.findBySchoolId(school.getId());
         if (!facilityList.isEmpty()) {
             OldOtherFacility otherFacility = facilityList.get(facilityList.size() - 1);
             dto.setMinimum200DaysOf800ClockHoursForPrimaryAndHigher(otherFacility.getMinimum200DaysOf800ClockHoursForPrimaryAndHigher());
             dto.setHoursOfTeachingPerWeek(otherFacility.getHoursOfTeachingPerWeek());
             dto.setSufficientEducationalMaterialInEachClassAsRequired(otherFacility.getSufficientEducationalMaterialInEachClassAsRequired());
             dto.setNumberOfReferenceBooksAvailableForTeacherTraining(otherFacility.getNumberOfReferenceBooksAvailableForTeacherTraining());
             dto.setNumberOfBooksAvailableForStudentReadingInTheLibrary(otherFacility.getNumberOfBooksAvailableForStudentReadingInTheLibrary());
             dto.setMagzinBooksCount(otherFacility.getMagzinBooksCount());
             dto.setNewspaperAndTotalCount(otherFacility.getNewspaperAndTotalCount());
             dto.setNumberOfSportsAndSportsLiterature(otherFacility.getNumberOfSportsAndSportsLiterature());
         }

         // Set Granted/Non-Granted specific info
         if ("Granted".equalsIgnoreCase(school.getSchoolType())) {
             List<OldGrantedSchoolInfo> grantedList = oldGrantedSchoolInfoRepo.findBySchoolId(school.getId());
             if (!grantedList.isEmpty()) {
                 OldGrantedSchoolInfo grantedInfo = grantedList.get(grantedList.size() - 1);
                 dto.setGrantedGovernmentDecisionOfApproval(grantedInfo.getGovernmentDecisionOfApproval());
                 dto.setGrantedApprovalOrderOfDeputyDirectorOfEducation(grantedInfo.getApprovalOrderOfDeputyDirectorOfEducation());
                 dto.setGrantedFirstApprovalOrder(grantedInfo.getFirstApprovalOrder());
                 dto.setGrantedOrganizationsRequisitionApplicationInSample1(grantedInfo.getOrganizationsRequisitionApplicationInSample1());
                 dto.setGrantedInstitutionRegistration19501860Certificate(grantedInfo.getInstitutionRegistration19501860Certificate());
                 dto.setGrantedGovtMinorityCertificateIfTheSchoolIsMinority(grantedInfo.getGovtMinorityCertificateIfTheSchoolIsMinority());
                 dto.setGrantedPurchaseDeedLeaseAgreementAwardDeed(grantedInfo.getPurchaseDeedLeaseAgreementAwardDeed());
                 dto.setGrantedCertificationOfJoiningIfAdditionalTeacher(grantedInfo.getCertificationOfJoiningIfJoiningIfAdditionalTeacher());
                 dto.setGrantedInstitutionalUndertakingOfSchoolsNotChargingAny(grantedInfo.getInstitutionalUndertakingOfSchoolsNotChargingAny());
                 dto.setGrantedWomenGrievanceRedressalCommittee(grantedInfo.getWomenGrievanceRedressalCommittee());
                 dto.setGrantedAffidavitOnStampOfRs100(grantedInfo.getAffidavitOnStampOfRs100());
                 dto.setGrantedSchoolPrincipalSignStamp(grantedInfo.getSchoolPrincipalSignStamp());
                 dto.setGrantedCommonOrder2013To2016Bit(grantedInfo.getCommonOrder2013To2016Bit());
                 dto.setGrantedCommonOrder2016To2019Bit(grantedInfo.getCommonOrder2016To2019Bit());
                 dto.setGrantedCommonOrder2019To2022Bit(grantedInfo.getCommonOrder2019To2022Bit());
             }
         } else if ("Non_Granted".equalsIgnoreCase(school.getSchoolType())) {
             List<OldNonGrantedSchoolInfo> nonGrantedList = oldNonGrantedSchoolInfoRepo.findBySchoolId(school.getId());
             if (!nonGrantedList.isEmpty()) {
                 OldNonGrantedSchoolInfo nonGrantedInfo = nonGrantedList.get(nonGrantedList.size() - 1);
                 dto.setNonGrantedGovernmentDecisionOfApproval(nonGrantedInfo.getGovernmentDecisionOfApproval());
                 dto.setNonGrantedApprovalOrderOfDeputyDirectorOfEducation(nonGrantedInfo.getApprovalOrderOfDeputyDirectorOfEducation());
                 dto.setNonGrantedFirstApprovalOrder(nonGrantedInfo.getFirstApprovalOrder());
                 dto.setNonGrantedOrganizationsRequisitionApplicationInSample1(nonGrantedInfo.getOrganizationsRequisitionApplicationInSample1());
                 dto.setNonGrantedJointAccountRetentionReceiptOfInstitution(nonGrantedInfo.getJointAccountRetentionReceiptOfInstitution());
                 dto.setNonGrantedOrganizationCompanyRegistrationCertificate(nonGrantedInfo.getOrganizationCompanyRegistrationCertificate());
                 dto.setNonGrantedGovtMinorityCertificate(nonGrantedInfo.getGovtMinorityCertificate());
                 dto.setNonGrantedPurchaseDeedLeaseAgreementAward(nonGrantedInfo.getPurchaseDeedLeaseAgreementAward());
                 dto.setNonGrantedAuditReport(nonGrantedInfo.getAuditReport());
                 dto.setNonGrantedCopyOfEptaApprovalMinutes(nonGrantedInfo.getCopyOfEptaApprovalMinutes());
                 dto.setNonGrantedFreeStructureAccordingToPrevious(nonGrantedInfo.getFreeStructureAccordingToPrevious());
                 dto.setNonGrantedTransportCommitteeOnlineCopy(nonGrantedInfo.getTransportCommitteeOnlineCopy());
                 dto.setNonGrantedWomenGrievanceRedressalCommittee(nonGrantedInfo.getWomenGrievanceRedressalCommittee());
                 dto.setNonGrantedAffidavitOnStampOfRs100(nonGrantedInfo.getAffidavitOnStampOfRs100());
                 dto.setNonGrantedSchoolPrincipalSignStamp(nonGrantedInfo.getSchoolPrincipalSignStamp());
                 dto.setNonGrantedCommonOrder2013To2016Bit(nonGrantedInfo.getCommonOrder2013To2016Bit());
                 dto.setNonGrantedCommonOrder2016To2019Bit(nonGrantedInfo.getCommonOrder2016To2019Bit());
                 dto.setNonGrantedCommonOrder2019To2022Bit(nonGrantedInfo.getCommonOrder2019To2022Bit());
             }
         }
}
}