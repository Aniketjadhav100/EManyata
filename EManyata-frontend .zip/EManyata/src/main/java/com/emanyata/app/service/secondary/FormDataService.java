package com.emanyata.app.service.secondary;


import com.emanyata.app.dto.YearWiseFormDataRequest;

import java.util.Map;

public interface FormDataService {
    Map<String, Object> getYearWiseData(YearWiseFormDataRequest request);
}
