package com.emanyata.app.authdto;

public class OtpRequest {
    private String emailOrMobile;
    private String otpOrMobileOtp;
    
	public String getEmailOrMobile() {
		return emailOrMobile;
	}
	public void setEmailOrMobile(String emailOrMobile) {
		this.emailOrMobile = emailOrMobile;
	}
	public String getOtpOrMobileOtp() {
		return otpOrMobileOtp;
	}
	public void setOtpOrMobileOtp(String otpOrMobileOtp) {
		this.otpOrMobileOtp = otpOrMobileOtp;
	}
	
}