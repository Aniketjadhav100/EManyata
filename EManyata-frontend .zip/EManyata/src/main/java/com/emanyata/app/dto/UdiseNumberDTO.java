package com.emanyata.app.dto;


public class UdiseNumberDTO {
    private Long id;
    private String name;
    private String addressDeputydirector;
    private String district;
    private String taluka;
    private String village;
    private String pincode;
    private String telephonenumber;
    private String schoolMobilenumber;
    private String schoolemailid;
    private String typeofschool;
    private String udiseNumber;
    private String addressapprovaldocuments;
    private String schoolestablishmentYear;
    private String dateoffirstcommencementschool;
    private String dateoffirstopeningofschool;
    private String schoolarea;
    private String medium;
    private String schoolBoard;
    private String status;
    private String schoolhalfdayschedule;
    private String schooldayschedule;
    private String middaymealschedule;
    private String nameoftSocietyManagementCommittee;
    private String classpresentinUDISE;
    private String selfapprovalcertificate;
    private String uploadedFilePath;
    private String nearpolicestationname;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddressDeputydirector() {
		return addressDeputydirector;
	}
	public void setAddressDeputydirector(String addressDeputydirector) {
		this.addressDeputydirector = addressDeputydirector;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getTaluka() {
		return taluka;
	}
	public void setTaluka(String taluka) {
		this.taluka = taluka;
	}
	public String getVillage() {
		return village;
	}
	public void setVillage(String village) {
		this.village = village;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getTelephonenumber() {
		return telephonenumber;
	}
	public void setTelephonenumber(String telephonenumber) {
		this.telephonenumber = telephonenumber;
	}
	public String getSchoolMobilenumber() {
		return schoolMobilenumber;
	}
	public void setSchoolMobilenumber(String schoolMobilenumber) {
		this.schoolMobilenumber = schoolMobilenumber;
	}
	public String getSchoolemailid() {
		return schoolemailid;
	}
	public void setSchoolemailid(String schoolemailid) {
		this.schoolemailid = schoolemailid;
	}
	public String getTypeofschool() {
		return typeofschool;
	}
	public void setTypeofschool(String typeofschool) {
		this.typeofschool = typeofschool;
	}
	public String getUdiseNumber() {
		return udiseNumber;
	}
	public void setUdiseNumber(String udiseNumber) {
		this.udiseNumber = udiseNumber;
	}
	public String getAddressapprovaldocuments() {
		return addressapprovaldocuments;
	}
	public void setAddressapprovaldocuments(String addressapprovaldocuments) {
		this.addressapprovaldocuments = addressapprovaldocuments;
	}
	public String getSchoolestablishmentYear() {
		return schoolestablishmentYear;
	}
	public void setSchoolestablishmentYear(String schoolestablishmentYear) {
		this.schoolestablishmentYear = schoolestablishmentYear;
	}
	public String getDateoffirstcommencementschool() {
		return dateoffirstcommencementschool;
	}
	public void setDateoffirstcommencementschool(String dateoffirstcommencementschool) {
		this.dateoffirstcommencementschool = dateoffirstcommencementschool;
	}
	public String getSchoolarea() {
		return schoolarea;
	}
	public void setSchoolarea(String schoolarea) {
		this.schoolarea = schoolarea;
	}
	public String getMedium() {
		return medium;
	}
	public void setMedium(String medium) {
		this.medium = medium;
	}
	public String getSchoolBoard() {
		return schoolBoard;
	}
	public void setSchoolBoard(String schoolBoard) {
		this.schoolBoard = schoolBoard;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSchoolhalfdayschedule() {
		return schoolhalfdayschedule;
	}
	public void setSchoolhalfdayschedule(String schoolhalfdayschedule) {
		this.schoolhalfdayschedule = schoolhalfdayschedule;
	}
	public String getSchooldayschedule() {
		return schooldayschedule;
	}
	public void setSchooldayschedule(String schooldayschedule) {
		this.schooldayschedule = schooldayschedule;
	}
	public String getMiddaymealschedule() {
		return middaymealschedule;
	}
	public void setMiddaymealschedule(String middaymealschedule) {
		this.middaymealschedule = middaymealschedule;
	}
	public String getNameoftSocietyManagementCommittee() {
		return nameoftSocietyManagementCommittee;
	}
	public void setNameoftSocietyManagementCommittee(String nameoftSocietyManagementCommittee) {
		this.nameoftSocietyManagementCommittee = nameoftSocietyManagementCommittee;
	}
	public String getClasspresentinUDISE() {
		return classpresentinUDISE;
	}
	public void setClasspresentinUDISE(String classpresentinUDISE) {
		this.classpresentinUDISE = classpresentinUDISE;
	}
	public String getSelfapprovalcertificate() {
		return selfapprovalcertificate;
	}
	public void setSelfapprovalcertificate(String selfapprovalcertificate) {
		this.selfapprovalcertificate = selfapprovalcertificate;
	}
	public String getUploadedFilePath() {
		return uploadedFilePath;
	}
	public void setUploadedFilePath(String uploadedFilePath) {
		this.uploadedFilePath = uploadedFilePath;
	}
	public String getNearpolicestationname() {
		return nearpolicestationname;
	}
	public void setNearpolicestationname(String nearpolicestationname) {
		this.nearpolicestationname = nearpolicestationname;
	}
    
    
    
    
}
