package com.emanyata.app.controller.primary;

import com.emanyata.app.dto.TapasaniFormDTO;
import com.emanyata.app.entity.primary.Image;
import com.emanyata.app.service.primary.TapasaniFormService;
import com.emanyata.app.util.TapasaniFileUploadUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;
import java.util.stream.Stream;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

@RestController
@RequestMapping("/api/tapasani")
@CrossOrigin(origins = "http://localhost:3000")
public class TapasaniFormController {

    @Autowired
    private TapasaniFormService tapasaniFormService;

    @Autowired
    private TapasaniFileUploadUtil fileUploadUtil;

    @PostMapping(value = "/save", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> saveForm(
            @RequestParam("name") String name,
            @RequestParam("email") String email,
            @RequestParam("password") String password,
            @RequestParam("confirmPassword") String confirmPassword,
            @RequestParam("mobileNo") String mobileNo,
            @RequestParam(value = "status", required = false, defaultValue = "1") Byte status,
            @RequestPart(value = "photo", required = false) MultipartFile photo) {

        try {
            // Validate password match
            if (!password.equals(confirmPassword)) {
                return ResponseEntity.badRequest().body(createErrorResponse("Password and confirm password do not match"));
            }

            // Create DTO
            TapasaniFormDTO formDTO = new TapasaniFormDTO();
            formDTO.setName(name);
            formDTO.setEmail(email);
            formDTO.setPassword(password);
            formDTO.setConfirmPassword(confirmPassword);
            formDTO.setMobileNo(mobileNo);
            formDTO.setStatus(status);
            

            // Handle file upload
            if (photo != null && !photo.isEmpty()) {
                try {
                    String filePath = fileUploadUtil.saveFile(photo, "profile-photos");
                    Image image = new Image();
                    image.setPath(filePath);
                    formDTO.setPhoto(image);
                } catch (IOException e) {
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body(createErrorResponse("Failed to upload image: " + e.getMessage()));
                }
            }

            // Save the form
            TapasaniFormDTO savedForm = tapasaniFormService.saveForm(formDTO);
            return ResponseEntity.ok(savedForm);

        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(createErrorResponse(e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("An error occurred: " + e.getMessage()));
        }
    }

    @PostMapping("/getAll")
    public ResponseEntity<?> getAllForms() {
        try {
            return ResponseEntity.ok(tapasaniFormService.getAllForms());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Error fetching forms: " + e.getMessage()));
        }
    }

    @PostMapping("/get/{id}")
    public ResponseEntity<?> getFormById(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(tapasaniFormService.getFormById(id));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(createErrorResponse(e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Error fetching form: " + e.getMessage()));
        }
    }

    @PostMapping(value = "/update/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> updateForm(
            @PathVariable Long id,
            @RequestParam("name") String name,
            @RequestParam("email") String email,
            @RequestParam(value = "password", required = false) String password,
            @RequestParam("mobileNo") String mobileNo,
            @RequestParam(value = "status", required = false, defaultValue = "1") Byte status,
            @RequestPart(value = "photo", required = false) MultipartFile photo) {

        try {
            // Create DTO
            TapasaniFormDTO formDTO = new TapasaniFormDTO();
            formDTO.setName(name);
            formDTO.setEmail(email);
            formDTO.setPassword(password);
            formDTO.setMobileNo(mobileNo);
            formDTO.setStatus(status);

            // Handle file upload if new photo is provided
            if (photo != null && !photo.isEmpty()) {
                try {
                    String filePath = fileUploadUtil.saveFile(photo, "profile-photos");
                    Image image = new Image();
                    image.setPath(filePath);
                    formDTO.setPhoto(image);
                } catch (IOException e) {
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body(createErrorResponse("Failed to upload new image: " + e.getMessage()));
                }
            }

            TapasaniFormDTO updatedForm = tapasaniFormService.updateForm(id, formDTO);
            return ResponseEntity.ok(updatedForm);

        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(createErrorResponse(e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Error updating form: " + e.getMessage()));
        }
    }

    @PostMapping("/delete/{id}")
    public ResponseEntity<?> deleteForm(@PathVariable Long id) {
        try {
            tapasaniFormService.deleteForm(id);
            return ResponseEntity.ok().build();
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(createErrorResponse(e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Error deleting form: " + e.getMessage()));
        }
    }

    @GetMapping("/photo/{filename:.+}")
    public ResponseEntity<Resource> servePhoto(@PathVariable String filename) {
        try {
            // First try the exact path
            Path filePath = Paths.get("uploads", filename).normalize();
            Resource resource = new UrlResource(filePath.toUri());

            // If not found, try to find by filename in the uploads directory
            if (!resource.exists() || !resource.isReadable()) {
                // Search recursively in the uploads directory
                Path uploadsDir = Paths.get("uploads");
                if (Files.isDirectory(uploadsDir)) {
                    try (var walk = Files.walk(uploadsDir)) {
                        Optional<Path> foundFile = walk
                            .filter(Files::isRegularFile)
                            .filter(path -> path.getFileName().toString().equals(filename) || 
                                          path.getFileName().toString().endsWith(filename))
                            .findFirst();
                        
                        if (foundFile.isPresent()) {
                            resource = new UrlResource(foundFile.get().toUri());
                        }
                    }
                }
            }

            if (resource.exists() && resource.isReadable()) {
                // Determine content type
                String contentType = determineContentType(filename);
                return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .body(resource);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    private String determineContentType(String filename) {
        String extension = filename.substring(filename.lastIndexOf('.') + 1).toLowerCase();
        return switch (extension) {
            case "jpg", "jpeg" -> "image/jpeg";
            case "png" -> "image/png";
            case "gif" -> "image/gif";
            case "pdf" -> "application/pdf";
            default -> "application/octet-stream";
        };
    }

    // Helper method to create error response
    private Map<String, String> createErrorResponse(String message) {
        Map<String, String> response = new HashMap<>();
        response.put("message", message);
        return response;
    }
}