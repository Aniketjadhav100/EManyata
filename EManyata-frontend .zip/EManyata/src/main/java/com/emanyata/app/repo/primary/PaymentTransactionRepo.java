package com.emanyata.app.repo.primary;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.primary.Payment;

public interface PaymentTransactionRepo extends JpaRepository<Payment, Long> {
    Optional<Payment> findByTransactionId(String transactionId);
    Optional<Payment> findBySchoolId(Long id);
    List<Payment> findAllBySchoolId(Long id);
}
