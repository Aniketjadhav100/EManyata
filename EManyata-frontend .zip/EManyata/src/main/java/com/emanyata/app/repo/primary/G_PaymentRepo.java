package com.emanyata.app.repo.primary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.primary.G_Payment;

public interface G_PaymentRepo extends JpaRepository<G_Payment, Long> {
}