package com.emanyata.app.repo.primary;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.emanyata.app.dto.SchoolTypeCountDTO;
import com.emanyata.app.entity.primary.School;

@Repository
public interface SchoolTypeCountRepository extends CrudRepository<School, Long> {
	
	@Query("SELECT new com.emanyata.app.dto.SchoolTypeCountDTO(s.schoolType, COUNT(s)) " +
		       "FROM School s GROUP BY s.schoolType")
	List<SchoolTypeCountDTO> countBySchoolType();	
}
