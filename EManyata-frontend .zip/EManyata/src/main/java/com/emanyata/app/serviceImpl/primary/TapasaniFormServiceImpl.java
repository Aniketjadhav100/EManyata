package com.emanyata.app.serviceImpl.primary;

import com.emanyata.app.dto.TapasaniFormDTO;
import com.emanyata.app.entity.primary.Image;
import com.emanyata.app.entity.primary.Role;
import com.emanyata.app.entity.primary.User;
import com.emanyata.app.repo.primary.ImageRepo;
import com.emanyata.app.repo.primary.RoleRepo;
import com.emanyata.app.repo.primary.UserRepo;
import com.emanyata.app.service.primary.TapasaniFormService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TapasaniFormServiceImpl implements TapasaniFormService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private RoleRepo roleRepo;

    @Autowired
    private ImageRepo imageRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public TapasaniFormDTO saveForm(TapasaniFormDTO dto) {
        validateForm(dto);
        
        // Check if email already exists
        Optional<User> existingEmail = userRepo.findByEmail(dto.getEmail());
        if (existingEmail.isPresent()) {
            throw new RuntimeException("Email already exists");
        }
        
        // Check if mobile already exists
        Optional<User> existingMobile = userRepo.findByMobile(dto.getMobileNo());
        if (existingMobile.isPresent()) {
            throw new RuntimeException("Mobile number already exists");
        }

        // Get or create role with ID 5 (Tapasani)
        Role role = roleRepo.findById(5L)
                .orElseThrow(() -> new RuntimeException("Role with ID 5 (Tapasani) not found"));

        // Convert DTO to entity
        User user = new User();
        user.setName(dto.getName());
        user.setEmail(dto.getEmail());
        user.setPassword(passwordEncoder.encode(dto.getPassword()));
        user.setMobile(dto.getMobileNo());
        user.setDesignation(null);
        user.setStatus(dto.getStatus() != null ? dto.getStatus() : (byte) 1);
        user.setRole(role);
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());
        user.setUdiseNo("N/A"); // Default value for required field
        user.setOtpverified("");

        // Handle image upload if exists
        if (dto.getPhoto() != null) {
            Image image = dto.getPhoto();
            if (image.getCreatedAt() == null) {
                image.setCreatedAt(LocalDateTime.now());
            }
            image.setUpdatedAt(LocalDateTime.now());
            Image savedImage = imageRepo.save(image);
            user.setImage(savedImage);
        }

        // Save the user
        User savedUser = userRepo.save(user);
        return convertToDto(savedUser);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TapasaniFormDTO> getAllForms() {
        return userRepo.findByRoleId(5L).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public TapasaniFormDTO getFormById(Long id) {
        User user = userRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));
        
        // Verify user has role ID 5 (Tapasani)
        if (user.getRole() == null || user.getRole().getId() != 5) {
            throw new RuntimeException("User is not a Tapasani user");
        }
        
        return convertToDto(user);
    }

    @Override
    @Transactional
    public void deleteForm(Long id) {
        User user = userRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));
        
        // Verify user has role ID 5 (Tapasani)
        if (user.getRole() == null || user.getRole().getId() != 5) {
            throw new RuntimeException("Cannot delete non-Tapasani user");
        }
        
        // Delete associated image if exists
        if (user.getImage() != null) {
            imageRepo.delete(user.getImage());
        }
        
        userRepo.delete(user);
    }

    @Override
    @Transactional
    public TapasaniFormDTO updateForm(Long id, TapasaniFormDTO dto) {
        User existingUser = userRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));
        
        // Verify user has role ID 5 (Tapasani)
        if (existingUser.getRole() == null || existingUser.getRole().getId() != 5) {
            throw new RuntimeException("Cannot update non-Tapasani user");
        }
        
        // Check if email is being changed and already exists
        if (!existingUser.getEmail().equals(dto.getEmail())) {
            Optional<User> userWithEmail = userRepo.findByEmail(dto.getEmail());
            if (userWithEmail.isPresent() && !userWithEmail.get().getId().equals(id)) {
                throw new RuntimeException("Email already exists");
            }
        }
        
        // Check if mobile is being changed and already exists
        if (!existingUser.getMobile().equals(dto.getMobileNo())) {
            Optional<User> userWithMobile = userRepo.findByMobile(dto.getMobileNo());
            if (userWithMobile.isPresent() && !userWithMobile.get().getId().equals(id)) {
                throw new RuntimeException("Mobile number already exists");
            }
        }
        
        // Update user fields
        existingUser.setName(dto.getName());
        existingUser.setEmail(dto.getEmail());
        if (dto.getPassword() != null && !dto.getPassword().isEmpty()) {
            existingUser.setPassword(passwordEncoder.encode(dto.getPassword()));
        }
        existingUser.setMobile(dto.getMobileNo());
        if (dto.getStatus() != null) {
            existingUser.setStatus(dto.getStatus());
        }
        existingUser.setUpdatedAt(LocalDateTime.now());
        
        // Handle image update if exists
        if (dto.getPhoto() != null) {
            // Delete old image if exists
            if (existingUser.getImage() != null) {
                imageRepo.delete(existingUser.getImage());
            }
            
            // Save new image
            Image image = dto.getPhoto();
            if (image.getCreatedAt() == null) {
                image.setCreatedAt(LocalDateTime.now());
            }
            image.setUpdatedAt(LocalDateTime.now());
            Image savedImage = imageRepo.save(image);
            existingUser.setImage(savedImage);
        }
        
        // Save the updated user
        User updatedUser = userRepo.save(existingUser);
        return convertToDto(updatedUser);
    }

    private void validateForm(TapasaniFormDTO dto) {
        if (dto == null) {
            throw new IllegalArgumentException("Form data cannot be null");
        }
        if (dto.getEmail() == null || dto.getEmail().trim().isEmpty()) {
            throw new IllegalArgumentException("Email is required");
        }
        if (dto.getPassword() == null || dto.getPassword().trim().isEmpty()) {
            throw new IllegalArgumentException("Password is required");
        }
        if (dto.getMobileNo() == null || dto.getMobileNo().trim().isEmpty()) {
            throw new IllegalArgumentException("Mobile number is required");
        }
        // Add more validations as needed
    }

    private TapasaniFormDTO convertToDto(User user) {
        if (user == null) {
            return null;
        }
        TapasaniFormDTO dto = new TapasaniFormDTO();
        dto.setId(user.getId());
        dto.setName(user.getName());
        dto.setEmail(user.getEmail());
        dto.setMobileNo(user.getMobile());
        dto.setStatus(user.getStatus());
        dto.setPhoto(user.getImage());
        return dto;
    }
}