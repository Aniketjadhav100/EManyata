package com.emanyata.app.dto;

import java.time.LocalDateTime;

public class OtherFacilityDTO {
	private Long id;
	    private Long schoolId;
	    private String areAllFacilitiesAccessibleWithoutHindrance;
	    private String studyTeachingMaterials;
	    private String sportsAndSportsEquipment;
	    private String libraryBookFacilityBooks;
	    private String typeAndNumberOfDrinkingWaterFacilities;
	    private String sanitaryCondition;
	    private String typeOfToilets;
	    private String numberOfSeparateToiletFacilitiesForBoys;
	    private String numberOfSeparateToiletFacilitiesForGirls;
	    private String divisionWiseInformation;
	    private String studentPerformanceMethod;
	    private String isSchoolPressureToGiveThirdPartyExam;
	    private LocalDateTime createdAt;
	    private LocalDateTime updatedAt;
	    private Long applicationId;
	    private String minimum200DaysOf800ClockHoursForPrimaryAndHigher;
	    private String numberOfBooksAvailableForStudentReadingInTheLibrary;
	    private String numberOfSportsAndSportsLiterature;
	    private String numberOfReferenceBooksAvailableForTeacherTraining;
	    private String hoursOfTeachingPerWeek;
	    private String sufficientEducationalMaterialInEachClassAsRequired;
	    private String magzinBooksCount;
	    private String newspaperAndTotalCount;
	    private String inspectionApproval;
	    private String inspectionComment;
	    
	    
	    private Byte generalInfo;
	    private Byte detailsOfPhysicals;
	    private Byte otherFacility;
	    private Byte studentCount;
	    private Byte grantedSchool;
	    private Byte nonGrantedSchool;
	    
	    private Byte status;
	    
	    
	    
		public Byte getStatus() {
			return status;
		}
		public void setStatus(Byte status) {
			this.status = status;
		}

	    
		public Byte getGeneralInfo() {
			return generalInfo;
		}
		public void setGeneralInfo(Byte generalInfo) {
			this.generalInfo = generalInfo;
		}
		public Byte getDetailsOfPhysicals() {
			return detailsOfPhysicals;
		}
		public void setDetailsOfPhysicals(Byte detailsOfPhysicals) {
			this.detailsOfPhysicals = detailsOfPhysicals;
		}
		public Byte getOtherFacility() {
			return otherFacility;
		}
		public void setOtherFacility(Byte otherFacility) {
			this.otherFacility = otherFacility;
		}
		public Byte getStudentCount() {
			return studentCount;
		}
		public void setStudentCount(Byte studentCount) {
			this.studentCount = studentCount;
		}
		public Byte getGrantedSchool() {
			return grantedSchool;
		}
		public void setGrantedSchool(Byte grantedSchool) {
			this.grantedSchool = grantedSchool;
		}
		public Byte getNonGrantedSchool() {
			return nonGrantedSchool;
		}
		public void setNonGrantedSchool(Byte nonGrantedSchool) {
			this.nonGrantedSchool = nonGrantedSchool;
		}
	    
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public Long getSchoolId() {
			return schoolId;
		}
		public void setSchoolId(Long schoolId) {
			this.schoolId = schoolId;
		}
		public String getAreAllFacilitiesAccessibleWithoutHindrance() {
			return areAllFacilitiesAccessibleWithoutHindrance;
		}
		public void setAreAllFacilitiesAccessibleWithoutHindrance(String areAllFacilitiesAccessibleWithoutHindrance) {
			this.areAllFacilitiesAccessibleWithoutHindrance = areAllFacilitiesAccessibleWithoutHindrance;
		}
		public String getStudyTeachingMaterials() {
			return studyTeachingMaterials;
		}
		public void setStudyTeachingMaterials(String studyTeachingMaterials) {
			this.studyTeachingMaterials = studyTeachingMaterials;
		}
		public String getSportsAndSportsEquipment() {
			return sportsAndSportsEquipment;
		}
		public void setSportsAndSportsEquipment(String sportsAndSportsEquipment) {
			this.sportsAndSportsEquipment = sportsAndSportsEquipment;
		}
		public String getLibraryBookFacilityBooks() {
			return libraryBookFacilityBooks;
		}
		public void setLibraryBookFacilityBooks(String libraryBookFacilityBooks) {
			this.libraryBookFacilityBooks = libraryBookFacilityBooks;
		}
		public String getTypeAndNumberOfDrinkingWaterFacilities() {
			return typeAndNumberOfDrinkingWaterFacilities;
		}
		public void setTypeAndNumberOfDrinkingWaterFacilities(String typeAndNumberOfDrinkingWaterFacilities) {
			this.typeAndNumberOfDrinkingWaterFacilities = typeAndNumberOfDrinkingWaterFacilities;
		}
		public String getSanitaryCondition() {
			return sanitaryCondition;
		}
		public void setSanitaryCondition(String sanitaryCondition) {
			this.sanitaryCondition = sanitaryCondition;
		}
		public String getTypeOfToilets() {
			return typeOfToilets;
		}
		public void setTypeOfToilets(String typeOfToilets) {
			this.typeOfToilets = typeOfToilets;
		}
		public String getNumberOfSeparateToiletFacilitiesForBoys() {
			return numberOfSeparateToiletFacilitiesForBoys;
		}
		public void setNumberOfSeparateToiletFacilitiesForBoys(String numberOfSeparateToiletFacilitiesForBoys) {
			this.numberOfSeparateToiletFacilitiesForBoys = numberOfSeparateToiletFacilitiesForBoys;
		}
		public String getNumberOfSeparateToiletFacilitiesForGirls() {
			return numberOfSeparateToiletFacilitiesForGirls;
		}
		public void setNumberOfSeparateToiletFacilitiesForGirls(String numberOfSeparateToiletFacilitiesForGirls) {
			this.numberOfSeparateToiletFacilitiesForGirls = numberOfSeparateToiletFacilitiesForGirls;
		}
		public String getDivisionWiseInformation() {
			return divisionWiseInformation;
		}
		public void setDivisionWiseInformation(String divisionWiseInformation) {
			this.divisionWiseInformation = divisionWiseInformation;
		}
		public String getStudentPerformanceMethod() {
			return studentPerformanceMethod;
		}
		public void setStudentPerformanceMethod(String studentPerformanceMethod) {
			this.studentPerformanceMethod = studentPerformanceMethod;
		}
		public String getIsSchoolPressureToGiveThirdPartyExam() {
			return isSchoolPressureToGiveThirdPartyExam;
		}
		public void setIsSchoolPressureToGiveThirdPartyExam(String isSchoolPressureToGiveThirdPartyExam) {
			this.isSchoolPressureToGiveThirdPartyExam = isSchoolPressureToGiveThirdPartyExam;
		}
		public LocalDateTime getCreatedAt() {
			return createdAt;
		}
		public void setCreatedAt(LocalDateTime createdAt) {
			this.createdAt = createdAt;
		}
		public LocalDateTime getUpdatedAt() {
			return updatedAt;
		}
		public void setUpdatedAt(LocalDateTime updatedAt) {
			this.updatedAt = updatedAt;
		}
		public Long getApplicationId() {
			return applicationId;
		}
		public void setApplicationId(Long applicationId) {
			this.applicationId = applicationId;
		}
		public String getMinimum200DaysOf800ClockHoursForPrimaryAndHigher() {
			return minimum200DaysOf800ClockHoursForPrimaryAndHigher;
		}
		public void setMinimum200DaysOf800ClockHoursForPrimaryAndHigher(
				String minimum200DaysOf800ClockHoursForPrimaryAndHigher) {
			this.minimum200DaysOf800ClockHoursForPrimaryAndHigher = minimum200DaysOf800ClockHoursForPrimaryAndHigher;
		}
		public String getNumberOfBooksAvailableForStudentReadingInTheLibrary() {
			return numberOfBooksAvailableForStudentReadingInTheLibrary;
		}
		public void setNumberOfBooksAvailableForStudentReadingInTheLibrary(
				String numberOfBooksAvailableForStudentReadingInTheLibrary) {
			this.numberOfBooksAvailableForStudentReadingInTheLibrary = numberOfBooksAvailableForStudentReadingInTheLibrary;
		}
		public String getNumberOfSportsAndSportsLiterature() {
			return numberOfSportsAndSportsLiterature;
		}
		public void setNumberOfSportsAndSportsLiterature(String numberOfSportsAndSportsLiterature) {
			this.numberOfSportsAndSportsLiterature = numberOfSportsAndSportsLiterature;
		}
		public String getNumberOfReferenceBooksAvailableForTeacherTraining() {
			return numberOfReferenceBooksAvailableForTeacherTraining;
		}
		public void setNumberOfReferenceBooksAvailableForTeacherTraining(
				String numberOfReferenceBooksAvailableForTeacherTraining) {
			this.numberOfReferenceBooksAvailableForTeacherTraining = numberOfReferenceBooksAvailableForTeacherTraining;
		}
		public String getHoursOfTeachingPerWeek() {
			return hoursOfTeachingPerWeek;
		}
		public void setHoursOfTeachingPerWeek(String hoursOfTeachingPerWeek) {
			this.hoursOfTeachingPerWeek = hoursOfTeachingPerWeek;
		}
		public String getSufficientEducationalMaterialInEachClassAsRequired() {
			return sufficientEducationalMaterialInEachClassAsRequired;
		}
		public void setSufficientEducationalMaterialInEachClassAsRequired(
				String sufficientEducationalMaterialInEachClassAsRequired) {
			this.sufficientEducationalMaterialInEachClassAsRequired = sufficientEducationalMaterialInEachClassAsRequired;
		}
		public String getMagzinBooksCount() {
			return magzinBooksCount;
		}
		public void setMagzinBooksCount(String magzinBooksCount) {
			this.magzinBooksCount = magzinBooksCount;
		}
		public String getNewspaperAndTotalCount() {
			return newspaperAndTotalCount;
		}
		public void setNewspaperAndTotalCount(String newspaperAndTotalCount) {
			this.newspaperAndTotalCount = newspaperAndTotalCount;
		}
		public String getInspectionApproval() {
			return inspectionApproval;
		}
		public void setInspectionApproval(String inspectionApproval) {
			this.inspectionApproval = inspectionApproval;
		}
		public String getInspectionComment() {
			return inspectionComment;
		}
		public void setInspectionComment(String inspectionComment) {
			this.inspectionComment = inspectionComment;
		}
	    
	    

}
