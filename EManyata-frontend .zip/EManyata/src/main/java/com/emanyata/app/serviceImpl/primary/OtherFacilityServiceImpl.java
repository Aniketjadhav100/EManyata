package com.emanyata.app.serviceImpl.primary;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emanyata.app.dto.OtherFacilityDTO;
import com.emanyata.app.dto.StudentCountDTO;
import com.emanyata.app.entity.primary.ApplicationsResult;
import com.emanyata.app.entity.primary.OtherFacility;
import com.emanyata.app.entity.primary.School;
import com.emanyata.app.entity.primary.SchoolApply;
import com.emanyata.app.repo.primary.ApplicationResultRepo;
import com.emanyata.app.repo.primary.OtherFacilityRepo;
import com.emanyata.app.repo.primary.SchoolApplyRepo;
import com.emanyata.app.repo.primary.SchoolRepo;
import com.emanyata.app.service.primary.OtherFacilityService;
import com.emanyata.app.util.ApplicationFormStepsUtil;

import jakarta.persistence.EntityNotFoundException;

@Service
public class OtherFacilityServiceImpl implements OtherFacilityService {

	@Autowired
	private OtherFacilityRepo otherFacilityRepo;

	@Autowired
	private SchoolApplyRepo applyRepo;

	@Autowired
	private SchoolRepo schoolRepo;

	@Autowired
	private ApplicationResultRepo applicationResultRepo;
	
	@Autowired
	private ApplicationFormStepsUtil stepsUtil;

	private OtherFacilityDTO toDTO(OtherFacility entity) {
		OtherFacilityDTO dto = new OtherFacilityDTO();
		dto.setId(entity.getId());
		dto.setSchoolId(entity.getSchool().getId());
		dto.setAreAllFacilitiesAccessibleWithoutHindrance(entity.getAreAllFacilitiesAccessibleWithoutHindrance());
		dto.setStudyTeachingMaterials(entity.getStudyTeachingMaterials());
		dto.setSportsAndSportsEquipment(entity.getSportsAndSportsEquipment());
		dto.setLibraryBookFacilityBooks(entity.getLibraryBookFacilityBooks());
		dto.setTypeAndNumberOfDrinkingWaterFacilities(entity.getTypeAndNumberOfDrinkingWaterFacilities());
		dto.setSanitaryCondition(entity.getSanitaryCondition());
		dto.setTypeOfToilets(entity.getTypeOfToilets());
		dto.setNumberOfSeparateToiletFacilitiesForBoys(entity.getNumberOfSeparateToiletFacilitiesForBoys());
		dto.setNumberOfSeparateToiletFacilitiesForGirls(entity.getNumberOfSeparateToiletFacilitiesForGirls());
		dto.setDivisionWiseInformation(entity.getDivisionWiseInformation());
		dto.setStudentPerformanceMethod(entity.getStudentPerformanceMethod());
		dto.setIsSchoolPressureToGiveThirdPartyExam(entity.getIsSchoolPressureToGiveThirdPartyExam());
		dto.setCreatedAt(entity.getCreatedAt());
		dto.setUpdatedAt(entity.getUpdatedAt());
		dto.setApplicationId(entity.getApplicationId());
		dto.setMinimum200DaysOf800ClockHoursForPrimaryAndHigher(
				entity.getMinimum200DaysOf800ClockHoursForPrimaryAndHigher());
		dto.setNumberOfBooksAvailableForStudentReadingInTheLibrary(
				entity.getNumberOfBooksAvailableForStudentReadingInTheLibrary());
		dto.setNumberOfSportsAndSportsLiterature(entity.getNumberOfSportsAndSportsLiterature());
		dto.setNumberOfReferenceBooksAvailableForTeacherTraining(
				entity.getNumberOfReferenceBooksAvailableForTeacherTraining());
		dto.setHoursOfTeachingPerWeek(entity.getHoursOfTeachingPerWeek());
		dto.setSufficientEducationalMaterialInEachClassAsRequired(
				entity.getSufficientEducationalMaterialInEachClassAsRequired());
		dto.setMagzinBooksCount(entity.getMagzinBooksCount());
		dto.setNewspaperAndTotalCount(entity.getNewspaperAndTotalCount());
		dto.setInspectionApproval(entity.getInspectionApproval());
		dto.setInspectionComment(entity.getInspectionComment());
		return dto;
	}

	@Override
	public OtherFacilityDTO saveOtherFacility(OtherFacilityDTO dto) {

		if (dto.getApplicationId() != null && dto.getSchoolId() != null) {

			Optional<OtherFacility> otherFacility = otherFacilityRepo.findBySchoolId(dto.getSchoolId());
			Optional<SchoolApply> opt = applyRepo.findById(dto.getApplicationId());

			if (opt.isPresent()) {
				if (otherFacility.isPresent()) {
					if (otherFacility.get().getApplicationId().equals(dto.getApplicationId())) {
						OtherFacility existing = otherFacility.get();

						if (dto.getAreAllFacilitiesAccessibleWithoutHindrance() != null)
							existing.setAreAllFacilitiesAccessibleWithoutHindrance(
									dto.getAreAllFacilitiesAccessibleWithoutHindrance());

						if (dto.getStudyTeachingMaterials() != null)
							existing.setStudyTeachingMaterials(dto.getStudyTeachingMaterials());

						if (dto.getSportsAndSportsEquipment() != null)
							existing.setSportsAndSportsEquipment(dto.getSportsAndSportsEquipment());

						if (dto.getLibraryBookFacilityBooks() != null)
							existing.setLibraryBookFacilityBooks(dto.getLibraryBookFacilityBooks());

						if (dto.getTypeAndNumberOfDrinkingWaterFacilities() != null)
							existing.setTypeAndNumberOfDrinkingWaterFacilities(
									dto.getTypeAndNumberOfDrinkingWaterFacilities());

						if (dto.getSanitaryCondition() != null)
							existing.setSanitaryCondition(dto.getSanitaryCondition());

						if (dto.getTypeOfToilets() != null)
							existing.setTypeOfToilets(dto.getTypeOfToilets());

						if (dto.getNumberOfSeparateToiletFacilitiesForBoys() != null)
							existing.setNumberOfSeparateToiletFacilitiesForBoys(
									dto.getNumberOfSeparateToiletFacilitiesForBoys());

						if (dto.getNumberOfSeparateToiletFacilitiesForGirls() != null)
							existing.setNumberOfSeparateToiletFacilitiesForGirls(
									dto.getNumberOfSeparateToiletFacilitiesForGirls());

						if (dto.getDivisionWiseInformation() != null)
							existing.setDivisionWiseInformation(dto.getDivisionWiseInformation());

						if (dto.getStudentPerformanceMethod() != null)
							existing.setStudentPerformanceMethod(dto.getStudentPerformanceMethod());

						if (dto.getIsSchoolPressureToGiveThirdPartyExam() != null)
							existing.setIsSchoolPressureToGiveThirdPartyExam(
									dto.getIsSchoolPressureToGiveThirdPartyExam());

						if (dto.getMinimum200DaysOf800ClockHoursForPrimaryAndHigher() != null)
							existing.setMinimum200DaysOf800ClockHoursForPrimaryAndHigher(
									dto.getMinimum200DaysOf800ClockHoursForPrimaryAndHigher());

						if (dto.getNumberOfBooksAvailableForStudentReadingInTheLibrary() != null)
							existing.setNumberOfBooksAvailableForStudentReadingInTheLibrary(
									dto.getNumberOfBooksAvailableForStudentReadingInTheLibrary());

						if (dto.getNumberOfSportsAndSportsLiterature() != null)
							existing.setNumberOfSportsAndSportsLiterature(dto.getNumberOfSportsAndSportsLiterature());

						if (dto.getNumberOfReferenceBooksAvailableForTeacherTraining() != null)
							existing.setNumberOfReferenceBooksAvailableForTeacherTraining(
									dto.getNumberOfReferenceBooksAvailableForTeacherTraining());

						if (dto.getHoursOfTeachingPerWeek() != null)
							existing.setHoursOfTeachingPerWeek(dto.getHoursOfTeachingPerWeek());

						if (dto.getSufficientEducationalMaterialInEachClassAsRequired() != null)
							existing.setSufficientEducationalMaterialInEachClassAsRequired(
									dto.getSufficientEducationalMaterialInEachClassAsRequired());

						if (dto.getMagzinBooksCount() != null)
							existing.setMagzinBooksCount(dto.getMagzinBooksCount());

						if (dto.getNewspaperAndTotalCount() != null)
							existing.setNewspaperAndTotalCount(dto.getNewspaperAndTotalCount());

						if (dto.getInspectionApproval() != null)
							existing.setInspectionApproval(dto.getInspectionApproval());

						if (dto.getInspectionComment() != null)
							existing.setInspectionComment(dto.getInspectionComment());

						if (dto.getApplicationId() != null)
							existing.setApplicationId(dto.getApplicationId());

						existing.setUpdatedAt(LocalDateTime.now());
						
						applyRepo.findById(dto.getApplicationId()).ifPresent(apply -> {
							String updatedSteps = stepsUtil.updateStepsJson(apply.getSteps(), "other-facility");
							apply.setSteps(updatedSteps);
							applyRepo.save(apply);
						});

						OtherFacility std= otherFacilityRepo.save(existing);
						
						OtherFacilityDTO dto2 = toDTO(std);
						ApplicationsResult rs = applicationResultRepo.findByApplicationId(dto2.getApplicationId())
								.orElseThrow(() -> new RuntimeException("No ecords found in appliation result"));
						dto2.setGeneralInfo(rs.getGeneralInfo());
						dto2.setStudentCount(rs.getStudentCount());
						dto2.setDetailsOfPhysicals(rs.getDetailsOfPhysical());
						dto2.setOtherFacility(rs.getOtherFacilities());
						dto2.setGrantedSchool(rs.getGranted());
						dto2.setNonGrantedSchool(rs.getNonGranted());
						return dto2;
					} else {
						throw new RuntimeException("Application Id mismatched.");
					}

				} else {
					School school = schoolRepo.findById(dto.getSchoolId())
							.orElseThrow(() -> new RuntimeException("School not found with ID: " + dto.getSchoolId()));

					OtherFacility newFacility = new OtherFacility();
					newFacility.setSchool(school);
					newFacility.setApplicationId(dto.getApplicationId());

					newFacility.setAreAllFacilitiesAccessibleWithoutHindrance(
							dto.getAreAllFacilitiesAccessibleWithoutHindrance());
					newFacility.setStudyTeachingMaterials(dto.getStudyTeachingMaterials());
					newFacility.setSportsAndSportsEquipment(dto.getSportsAndSportsEquipment());
					newFacility.setLibraryBookFacilityBooks(dto.getLibraryBookFacilityBooks());
					newFacility
							.setTypeAndNumberOfDrinkingWaterFacilities(dto.getTypeAndNumberOfDrinkingWaterFacilities());
					newFacility.setSanitaryCondition(dto.getSanitaryCondition());
					newFacility.setTypeOfToilets(dto.getTypeOfToilets());
					newFacility.setNumberOfSeparateToiletFacilitiesForBoys(
							dto.getNumberOfSeparateToiletFacilitiesForBoys());
					newFacility.setNumberOfSeparateToiletFacilitiesForGirls(
							dto.getNumberOfSeparateToiletFacilitiesForGirls());
					newFacility.setDivisionWiseInformation(dto.getDivisionWiseInformation());
					newFacility.setStudentPerformanceMethod(dto.getStudentPerformanceMethod());
					newFacility.setIsSchoolPressureToGiveThirdPartyExam(dto.getIsSchoolPressureToGiveThirdPartyExam());
					newFacility.setMinimum200DaysOf800ClockHoursForPrimaryAndHigher(
							dto.getMinimum200DaysOf800ClockHoursForPrimaryAndHigher());
					newFacility.setNumberOfBooksAvailableForStudentReadingInTheLibrary(
							dto.getNumberOfBooksAvailableForStudentReadingInTheLibrary());
					newFacility.setNumberOfSportsAndSportsLiterature(dto.getNumberOfSportsAndSportsLiterature());
					newFacility.setNumberOfReferenceBooksAvailableForTeacherTraining(
							dto.getNumberOfReferenceBooksAvailableForTeacherTraining());
					newFacility.setHoursOfTeachingPerWeek(dto.getHoursOfTeachingPerWeek());
					newFacility.setSufficientEducationalMaterialInEachClassAsRequired(
							dto.getSufficientEducationalMaterialInEachClassAsRequired());
					newFacility.setMagzinBooksCount(dto.getMagzinBooksCount());
					newFacility.setNewspaperAndTotalCount(dto.getNewspaperAndTotalCount());
					newFacility.setInspectionApproval(dto.getInspectionApproval());
					newFacility.setInspectionComment(dto.getInspectionComment());

					newFacility.setCreatedAt(LocalDateTime.now());
					newFacility.setUpdatedAt(LocalDateTime.now());
					newFacility.setStatus((byte) 1);
					

					OtherFacility facility = otherFacilityRepo.save(newFacility);
					
					applyRepo.findById(dto.getApplicationId()).ifPresent(apply -> {
						String updatedSteps = stepsUtil.updateStepsJson(apply.getSteps(), "other-facility");
						apply.setSteps(updatedSteps);
						applyRepo.save(apply);
					});

					Optional<ApplicationsResult> resultOpt = applicationResultRepo
							.findByApplicationId(dto.getApplicationId());

					if (resultOpt.isPresent()) {
						ApplicationsResult result = resultOpt.get();
						result.setOtherFacilities((byte) 1);
						applicationResultRepo.save(result);
					} else {
						throw new RuntimeException("Application Id not present in application result.");
					}
					
					OtherFacilityDTO dto2 = toDTO(facility);
					ApplicationsResult rs = applicationResultRepo.findByApplicationId(dto2.getApplicationId())
							.orElseThrow(() -> new RuntimeException("No ecords found in appliation result"));
					dto2.setGeneralInfo(rs.getGeneralInfo());
					dto2.setStudentCount(rs.getStudentCount());
					dto2.setDetailsOfPhysicals(rs.getDetailsOfPhysical());
					dto2.setOtherFacility(rs.getOtherFacilities());
					dto2.setGrantedSchool(rs.getGranted());
					dto2.setNonGrantedSchool(rs.getNonGranted());
					return dto2;
				}
			} else {
				throw new RuntimeException("Application Id not present in School Applies.");
			}
		} else {
			throw new RuntimeException("Application ID and School ID must be provided.");
		}
	}

	@Override
	public OtherFacilityDTO getOtherFacility(Long schoolId) {
	    OtherFacility otherFacility = otherFacilityRepo.findBySchoolId(schoolId)
	            .orElseThrow(() -> new RuntimeException("OtherFacility not found for school ID: " + schoolId));

	    Long applicationId = otherFacility.getApplicationId();

	    ApplicationsResult applicationResult = applicationResultRepo.findByApplicationId(applicationId)
	            .orElseThrow(() -> new RuntimeException("Application result not found for application ID: " + applicationId));

	    OtherFacilityDTO dto = toDTO(otherFacility);

	    // Populate additional details from ApplicationsResult
	    dto.setGeneralInfo(applicationResult.getGeneralInfo());
	    dto.setDetailsOfPhysicals(applicationResult.getDetailsOfPhysical());
	    dto.setGrantedSchool(applicationResult.getGranted());
	    dto.setStudentCount(applicationResult.getStudentCount());
	    dto.setNonGrantedSchool(applicationResult.getNonGranted());
	    dto.setOtherFacility(applicationResult.getOtherFacilities());

	    return dto;
	}


}
