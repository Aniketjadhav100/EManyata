package com.emanyata.app.service.secondary;


import com.emanyata.app.dto.AllFormsDTO;
import com.emanyata.app.dto.EmailMobileDTO;

public interface OldSchoolService {
	AllFormsDTO findByUdiseNo(EmailMobileDTO dto,String udiseNumber);
}
