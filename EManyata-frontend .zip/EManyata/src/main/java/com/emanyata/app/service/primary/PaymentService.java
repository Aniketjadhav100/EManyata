package com.emanyata.app.service.primary;


import java.util.List;

import com.emanyata.app.dto.PaymentFieldsDTO;
import com.emanyata.app.dto.PaymentRequestDTO;
import com.emanyata.app.dto.PaymentResponseDTO;
import com.emanyata.app.entity.primary.Payment;


public interface PaymentService {
	PaymentFieldsDTO createTransaction(PaymentRequestDTO dto);
    PaymentResponseDTO getBySchoolId(Long id);
}

