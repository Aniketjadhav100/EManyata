package com.emanyata.app.service.primary;

public interface ValidationService {

	boolean emailExists(String email);

	boolean mobileExists(String mobile);

}
