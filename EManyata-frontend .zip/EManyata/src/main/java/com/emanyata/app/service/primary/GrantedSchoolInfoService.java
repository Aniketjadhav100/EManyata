package com.emanyata.app.service.primary;

import org.springframework.core.io.Resource;

import com.emanyata.app.dto.GrantedSchoolInfoDTO;

public interface GrantedSchoolInfoService {
	GrantedSchoolInfoDTO saveOrUpdate(GrantedSchoolInfoDTO dto);
	GrantedSchoolInfoDTO getBySchoolId(Long schoolId);
	Resource loadFileAsResource(String fileName) throws Exception;
}