package com.emanyata.app.service.primary;

import java.util.List;

import com.emanyata.app.dto.rejectedApplicationDTO;

public interface rejectedApplicationService {

	List<rejectedApplicationDTO> getAllRejectedApplications();

}
