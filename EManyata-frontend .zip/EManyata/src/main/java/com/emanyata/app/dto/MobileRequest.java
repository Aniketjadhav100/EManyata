package com.emanyata.app.dto;

public class MobileRequest {

	
	    private String mobile;

	    // getters & setters
	    public String getMobile() { return mobile; }
	    public void setMobile(String mobile) { this.mobile = mobile; }
	}


