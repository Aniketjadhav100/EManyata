package com.emanyata.app.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.*;

@Component
public class NonGrantedSchoolUtil {

    private static final Logger logger = LoggerFactory.getLogger(NonGrantedSchoolUtil.class);

    @Value("${file.upload-dir}")
    private String uploadDir;

    @PostConstruct
    public void init() {
        try {
            // Create base directory: uploads/nonGrantedDocuments
            Path baseUploadPath = Paths.get(uploadDir, "nonGrantedDocuments");
            Files.createDirectories(baseUploadPath);
            logger.info("Upload base directory created: {}", baseUploadPath);
        } catch (IOException e) {
            logger.error("Error creating upload directories: {}", e.getMessage());
        }
    }

    public String saveFile(MultipartFile file) throws IOException {
        if (file == null || file.isEmpty()) {
            return null;
        }

        // Get original filename
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null) {
            throw new IOException("Original filename is null.");
        }

        // Extract extension
        String fileExtension = "";
        int dotIndex = originalFilename.lastIndexOf('.');
        if (dotIndex != -1 && dotIndex < originalFilename.length() - 1) {
            fileExtension = originalFilename.substring(dotIndex + 1).toLowerCase();
        }

        // ✅ Save under: uploads/nonGrantedDocuments/pdf/
        Path targetDir = Paths.get(uploadDir, "nonGrantedDocuments");
        Files.createDirectories(targetDir);

        // Sanitize filename
        String sanitizedFilename = originalFilename.replaceAll("[^a-zA-Z0-9\\.\\-_]", "_");

        // Save file
        Path targetPath = targetDir.resolve(sanitizedFilename);
        Files.copy(file.getInputStream(), targetPath, StandardCopyOption.REPLACE_EXISTING);

        // Return relative path
        return "uploads/nonGrantedDocuments/"  + "/" + sanitizedFilename;
    }

    public byte[] loadFile(String relativePath) throws IOException {
        if (relativePath == null || relativePath.isEmpty()) {
            return null;
        }

        Path filePath = Paths.get(relativePath).normalize();
        return Files.readAllBytes(filePath);
    }

    public boolean deleteFile(String relativePath) {
        try {
            if (relativePath == null || relativePath.isEmpty()) {
                return false;
            }

            Path filePath = Paths.get(relativePath).normalize();
            return Files.deleteIfExists(filePath);

        } catch (IOException e) {
            logger.error("Error deleting file: {}", e.getMessage());
            return false;
        }
    }
}
