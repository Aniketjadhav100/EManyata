package com.emanyata.app.serviceImpl.secondary;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emanyata.app.dto.AllFormsDTO;
import com.emanyata.app.dto.BhauticSuvidhaDTO;
import com.emanyata.app.dto.EmailMobileDTO;
import com.emanyata.app.dto.OtherFacilityDTO;
import com.emanyata.app.dto.SchoolGeneralInfoDTO;
import com.emanyata.app.dto.StudentCountDTO;
import com.emanyata.app.entity.secondary.*;
import com.emanyata.app.repo.secondary.*;
import com.emanyata.app.service.secondary.OldSchoolService;

import jakarta.transaction.Transactional;

@Service
public class OldSchoolServiceImpl implements OldSchoolService {

    @Autowired
    private OldSchoolRepository oldSchoolRepository;

    @Autowired
    private OldUserRepo userRepo;

    @Autowired
    private OldSchoolApplyRepo oldSchoolApplyRepo;

    @Autowired
    private OldStudentCountRepository oldStudentCountRepo;

    @Autowired
    private OldSchoolGeneralInfoRepository oldSchoolGeneralInfoRepo;

    @Autowired
    private OldDetailOfPhysicalRepository oldDetailsPhysicalRepo;

    @Autowired
    private OldOtherFacilityRepo oldOtherFacilityRepo;

    @Override
    @Transactional
    public AllFormsDTO findByUdiseNo(EmailMobileDTO dto, String udiseNumber) {
        // Check school existence by UDISE no
        List<OldSchool> schools = oldSchoolRepository.findByUdiseNo(udiseNumber);
        if (schools.isEmpty())
            throw new RuntimeException("No records found with UDISE Number: " + udiseNumber);

        // Find user by email or phone
        OldUser user = findUserByEmailOrPhone(dto.getEmailOrMobile());

        // Find school by user id
        OldSchool oldSchool = oldSchoolRepository.findByUserId(user.getId())
                .orElseThrow(() -> new RuntimeException("No school found for user ID: " + user.getId()));

        boolean isSameSchool = schools.stream()
                .anyMatch(school -> school.getId().equals(oldSchool.getId()));

        if (!isSameSchool) {
            throw new RuntimeException("Mismatch: UDISE number school and user-linked school are different.");
        }

        
        // Application with specific status
        List<String> statusList = List.of("final_submit", "verified_by_inspection_officer");
        OldSchoolApply oldSchoolApply = oldSchoolApplyRepo.findFirstBySchoolIdAndStatusIn(oldSchool.getId(), statusList)
                .orElseThrow(() -> new RuntimeException("Application not found for UDISE Number " + udiseNumber));

        // Fetch related entities by applicationId with safe Optional
        OldStudentCount studentCount = oldStudentCountRepo.findByApplicationId(oldSchoolApply.getId())
                .orElseThrow(() -> new RuntimeException("OldStudentCount not found for applicationId: " + oldSchoolApply.getId()));

        OldSchoolGeneralInfo generalInfo = oldSchoolGeneralInfoRepo.findByApplicationId(oldSchoolApply.getId())
                .orElseThrow(() -> new RuntimeException("OldSchoolGeneralInfo not found for applicationId: " + oldSchoolApply.getId()));

        OldDetailOfPhysical detailsOfPhysical = oldDetailsPhysicalRepo.findByApplicationId(oldSchoolApply.getId())
                .orElseThrow(() -> new RuntimeException("OldDetailOfPhysical not found for applicationId: " + oldSchoolApply.getId()));

        // Make OtherFacility optional - create empty object if not found
        OldOtherFacility otherFacility = oldOtherFacilityRepo.findByApplicationId(oldSchoolApply.getId())
                .orElse(new OldOtherFacility()); // Create empty entity if not found

        // Map entities to DTOs
        StudentCountDTO studentCountDTO = mapStudentCount(studentCount);
        SchoolGeneralInfoDTO schoolGeneralInfoDTO = mapSchoolGeneralInfo(generalInfo);
        BhauticSuvidhaDTO bhauticSuvidhaDTO = mapPhysicalDetails(detailsOfPhysical);
        OtherFacilityDTO otherFacilityDTO = mapOtherFacility(otherFacility);

        // Combine all into AllFormsDTO and return
        AllFormsDTO allFormsDTO = new AllFormsDTO();
        allFormsDTO.setStudentCountDTO(studentCountDTO);
        allFormsDTO.setSchoolGeneralInfoDTO(schoolGeneralInfoDTO);
        allFormsDTO.setBhauticSuvidhaDTO(bhauticSuvidhaDTO);
        allFormsDTO.setOtherFacilityDTO(otherFacilityDTO);

        return allFormsDTO;
    }

    private OldUser findUserByEmailOrPhone(String emailOrPhone) {
        if (emailOrPhone.contains("@")) {
            return userRepo.findByEmail(emailOrPhone)
                    .orElseThrow(() -> new RuntimeException("User not found with email: " + emailOrPhone));
        } else {
            return userRepo.findByPhone(emailOrPhone)
                    .orElseThrow(() -> new RuntimeException("User not found with phone: " + emailOrPhone));
        }
    }

    private StudentCountDTO mapStudentCount(OldStudentCount studentCount) {
        StudentCountDTO dto = new StudentCountDTO();
        dto.setId(studentCount.getId());
        dto.setSchoolId(studentCount.getSchool() != null ? studentCount.getSchool().getId() : null);
        dto.setTotalBoys(studentCount.getTotalBoys());
        dto.setTotalGirls(studentCount.getTotalGirls());
        dto.setTotal(studentCount.getTotal());
        dto.setLower(studentCount.getLower());
        dto.setHigher(studentCount.getHigher());
        dto.setCreatedAt(studentCount.getCreatedAt());
        dto.setUpdatedAt(studentCount.getUpdatedAt());
        dto.setApplicationId(studentCount.getApplicationId());
        dto.setInspectionAppoval(studentCount.getInspectionAppoval());
        dto.setInspectionComment(studentCount.getInspectionComment());
        return dto;
    }

    private SchoolGeneralInfoDTO mapSchoolGeneralInfo(OldSchoolGeneralInfo generalInfo) {
		SchoolGeneralInfoDTO schoolGeneralInfoDTO = new SchoolGeneralInfoDTO();

		schoolGeneralInfoDTO.setSchoolId(generalInfo.getSchool().getId());
		schoolGeneralInfoDTO.setSchoolAddress(generalInfo.getSchoolAddress());
		schoolGeneralInfoDTO.setAddressMentionedInGovernmentApprovalDocument(
				generalInfo.getAddressMentionedInGovernmentApprovalDocument());
		schoolGeneralInfoDTO.setSchoolEstablishmentYear(generalInfo.getSchoolEstablishmentYear());
		schoolGeneralInfoDTO.setDateOfFirstCommencementOfSchool(generalInfo.getDateOfFirstCommencementOfSchool());
		schoolGeneralInfoDTO.setSchoolAcademicSession(generalInfo.getSchoolAcademicSession());
		schoolGeneralInfoDTO.setSchoolTimeFullTime(generalInfo.getSchoolTimeFullTime());
		schoolGeneralInfoDTO.setSchoolTimeHalfTime(generalInfo.getSchoolTimeHalfTime());
		schoolGeneralInfoDTO.setAcademicLearningTimeForEachClass(generalInfo.getAcademicLearningTimeForEachClass());
		schoolGeneralInfoDTO.setLunchTimeForEachClass(generalInfo.getLunchTimeForEachClass());
		schoolGeneralInfoDTO.setSportsAndPhysicalEducationTimeForEachClass(
				generalInfo.getSportsAndPhysicalEducationTimeForEachClass());

		schoolGeneralInfoDTO
				.setNameOfTrustSocietyManagementCommittee(generalInfo.getNameOfTrustSocietyManagementCommittee());
		schoolGeneralInfoDTO.setRegistrationNo(generalInfo.getRegistrationNo());
		schoolGeneralInfoDTO
				.setUnderTheSocietiesRegistrationAct1860(generalInfo.getUnderTheSocietiesRegistrationAct1860());
		schoolGeneralInfoDTO
				.setUnderTheMumbaiPublicTrusteeSystemAct1950(generalInfo.getUnderTheMumbaiPublicTrusteeSystemAct1950());
		schoolGeneralInfoDTO
				.setTillWhatPeriodTheRegistrationOfTrust(generalInfo.getTillWhatPeriodTheRegistrationOfTrust());
		schoolGeneralInfoDTO.setIsThereEvidenceThatTheTrust(generalInfo.getIsThereEvidenceThatTheTrust());

		schoolGeneralInfoDTO.setSchoolUserName(generalInfo.getSchoolUserName());
		schoolGeneralInfoDTO.setSchoolUserDegisnation(generalInfo.getSchoolUserDegisnation());
		schoolGeneralInfoDTO.setSchoolUserAddress(generalInfo.getSchoolUserAddress());
		schoolGeneralInfoDTO.setSchoolUserTelephone(generalInfo.getSchoolUserTelephone());

		schoolGeneralInfoDTO.setAccountYear(generalInfo.getAccountYear());
		schoolGeneralInfoDTO.setAccountIncome(generalInfo.getAccountIncome());
		schoolGeneralInfoDTO.setAccountExpense(generalInfo.getAccountExpense());
		schoolGeneralInfoDTO.setAccountBalance(generalInfo.getAccountBalance());

		schoolGeneralInfoDTO.setApplicationId(generalInfo.getApplicationId());
		schoolGeneralInfoDTO.setCreatedAt(generalInfo.getCreatedAt());
		schoolGeneralInfoDTO.setUpdatedAt(generalInfo.getUpdatedAt());

		schoolGeneralInfoDTO.setForWhichYearYouWantToApplyForACertificate(
				generalInfo.getForWhichYearYouWantToApplyForACertificate());
		schoolGeneralInfoDTO.setYearOfFoundationzOfSchool(generalInfo.getYearOfFoundationzOfSchool());
		schoolGeneralInfoDTO.setDateOfFirstOpeningOfSchool(generalInfo.getDateOfFirstOpeningOfSchool());

		schoolGeneralInfoDTO.setLowerStandard(generalInfo.getLowerStandard());
		schoolGeneralInfoDTO.setHigherStandard(generalInfo.getHigherStandard());
		schoolGeneralInfoDTO.setSchoolArea(generalInfo.getSchoolArea());
		schoolGeneralInfoDTO.setMediumOfInstruction(generalInfo.getMediumOfInstruction());
		schoolGeneralInfoDTO.setSchoolBoard(generalInfo.getSchoolBoard());

		schoolGeneralInfoDTO.setSangsthaCompanyName(generalInfo.getSangsthaCompanyName());
		schoolGeneralInfoDTO.setSansthaCompanyHasPurposeForOnlyEducationService(
				generalInfo.getSansthaCompanyHasPurposeForOnlyEducationService());
		schoolGeneralInfoDTO.setIsSchoolOpenWhereAddressMentionedInApproval(
				generalInfo.getIsSchoolOpenWhereAddressMentionedInApproval());
		schoolGeneralInfoDTO.setIfSansthaIsHandoverToSomeone(generalInfo.getIfSansthaIsHandoverToSomeone());

		schoolGeneralInfoDTO
				.setDoYouHaveMaharastraShashanManyataNo(generalInfo.getDoYouHaveMaharastraShashanManyataNo());
		schoolGeneralInfoDTO.setMaharastraShashanApprovalNumber(generalInfo.getMaharastraShashanApprovalNumber());
		schoolGeneralInfoDTO.setMaharastraShashanApprovalDate(generalInfo.getMaharastraShashanApprovalDate());

		schoolGeneralInfoDTO
				.setDoYouHaveShikshanUpsanchalakApproval(generalInfo.getDoYouHaveShikshanUpsanchalakApproval());
		schoolGeneralInfoDTO.setShikshanUpsanchalakApprovalDate(generalInfo.getShikshanUpsanchalakApprovalDate());
		schoolGeneralInfoDTO.setShikshanUpsanchalakApprovalNumber(generalInfo.getShikshanUpsanchalakApprovalNumber());

		schoolGeneralInfoDTO.setDoYouHavePrathamManyataCertificate(generalInfo.getDoYouHavePrathamManyataCertificate());
		schoolGeneralInfoDTO.setPrathamManyataNumber(generalInfo.getPrathamManyataNumber());
		schoolGeneralInfoDTO.setPrathamManyataDate(generalInfo.getPrathamManyataDate());

		schoolGeneralInfoDTO.setDoYouRunOnGovernmentNoObjectionCertificate(
				generalInfo.getDoYouRunOnGovernmentNoObjectionCertificate());
		schoolGeneralInfoDTO.setNoObjectionCertificateNumber(generalInfo.getNoObjectionCertificateNumber());
		schoolGeneralInfoDTO.setNoObjectionCertificateDate(generalInfo.getNoObjectionCertificateDate());

		schoolGeneralInfoDTO
				.setWhetherSchoolIsMovedToAnotherLocation(generalInfo.getWhetherSchoolIsMovedToAnotherLocation());
		schoolGeneralInfoDTO.setMembers(generalInfo.getMembers());

		schoolGeneralInfoDTO.setSimpleHigherStandard(generalInfo.getSimpleHigherStandard());
		schoolGeneralInfoDTO.setSimpleLowerStandard(generalInfo.getSimpleLowerStandard());
		schoolGeneralInfoDTO.setUdiseLowerStandard(generalInfo.getUdiseLowerStandard());
		schoolGeneralInfoDTO.setUdiseHigherStandard(generalInfo.getUdiseHigherStandard());

		schoolGeneralInfoDTO.setIsThereAnAffiliationCertificate(generalInfo.getIsThereAnAffiliationCertificate());
		schoolGeneralInfoDTO.setAffiliationCertificateNumber(generalInfo.getAffiliationCertificateNumber());
		schoolGeneralInfoDTO.setAffiliationCertificateDate(generalInfo.getAffiliationCertificateDate());

		schoolGeneralInfoDTO.setSection1InspectionApproval(generalInfo.getSection1InspectionApproval());
		schoolGeneralInfoDTO.setSection2InspectionApproval(generalInfo.getSection2InspectionApproval());
		schoolGeneralInfoDTO.setSection3InspectionApproval(generalInfo.getSection3InspectionApproval());

		schoolGeneralInfoDTO.setSection1InspectionComment(generalInfo.getSection1InspectionComment());
		schoolGeneralInfoDTO.setSection2InspectionComment(generalInfo.getSection2InspectionComment());
		schoolGeneralInfoDTO.setSection3InspectionComment(generalInfo.getSection3InspectionComment());

        return schoolGeneralInfoDTO;
    }

    private BhauticSuvidhaDTO mapPhysicalDetails(OldDetailOfPhysical detailsOfPhysical) {
		BhauticSuvidhaDTO bhauticSuvidhaDTO = new BhauticSuvidhaDTO();

		bhauticSuvidhaDTO.setId(detailsOfPhysical.getId());
		bhauticSuvidhaDTO
				.setSchoolId(detailsOfPhysical.getSchool() != null ? detailsOfPhysical.getSchool().getId() : null);

		bhauticSuvidhaDTO.setClassroom(detailsOfPhysical.getClassroom());
		bhauticSuvidhaDTO.setOfficeRoom(detailsOfPhysical.getOfficeRoom());
		bhauticSuvidhaDTO.setKitchen(detailsOfPhysical.getKitchen());
		bhauticSuvidhaDTO.setSeparateToiletsForBoysAndGirls(detailsOfPhysical.getSeparateToiletsForBoysAndGirls());
		bhauticSuvidhaDTO.setDrinkingWaterFacility(detailsOfPhysical.getDrinkingWaterFacility());

		bhauticSuvidhaDTO.setCreatedAt(detailsOfPhysical.getCreatedAt());
		bhauticSuvidhaDTO.setUpdatedAt(detailsOfPhysical.getUpdatedAt());
		bhauticSuvidhaDTO.setApplicationId(detailsOfPhysical.getApplicationId());

		bhauticSuvidhaDTO
				.setWhetherSchoolIsMovedToAnotherLocation(detailsOfPhysical.getWhetherSchoolIsMovedToAnotherLocation());
		bhauticSuvidhaDTO.setTypeOfProofAvailableAndItsDate(detailsOfPhysical.getTypeOfProofAvailableAndItsDate());
		bhauticSuvidhaDTO.setForYouTakePropertyDocumentType(detailsOfPhysical.getForYouTakePropertyDocumentType());

		bhauticSuvidhaDTO.setAreaSqM(detailsOfPhysical.getAreaSqM());
		bhauticSuvidhaDTO.setTotalAreaSqM(detailsOfPhysical.getTotalAreaSqM());
		bhauticSuvidhaDTO.setSchoolTotalAreaSqM(detailsOfPhysical.getSchoolTotalAreaSqM());

		bhauticSuvidhaDTO.setPrincipalCount(detailsOfPhysical.getPrincipalCount());
		bhauticSuvidhaDTO.setPrincipalArea(detailsOfPhysical.getPrincipalArea());
		bhauticSuvidhaDTO.setOfficeCount(detailsOfPhysical.getOfficeCount());
		bhauticSuvidhaDTO.setOfficeArea(detailsOfPhysical.getOfficeArea());
		bhauticSuvidhaDTO.setStaffCount(detailsOfPhysical.getStaffCount());
		bhauticSuvidhaDTO.setStaffArea(detailsOfPhysical.getStaffArea());
		bhauticSuvidhaDTO.setStorageCount(detailsOfPhysical.getStorageCount());
		bhauticSuvidhaDTO.setStorageArea(detailsOfPhysical.getStorageArea());
		bhauticSuvidhaDTO.setClassroomCount(detailsOfPhysical.getClassroomCount());
		bhauticSuvidhaDTO.setClassroomArea(detailsOfPhysical.getClassroomArea());
		bhauticSuvidhaDTO.setLabCount(detailsOfPhysical.getLabCount());
		bhauticSuvidhaDTO.setLabArea(detailsOfPhysical.getLabArea());
		bhauticSuvidhaDTO.setCompCount(detailsOfPhysical.getCompCount());
		bhauticSuvidhaDTO.setCompArea(detailsOfPhysical.getCompArea());
		bhauticSuvidhaDTO.setLibraryCount(detailsOfPhysical.getLibraryCount());
		bhauticSuvidhaDTO.setLibraryArea(detailsOfPhysical.getLibraryArea());

		bhauticSuvidhaDTO.setSchoolTotalCount(detailsOfPhysical.getSchoolTotalCount());
		bhauticSuvidhaDTO.setSchoolTotalArea(detailsOfPhysical.getSchoolTotalArea());
		bhauticSuvidhaDTO.setWesternToiletCount(detailsOfPhysical.getWesternToiletCount());
		bhauticSuvidhaDTO.setToiletAvailableFacilityDetails(detailsOfPhysical.getToiletAvailableFacilityDetails());

		// Note: The entity doesn't have boys toilet fields, only girls
		bhauticSuvidhaDTO.setSeperateGirlsToiletCount(detailsOfPhysical.getSeperateGirlsToiletCount());
		bhauticSuvidhaDTO
				.setSeperateGirlsToiletFacilityDetails(detailsOfPhysical.getSeperateGirlsToiletFacilityDetails());
		bhauticSuvidhaDTO.setSeperateGirlsWashroomCount(detailsOfPhysical.getSeperateGirlsWashroomCount());
		bhauticSuvidhaDTO
				.setSeperateGirlsWashroomFacilityDetails(detailsOfPhysical.getSeperateGirlsWashroomFacilityDetails());
		bhauticSuvidhaDTO.setSeperateGirlsDrinkingWaterCount(detailsOfPhysical.getSeperateGirlsDrinkingWaterCount());
		bhauticSuvidhaDTO
				.setSeperateGirlsDrinkingWaterFacilityDetails(detailsOfPhysical.getGirlsDrinkingWaterFacilityDetails());

		bhauticSuvidhaDTO.setRampRoad(detailsOfPhysical.getRampRoad());
		bhauticSuvidhaDTO.setRocksOnTheSideOfTheRamp(detailsOfPhysical.getRocksOnTheSideOfTheRamp());
		bhauticSuvidhaDTO.setRampFacilityDetails(detailsOfPhysical.getRampFacilityDetails());

		bhauticSuvidhaDTO.setRoomNumber(detailsOfPhysical.getRoomNumber());
		bhauticSuvidhaDTO.setTheRoofIsSolidRcc(detailsOfPhysical.getTheRoofIsSolidRcc());
		bhauticSuvidhaDTO.setFireWarrantyCylinderNo(detailsOfPhysical.getFireWarrantyCylinderNo());
		bhauticSuvidhaDTO.setMedicalPrimaryBoxNumber(detailsOfPhysical.getMedicalPrimaryBoxNumber());
		bhauticSuvidhaDTO.setCctvNo(detailsOfPhysical.getCctvNo());
		bhauticSuvidhaDTO
				.setPlaquesInFacadesOfSchoolRecognition(detailsOfPhysical.getPlaquesInFacadesOfSchoolRecognition());
		bhauticSuvidhaDTO.setaRampForBarrierFreeAccess(detailsOfPhysical.getARampForBarrierFreeAccess());

		bhauticSuvidhaDTO.setAreaOfPlayground(detailsOfPhysical.getAreaOfPlayground());
		bhauticSuvidhaDTO.setAreaOfPlaygroundDetails(detailsOfPhysical.getAreaOfPlaygroundDetails());
		bhauticSuvidhaDTO.setRetainingWallCompound(detailsOfPhysical.getRetainingWallCompound());
		bhauticSuvidhaDTO
				.setEntranceWithProtectiveWallAndIronGate(detailsOfPhysical.getEntranceWithProtectiveWallAndIronGate());

		bhauticSuvidhaDTO.setKitchenShed(detailsOfPhysical.getKitchenShed());
		bhauticSuvidhaDTO.setKitchenShedDetails(detailsOfPhysical.getKitchenShedDetails());
		bhauticSuvidhaDTO.setWaterTapCount(detailsOfPhysical.getWaterTapCount());
		bhauticSuvidhaDTO.setWaterTankCapacity(detailsOfPhysical.getWaterTankCapacity());
		bhauticSuvidhaDTO
				.setActualAvailableFacilityDetailsTap(detailsOfPhysical.getActualAvailableFacilityDetailsTap());
		bhauticSuvidhaDTO
				.setActualAvailableFacilityDetailsWater(detailsOfPhysical.getActualAvailableFacilityDetailsWater());

		bhauticSuvidhaDTO.setSection1InspectionApproval(detailsOfPhysical.getSection1InspectionApproval());
		bhauticSuvidhaDTO.setSection2InspectionApproval(detailsOfPhysical.getSection2InspectionApproval());
		bhauticSuvidhaDTO.setSection3InspectionApproval(detailsOfPhysical.getSection3InspectionApproval());
		bhauticSuvidhaDTO.setSection4InspectionApproval(detailsOfPhysical.getSection4InspectionApproval());
		bhauticSuvidhaDTO.setSection5InspectionApproval(detailsOfPhysical.getSection5InspectionApproval());
		bhauticSuvidhaDTO.setSection6InspectionApproval(detailsOfPhysical.getSection6InspectionApproval());

		bhauticSuvidhaDTO.setSection1InspectionComment(detailsOfPhysical.getSection1InspectionComment());
		bhauticSuvidhaDTO.setSection2InspectionComment(detailsOfPhysical.getSection2InspectionComment());
		bhauticSuvidhaDTO.setSection3InspectionComment(detailsOfPhysical.getSection3InspectionComment());
		bhauticSuvidhaDTO.setSection4InspectionComment(detailsOfPhysical.getSection4InspectionComment());
		bhauticSuvidhaDTO.setSection5InspectionComment(detailsOfPhysical.getSection5InspectionComment());
		bhauticSuvidhaDTO.setSection6InspectionComment(detailsOfPhysical.getSection6InspectionComment());
        return bhauticSuvidhaDTO;
    }

    private OtherFacilityDTO mapOtherFacility(OldOtherFacility oldOtherFacility) {
		OtherFacilityDTO otherFacilityDTO = new OtherFacilityDTO();

		otherFacilityDTO.setId(oldOtherFacility.getId());
		otherFacilityDTO
				.setSchoolId(oldOtherFacility.getSchool() != null ? oldOtherFacility.getSchool().getId() : null);
		otherFacilityDTO.setAreAllFacilitiesAccessibleWithoutHindrance(
				oldOtherFacility.getAreAllFacilitiesAccessibleWithoutHindrance());
		otherFacilityDTO.setStudyTeachingMaterials(oldOtherFacility.getStudyTeachingMaterials());
		otherFacilityDTO.setSportsAndSportsEquipment(oldOtherFacility.getSportsAndSportsEquipment());
		otherFacilityDTO.setLibraryBookFacilityBooks(oldOtherFacility.getLibraryBookFacilityBooks());
		otherFacilityDTO.setTypeAndNumberOfDrinkingWaterFacilities(
				oldOtherFacility.getTypeAndNumberOfDrinkingWaterFacilities());
		otherFacilityDTO.setSanitaryCondition(oldOtherFacility.getSanitaryCondition());
		otherFacilityDTO.setTypeOfToilets(oldOtherFacility.getTypeOfToilets());
		otherFacilityDTO.setNumberOfSeparateToiletFacilitiesForBoys(
				oldOtherFacility.getNumberOfSeparateToiletFacilitiesForBoys());
		otherFacilityDTO.setNumberOfSeparateToiletFacilitiesForGirls(
				oldOtherFacility.getNumberOfSeparateToiletFacilitiesForGirls());
		otherFacilityDTO.setDivisionWiseInformation(oldOtherFacility.getDivisionWiseInformation());
		otherFacilityDTO.setStudentPerformanceMethod(oldOtherFacility.getStudentPerformanceMethod());
		otherFacilityDTO
				.setIsSchoolPressureToGiveThirdPartyExam(oldOtherFacility.getIsSchoolPressureToGiveThirdPartyExam());
		otherFacilityDTO.setCreatedAt(oldOtherFacility.getCreatedAt());
		otherFacilityDTO.setUpdatedAt(oldOtherFacility.getUpdatedAt());
		otherFacilityDTO.setApplicationId(oldOtherFacility.getApplicationId());
		otherFacilityDTO.setMinimum200DaysOf800ClockHoursForPrimaryAndHigher(
				oldOtherFacility.getMinimum200DaysOf800ClockHoursForPrimaryAndHigher());
		otherFacilityDTO.setNumberOfBooksAvailableForStudentReadingInTheLibrary(
				oldOtherFacility.getNumberOfBooksAvailableForStudentReadingInTheLibrary());
		otherFacilityDTO.setNumberOfSportsAndSportsLiterature(oldOtherFacility.getNumberOfSportsAndSportsLiterature());
		otherFacilityDTO.setNumberOfReferenceBooksAvailableForTeacherTraining(
				oldOtherFacility.getNumberOfReferenceBooksAvailableForTeacherTraining());
		otherFacilityDTO.setHoursOfTeachingPerWeek(oldOtherFacility.getHoursOfTeachingPerWeek());
		otherFacilityDTO.setSufficientEducationalMaterialInEachClassAsRequired(
				oldOtherFacility.getSufficientEducationalMaterialInEachClassAsRequired());
		otherFacilityDTO.setMagzinBooksCount(oldOtherFacility.getMagzinBooksCount());
		otherFacilityDTO.setNewspaperAndTotalCount(oldOtherFacility.getNewspaperAndTotalCount());
		otherFacilityDTO.setInspectionApproval(oldOtherFacility.getInspectionApproval());
		otherFacilityDTO.setInspectionComment(oldOtherFacility.getInspectionComment());
        return otherFacilityDTO;
    }
}
