package com.emanyata.app.repo.primary;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.emanyata.app.entity.primary.GrantedSchoolInfo;

import java.util.Optional;

@Repository
public interface GrantedSchoolInfoRepository extends JpaRepository<GrantedSchoolInfo, Long> {
    Optional<GrantedSchoolInfo> findBySchoolId(Long schoolId);
}