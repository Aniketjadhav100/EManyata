package com.emanyata.app.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import jakarta.annotation.PostConstruct;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class ExcelFileUploadUtil {
	
	private static final Logger logger = LoggerFactory.getLogger(ExcelFileUploadUtil.class);
    
    @Value("${file.upload-dir}")
    private String uploadDir;
    
    @PostConstruct
    public void init() {
        try {
            // Create the upload directory structure
            Path uploadPath = Paths.get(uploadDir, "udiseexcel");
            Files.createDirectories(uploadPath);
            logger.info("Upload directories created: {}", uploadPath);
        } catch (IOException e) {
            logger.error("Error creating upload directories: {}", e.getMessage());
        }
    }

    public String saveFile(MultipartFile file, String subDirectory) throws IOException {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("File cannot be null or empty");
        }

        // Create upload directory if it doesn't exist
        Path uploadPath = Paths.get(uploadDir, subDirectory);
        Files.createDirectories(uploadPath);

        // Get original filename
        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null || originalFilename.isEmpty()) {
            throw new IllegalArgumentException("File must have a name");
        }

        // Clean the filename to remove any unsafe characters
        String cleanFilename = originalFilename.replaceAll("[^a-zA-Z0-9._-]", "_");
        
        // Create the full path
        Path filePath = uploadPath.resolve(cleanFilename);

        // Save the file
        Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

        // Return relative path with full upload directory
        return Paths.get(uploadDir, subDirectory, cleanFilename).toString();
    }

    public void deleteFile(String filePath) {
        try {
            Files.deleteIfExists(Paths.get(filePath));
        } catch (IOException e) {
            // Log the error but continue
            System.err.println("Error deleting file: " + e.getMessage());
        }
    }
}