package com.emanyata.app.repo.secondary;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.emanyata.app.entity.secondary.OldStudentCount;

@Repository
public interface OldStudentCountRepository extends JpaRepository<OldStudentCount, Long> {
    List<OldStudentCount> findBySchoolId(Long schoolId);
    Optional<OldStudentCount> findByApplicationId(Long applicationId);
}
