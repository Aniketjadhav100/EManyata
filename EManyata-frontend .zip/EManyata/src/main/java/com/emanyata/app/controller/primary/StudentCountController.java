package com.emanyata.app.controller.primary;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.emanyata.app.dto.StudentCountDTO;
import com.emanyata.app.service.primary.StudentCountService;

@RestController
@RequestMapping("/api/student-counts")
public class StudentCountController {

    @Autowired
    private StudentCountService studentCountService;

    @PostMapping("/add")
    public ResponseEntity<Map<String, Object>> addStudentCount(@RequestBody StudentCountDTO dto) {
        Map<String, Object> response = new HashMap<>();
        try {
            StudentCountDTO savedStudentCount = studentCountService.createStudentCount(dto);
            response.put("status", "success");
            response.put("message", "Record created successfully.");
            response.put("data", savedStudentCount);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", "Failed to create record: " + e.getMessage());
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/school/{schoolId}")
    public ResponseEntity<Map<String, Object>> getBySchoolId(@PathVariable Long schoolId) {
        Map<String, Object> response = new HashMap<>();
        try {
            StudentCountDTO studentCounts = studentCountService.getStudentCountBySchoolId(schoolId);
            if (studentCounts == null) {
                throw new NoSuchElementException("No record found for School Id " + schoolId);
            }
            response.put("status", "success");
            response.put("message", "Record fetched successfully.");
            response.put("data", studentCounts);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", "Error fetching record: " + e.getMessage());
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }
}
