package com.emanyata.app.dto;

public class EmailMobileDTO {

	private String emailOrMobile;

	public String getEmailOrMobile() {
		return emailOrMobile;
	}

	public void setEmailOrMobile(String emailOrMobile) {
		this.emailOrMobile = emailOrMobile;
	}
	
}
