package com.emanyata.app.controller.primary;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emanyata.app.dto.pendingApplicationDTO;
import com.emanyata.app.service.primary.pendingApplicationService;

@RestController
@RequestMapping("/users/api")
@CrossOrigin(origins = "http://localhost:3000")
public class pendingApplicationController {

    @Autowired
    private pendingApplicationService ser;

    // GET all finalized applications
    @PostMapping("/pending-applications")
    public List<pendingApplicationDTO> getAllFinalizedApplications() {
        return ser.getAllPendingApplications();
    }
}