package com.emanyata.app.entity.primary;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "detail_of_physicals")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class BhauticSuvidha {
    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

//    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "school_id", nullable = false)
    private School school;

   
    @Column(name = "classroom")
    private String classroom;

   
    @Column(name = "office_room")
    private String officeRoom;

   
    @Column(name = "kitchen")
    private String kitchen;

   
    @Column(name = "separate_toilets_for_boys_and_girls")
    private String separateToiletsForBoysAndGirls;

   
    @Column(name = "drinking_water_facility")
    private String drinkingWaterFacility;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "application_id")
    private Long applicationId;

    @Size(max = 255)
    @Column(name = "whether_school_is_moved_to_another_location")
    private String whetherSchoolIsMovedToAnotherLocation;

    @Size(max = 255)
    @Column(name = "type_of_proof_available_and_its_date")
    private String typeOfProofAvailableAndItsDate;

    @Size(max = 255)
    @Column(name = "for_you_take_property_document_type")
    private String forYouTakePropertyDocumentType;

    @Size(max = 255)
    @Column(name = "area_sq_m")
    private String areaSqM;

    @Size(max = 255)
    @Column(name = "total_area_sq_m")
    private String totalAreaSqM;

    @Size(max = 255)
    @Column(name = "school_total_area_sq_m")
    private String schoolTotalAreaSqM;

    @Size(max = 255)
    @Column(name = "principal_count")
    private String principalCount;

    @Size(max = 255)
    @Column(name = "principal_area")
    private String principalArea;

    @Size(max = 255)
    @Column(name = "office_count")
    private String officeCount;

    @Size(max = 255)
    @Column(name = "office_area")
    private String officeArea;

    @Size(max = 255)
    @Column(name = "staff_count")
    private String staffCount;

    @Size(max = 255)
    @Column(name = "staff_area")
    private String staffArea;

    @Size(max = 255)
    @Column(name = "storage_count")
    private String storageCount;

    @Size(max = 255)
    @Column(name = "storage_area")
    private String storageArea;

    @Size(max = 255)
    @Column(name = "classroom_count")
    private String classroomCount;

    @Size(max = 255)
    @Column(name = "classroom_area")
    private String classroomArea;

    @Size(max = 255)
    @Column(name = "lab_count")
    private String labCount;

    @Size(max = 255)
    @Column(name = "lab_area")
    private String labArea;

    @Size(max = 255)
    @Column(name = "comp_count")
    private String compCount;

    @Size(max = 255)
    @Column(name = "comp_area")
    private String compArea;

    @Size(max = 255)
    @Column(name = "library_count")
    private String libraryCount;

    @Size(max = 255)
    @Column(name = "library_area")
    private String libraryArea;

    @Size(max = 255)
    @Column(name = "school_total_count")
    private String schoolTotalCount;

    @Size(max = 255)
    @Column(name = "school_total_area")
    private String schoolTotalArea;

    @Size(max = 255)
    @Column(name = "western_toilet_count")
    private String westernToiletCount;

    @Size(max = 255)
    @Column(name = "toilet_available_facility_details")
    private String toiletAvailableFacilityDetails;

    @Size(max = 255)
    @Column(name = "seperate_boys_toilet_count")
    private String seperateBoysToiletCount;

    @Size(max = 255)
    @Column(name = "seperate_boys_toilet_facility_details")
    private String seperateBoysToiletFacilityDetails;

    @Size(max = 255)
    @Column(name = "seperate_boys_washroom_count")
    private String seperateBoysWashroomCount;

    @Size(max = 255)
    @Column(name = "seperate_boys_washroom_facility_details")
    private String seperateBoysWashroomFacilityDetails;

    @Size(max = 255)
    @Column(name = "seperate_boys_drinking_water_count")
    private String seperateBoysDrinkingWaterCount;

    @Size(max = 100)
    @Column(name = "seperate_boys_drinking_water_facility_details", length = 100)
    private String seperateBoysDrinkingWaterFacilityDetails;

    @Size(max = 255)
    @Column(name = "seperate_girls_toilet_count")
    private String seperateGirlsToiletCount;

    @Size(max = 255)
    @Column(name = "seperate_girls_toilet_facility_details")
    private String seperateGirlsToiletFacilityDetails;

    @Size(max = 255)
    @Column(name = "seperate_girls_washroom_count")
    private String seperateGirlsWashroomCount;

    @Size(max = 255)
    @Column(name = "seperate_girls_washroom_facility_details")
    private String seperateGirlsWashroomFacilityDetails;

    @Size(max = 255)
    @Column(name = "seperate_girls_drinking_water_count")
    private String seperateGirlsDrinkingWaterCount;

    @Size(max = 100)
    @Column(name = "seperate_girls_drinking_water_facility_details", length = 100)
    private String seperateGirlsDrinkingWaterFacilityDetails;

    @Size(max = 100)
    @Column(name = "ramp_road", length = 100)
    private String rampRoad;

    @Size(max = 100)
    @Column(name = "rocks_on_the_side_of_the_ramp", length = 100)
    private String rocksOnTheSideOfTheRamp;

    @Size(max = 100)
    @Column(name = "ramp_facility_details", length = 100)
    private String rampFacilityDetails;

    @Size(max = 100)
    @Column(name = "room_number", length = 100)
    private String roomNumber;

    @Size(max = 100)
    @Column(name = "the_roof_is_solid_rcc", length = 100)
    private String theRoofIsSolidRcc;

    @Size(max = 100)
    @Column(name = "fire_warranty_cylinder_no", length = 100)
    private String fireWarrantyCylinderNo;

    @Size(max = 100)
    @Column(name = "medical_primary_box_number", length = 100)
    private String medicalPrimaryBoxNumber;

    @Size(max = 100)
    @Column(name = "cctv_no", length = 100)
    private String cctvNo;

    @Size(max = 100)
    @Column(name = "plaques_in_facades_of_school_recognition", length = 100)
    private String plaquesInFacadesOfSchoolRecognition;

    @Size(max = 100)
    @Column(name = "a_ramp_for_barrier_free_access", length = 100)
    private String aRampForBarrierFreeAccess;

    @Size(max = 100)
    @Column(name = "area_of_playground", length = 100)
    private String areaOfPlayground;

    @Size(max = 100)
    @Column(name = "area_of_playground_details", length = 100)
    private String areaOfPlaygroundDetails;

    @Size(max = 100)
    @Column(name = "retaining_wall_compound", length = 100)
    private String retainingWallCompound;

    @Size(max = 100)
    @Column(name = "entrance_with_protective_wall_and_iron_gate", length = 100)
    private String entranceWithProtectiveWallAndIronGate;

    @Size(max = 100)
    @Column(name = "kitchen_shed", length = 100)
    private String kitchenShed;

    @Size(max = 100)
    @Column(name = "kitchen_shed_details", length = 100)
    private String kitchenShedDetails;

    @Size(max = 100)
    @Column(name = "water_tap_count", length = 100)
    private String waterTapCount;

    @Size(max = 100)
    @Column(name = "water_tank_capacity", length = 100)
    private String waterTankCapacity;

    @Size(max = 100)
    @Column(name = "actual_available_facility_details_tap", length = 100)
    private String actualAvailableFacilityDetailsTap;

    @Size(max = 100)
    @Column(name = "actual_available_facility_details_water", length = 100)
    private String actualAvailableFacilityDetailsWater;

    @Size(max = 50)
    @Column(name = "section1_inspection_approval", length = 50)
    private String section1InspectionApproval;

    @Size(max = 50)
    @Column(name = "section2_inspection_approval", length = 50)
    private String section2InspectionApproval;

    @Size(max = 50)
    @Column(name = "section3_inspection_approval", length = 50)
    private String section3InspectionApproval;

    @Size(max = 50)
    @Column(name = "section4_inspection_approval", length = 50)
    private String section4InspectionApproval;

    @Size(max = 50)
    @Column(name = "section5_inspection_approval", length = 50)
    private String section5InspectionApproval;

    @Size(max = 50)
    @Column(name = "section6_inspection_approval", length = 50)
    private String section6InspectionApproval;

    @Size(max = 255)
    @Column(name = "section1_inspection_comment")
    private String section1InspectionComment;

    @Size(max = 255)
    @Column(name = "section2_inspection_comment")
    private String section2InspectionComment;

    @Size(max = 255)
    @Column(name = "section3_inspection_comment")
    private String section3InspectionComment;

    @Size(max = 255)
    @Column(name = "section4_inspection_comment")
    private String section4InspectionComment;

    @Size(max = 255)
    @Column(name = "section5_inspection_comment")
    private String section5InspectionComment;

    @Size(max = 255)
    @Column(name = "section6_inspection_comment")
    private String section6InspectionComment;
    
    @Column(name="status")
    private Byte status;

    public Byte getStatus() {
		return status;
	}

	public void setStatus(Byte status) {
		this.status = status;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public School getSchool() {
        return school;
    }

    public void setSchool(School school) {
        this.school = school;
    }

    public String getClassroom() {
        return classroom;
    }

    public void setClassroom(String classroom) {
        this.classroom = classroom;
    }

    public String getOfficeRoom() {
        return officeRoom;
    }

    public void setOfficeRoom(String officeRoom) {
        this.officeRoom = officeRoom;
    }

    public String getKitchen() {
        return kitchen;
    }

    public void setKitchen(String kitchen) {
        this.kitchen = kitchen;
    }

    public String getSeparateToiletsForBoysAndGirls() {
        return separateToiletsForBoysAndGirls;
    }

    public void setSeparateToiletsForBoysAndGirls(String separateToiletsForBoysAndGirls) {
        this.separateToiletsForBoysAndGirls = separateToiletsForBoysAndGirls;
    }

    public String getDrinkingWaterFacility() {
        return drinkingWaterFacility;
    }

    public void setDrinkingWaterFacility(String drinkingWaterFacility) {
        this.drinkingWaterFacility = drinkingWaterFacility;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long applicationId) {
        this.applicationId = applicationId;
    }

    public String getWhetherSchoolIsMovedToAnotherLocation() {
        return whetherSchoolIsMovedToAnotherLocation;
    }

    public void setWhetherSchoolIsMovedToAnotherLocation(String whetherSchoolIsMovedToAnotherLocation) {
        this.whetherSchoolIsMovedToAnotherLocation = whetherSchoolIsMovedToAnotherLocation;
    }

    public String getTypeOfProofAvailableAndItsDate() {
        return typeOfProofAvailableAndItsDate;
    }

    public void setTypeOfProofAvailableAndItsDate(String typeOfProofAvailableAndItsDate) {
        this.typeOfProofAvailableAndItsDate = typeOfProofAvailableAndItsDate;
    }

    public String getForYouTakePropertyDocumentType() {
        return forYouTakePropertyDocumentType;
    }

    public void setForYouTakePropertyDocumentType(String forYouTakePropertyDocumentType) {
        this.forYouTakePropertyDocumentType = forYouTakePropertyDocumentType;
    }

    public String getAreaSqM() {
        return areaSqM;
    }

    public void setAreaSqM(String areaSqM) {
        this.areaSqM = areaSqM;
    }

    public String getTotalAreaSqM() {
        return totalAreaSqM;
    }

    public void setTotalAreaSqM(String totalAreaSqM) {
        this.totalAreaSqM = totalAreaSqM;
    }

    public String getSchoolTotalAreaSqM() {
        return schoolTotalAreaSqM;
    }

    public void setSchoolTotalAreaSqM(String schoolTotalAreaSqM) {
        this.schoolTotalAreaSqM = schoolTotalAreaSqM;
    }

    public String getPrincipalCount() {
        return principalCount;
    }

    public void setPrincipalCount(String principalCount) {
        this.principalCount = principalCount;
    }

    public String getPrincipalArea() {
        return principalArea;
    }

    public void setPrincipalArea(String principalArea) {
        this.principalArea = principalArea;
    }

    public String getOfficeCount() {
        return officeCount;
    }

    public void setOfficeCount(String officeCount) {
        this.officeCount = officeCount;
    }

    public String getOfficeArea() {
        return officeArea;
    }

    public void setOfficeArea(String officeArea) {
        this.officeArea = officeArea;
    }

    public String getStaffCount() {
        return staffCount;
    }

    public void setStaffCount(String staffCount) {
        this.staffCount = staffCount;
    }

    public String getStaffArea() {
        return staffArea;
    }

    public void setStaffArea(String staffArea) {
        this.staffArea = staffArea;
    }

    public String getStorageCount() {
        return storageCount;
    }

    public void setStorageCount(String storageCount) {
        this.storageCount = storageCount;
    }

    public String getStorageArea() {
        return storageArea;
    }

    public void setStorageArea(String storageArea) {
        this.storageArea = storageArea;
    }

    public String getClassroomCount() {
        return classroomCount;
    }

    public void setClassroomCount(String classroomCount) {
        this.classroomCount = classroomCount;
    }

    public String getClassroomArea() {
        return classroomArea;
    }

    public void setClassroomArea(String classroomArea) {
        this.classroomArea = classroomArea;
    }

    public String getLabCount() {
        return labCount;
    }

    public void setLabCount(String labCount) {
        this.labCount = labCount;
    }

    public String getLabArea() {
        return labArea;
    }

    public void setLabArea(String labArea) {
        this.labArea = labArea;
    }

    public String getCompCount() {
        return compCount;
    }

    public void setCompCount(String compCount) {
        this.compCount = compCount;
    }

    public String getCompArea() {
        return compArea;
    }

    public void setCompArea(String compArea) {
        this.compArea = compArea;
    }

    public String getLibraryCount() {
        return libraryCount;
    }

    public void setLibraryCount(String libraryCount) {
        this.libraryCount = libraryCount;
    }

    public String getLibraryArea() {
        return libraryArea;
    }

    public void setLibraryArea(String libraryArea) {
        this.libraryArea = libraryArea;
    }

    public String getSchoolTotalCount() {
        return schoolTotalCount;
    }

    public void setSchoolTotalCount(String schoolTotalCount) {
        this.schoolTotalCount = schoolTotalCount;
    }

    public String getSchoolTotalArea() {
        return schoolTotalArea;
    }

    public void setSchoolTotalArea(String schoolTotalArea) {
        this.schoolTotalArea = schoolTotalArea;
    }

    public String getWesternToiletCount() {
        return westernToiletCount;
    }

    public void setWesternToiletCount(String westernToiletCount) {
        this.westernToiletCount = westernToiletCount;
    }

    public String getToiletAvailableFacilityDetails() {
        return toiletAvailableFacilityDetails;
    }

    public void setToiletAvailableFacilityDetails(String toiletAvailableFacilityDetails) {
        this.toiletAvailableFacilityDetails = toiletAvailableFacilityDetails;
    }

   
    
    public String getSeperateBoysToiletCount() {
		return seperateBoysToiletCount;
	}

	public void setSeperateBoysToiletCount(String seperateBoysToiletCount) {
		this.seperateBoysToiletCount = seperateBoysToiletCount;
	}

	public String getSeperateBoysToiletFacilityDetails() {
		return seperateBoysToiletFacilityDetails;
	}

	public void setSeperateBoysToiletFacilityDetails(String seperateBoysToiletFacilityDetails) {
		this.seperateBoysToiletFacilityDetails = seperateBoysToiletFacilityDetails;
	}

	public String getSeperateBoysWashroomCount() {
		return seperateBoysWashroomCount;
	}

	public void setSeperateBoysWashroomCount(String seperateBoysWashroomCount) {
		this.seperateBoysWashroomCount = seperateBoysWashroomCount;
	}

	public String getSeperateBoysWashroomFacilityDetails() {
		return seperateBoysWashroomFacilityDetails;
	}

	public void setSeperateBoysWashroomFacilityDetails(String seperateBoysWashroomFacilityDetails) {
		this.seperateBoysWashroomFacilityDetails = seperateBoysWashroomFacilityDetails;
	}

	public String getSeperateBoysDrinkingWaterCount() {
		return seperateBoysDrinkingWaterCount;
	}

	public void setSeperateBoysDrinkingWaterCount(String seperateBoysDrinkingWaterCount) {
		this.seperateBoysDrinkingWaterCount = seperateBoysDrinkingWaterCount;
	}

	public String getSeperateBoysDrinkingWaterFacilityDetails() {
		return seperateBoysDrinkingWaterFacilityDetails;
	}

	public void setSeperateBoysDrinkingWaterFacilityDetails(String seperateBoysDrinkingWaterFacilityDetails) {
		this.seperateBoysDrinkingWaterFacilityDetails = seperateBoysDrinkingWaterFacilityDetails;
	}

	public String getSeperateGirlsDrinkingWaterFacilityDetails() {
		return seperateGirlsDrinkingWaterFacilityDetails;
	}

	public void setSeperateGirlsDrinkingWaterFacilityDetails(String seperateGirlsDrinkingWaterFacilityDetails) {
		this.seperateGirlsDrinkingWaterFacilityDetails = seperateGirlsDrinkingWaterFacilityDetails;
	}

	public String getaRampForBarrierFreeAccess() {
		return aRampForBarrierFreeAccess;
	}

	public void setaRampForBarrierFreeAccess(String aRampForBarrierFreeAccess) {
		this.aRampForBarrierFreeAccess = aRampForBarrierFreeAccess;
	}

	public String getSeperateGirlsToiletCount() {
        return seperateGirlsToiletCount;
    }

    public void setSeperateGirlsToiletCount(String seperateGirlsToiletCount) {
        this.seperateGirlsToiletCount = seperateGirlsToiletCount;
    }

    public String getSeperateGirlsToiletFacilityDetails() {
        return seperateGirlsToiletFacilityDetails;
    }

    public void setSeperateGirlsToiletFacilityDetails(String seperateGirlsToiletFacilityDetails) {
        this.seperateGirlsToiletFacilityDetails = seperateGirlsToiletFacilityDetails;
    }

    public String getSeperateGirlsWashroomCount() {
        return seperateGirlsWashroomCount;
    }

    public void setSeperateGirlsWashroomCount(String seperateGirlsWashroomCount) {
        this.seperateGirlsWashroomCount = seperateGirlsWashroomCount;
    }

    public String getSeperateGirlsWashroomFacilityDetails() {
        return seperateGirlsWashroomFacilityDetails;
    }

    public void setSeperateGirlsWashroomFacilityDetails(String seperateGirlsWashroomFacilityDetails) {
        this.seperateGirlsWashroomFacilityDetails = seperateGirlsWashroomFacilityDetails;
    }

    public String getSeperateGirlsDrinkingWaterCount() {
        return seperateGirlsDrinkingWaterCount;
    }

    public void setSeperateGirlsDrinkingWaterCount(String seperateGirlsDrinkingWaterCount) {
        this.seperateGirlsDrinkingWaterCount = seperateGirlsDrinkingWaterCount;
    }

    public String getRampRoad() {
        return rampRoad;
    }

    public void setRampRoad(String rampRoad) {
        this.rampRoad = rampRoad;
    }

    public String getRocksOnTheSideOfTheRamp() {
        return rocksOnTheSideOfTheRamp;
    }

    public void setRocksOnTheSideOfTheRamp(String rocksOnTheSideOfTheRamp) {
        this.rocksOnTheSideOfTheRamp = rocksOnTheSideOfTheRamp;
    }

    public String getRampFacilityDetails() {
        return rampFacilityDetails;
    }

    public void setRampFacilityDetails(String rampFacilityDetails) {
        this.rampFacilityDetails = rampFacilityDetails;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getTheRoofIsSolidRcc() {
        return theRoofIsSolidRcc;
    }

    public void setTheRoofIsSolidRcc(String theRoofIsSolidRcc) {
        this.theRoofIsSolidRcc = theRoofIsSolidRcc;
    }

    public String getFireWarrantyCylinderNo() {
        return fireWarrantyCylinderNo;
    }

    public void setFireWarrantyCylinderNo(String fireWarrantyCylinderNo) {
        this.fireWarrantyCylinderNo = fireWarrantyCylinderNo;
    }

    public String getMedicalPrimaryBoxNumber() {
        return medicalPrimaryBoxNumber;
    }

    public void setMedicalPrimaryBoxNumber(String medicalPrimaryBoxNumber) {
        this.medicalPrimaryBoxNumber = medicalPrimaryBoxNumber;
    }

    public String getCctvNo() {
        return cctvNo;
    }

    public void setCctvNo(String cctvNo) {
        this.cctvNo = cctvNo;
    }

    public String getPlaquesInFacadesOfSchoolRecognition() {
        return plaquesInFacadesOfSchoolRecognition;
    }

    public void setPlaquesInFacadesOfSchoolRecognition(String plaquesInFacadesOfSchoolRecognition) {
        this.plaquesInFacadesOfSchoolRecognition = plaquesInFacadesOfSchoolRecognition;
    }

    public String getARampForBarrierFreeAccess() {
        return aRampForBarrierFreeAccess;
    }

    public void setARampForBarrierFreeAccess(String aRampForBarrierFreeAccess) {
        this.aRampForBarrierFreeAccess = aRampForBarrierFreeAccess;
    }

    public String getAreaOfPlayground() {
        return areaOfPlayground;
    }

    public void setAreaOfPlayground(String areaOfPlayground) {
        this.areaOfPlayground = areaOfPlayground;
    }

    public String getAreaOfPlaygroundDetails() {
        return areaOfPlaygroundDetails;
    }

    public void setAreaOfPlaygroundDetails(String areaOfPlaygroundDetails) {
        this.areaOfPlaygroundDetails = areaOfPlaygroundDetails;
    }

    public String getRetainingWallCompound() {
        return retainingWallCompound;
    }

    public void setRetainingWallCompound(String retainingWallCompound) {
        this.retainingWallCompound = retainingWallCompound;
    }

    public String getEntranceWithProtectiveWallAndIronGate() {
        return entranceWithProtectiveWallAndIronGate;
    }

    public void setEntranceWithProtectiveWallAndIronGate(String entranceWithProtectiveWallAndIronGate) {
        this.entranceWithProtectiveWallAndIronGate = entranceWithProtectiveWallAndIronGate;
    }

    public String getKitchenShed() {
        return kitchenShed;
    }

    public void setKitchenShed(String kitchenShed) {
        this.kitchenShed = kitchenShed;
    }

    public String getKitchenShedDetails() {
        return kitchenShedDetails;
    }

    public void setKitchenShedDetails(String kitchenShedDetails) {
        this.kitchenShedDetails = kitchenShedDetails;
    }

    public String getWaterTapCount() {
        return waterTapCount;
    }

    public void setWaterTapCount(String waterTapCount) {
        this.waterTapCount = waterTapCount;
    }

    public String getWaterTankCapacity() {
        return waterTankCapacity;
    }

    public void setWaterTankCapacity(String waterTankCapacity) {
        this.waterTankCapacity = waterTankCapacity;
    }

    public String getActualAvailableFacilityDetailsTap() {
        return actualAvailableFacilityDetailsTap;
    }

    public void setActualAvailableFacilityDetailsTap(String actualAvailableFacilityDetailsTap) {
        this.actualAvailableFacilityDetailsTap = actualAvailableFacilityDetailsTap;
    }

    public String getActualAvailableFacilityDetailsWater() {
        return actualAvailableFacilityDetailsWater;
    }

    public void setActualAvailableFacilityDetailsWater(String actualAvailableFacilityDetailsWater) {
        this.actualAvailableFacilityDetailsWater = actualAvailableFacilityDetailsWater;
    }

    public String getSection1InspectionApproval() {
        return section1InspectionApproval;
    }

    public void setSection1InspectionApproval(String section1InspectionApproval) {
        this.section1InspectionApproval = section1InspectionApproval;
    }

    public String getSection2InspectionApproval() {
        return section2InspectionApproval;
    }

    public void setSection2InspectionApproval(String section2InspectionApproval) {
        this.section2InspectionApproval = section2InspectionApproval;
    }

    public String getSection3InspectionApproval() {
        return section3InspectionApproval;
    }

    public void setSection3InspectionApproval(String section3InspectionApproval) {
        this.section3InspectionApproval = section3InspectionApproval;
    }

    public String getSection4InspectionApproval() {
        return section4InspectionApproval;
    }

    public void setSection4InspectionApproval(String section4InspectionApproval) {
        this.section4InspectionApproval = section4InspectionApproval;
    }

    public String getSection5InspectionApproval() {
        return section5InspectionApproval;
    }

    public void setSection5InspectionApproval(String section5InspectionApproval) {
        this.section5InspectionApproval = section5InspectionApproval;
    }

    public String getSection6InspectionApproval() {
        return section6InspectionApproval;
    }

    public void setSection6InspectionApproval(String section6InspectionApproval) {
        this.section6InspectionApproval = section6InspectionApproval;
    }

    public String getSection1InspectionComment() {
        return section1InspectionComment;
    }

    public void setSection1InspectionComment(String section1InspectionComment) {
        this.section1InspectionComment = section1InspectionComment;
    }

    public String getSection2InspectionComment() {
        return section2InspectionComment;
    }

    public void setSection2InspectionComment(String section2InspectionComment) {
        this.section2InspectionComment = section2InspectionComment;
    }

    public String getSection3InspectionComment() {
        return section3InspectionComment;
    }

    public void setSection3InspectionComment(String section3InspectionComment) {
        this.section3InspectionComment = section3InspectionComment;
    }

    public String getSection4InspectionComment() {
        return section4InspectionComment;
    }

    public void setSection4InspectionComment(String section4InspectionComment) {
        this.section4InspectionComment = section4InspectionComment;
    }

    public String getSection5InspectionComment() {
        return section5InspectionComment;
    }

    public void setSection5InspectionComment(String section5InspectionComment) {
        this.section5InspectionComment = section5InspectionComment;
    }

    public String getSection6InspectionComment() {
        return section6InspectionComment;
    }

    public void setSection6InspectionComment(String section6InspectionComment) {
        this.section6InspectionComment = section6InspectionComment;
    }

}
