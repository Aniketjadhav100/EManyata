package com.emanyata.app.repo.primary;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.primary.StudentCount;

public interface StudentCountRepository extends JpaRepository<StudentCount, Long> {
    Optional<StudentCount> findBySchoolId(Long schoolId);

	Object findByApplicationId(Long applicationId);
}