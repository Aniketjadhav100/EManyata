package com.emanyata.app.serviceImpl.primary;

import com.emanyata.app.dto.GrantedSchoolInfoDTO;
import com.emanyata.app.dto.NonGrantedSchoolInfoDTO;
import com.emanyata.app.entity.primary.ApplicationsResult;
import com.emanyata.app.entity.primary.NonGrantedSchoolInfo;
import com.emanyata.app.entity.primary.School;
import com.emanyata.app.entity.primary.SchoolApply;
import com.emanyata.app.entity.primary.SchoolGeneralInfo;
import com.emanyata.app.repo.primary.ApplicationResultRepo;
import com.emanyata.app.repo.primary.NonGrantedSchoolInfoRepo;
import com.emanyata.app.repo.primary.SchoolApplyRepo;
import com.emanyata.app.repo.primary.SchoolRepo;
import com.emanyata.app.service.primary.NonGrantedSchoolInfoService;
import com.emanyata.app.util.ApplicationFormStepsUtil;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.PathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class NonGrantedSchoolInfoServiceImpl implements NonGrantedSchoolInfoService {

    @Autowired
    private NonGrantedSchoolInfoRepo repository;
    
	@Autowired
	private SchoolApplyRepo applyRepo;
	
	@Autowired
	private SchoolRepo schoolRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private ApplicationFormStepsUtil stepsUtil;
	
	@Autowired
	private ApplicationResultRepo applicationResultRepo;

    @Override
    public NonGrantedSchoolInfoDTO saveOrUpdate(NonGrantedSchoolInfoDTO dto) {
        Optional<NonGrantedSchoolInfo> optional = repository.findBySchoolId(dto.getSchoolId());
        NonGrantedSchoolInfo info = optional.orElse(new NonGrantedSchoolInfo());
        Optional<SchoolApply> applyOpt=applyRepo.findById(dto.getApplicationId());
        
        if(dto.getSchoolId()!=null && dto.getApplicationId()!=null) {
        	if(applyOpt.isPresent()) {
        		if(optional.isPresent()) {
        			if(info.getApplicationId().equals(dto.getApplicationId())) {
        				// update logic
        				if (dto.getGovernmentDecisionOfApprovall() != null)
        				    info.setGovernmentDecisionOfApproval(dto.getGovernmentDecisionOfApprovall());

        				if (dto.getApprovalOrderOfDeputyDirectorOfEducation() != null)
        				    info.setApprovalOrderOfDeputyDirectorOfEducation(dto.getApprovalOrderOfDeputyDirectorOfEducation());

        				if (dto.getFirstApprovalOrder() != null)
        				    info.setFirstApprovalOrder(dto.getFirstApprovalOrder());

        				if (dto.getOrganizationsRequisitionApplicationInSample1() != null)
        				    info.setOrganizationsRequisitionApplicationInSample1(dto.getOrganizationsRequisitionApplicationInSample1());

        				if (dto.getJointAccountRetentionReceiptOfInstitution() != null)
        				    info.setJointAccountRetentionReceiptOfInstitution(dto.getJointAccountRetentionReceiptOfInstitution());

        				if (dto.getOrganizationCompanyRegistrationCertificate() != null)
        				    info.setOrganizationCompanyRegistrationCertificate(dto.getOrganizationCompanyRegistrationCertificate());

        				if (dto.getGovtMinorityCertificate() != null)
        				    info.setGovtMinorityCertificate(dto.getGovtMinorityCertificate());

        				if (dto.getPurchaseDeedLeaseAgreementAward() != null)
        				    info.setPurchaseDeedLeaseAgreementAward(dto.getPurchaseDeedLeaseAgreementAward());

        				if (dto.getAuditReport() != null)
        				    info.setAuditReport(dto.getAuditReport());

        				if (dto.getCopyOfEptaApprovalMinutes() != null)
        				    info.setCopyOfEptaApprovalMinutes(dto.getCopyOfEptaApprovalMinutes());

        				if (dto.getFreeStructureAccordingToPrevious() != null)
        				    info.setFreeStructureAccordingToPrevious(dto.getFreeStructureAccordingToPrevious());

        				if (dto.getTransportCommitteeOnlineCopy() != null)
        				    info.setTransportCommitteeOnlineCopy(dto.getTransportCommitteeOnlineCopy());

        				if (dto.getWomenGrievanceRedressalCommittee() != null)
        				    info.setWomenGrievanceRedressalCommittee(dto.getWomenGrievanceRedressalCommittee());

        				if (dto.getAffidavitOnStampOfRs100() != null)
        				    info.setAffidavitOnStampOfRs100(dto.getAffidavitOnStampOfRs100());

        				if (dto.getSchoolPrincipalSignStamp() != null)
        				    info.setSchoolPrincipalSignStamp(dto.getSchoolPrincipalSignStamp());

        				if (dto.getNamuna1HandWrittenForm() != null)
        				    info.setNamuna1HandWrittenForm(dto.getNamuna1HandWrittenForm());

        				if (dto.getSchoolLocationChangedBit() != null)
        				    info.setSchoolLocationChangedBit(dto.getSchoolLocationChangedBit());

        				if (dto.getSchoolLocationChanged() != null)
        				    info.setSchoolLocationChanged(dto.getSchoolLocationChanged());

        				if (dto.getCommonOrder2013To2016Bit() != null)
        				    info.setCommonOrder2013To2016Bit(dto.getCommonOrder2013To2016Bit());

        				if (dto.getCommonOrder2016To2019Bit() != null)
        				    info.setCommonOrder2016To2019Bit(dto.getCommonOrder2016To2019Bit());

        				if (dto.getCommonOrder2019To2022Bit() != null)
        				    info.setCommonOrder2019To2022Bit(dto.getCommonOrder2019To2022Bit());
        				
        				if (dto.getCommonOrder2022To2025Bit() != null)
        				    info.setCommonOrder2022To2025Bit(dto.getCommonOrder2022To2025Bit());

        				if (dto.getCommonOrder2013To2016() != null)
        				    info.setCommonOrder2013To2016(dto.getCommonOrder2013To2016());

        				if (dto.getCommonOrder2016To2019() != null)
        				    info.setCommonOrder2016To2019(dto.getCommonOrder2016To2019());

        				if (dto.getCommonOrder2019To2022() != null)
        				    info.setCommonOrder2019To2022(dto.getCommonOrder2019To2022());
        				
        				if (dto.getCommonOrder2022To2025() != null)
        				    info.setCommonOrder2022To2025(dto.getCommonOrder2022To2025());

        				info.setUpdatedAt(LocalDateTime.now());
        				NonGrantedSchoolInfo schoolInfo= repository.save(info);
        				
        	             NonGrantedSchoolInfoDTO dto2= modelMapper.map(schoolInfo,NonGrantedSchoolInfoDTO.class);
                         ApplicationsResult rs=applicationResultRepo.findByApplicationId(schoolInfo.getApplicationId()).orElseThrow(()->new RuntimeException("No records found in application result."));
                         dto2.setGeneralInfo(rs.getGeneralInfo());
                         dto2.setStudentCount(rs.getStudentCount());
                         dto2.setDetailsOfPhysicals(rs.getDetailsOfPhysical());
                         dto2.setOtherFacility(rs.getOtherFacilities());
                         dto2.setGranted(rs.getGranted());
                         dto2.setNonGranted(rs.getNonGranted());
                         return dto2;

        				
        			}else {
        				throw new RuntimeException("Application Id Mismatched.");
        			}
        		}else {
        			// save logic
        			School school =schoolRepo.findById(dto.getSchoolId())
					.orElseThrow(() -> new RuntimeException("School not found with ID: " + dto.getSchoolId()));
        			
        			
        	        info.setSchool(school);
        	        info.setGovernmentDecisionOfApproval(dto.getGovernmentDecisionOfApprovall());
        	        info.setApprovalOrderOfDeputyDirectorOfEducation(dto.getApprovalOrderOfDeputyDirectorOfEducation());
        	        info.setFirstApprovalOrder(dto.getFirstApprovalOrder());
        	        info.setOrganizationsRequisitionApplicationInSample1(dto.getOrganizationsRequisitionApplicationInSample1());
        	        info.setJointAccountRetentionReceiptOfInstitution(dto.getJointAccountRetentionReceiptOfInstitution());
        	        info.setOrganizationCompanyRegistrationCertificate(dto.getOrganizationCompanyRegistrationCertificate());
        	        info.setGovtMinorityCertificate(dto.getGovtMinorityCertificate());
        	        info.setPurchaseDeedLeaseAgreementAward(dto.getPurchaseDeedLeaseAgreementAward());
        	        info.setAuditReport(dto.getAuditReport());
        	        info.setCopyOfEptaApprovalMinutes(dto.getCopyOfEptaApprovalMinutes());
        	        info.setFreeStructureAccordingToPrevious(dto.getFreeStructureAccordingToPrevious());
        	        info.setTransportCommitteeOnlineCopy(dto.getTransportCommitteeOnlineCopy());
        	        info.setWomenGrievanceRedressalCommittee(dto.getWomenGrievanceRedressalCommittee());
        	        info.setAffidavitOnStampOfRs100(dto.getAffidavitOnStampOfRs100());
        	        info.setSchoolPrincipalSignStamp(dto.getSchoolPrincipalSignStamp());
        	        info.setNamuna1HandWrittenForm(dto.getNamuna1HandWrittenForm());
        	        info.setSchoolLocationChangedBit(dto.getSchoolLocationChangedBit());
        	        info.setSchoolLocationChanged(dto.getSchoolLocationChanged());
        	        info.setCommonOrder2013To2016Bit(dto.getCommonOrder2013To2016Bit());
        	        info.setCommonOrder2016To2019Bit(dto.getCommonOrder2016To2019Bit());
        	        info.setCommonOrder2019To2022Bit(dto.getCommonOrder2019To2022Bit());
        	        info.setCommonOrder2022To2025Bit(dto.getCommonOrder2022To2025Bit());
        	        info.setCommonOrder2013To2016(dto.getCommonOrder2013To2016());
        	        info.setCommonOrder2016To2019(dto.getCommonOrder2016To2019());
        	        info.setCommonOrder2019To2022(dto.getCommonOrder2019To2022());
        	        info.setCommonOrder2022To2025(dto.getCommonOrder2022To2025());
        	        info.setApplicationId(dto.getApplicationId());
        	        info.setCreatedAt(LocalDateTime.now());
        	        info.setUpdatedAt(LocalDateTime.now());
        	        
        	        applyRepo.findById(dto.getApplicationId()).ifPresent(apply -> {
		                String updatedSteps = stepsUtil.updateStepsJson(apply.getSteps(), "non-granted-school-info");
		                apply.setSteps(updatedSteps);
		                applyRepo.save(apply);
		            });
        	        
        	        NonGrantedSchoolInfo infoOpt =repository.save(info);
        	        
        	        Optional<ApplicationsResult> resultOpt = applicationResultRepo
							.findByApplicationId(dto.getApplicationId());

					if (resultOpt.isPresent()) {
						ApplicationsResult result = resultOpt.get();
						result.setNonGranted((byte) 1);
						applicationResultRepo.save(result);
					} else {
						throw new RuntimeException("Application Id not present in application result.");
					}
        	        
        	        NonGrantedSchoolInfoDTO dto2= modelMapper.map(infoOpt,NonGrantedSchoolInfoDTO.class);
                    ApplicationsResult rs=applicationResultRepo.findByApplicationId(infoOpt.getApplicationId()).orElseThrow(()->new RuntimeException("No records found in application result."));
                    dto2.setGeneralInfo(rs.getGeneralInfo());
                    dto2.setStudentCount(rs.getStudentCount());
                    dto2.setDetailsOfPhysicals(rs.getDetailsOfPhysical());
                    dto2.setOtherFacility(rs.getOtherFacilities());
                    dto2.setGranted(rs.getGranted());
                    dto2.setNonGranted(rs.getNonGranted());
                    return dto2;

        		}
        	}else {
        		throw new RuntimeException("Application not found for application ID "+dto.getApplicationId()+" in School Applies.");
        	}
        }else {
        	throw new RuntimeException("School Id and Application Id must be provided.");
        }
    }

    @Override
    public NonGrantedSchoolInfoDTO getBySchoolId(Long schoolId) {
        try {
            NonGrantedSchoolInfo nonGrantedSchoolInfo = repository.findBySchoolId(schoolId)
                .orElseThrow(() -> new RuntimeException("NonGrantedSchoolInfo not found for schoolId: " + schoolId));

            Long applicationId = nonGrantedSchoolInfo.getApplicationId();

            ApplicationsResult applicationResult = applicationResultRepo.findByApplicationId(applicationId)
                .orElseThrow(() -> new RuntimeException("Application result not found for application ID: " + applicationId));

            NonGrantedSchoolInfoDTO dto = modelMapper.map(nonGrantedSchoolInfo, NonGrantedSchoolInfoDTO.class);

            dto.setGranted(applicationResult.getGranted());
            dto.setGeneralInfo(applicationResult.getGeneralInfo());
            dto.setDetailsOfPhysicals(applicationResult.getDetailsOfPhysical());
            dto.setStudentCount(applicationResult.getStudentCount());
            dto.setOtherFacility(applicationResult.getOtherFacilities());
            dto.setNonGranted(applicationResult.getNonGranted());

            return dto;
        } catch (Exception e) {
            // Log full exception for debugging
            e.printStackTrace();
            throw e;
        }
    }

    
    @Value("${upload.directory:uploads/nonGrantedDocuments}")
    private String uploadDir;

    @Override
    public Resource loadFileAsResource(String fileName) throws Exception {
        Path filePath = Paths.get(uploadDir).resolve(fileName).normalize();
        if (Files.exists(filePath)) {
            return new PathResource(filePath);
        } else {
            throw new Exception("File not found: " + fileName);
        }
    }
}