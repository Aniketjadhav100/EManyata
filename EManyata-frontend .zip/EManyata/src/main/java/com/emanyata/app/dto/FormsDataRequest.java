package com.emanyata.app.dto;

public class FormsDataRequest {
    private String key;
    private String udiseNumber;
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getUdiseNumber() {
		return udiseNumber;
	}
	public void setUdiseNumber(String udiseNumber) {
		this.udiseNumber = udiseNumber;
	}

    
}
