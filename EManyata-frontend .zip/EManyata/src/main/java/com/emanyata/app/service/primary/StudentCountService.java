package com.emanyata.app.service.primary;


import com.emanyata.app.dto.StudentCountDTO;


public interface StudentCountService {
    StudentCountDTO createStudentCount(StudentCountDTO dto);
    StudentCountDTO getStudentCountBySchoolId(Long schoolId);
}