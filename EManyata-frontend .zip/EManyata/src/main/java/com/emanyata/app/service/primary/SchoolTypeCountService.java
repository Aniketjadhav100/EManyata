package com.emanyata.app.service.primary;

import com.emanyata.app.dto.SchoolTypeCountResponseDTO;

public interface SchoolTypeCountService {
//    List<SchoolTypeCountDTO> getSchoolTypeCounts();
    SchoolTypeCountResponseDTO getSchoolTypeCounts();
}