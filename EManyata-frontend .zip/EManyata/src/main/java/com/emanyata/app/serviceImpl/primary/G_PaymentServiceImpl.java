package com.emanyata.app.serviceImpl.primary;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.emanyata.app.dto.G_PaymentRequestDTO;
import com.emanyata.app.dto.G_PaymentResponseDTO;
import com.emanyata.app.entity.primary.G_Payment;
import com.emanyata.app.repo.primary.G_PaymentRepo;
import com.emanyata.app.service.primary.G_PaymentService;

@Service
public class G_PaymentServiceImpl implements G_PaymentService {

    @Value("${merchant.key}")
    private String key;

    @Value("${merchant.salt}")
    private String salt;

    private final G_PaymentRepo paymentRepo;

    public G_PaymentServiceImpl(G_PaymentRepo paymentRepo) {
        this.paymentRepo = paymentRepo;
    }

    @Override
    public G_PaymentResponseDTO initiatePayment(G_PaymentRequestDTO request) {
        try {
            String hashString = key + "|" +
                    request.getTxnid() + "|" +
                    request.getAmount() + "|" +
                    request.getProductinfo() + "|" +
                    request.getFirstname() + "|" +
                    request.getEmail() + "|||||||||||" + salt;

            MessageDigest md = MessageDigest.getInstance("SHA-512");
            byte[] hashBytes = md.digest(hashString.getBytes(StandardCharsets.UTF_8));
            StringBuilder hash = new StringBuilder();
            for (byte b : hashBytes) {
                hash.append(String.format("%02x", b));
            }

            String finalHash = hash.toString();

            // Optional: Save to DB
            G_Payment payment = new G_Payment();
            payment.setTxnid(request.getTxnid());
            payment.setAmount(request.getAmount());
            payment.setProductinfo(request.getProductinfo());
            payment.setFirstname(request.getFirstname());
            payment.setEmail(request.getEmail());
            payment.setHash(finalHash);
            paymentRepo.save(payment);

            G_PaymentResponseDTO response = new G_PaymentResponseDTO();
            response.setKey(key);
            response.setTxnid(request.getTxnid());
            response.setAmount(request.getAmount());
            response.setProductinfo(request.getProductinfo());
            response.setFirstname(request.getFirstname());
            response.setEmail(request.getEmail());
            response.setHash(finalHash);

            return response;
        } catch (Exception e) {
            throw new RuntimeException("Error generating payment hash", e);
        }
    }
}

