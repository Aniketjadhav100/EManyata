package com.emanyata.app.dto;

import java.util.List;

import com.emanyata.app.entity.primary.Payment;

public class PaymentResponseDTO {

	private String applyStatus;
	private String applicationNo;
	private String schoolName;
	private String udiseNo;
	private Long applicationId;
	private List<Payment> paymentList;
	
	
	public List<Payment> getPaymentList() {
		return paymentList;
	}
	public void setPaymentList(List<Payment> paymentList) {
		this.paymentList = paymentList;
	}
	public String getApplyStatus() {
		return applyStatus;
	}
	public void setApplyStatus(String applyStatus) {
		this.applyStatus = applyStatus;
	}
	public String getApplicationNo() {
		return applicationNo;
	}
	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}
	public String getSchoolName() {
		return schoolName;
	}
	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}
	public String getUdiseNo() {
		return udiseNo;
	}
	public void setUdiseNo(String udiseNo) {
		this.udiseNo = udiseNo;
	}
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}	
}
