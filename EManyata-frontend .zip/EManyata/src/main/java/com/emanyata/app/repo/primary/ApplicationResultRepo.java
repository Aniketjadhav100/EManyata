package com.emanyata.app.repo.primary;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.primary.ApplicationsResult;
import com.emanyata.app.entity.primary.School;

public interface ApplicationResultRepo extends JpaRepository<ApplicationsResult, Long> {
	Optional<ApplicationsResult> findByApplicationId(Long id);
	void deleteByApplication_School(School existingSchool);
}
