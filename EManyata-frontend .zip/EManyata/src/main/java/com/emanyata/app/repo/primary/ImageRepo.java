package com.emanyata.app.repo.primary;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.dto.ImageDTO;
import com.emanyata.app.entity.primary.Image;
import com.emanyata.app.entity.primary.User;

public interface ImageRepo extends JpaRepository<Image, Long> {

	Optional<Image> findByUser(User user);

}
