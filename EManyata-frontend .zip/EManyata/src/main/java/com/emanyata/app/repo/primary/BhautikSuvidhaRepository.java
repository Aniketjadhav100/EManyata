package com.emanyata.app.repo.primary;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.emanyata.app.entity.primary.BhauticSuvidha;


@Repository
public interface BhautikSuvidhaRepository extends JpaRepository<BhauticSuvidha, Long> {
	Optional<BhauticSuvidha> getBySchoolId(Long id); 
	Optional<BhauticSuvidha> findBySchoolId(Long id);
}
