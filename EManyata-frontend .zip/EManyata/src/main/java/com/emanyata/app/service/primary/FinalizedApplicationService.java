package com.emanyata.app.service.primary;

import java.util.List;

import com.emanyata.app.dto.FinalizedApplicationDTO;

public interface FinalizedApplicationService {

	List<FinalizedApplicationDTO> getAllFinalizedApplications();
	
}
