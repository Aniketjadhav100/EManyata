package com.emanyata.app.exceptions;

import java.util.Map;

public class CustomFileProcessingException extends RuntimeException {
    private final Map<String, Object> errorDetails;

    public CustomFileProcessingException(String message, Map<String, Object> errorDetails) {
        super(message);
        this.errorDetails = errorDetails;
    }

    public Map<String, Object> getErrorDetails() {
        return errorDetails;
    }
}
