package com.emanyata.app.dto;


import java.time.LocalDateTime;

public class StudentCountDTO {
    private Long id;
    private Long schoolId;
    private String totalBoys;
    private String totalGirls;
    private String total;
    private String lower;
    private String higher;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Long applicationId;
    private String inspectionAppoval;
    private String inspectionComment;
    
    private Byte generalInfo;
    private Byte detailsOfPhysicals;
    private Byte otherFacility;
    private Byte studentCount;
    private Byte grantedSchool;
    private Byte nonGrantedSchool;
    private Byte status;
    
    
    
	public Byte getStatus() {
		return status;
	}
	public void setStatus(Byte status) {
		this.status = status;
	}
	public Byte getGeneralInfo() {
		return generalInfo;
	}
	public void setGeneralInfo(Byte generalInfo) {
		this.generalInfo = generalInfo;
	}
	public Byte getDetailsOfPhysicals() {
		return detailsOfPhysicals;
	}
	public void setDetailsOfPhysicals(Byte detailsOfPhysicals) {
		this.detailsOfPhysicals = detailsOfPhysicals;
	}
	public Byte getOtherFacility() {
		return otherFacility;
	}
	public void setOtherFacility(Byte otherFacility) {
		this.otherFacility = otherFacility;
	}
	public Byte getStudentCount() {
		return studentCount;
	}
	public void setStudentCount(Byte studentCount) {
		this.studentCount = studentCount;
	}
	public Byte getGrantedSchool() {
		return grantedSchool;
	}
	public void setGrantedSchool(Byte grantedSchool) {
		this.grantedSchool = grantedSchool;
	}
	public Byte getNonGrantedSchool() {
		return nonGrantedSchool;
	}
	public void setNonGrantedSchool(Byte nonGrantedSchool) {
		this.nonGrantedSchool = nonGrantedSchool;
	}
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(Long schoolId) {
		this.schoolId = schoolId;
	}
	public String getTotalBoys() {
		return totalBoys;
	}
	public void setTotalBoys(String totalBoys) {
		this.totalBoys = totalBoys;
	}
	public String getTotalGirls() {
		return totalGirls;
	}
	public void setTotalGirls(String totalGirls) {
		this.totalGirls = totalGirls;
	}
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getLower() {
		return lower;
	}
	public void setLower(String lower) {
		this.lower = lower;
	}
	public String getHigher() {
		return higher;
	}
	public void setHigher(String higher) {
		this.higher = higher;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	public String getInspectionAppoval() {
		return inspectionAppoval;
	}
	public void setInspectionAppoval(String inspectionAppoval) {
		this.inspectionAppoval = inspectionAppoval;
	}
	public String getInspectionComment() {
		return inspectionComment;
	}
	public void setInspectionComment(String inspectionComment) {
		this.inspectionComment = inspectionComment;
	}




}
