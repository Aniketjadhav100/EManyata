package com.emanyata.app.controller.secondary;


import com.emanyata.app.dto.YearWiseFormDataRequest;
import com.emanyata.app.service.secondary.FormDataService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/year-wise-data")
public class FormDataController {

    @Autowired
    private FormDataService formDataService;

    @PostMapping
    public ResponseEntity<?> getYearWiseFormData(@RequestBody YearWiseFormDataRequest request) {
        return ResponseEntity.ok(formDataService.getYearWiseData(request));
    }
}
