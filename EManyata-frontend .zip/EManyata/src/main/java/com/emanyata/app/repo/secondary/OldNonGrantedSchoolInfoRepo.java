package com.emanyata.app.repo.secondary;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.primary.NonGrantedSchoolInfo;
import com.emanyata.app.entity.secondary.OldNonGrantedSchoolInfo;

public interface OldNonGrantedSchoolInfoRepo extends JpaRepository<OldNonGrantedSchoolInfo, Long> {
	Optional<OldNonGrantedSchoolInfo> findByApplicationId(Long id);

	List<OldNonGrantedSchoolInfo> findBySchoolId(Long id);

}
