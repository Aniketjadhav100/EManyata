package com.emanyata.app.controller.primary;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emanyata.app.dto.VillageDTO;
import com.emanyata.app.entity.primary.Village;
import com.emanyata.app.service.primary.VillageService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/villages")
public class VillageController {

	  private final VillageService villageService;

	    public VillageController(VillageService villageService) {
	        this.villageService = villageService;
	    }
	    
	    @PostMapping("/taluka/{talukaId}")
	    public ResponseEntity<?> getVillagesByTalukaId(@PathVariable Long talukaId) {
	        List<VillageDTO> villages = villageService.getVillagesByTalukaId(talukaId);

	        Map<String, Object> response = new HashMap<>();

	        if (villages.isEmpty()) {
	            response.put("message", "No villages found under the specified Taluka.");
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	        }

	        response.put("villages", villages);
	        return ResponseEntity.ok(response);
	    }


    @PostMapping("/add")
    public ResponseEntity<Map<String, Object>> addVillage(@Valid @RequestBody VillageDTO dto) {
        Optional<VillageDTO> existingVillage = villageService.getByName(dto.getName());
        Map<String, Object> response = new HashMap<>();

        if (existingVillage.isPresent()) {
            response.put("message", "Village already exists");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }

        VillageDTO saved = villageService.addVillage(dto);
        response.put("message", "Village added successfully");
        response.put("data", saved);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PostMapping("/{id}")
    public ResponseEntity<?> getVillageById(@PathVariable Long id) {
        VillageDTO result = villageService.getByVillageid(id);

        if (result == null) {
            Map<String, String> response = new HashMap<>();
            response.put("message", "No records associated with Village ID: " + id);
            return ResponseEntity.status(404).body(response);
        }

        return ResponseEntity.ok(result);
    }
    @PostMapping("/all")
    public ResponseEntity<?> getAllVillages() {
        List<VillageDTO> villages = villageService.getAllVillages();

        if (villages.isEmpty()) {
            Map<String, String> response = new HashMap<>();
            response.put("message", "No villages found.");
            return ResponseEntity.status(404).body(response);
        }

        return ResponseEntity.ok(villages);
    }
    @PostMapping("/delete/{id}")
    public ResponseEntity<Map<String, String>> deleteVillage(@PathVariable Long id) {
        Map<String, String> response = new HashMap<>();
        if (villageService.deleteVillageById(id)) {
            response.put("message", "Village deleted successfully");
            return ResponseEntity.ok(response);
        } else {
            response.put("error", "Village not found with ID: " + id);
            return ResponseEntity.status(404).body(response);
        }
    }

        @PostMapping("/update/{id}")
        public ResponseEntity<?> updateVillage(@PathVariable Long id, @RequestBody VillageDTO dto) {
            try {
                VillageDTO updated = villageService.updateVillageById(id, dto);
                Map<String, Object> response = new HashMap<>();
                response.put("message", "Village updated successfully");
                response.put("data", updated);
                return ResponseEntity.ok(response);
            } catch (RuntimeException e) {
                Map<String, String> error = new HashMap<>();
                error.put("error", e.getMessage());
                return ResponseEntity.status(404).body(error);
            }
    }
}