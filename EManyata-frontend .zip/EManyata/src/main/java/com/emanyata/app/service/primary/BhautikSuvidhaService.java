package com.emanyata.app.service.primary;

import com.emanyata.app.dto.BhauticSuvidhaDTO;


public interface BhautikSuvidhaService {

    BhauticSuvidhaDTO getById(Long id);

	BhauticSuvidhaDTO save(BhauticSuvidhaDTO dto);
	
	BhauticSuvidhaDTO getBySchoolID(Long id);

}

