package com.emanyata.app.dto;

public class G_PaymentResponseDTO {
	   private String key;
	    private String txnid;
	    private String amount;
	    private String productinfo;
	    private String firstname;
	    private String email;
	    private String hash;
		public String getKey() {
			return key;
		}
		public void setKey(String key) {
			this.key = key;
		}
		public String getTxnid() {
			return txnid;
		}
		public void setTxnid(String txnid) {
			this.txnid = txnid;
		}
		public String getAmount() {
			return amount;
		}
		public void setAmount(String amount) {
			this.amount = amount;
		}
		public String getProductinfo() {
			return productinfo;
		}
		public void setProductinfo(String productinfo) {
			this.productinfo = productinfo;
		}
		public String getFirstname() {
			return firstname;
		}
		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getHash() {
			return hash;
		}
		public void setHash(String hash) {
			this.hash = hash;
		}
	    
	    
}
