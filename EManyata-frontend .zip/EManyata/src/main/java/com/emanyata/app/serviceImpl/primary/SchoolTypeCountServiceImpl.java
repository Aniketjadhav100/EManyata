//package com.emanyata.app.serviceImpl.primary;
//
//import java.util.ArrayList;
//import java.util.LinkedHashMap;
//import java.util.List;
//import java.util.Map;
//
//import org.springframework.stereotype.Service;
//
//import com.emanyata.app.dto.SchoolTypeCountDTO;
//import com.emanyata.app.dto.SchoolTypeCountResponseDTO;
//import com.emanyata.app.repo.primary.SchoolTypeCountRepository;
//import com.emanyata.app.repo.secondary.OldSchoolTypeCountRepo;
//import com.emanyata.app.service.primary.SchoolTypeCountService;
//
//@Service
//public class SchoolTypeCountServiceImpl implements SchoolTypeCountService {
//
//    private final SchoolTypeCountRepository repository;
//    
//    private final OldSchoolTypeCountRepo oldSchoolTypeCountRepo;
//
//    public SchoolTypeCountServiceImpl(SchoolTypeCountRepository repository,OldSchoolTypeCountRepo oldSchoolTypeCountRepo) {
//        this.repository = repository;
//        this.oldSchoolTypeCountRepo=oldSchoolTypeCountRepo;
//    }
//
//    @Override
//    public SchoolTypeCountResponseDTO getSchoolTypeCounts() {
//        Map<String, Long> countMap = new LinkedHashMap<>();
//        countMap.put("granted", 0L);
//        countMap.put("non-granted", 0L);
//        countMap.put("permanently_unaided", 0L);
//        countMap.put("self-finance", 0L);
//        countMap.put("partially_granted", 0L);
//
//        for (SchoolTypeCountDTO dto : repository.countBySchoolType()) {
//            String type = dto.getSchoolType();
//            Long count = dto.getCount();
//            countMap.put(type, count);
//        }
//        
//        for (SchoolTypeCountDTO dto : oldSchoolTypeCountRepo.countBySchoolType()) {
//            String type = dto.getSchoolType();
//            Long count = dto.getCount();
//            countMap.put(type, count);
//        }
//
//        List<SchoolTypeCountDTO> result = new ArrayList<>();
//        Long total = 0L;
//        for (Map.Entry<String, Long> entry : countMap.entrySet()) {
//            result.add(new SchoolTypeCountDTO(entry.getKey(), entry.getValue()));
//            total += entry.getValue();
//        }
//
//        return new SchoolTypeCountResponseDTO(result, total);
//    }
//
//}

package com.emanyata.app.serviceImpl.primary;

import java.util.*;

import org.springframework.stereotype.Service;

import com.emanyata.app.dto.SchoolTypeCountDTO;
import com.emanyata.app.dto.SchoolTypeCountResponseDTO;
import com.emanyata.app.repo.primary.SchoolTypeCountRepository;
import com.emanyata.app.repo.secondary.OldSchoolTypeCountRepo;
import com.emanyata.app.service.primary.SchoolTypeCountService;

@Service
public class SchoolTypeCountServiceImpl implements SchoolTypeCountService {

    private final SchoolTypeCountRepository repository;
    private final OldSchoolTypeCountRepo oldSchoolTypeCountRepo;

    // ✅ Set of allowed school types
    private static final Set<String> ALLOWED_SCHOOL_TYPES = Set.of(
        "granted",
        "non-granted",
        "permanently_unaided",
        "self-finance",
        "partially_granted"
    );

    public SchoolTypeCountServiceImpl(SchoolTypeCountRepository repository, OldSchoolTypeCountRepo oldSchoolTypeCountRepo) {
        this.repository = repository;
        this.oldSchoolTypeCountRepo = oldSchoolTypeCountRepo;
    }

    @Override
    public SchoolTypeCountResponseDTO getSchoolTypeCounts() {
        Map<String, Long> countMap = new LinkedHashMap<>();
        
        // ✅ Initialize allowed types with 0
        for (String type : ALLOWED_SCHOOL_TYPES) {
            countMap.put(type, 0L);
        }

        // ✅ Filter and aggregate from primary DB
        for (SchoolTypeCountDTO dto : repository.countBySchoolType()) {
            String type = dto.getSchoolType();
            Long count = dto.getCount();

            if (ALLOWED_SCHOOL_TYPES.contains(type)) {
                countMap.put(type, countMap.getOrDefault(type, 0L) + count);
            }
        }

        // ✅ Filter and aggregate from old/secondary DB
        for (SchoolTypeCountDTO dto : oldSchoolTypeCountRepo.countBySchoolType()) {
            String type = dto.getSchoolType();
            Long count = dto.getCount();

            if (ALLOWED_SCHOOL_TYPES.contains(type)) {
                countMap.put(type, countMap.getOrDefault(type, 0L) + count);
            }
        }

        // ✅ Build final result list and calculate total
        List<SchoolTypeCountDTO> result = new ArrayList<>();
        Long total = 0L;
        for (Map.Entry<String, Long> entry : countMap.entrySet()) {
            result.add(new SchoolTypeCountDTO(entry.getKey(), entry.getValue()));
            total += entry.getValue();
        }

        return new SchoolTypeCountResponseDTO(result, total);
    }
}

