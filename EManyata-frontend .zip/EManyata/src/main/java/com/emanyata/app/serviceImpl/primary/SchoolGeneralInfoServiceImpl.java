package com.emanyata.app.serviceImpl.primary;

import com.emanyata.app.dto.BhauticSuvidhaDTO;
import com.emanyata.app.dto.SchoolGeneralInfoDTO;
import com.emanyata.app.entity.primary.ApplicationsResult;
import com.emanyata.app.entity.primary.School;
import com.emanyata.app.entity.primary.SchoolApply;
import com.emanyata.app.entity.primary.SchoolGeneralInfo;
import com.emanyata.app.repo.primary.ApplicationResultRepo;
import com.emanyata.app.repo.primary.SchoolApplyRepo;
import com.emanyata.app.repo.primary.SchoolGeneralInfoRepo;
import com.emanyata.app.repo.primary.SchoolRepo;
import com.emanyata.app.service.primary.SchoolGeneralInfoService;
import com.emanyata.app.util.ApplicationFormStepsUtil;

import java.time.LocalDateTime;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SchoolGeneralInfoServiceImpl implements SchoolGeneralInfoService {

	@Autowired
	private SchoolGeneralInfoRepo schoolGeneralInfoRepository;

	@Autowired
	private SchoolRepo schoolRepo;

	@Autowired
	private SchoolApplyRepo applyRepo;

	@Autowired
	private ApplicationResultRepo applicationResultRepo;

	@Autowired
	private ApplicationFormStepsUtil stepsUtil;

	@Autowired
	private ModelMapper modelMapper;

	@Override
	public SchoolGeneralInfoDTO getSchoolById(Long schoolId) {
		SchoolGeneralInfo schoolInfo = schoolGeneralInfoRepository.findBySchoolId(schoolId)
				.orElseThrow(() -> new RuntimeException("School info not found for school ID: " + schoolId));

		Long applicationId = schoolInfo.getApplicationId();

		ApplicationsResult applicationResult = applicationResultRepo.findByApplicationId(applicationId).orElseThrow(
				() -> new RuntimeException("Application result not found for application ID: " + applicationId));

		SchoolGeneralInfoDTO dto = modelMapper.map(schoolInfo, SchoolGeneralInfoDTO.class);

		// Populate additional details from ApplicationsResult
		dto.setGeneralInfo(applicationResult.getGeneralInfo());
		dto.setDetailsOfPhysicals(applicationResult.getDetailsOfPhysical());
		dto.setGrantedSchool(applicationResult.getGranted());
		dto.setStudentCount(applicationResult.getStudentCount());
		dto.setNonGrantedSchool(applicationResult.getNonGranted());
		dto.setOtherFacility(applicationResult.getOtherFacilities());

		return dto;
	}

	@Override
	public SchoolGeneralInfoDTO createSchoolInfo(SchoolGeneralInfoDTO dto) {
		// Validate required fields
		if (dto.getSchoolId() == null || dto.getApplicationId() == null) {
			throw new RuntimeException("Application ID and School ID must be provided.");
		}

		// Check if application exists
		SchoolApply schoolApply = applyRepo.findById(dto.getApplicationId())
				.orElseThrow(() -> new RuntimeException("Application not found with ID: " + dto.getApplicationId()));

		// Check if school exists
		School school = schoolRepo.findById(dto.getSchoolId())
				.orElseThrow(() -> new RuntimeException("School not found with ID: " + dto.getSchoolId()));

		// Check for existing record
		Optional<SchoolGeneralInfo> existingSchoolGeneralInfo = schoolGeneralInfoRepository
				.findBySchoolId(dto.getSchoolId());

		if (existingSchoolGeneralInfo.isPresent()) {
			// Validate application ID matches
			if (!existingSchoolGeneralInfo.get().getApplicationId().equals(dto.getApplicationId())) {
				throw new RuntimeException("Application ID mismatched.");
			}

			// Update existing record
			SchoolGeneralInfo existingEntity = existingSchoolGeneralInfo.get();
			updateEntityFromDto(existingEntity, dto);
			existingEntity.setUpdatedAt(LocalDateTime.now());
			SchoolGeneralInfo generalInfo = schoolGeneralInfoRepository.save(existingEntity);
			ApplicationsResult rs = applicationResultRepo.findByApplicationId(generalInfo.getApplicationId())
					.orElseThrow(() -> new RuntimeException("No records found in application result"));

			SchoolGeneralInfoDTO dto2 = modelMapper.map(generalInfo, SchoolGeneralInfoDTO.class);
			dto2.setGeneralInfo(rs.getGeneralInfo());
			dto2.setStudentCount(rs.getStudentCount());
			dto2.setDetailsOfPhysicals(rs.getDetailsOfPhysical());
			dto2.setOtherFacility(rs.getOtherFacilities());
			dto2.setGrantedSchool(rs.getGranted());
			dto2.setNonGrantedSchool(rs.getNonGranted());

			return dto2;
		} else {
			// Create new record
			SchoolGeneralInfo newEntity = new SchoolGeneralInfo();
			newEntity.setSchool(school);
			newEntity.setApplicationId(dto.getApplicationId());
			newEntity.setCreatedAt(LocalDateTime.now());
			newEntity.setUpdatedAt(LocalDateTime.now());
			newEntity.setStatus((byte) 1);

			updateEntityFromDto(newEntity, dto);

			SchoolGeneralInfo generalInfo = schoolGeneralInfoRepository.save(newEntity);

			applyRepo.findById(dto.getApplicationId()).ifPresent(apply -> {
				String updatedSteps = stepsUtil.updateStepsJson(apply.getSteps(), "school-general-info");
				apply.setSteps(updatedSteps);
				applyRepo.save(apply);
			});

			Optional<ApplicationsResult> resultOpt = applicationResultRepo.findByApplicationId(dto.getApplicationId());

			if (resultOpt.isPresent()) {
				ApplicationsResult result = resultOpt.get();
				result.setGeneralInfo((byte) 1);
				applicationResultRepo.save(result);
			} else {
				throw new RuntimeException("Application Id not present in application result.");
			}

			ApplicationsResult rs = applicationResultRepo.findByApplicationId(generalInfo.getApplicationId())
					.orElseThrow(() -> new RuntimeException("No records found in application result"));

			SchoolGeneralInfoDTO dto2 = modelMapper.map(generalInfo, SchoolGeneralInfoDTO.class);
			dto2.setGeneralInfo(rs.getGeneralInfo());
			dto2.setStudentCount(rs.getStudentCount());
			dto2.setDetailsOfPhysicals(rs.getDetailsOfPhysical());
			dto2.setOtherFacility(rs.getOtherFacilities());
			dto2.setGrantedSchool(rs.getGranted());
			dto2.setNonGrantedSchool(rs.getNonGranted());

			return dto2;
		}
	}

	private void updateEntityFromDto(SchoolGeneralInfo entity, SchoolGeneralInfoDTO dto) {
		// School Information
		if (dto.getSchoolAddress() != null) {
			entity.setSchoolAddress(dto.getSchoolAddress());
		}
		if (dto.getAddressMentionedInGovernmentApprovalDocument() != null) {
			entity.setAddressMentionedInGovernmentApprovalDocument(
					dto.getAddressMentionedInGovernmentApprovalDocument());
		}
		if (dto.getSchoolEstablishmentYear() != null) {
			entity.setSchoolEstablishmentYear(dto.getSchoolEstablishmentYear());
		}
		if (dto.getDateOfFirstCommencementOfSchool() != null) {
			entity.setDateOfFirstCommencementOfSchool(dto.getDateOfFirstCommencementOfSchool());
		}
		if (dto.getSchoolAcademicSession() != null) {
			entity.setSchoolAcademicSession(dto.getSchoolAcademicSession());
		}
		if (dto.getSchoolTimeFullTime() != null) {
			entity.setSchoolTimeFullTime(dto.getSchoolTimeFullTime());
		}
		if (dto.getSchoolTimeHalfTime() != null) {
			entity.setSchoolTimeHalfTime(dto.getSchoolTimeHalfTime());
		}

		// Academic Timing
		if (dto.getAcademicLearningTimeForEachClass() != null) {
			entity.setAcademicLearningTimeForEachClass(dto.getAcademicLearningTimeForEachClass());
		}
		if (dto.getLunchTimeForEachClass() != null) {
			entity.setLunchTimeForEachClass(dto.getLunchTimeForEachClass());
		}
		if (dto.getSportsAndPhysicalEducationTimeForEachClass() != null) {
			entity.setSportsAndPhysicalEducationTimeForEachClass(dto.getSportsAndPhysicalEducationTimeForEachClass());
		}

		// Trust/Society Information
		if (dto.getNameOfTrustSocietyManagementCommittee() != null) {
			entity.setNameOfTrustSocietyManagementCommittee(dto.getNameOfTrustSocietyManagementCommittee());
		}
		if (dto.getRegistrationNo() != null) {
			entity.setRegistrationNo(dto.getRegistrationNo());
		}
		if (dto.getUnderTheSocietiesRegistrationAct1860() != null) {
			entity.setUnderTheSocietiesRegistrationAct1860(dto.getUnderTheSocietiesRegistrationAct1860());
		}
		if (dto.getUnderTheMumbaiPublicTrusteeSystemAct1950() != null) {
			entity.setUnderTheMumbaiPublicTrusteeSystemAct1950(dto.getUnderTheMumbaiPublicTrusteeSystemAct1950());
		}
		if (dto.getTillWhatPeriodTheRegistrationOfTrust() != null) {
			entity.setTillWhatPeriodTheRegistrationOfTrust(dto.getTillWhatPeriodTheRegistrationOfTrust());
		}
		if (dto.getIsThereEvidenceThatTheTrust() != null) {
			entity.setIsThereEvidenceThatTheTrust(dto.getIsThereEvidenceThatTheTrust());
		}

		// School User Information
		if (dto.getSchoolUserName() != null) {
			entity.setSchoolUserName(dto.getSchoolUserName());
		}
		if (dto.getSchoolUserDegisnation() != null) {
			entity.setSchoolUserDegisnation(dto.getSchoolUserDegisnation());
		}
		if (dto.getSchoolUserAddress() != null) {
			entity.setSchoolUserAddress(dto.getSchoolUserAddress());
		}
		if (dto.getSchoolUserTelephone() != null) {
			entity.setSchoolUserTelephone(dto.getSchoolUserTelephone());
		}

		// Financial Information
		if (dto.getAccountYear() != null) {
			entity.setAccountYear(dto.getAccountYear());
		}
		if (dto.getAccountIncome() != null) {
			entity.setAccountIncome(dto.getAccountIncome());
		}
		if (dto.getAccountExpense() != null) {
			entity.setAccountExpense(dto.getAccountExpense());
		}
		if (dto.getAccountBalance() != null) {
			entity.setAccountBalance(dto.getAccountBalance());
		}

		// School Certification Information
		if (dto.getForWhichYearYouWantToApplyForACertificate() != null) {
			entity.setForWhichYearYouWantToApplyForACertificate(dto.getForWhichYearYouWantToApplyForACertificate());
		}
		if (dto.getYearOfFoundationzOfSchool() != null) {
			entity.setYearOfFoundationzOfSchool(dto.getYearOfFoundationzOfSchool());
		}
		if (dto.getDateOfFirstOpeningOfSchool() != null) {
			entity.setDateOfFirstOpeningOfSchool(dto.getDateOfFirstOpeningOfSchool());
		}

		// School Standards Information
		if (dto.getLowerStandard() != null) {
			entity.setLowerStandard(dto.getLowerStandard());
		}
		if (dto.getHigherStandard() != null) {
			entity.setHigherStandard(dto.getHigherStandard());
		}
		if (dto.getSchoolArea() != null) {
			entity.setSchoolArea(dto.getSchoolArea());
		}
		if (dto.getMediumOfInstruction() != null) {
			entity.setMediumOfInstruction(dto.getMediumOfInstruction());
		}
		if (dto.getSchoolBoard() != null) {
			entity.setSchoolBoard(dto.getSchoolBoard());
		}

		// Sanstha/Company Information
		if (dto.getSangsthaCompanyName() != null) {
			entity.setSangsthaCompanyName(dto.getSangsthaCompanyName());
		}
		if (dto.getSansthaCompanyHasPurposeForOnlyEducationService() != null) {
			entity.setSansthaCompanyHasPurposeForOnlyEducationService(
					dto.getSansthaCompanyHasPurposeForOnlyEducationService());
		}
		if (dto.getIsSchoolOpenWhereAddressMentionedInApproval() != null) {
			entity.setIsSchoolOpenWhereAddressMentionedInApproval(dto.getIsSchoolOpenWhereAddressMentionedInApproval());
		}
		if (dto.getIfSansthaIsHandoverToSomeone() != null) {
			entity.setIfSansthaIsHandoverToSomeone(dto.getIfSansthaIsHandoverToSomeone());
		}

		// Approval Information
		if (dto.getDoYouHaveMaharastraShashanManyataNo() != null) {
			entity.setDoYouHaveMaharastraShashanManyataNo(dto.getDoYouHaveMaharastraShashanManyataNo());
		}
		if (dto.getMaharastraShashanApprovalNumber() != null) {
			entity.setMaharastraShashanApprovalNumber(dto.getMaharastraShashanApprovalNumber());
		}
		if (dto.getMaharastraShashanApprovalDate() != null) {
			entity.setMaharastraShashanApprovalDate(dto.getMaharastraShashanApprovalDate());
		}
		if (dto.getDoYouHaveShikshanUpsanchalakApproval() != null) {
			entity.setDoYouHaveShikshanUpsanchalakApproval(dto.getDoYouHaveShikshanUpsanchalakApproval());
		}
		if (dto.getShikshanUpsanchalakApprovalDate() != null) {
			entity.setShikshanUpsanchalakApprovalDate(dto.getShikshanUpsanchalakApprovalDate());
		}
		if (dto.getShikshanUpsanchalakApprovalNumber() != null) {
			entity.setShikshanUpsanchalakApprovalNumber(dto.getShikshanUpsanchalakApprovalNumber());
		}

		// Certificate Information
		if (dto.getDoYouHavePrathamManyataCertificate() != null) {
			entity.setDoYouHavePrathamManyataCertificate(dto.getDoYouHavePrathamManyataCertificate());
		}
		if (dto.getPrathamManyataNumber() != null) {
			entity.setPrathamManyataNumber(dto.getPrathamManyataNumber());
		}
		if (dto.getPrathamManyataDate() != null) {
			entity.setPrathamManyataDate(dto.getPrathamManyataDate());
		}
		if (dto.getDoYouRunOnGovernmentNoObjectionCertificate() != null) {
			entity.setDoYouRunOnGovernmentNoObjectionCertificate(dto.getDoYouRunOnGovernmentNoObjectionCertificate());
		}
		if (dto.getNoObjectionCertificateNumber() != null) {
			entity.setNoObjectionCertificateNumber(dto.getNoObjectionCertificateNumber());
		}
		if (dto.getNoObjectionCertificateDate() != null) {
			entity.setNoObjectionCertificateDate(dto.getNoObjectionCertificateDate());
		}

		// School Location Information
		if (dto.getWhetherSchoolIsMovedToAnotherLocation() != null) {
			entity.setWhetherSchoolIsMovedToAnotherLocation(dto.getWhetherSchoolIsMovedToAnotherLocation());
		}

		// Members Information
		if (dto.getMembers() != null) {
			entity.setMembers(dto.getMembers());
		}

		// Standard Information
		if (dto.getSimpleHigherStandard() != null) {
			entity.setSimpleHigherStandard(dto.getSimpleHigherStandard());
		}
		if (dto.getSimpleLowerStandard() != null) {
			entity.setSimpleLowerStandard(dto.getSimpleLowerStandard());
		}
		if (dto.getUdiseLowerStandard() != null) {
			entity.setUdiseLowerStandard(dto.getUdiseLowerStandard());
		}
		if (dto.getUdiseHigherStandard() != null) {
			entity.setUdiseHigherStandard(dto.getUdiseHigherStandard());
		}

		// Affiliation Information
		if (dto.getIsThereAnAffiliationCertificate() != null) {
			entity.setIsThereAnAffiliationCertificate(dto.getIsThereAnAffiliationCertificate());
		}
		if (dto.getAffiliationCertificateNumber() != null) {
			entity.setAffiliationCertificateNumber(dto.getAffiliationCertificateNumber());
		}
		if (dto.getAffiliationCertificateDate() != null) {
			entity.setAffiliationCertificateDate(dto.getAffiliationCertificateDate());
		}

		// Inspection Information
		if (dto.getSection1InspectionApproval() != null) {
			entity.setSection1InspectionApproval(dto.getSection1InspectionApproval());
		}
		if (dto.getSection2InspectionApproval() != null) {
			entity.setSection2InspectionApproval(dto.getSection2InspectionApproval());
		}
		if (dto.getSection3InspectionApproval() != null) {
			entity.setSection3InspectionApproval(dto.getSection3InspectionApproval());
		}
		if (dto.getSection1InspectionComment() != null) {
			entity.setSection1InspectionComment(dto.getSection1InspectionComment());
		}
		if (dto.getSection2InspectionComment() != null) {
			entity.setSection2InspectionComment(dto.getSection2InspectionComment());
		}
		if (dto.getSection3InspectionComment() != null) {
			entity.setSection3InspectionComment(dto.getSection3InspectionComment());
		}
	}

}
