package com.emanyata.app.service.primary;

import com.emanyata.app.dto.G_PaymentRequestDTO;
import com.emanyata.app.dto.G_PaymentResponseDTO;

public interface G_PaymentService {

	G_PaymentResponseDTO initiatePayment(G_PaymentRequestDTO request);
}
