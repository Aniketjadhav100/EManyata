package com.emanyata.app.serviceImpl.primary;

import com.emanyata.app.dto.ImageDTO;
import com.emanyata.app.entity.primary.Image;
import com.emanyata.app.entity.primary.User;
import com.emanyata.app.repo.primary.ImageRepo;
import com.emanyata.app.repo.primary.UserRepo;
import com.emanyata.app.service.primary.ImageService;
import com.emanyata.app.util.ImageUploadUtil;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.PathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;

@Service
public class ImageServiceImpl implements ImageService {

    private final ImageRepo imageRepository;
    private final UserRepo userRepository;
    private final ImageUploadUtil imageUploadUtil;

    @Value("${upload.directory:uploads/images}")
    private String uploadDir;

    public ImageServiceImpl(ImageRepo imageRepository, UserRepo userRepository, ImageUploadUtil imageUploadUtil) {
        this.imageRepository = imageRepository;
        this.userRepository = userRepository;
        this.imageUploadUtil = imageUploadUtil;
    }

    @Override
    public ImageDTO upsertUserImage(Long userId, MultipartFile file) throws Exception {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

        String imagePath = imageUploadUtil.saveImage(file);

        Image image = imageRepository.findByUser(user)
                .orElseGet(() -> {
                    Image newImage = new Image();
                    newImage.setUser(user);
                    newImage.setCreatedAt(LocalDateTime.now());
                    return newImage;
                });

        image.setPath(imagePath);
        image.setUpdatedAt(LocalDateTime.now());
        imageRepository.save(image);

        ImageDTO dto = new ImageDTO();
        dto.setId(image.getId());
        dto.setUserId(user.getId());
        dto.setPath(image.getPath());
        dto.setCreatedAt(image.getCreatedAt());
        dto.setUpdatedAt(image.getUpdatedAt());
        return dto;
    }

    @Override
    public Resource loadUserImage(Long userId) throws Exception {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

        Image image = imageRepository.findByUser(user)
                .orElseThrow(() -> new RuntimeException("Image not found for user id: " + userId));

        String fileName = Paths.get(image.getPath()).getFileName().toString();
        Path imagePath = Paths.get(uploadDir).resolve(fileName).normalize();

        if (Files.exists(imagePath)) {
            return new PathResource(imagePath);
        } else {
            throw new IOException("File not found: " + fileName);
        }
    }

    @Override
    public void deleteUserImage(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));

        imageRepository.findByUser(user).ifPresent(image -> {
            try {
                Path path = Paths.get(image.getPath());
                Files.deleteIfExists(path);
            } catch (IOException e) {
                throw new RuntimeException("Failed to delete image file from disk", e);
            }
            imageRepository.delete(image);
        });
    }
}