package com.emanyata.app.service.primary;

import com.emanyata.app.dto.OtherFacilityDTO;

public interface OtherFacilityService {
	OtherFacilityDTO saveOtherFacility(OtherFacilityDTO dto);
    OtherFacilityDTO getOtherFacility(Long id);

}
