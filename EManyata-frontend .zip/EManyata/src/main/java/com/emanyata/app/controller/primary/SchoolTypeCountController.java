package com.emanyata.app.controller.primary;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import com.emanyata.app.dto.SchoolTypeCountResponseDTO;
import com.emanyata.app.service.primary.SchoolTypeCountService;

@RestController
public class SchoolTypeCountController {

    private final SchoolTypeCountService service;

    public SchoolTypeCountController(SchoolTypeCountService service) {
        this.service = service;
    }

    @PostMapping("/api/schools/count-by-type")
    public SchoolTypeCountResponseDTO getSchoolTypeCounts() {
        return service.getSchoolTypeCounts();
    }
}
