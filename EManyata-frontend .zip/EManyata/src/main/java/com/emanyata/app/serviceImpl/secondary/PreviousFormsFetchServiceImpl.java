package com.emanyata.app.serviceImpl.secondary;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emanyata.app.entity.secondary.OldSchool;
import com.emanyata.app.entity.secondary.OldSchoolApply;
import com.emanyata.app.repo.secondary.OldDetailOfPhysicalRepository;
import com.emanyata.app.repo.secondary.OldGrantedSchoolInfoRepo;
import com.emanyata.app.repo.secondary.OldNonGrantedSchoolInfoRepo;
import com.emanyata.app.repo.secondary.OldOtherFacilityRepo;
import com.emanyata.app.repo.secondary.OldSchoolApplyRepo;
import com.emanyata.app.repo.secondary.OldSchoolGeneralInfoRepository;
import com.emanyata.app.repo.secondary.OldSchoolRepository;
import com.emanyata.app.repo.secondary.OldStudentCountRepository;
import com.emanyata.app.service.secondary.PreviousFormService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class PreviousFormsFetchServiceImpl implements PreviousFormService {

    @Autowired private OldSchoolRepository oldSchoolRepo;
    @Autowired private OldSchoolApplyRepo oldSchoolApplyRepo;

    @Autowired private OldStudentCountRepository oldStudentCountRepo;
    @Autowired private OldSchoolGeneralInfoRepository oldGeneralInfoRepo;
    @Autowired private OldDetailOfPhysicalRepository oldDetailOfRepo;
    @Autowired private OldOtherFacilityRepo oldOtherFacilityRepo;
    @Autowired private OldGrantedSchoolInfoRepo oldGrantedSchoolInfoRepo;
    @Autowired private OldNonGrantedSchoolInfoRepo oldNonGrantedSchoolInfoRepo;

    private final ObjectMapper mapper = new ObjectMapper();

    @Override
    public Object getFormData(String key, String udiseNumber) {
        List<OldSchool> schools = oldSchoolRepo.findByUdiseNo(udiseNumber);
        if (schools.isEmpty()) return null;

        OldSchoolApply maxFilledApply = null;
        int maxSteps = -1;

        for (OldSchool school : schools) {
            List<OldSchoolApply> applyList = oldSchoolApplyRepo.findAllBySchoolId(school.getId());

	            for (OldSchoolApply apply : applyList) {
	                int stepCount = getStepsSize(apply.getSteps());
	                if (stepCount > maxSteps) {
	                    maxSteps = stepCount;
	                    maxFilledApply = apply;
	                }	
	            }
        }

        if (maxFilledApply == null) return null;

        Long applicationId = maxFilledApply.getId();

        switch (key.toLowerCase()) {
            case "general-info":
                return oldGeneralInfoRepo.findByApplicationId(applicationId);
            case "student-count":
                return oldStudentCountRepo.findByApplicationId(applicationId);
            case "bhautik-suvidha":
                return oldDetailOfRepo.findByApplicationId(applicationId);
            case "itar-suvidha":
                return oldOtherFacilityRepo.findByApplicationId(applicationId);
            case "granted-school-info":
                return oldGrantedSchoolInfoRepo.findByApplicationId(applicationId);
            case "non-granted-school-info":
                return oldNonGrantedSchoolInfoRepo.findByApplicationId(applicationId);
            default:
                return null;
        }
    }

    
    
    private int getStepsSize(String stepsJson) {
        if (stepsJson == null || stepsJson.isEmpty()) return 0;
        try {
            Map<String, Object> stepsMap = mapper.readValue(stepsJson, new TypeReference<>() {});
            return stepsMap.size();
        } catch (Exception e) {
            return 0;
        }
    }
    

}
