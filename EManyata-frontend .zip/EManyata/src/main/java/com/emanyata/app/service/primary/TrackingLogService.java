package com.emanyata.app.service.primary;

import com.emanyata.app.dto.TrackingLogDTO;

public interface TrackingLogService {
	TrackingLogDTO createTrackingLog(TrackingLogDTO log);
	TrackingLogDTO  findByApplicationNo(String number);
}
