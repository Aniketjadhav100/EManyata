package com.emanyata.app.entity.primary;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "schools")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class School {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "school_id")
    private Long id;

    @Size(max = 255)
    @NotNull
    @Column(name = "school_name", nullable = false)
    private String schoolName;
    
    @Size(max = 255)
    @NotNull
    @Column(name = "school_email", nullable = false)
    private String schoolEmail;

    @Size(max = 255)
    @NotNull
    @Column(name = "udise_no", nullable = false)
    private String udiseNo;

    @Size(max = 255)
    @NotNull
    @Column(name = "transactional_address", nullable = false)
    private String transactionalAddress;

    @Size(max = 255)
    @NotNull
    @Column(name = "district", nullable = false)
    private String district;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false,cascade = CascadeType.PERSIST)
    @JoinColumn(name = "taluka_id", nullable = false)
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
    private Taluka taluka;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false,cascade = CascadeType.PERSIST)
    @JoinColumn(name = "village_id", nullable = false)
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
    private Village village;

    @Size(max = 255)
    @NotNull
    @Column(name = "pincode", nullable = false)
    private String pincode;

    @Size(max = 255)
    @NotNull
    @Column(name = "telephone_number", nullable = false)
    private String telephoneNumber;

    @Size(max = 255)
    @NotNull
    @Column(name = "school_mobile", nullable = false)
    private String schoolMobile;

    @Size(max = 255)
    @NotNull
    @Column(name = "police_station", nullable = false)
    private String policeStation;

    @Size(max = 255)
    @NotNull
    @Column(name = "school_type", nullable = false)
    private String schoolType;

    @Column(name = "created_at")
    private LocalDateTime createdat;

    @Column(name = "updated_at")
    private LocalDateTime updatedat;
    
    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
    private User user_id;
    
 

    public User getUser_id() {
		return user_id;
	}

	public void setUser_id(User user_id) {
		this.user_id = user_id;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getUdiseNo() {
        return udiseNo;
    }

    public void setUdiseNo(String udiseNo) {
        this.udiseNo = udiseNo;
    }

    public String getTransactionalAddress() {
        return transactionalAddress;
    }

    public void setTransactionalAddress(String transactionalAddress) {
        this.transactionalAddress = transactionalAddress;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    
    public Taluka getTaluka() {
        return taluka;
    }

    public void setTaluka(Taluka taluka) {
        this.taluka = taluka;
    }

    public Village getVillage() {
        return village;
    }

    public void setVillage(Village village) {
        this.village = village;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getSchoolMobile() {
        return schoolMobile;
    }

    public void setSchoolMobile(String schoolMobile) {
        this.schoolMobile = schoolMobile;
    }

    public String getPoliceStation() {
        return policeStation;
    }

    public void setPoliceStation(String policeStation) {
        this.policeStation = policeStation;
    }

    public String getSchoolType() {
        return schoolType;
    }

    public void setSchoolType(String schoolType) {
        this.schoolType = schoolType;
    }

	public LocalDateTime getCreatedat() {
		return createdat;
	}

	public void setCreatedat(LocalDateTime createdat) {
		this.createdat = createdat;
	}

	public LocalDateTime getUpdatedat() {
		return updatedat;
	}

	public void setUpdatedat(LocalDateTime updatedat) {
		this.updatedat = updatedat;
	}

	public String getSchoolEmail() {
		return schoolEmail;
	}

	public void setSchoolEmail(String schoolEmail) {
		this.schoolEmail = schoolEmail;
	}

	
   

}