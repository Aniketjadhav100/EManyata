package com.emanyata.app.controller.primary;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emanyata.app.dto.TalukaDTO;
import com.emanyata.app.entity.primary.Taluka;
import com.emanyata.app.repo.primary.TalukaRepo;
import com.emanyata.app.service.primary.TalukaService;

@RestController
@RequestMapping("/api/talukas")
public class TalukaController {
	
	 private final TalukaRepo talukaRepository;
	 
	 public TalukaController(TalukaRepo talukaRepository) {
	        this.talukaRepository = talukaRepository;
	    }

	 @Autowired
	    private TalukaService talukaService;

	    @PostMapping("/add")
	    public ResponseEntity<?> addTaluka(@RequestBody TalukaDTO dto) {
	        try {
	            // Check if Taluka with the same name already exists
	            Optional<Taluka> existing = talukaService.getByName(dto.getName());
	            
	            // Log the result for debugging
	            System.out.println("Existing Taluka found: " + existing.isPresent());
	            
	            if (existing.isPresent()) {
	                Map<String, Object> response = new HashMap<>();
	                response.put("message", "Taluka already exists");
	                response.put("data", new TalukaDTO(existing.get())); // Assuming TalukaDTO constructor is correct
	                return ResponseEntity.status(HttpStatus.CONFLICT).body(response); // Use 409 Conflict
	            }

	            // Add new Taluka
	            TalukaDTO saved = talukaService.addTaluka(dto);
	            Map<String, Object> response = new HashMap<>();
	            response.put("message", "Taluka added successfully");
	            response.put("data", saved);
	            return ResponseEntity.status(HttpStatus.CREATED).body(response); // Use 201 Created for success
	        } catch (Exception e) {
	            Map<String, Object> error = new HashMap<>();
	            error.put("error", "Failed to add Taluka");
	            error.put("details", e.getMessage());
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error); // Use 500 Internal Server Error
	        }
	    }	    
	    
	    
	    
	    @PostMapping("/all")
	    public ResponseEntity<?> getAllTalukas() {
	        List<TalukaDTO> talukas = talukaService.getAllTalukas();
	        return ResponseEntity.ok(talukas);
	    }
	    
	    
	    
	    
	    
	    @PostMapping("/{id}")
	    public ResponseEntity<?> getTalukaById(@PathVariable Long id) {
	        Optional<Taluka> talukaOpt = talukaService.getById(id);

	        if (talukaOpt.isPresent()) {
	            TalukaDTO dto = new TalukaDTO(talukaOpt.get());
	            return ResponseEntity.ok(dto);
	        } else {
	            Map<String, String> error = new HashMap<>();
	            error.put("error", "Taluka not found");
	            return ResponseEntity.status(404).body(error);
	        }
	        
	        
}
	    
	    
	    @PostMapping("/delete/{id}")
	    public ResponseEntity<?> deleteTalukaById(@PathVariable Long id) {
	        try {
	            talukaService.deleteById(id);
	            Map<String, String> response = new HashMap<>();
	            response.put("message", "Taluka deleted successfully");
	            return ResponseEntity.ok(response);
	        } catch (RuntimeException e) {
	            Map<String, String> error = new HashMap<>();
	            error.put("error", e.getMessage());
	            return ResponseEntity.status(404).body(error);
	        }
	    }
	    
	    
	    
	    @PostMapping("/update/{id}")
	    public ResponseEntity<?> updateTaluka(@PathVariable Long id, @RequestBody Taluka updatedTaluka) {
	    	 Optional<Taluka> optionalTaluka = talukaRepository.findById(id);
	        if (optionalTaluka.isPresent()) {
	            Taluka existingTaluka = optionalTaluka.get();
	            existingTaluka.setName(updatedTaluka.getName());
	            existingTaluka.setStatus(updatedTaluka.getStatus());
	            existingTaluka.setUpdatedAt(LocalDateTime.now());
	            Taluka saved = talukaRepository.save(existingTaluka);
	            return ResponseEntity.ok(saved);
	        } else {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                    .body("Taluka with ID " + id + " not found");
	        }
	    }
}
