package com.emanyata.app.entity.secondary;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

@Entity
@Table(name = "other_facilities", schema = "emanyata")
public class OldOtherFacility {
    @Id
    @Column(name = "id", nullable = false)
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "school_id", nullable = false)
    private OldSchool school;

    @Size(max = 255)
    @Column(name = "are_all_facilities_accessible_without_hindrance")
    private String areAllFacilitiesAccessibleWithoutHindrance;

    @Size(max = 255)
    @Column(name = "study_teaching_materials")
    private String studyTeachingMaterials;

    @Size(max = 255)
    @Column(name = "sports_and_sports_equipment")
    private String sportsAndSportsEquipment;

    @Size(max = 255)
    @Column(name = "library_book_facility_books")
    private String libraryBookFacilityBooks;

    @Size(max = 255)
    @Column(name = "type_and_number_of_drinking_water_facilities")
    private String typeAndNumberOfDrinkingWaterFacilities;

    @Size(max = 255)
    @Column(name = "sanitary_condition")
    private String sanitaryCondition;

    @Size(max = 255)
    @Column(name = "type_of_toilets")
    private String typeOfToilets;

    @Size(max = 255)
    @Column(name = "number_of_separate_toilet_facilities_for_boys")
    private String numberOfSeparateToiletFacilitiesForBoys;

    @Size(max = 255)
    @Column(name = "number_of_separate_toilet_facilities_for_girls")
    private String numberOfSeparateToiletFacilitiesForGirls;

    @Size(max = 255)
    @Column(name = "division_wise_information")
    private String divisionWiseInformation;

    @Size(max = 255)
    @Column(name = "student_performance_method")
    private String studentPerformanceMethod;

    @Size(max = 255)
    @Column(name = "is_school_pressure_to_give_third_party_exam")
    private String isSchoolPressureToGiveThirdPartyExam;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "application_id")
    private Long applicationId;

    @Size(max = 255)
    @Column(name = "minimum_200_days_of_800_clock_hours_for_primary_and_higher")
    private String minimum200DaysOf800ClockHoursForPrimaryAndHigher;

    @Size(max = 255)
    @Column(name = "number_of_books_available_for_student_reading_in_the_library")
    private String numberOfBooksAvailableForStudentReadingInTheLibrary;

    @Size(max = 100)
    @Column(name = "number_of_sports_and_sports_literature", length = 100)
    private String numberOfSportsAndSportsLiterature;

    @Size(max = 100)
    @Column(name = "number_of_reference_books_available_for_teacher_training", length = 100)
    private String numberOfReferenceBooksAvailableForTeacherTraining;

    @Size(max = 100)
    @Column(name = "hours_of_teaching_per_week", length = 100)
    private String hoursOfTeachingPerWeek;

    @Size(max = 100)
    @Column(name = "sufficient_educational_material_in_each_class_as_required", length = 100)
    private String sufficientEducationalMaterialInEachClassAsRequired;

    @Size(max = 255)
    @Column(name = "magzin_books_count")
    private String magzinBooksCount;

    @Size(max = 255)
    @Column(name = "newspaper_and_total_count")
    private String newspaperAndTotalCount;

    @Size(max = 50)
    @Column(name = "inspection_approval", length = 50)
    private String inspectionApproval;

    @Size(max = 255)
    @Column(name = "inspection_comment")
    private String inspectionComment;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public OldSchool getSchool() {
        return school;
    }

    public void setSchool(OldSchool school) {
        this.school = school;
    }

    public String getAreAllFacilitiesAccessibleWithoutHindrance() {
        return areAllFacilitiesAccessibleWithoutHindrance;
    }

    public void setAreAllFacilitiesAccessibleWithoutHindrance(String areAllFacilitiesAccessibleWithoutHindrance) {
        this.areAllFacilitiesAccessibleWithoutHindrance = areAllFacilitiesAccessibleWithoutHindrance;
    }

    public String getStudyTeachingMaterials() {
        return studyTeachingMaterials;
    }

    public void setStudyTeachingMaterials(String studyTeachingMaterials) {
        this.studyTeachingMaterials = studyTeachingMaterials;
    }

    public String getSportsAndSportsEquipment() {
        return sportsAndSportsEquipment;
    }

    public void setSportsAndSportsEquipment(String sportsAndSportsEquipment) {
        this.sportsAndSportsEquipment = sportsAndSportsEquipment;
    }

    public String getLibraryBookFacilityBooks() {
        return libraryBookFacilityBooks;
    }

    public void setLibraryBookFacilityBooks(String libraryBookFacilityBooks) {
        this.libraryBookFacilityBooks = libraryBookFacilityBooks;
    }

    public String getTypeAndNumberOfDrinkingWaterFacilities() {
        return typeAndNumberOfDrinkingWaterFacilities;
    }

    public void setTypeAndNumberOfDrinkingWaterFacilities(String typeAndNumberOfDrinkingWaterFacilities) {
        this.typeAndNumberOfDrinkingWaterFacilities = typeAndNumberOfDrinkingWaterFacilities;
    }

    public String getSanitaryCondition() {
        return sanitaryCondition;
    }

    public void setSanitaryCondition(String sanitaryCondition) {
        this.sanitaryCondition = sanitaryCondition;
    }

    public String getTypeOfToilets() {
        return typeOfToilets;
    }

    public void setTypeOfToilets(String typeOfToilets) {
        this.typeOfToilets = typeOfToilets;
    }

    public String getNumberOfSeparateToiletFacilitiesForBoys() {
        return numberOfSeparateToiletFacilitiesForBoys;
    }

    public void setNumberOfSeparateToiletFacilitiesForBoys(String numberOfSeparateToiletFacilitiesForBoys) {
        this.numberOfSeparateToiletFacilitiesForBoys = numberOfSeparateToiletFacilitiesForBoys;
    }

    public String getNumberOfSeparateToiletFacilitiesForGirls() {
        return numberOfSeparateToiletFacilitiesForGirls;
    }

    public void setNumberOfSeparateToiletFacilitiesForGirls(String numberOfSeparateToiletFacilitiesForGirls) {
        this.numberOfSeparateToiletFacilitiesForGirls = numberOfSeparateToiletFacilitiesForGirls;
    }

    public String getDivisionWiseInformation() {
        return divisionWiseInformation;
    }

    public void setDivisionWiseInformation(String divisionWiseInformation) {
        this.divisionWiseInformation = divisionWiseInformation;
    }

    public String getStudentPerformanceMethod() {
        return studentPerformanceMethod;
    }

    public void setStudentPerformanceMethod(String studentPerformanceMethod) {
        this.studentPerformanceMethod = studentPerformanceMethod;
    }

    public String getIsSchoolPressureToGiveThirdPartyExam() {
        return isSchoolPressureToGiveThirdPartyExam;
    }

    public void setIsSchoolPressureToGiveThirdPartyExam(String isSchoolPressureToGiveThirdPartyExam) {
        this.isSchoolPressureToGiveThirdPartyExam = isSchoolPressureToGiveThirdPartyExam;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long applicationId) {
        this.applicationId = applicationId;
    }

    public String getMinimum200DaysOf800ClockHoursForPrimaryAndHigher() {
        return minimum200DaysOf800ClockHoursForPrimaryAndHigher;
    }

    public void setMinimum200DaysOf800ClockHoursForPrimaryAndHigher(String minimum200DaysOf800ClockHoursForPrimaryAndHigher) {
        this.minimum200DaysOf800ClockHoursForPrimaryAndHigher = minimum200DaysOf800ClockHoursForPrimaryAndHigher;
    }

    public String getNumberOfBooksAvailableForStudentReadingInTheLibrary() {
        return numberOfBooksAvailableForStudentReadingInTheLibrary;
    }

    public void setNumberOfBooksAvailableForStudentReadingInTheLibrary(String numberOfBooksAvailableForStudentReadingInTheLibrary) {
        this.numberOfBooksAvailableForStudentReadingInTheLibrary = numberOfBooksAvailableForStudentReadingInTheLibrary;
    }

    public String getNumberOfSportsAndSportsLiterature() {
        return numberOfSportsAndSportsLiterature;
    }

    public void setNumberOfSportsAndSportsLiterature(String numberOfSportsAndSportsLiterature) {
        this.numberOfSportsAndSportsLiterature = numberOfSportsAndSportsLiterature;
    }

    public String getNumberOfReferenceBooksAvailableForTeacherTraining() {
        return numberOfReferenceBooksAvailableForTeacherTraining;
    }

    public void setNumberOfReferenceBooksAvailableForTeacherTraining(String numberOfReferenceBooksAvailableForTeacherTraining) {
        this.numberOfReferenceBooksAvailableForTeacherTraining = numberOfReferenceBooksAvailableForTeacherTraining;
    }

    public String getHoursOfTeachingPerWeek() {
        return hoursOfTeachingPerWeek;
    }

    public void setHoursOfTeachingPerWeek(String hoursOfTeachingPerWeek) {
        this.hoursOfTeachingPerWeek = hoursOfTeachingPerWeek;
    }

    public String getSufficientEducationalMaterialInEachClassAsRequired() {
        return sufficientEducationalMaterialInEachClassAsRequired;
    }

    public void setSufficientEducationalMaterialInEachClassAsRequired(String sufficientEducationalMaterialInEachClassAsRequired) {
        this.sufficientEducationalMaterialInEachClassAsRequired = sufficientEducationalMaterialInEachClassAsRequired;
    }

    public String getMagzinBooksCount() {
        return magzinBooksCount;
    }

    public void setMagzinBooksCount(String magzinBooksCount) {
        this.magzinBooksCount = magzinBooksCount;
    }

    public String getNewspaperAndTotalCount() {
        return newspaperAndTotalCount;
    }

    public void setNewspaperAndTotalCount(String newspaperAndTotalCount) {
        this.newspaperAndTotalCount = newspaperAndTotalCount;
    }

    public String getInspectionApproval() {
        return inspectionApproval;
    }

    public void setInspectionApproval(String inspectionApproval) {
        this.inspectionApproval = inspectionApproval;
    }

    public String getInspectionComment() {
        return inspectionComment;
    }

    public void setInspectionComment(String inspectionComment) {
        this.inspectionComment = inspectionComment;
    }

}