package com.emanyata.app.authdto;

public class AdminRetrivalDTO {

}
