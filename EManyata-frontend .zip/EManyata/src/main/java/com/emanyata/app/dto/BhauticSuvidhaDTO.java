package com.emanyata.app.dto;

import java.time.LocalDateTime;


public class BhauticSuvidhaDTO 
{
    private Long id;
    private Long schoolId;   
    private String classroom; 
    private String officeRoom;
    private String kitchen;   
    private String separateToiletsForBoysAndGirls;
    private String drinkingWaterFacility;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Long applicationId;
    private String whetherSchoolIsMovedToAnotherLocation;
    private String typeOfProofAvailableAndItsDate;
    private String forYouTakePropertyDocumentType;
    private String areaSqM;
    private String totalAreaSqM;
    private String schoolTotalAreaSqM;
    private String principalCount;
    private String principalArea;
    private String officeCount;
    private String officeArea;
    private String staffCount;
    private String staffArea;
    private String storageCount;
    private String storageArea;
    private String classroomCount;
    private String classroomArea;
    private String labCount;
    private String labArea;
    private String compCount;
    private String compArea;
    private String libraryCount;
    private String libraryArea;
    private String schoolTotalCount;
    private String schoolTotalArea;
    private String westernToiletCount;
    private String toiletAvailableFacilityDetails;
    
  
    private String seperateBoysToiletCount;
    private String seperateBoysToiletFacilityDetails;
    private String seperateBoysWashroomCount;
    private String seperateBoysWashroomFacilityDetails;
    private String seperateBoysDrinkingWaterCount;
    private String seperateBoysDrinkingWaterFacilityDetails;
    
    private String seperateGirlsToiletCount;
    private String seperateGirlsToiletFacilityDetails;
    private String seperateGirlsWashroomCount;
    private String seperateGirlsWashroomFacilityDetails;
    private String seperateGirlsDrinkingWaterCount;
    private String seperateGirlsDrinkingWaterFacilityDetails;
    private String rampRoad;
    private String rocksOnTheSideOfTheRamp;
    private String rampFacilityDetails;
    private String roomNumber;
    private String theRoofIsSolidRcc;
    private String fireWarrantyCylinderNo;
    private String medicalPrimaryBoxNumber;
    private String cctvNo;
    private String plaquesInFacadesOfSchoolRecognition;
    private String aRampForBarrierFreeAccess;
    private String areaOfPlayground;
    private String areaOfPlaygroundDetails;
    private String retainingWallCompound;
    private String entranceWithProtectiveWallAndIronGate;
    private String kitchenShed;
    private String kitchenShedDetails;
    private String waterTapCount;
    private String waterTankCapacity;
    private String actualAvailableFacilityDetailsTap;
    private String actualAvailableFacilityDetailsWater;
    private String section1InspectionApproval;
    private String section2InspectionApproval;
    private String section3InspectionApproval;
    private String section4InspectionApproval;
    private String section5InspectionApproval;
    private String section6InspectionApproval;
    private String section1InspectionComment;
    private String section2InspectionComment;
    private String section3InspectionComment;
    private String section4InspectionComment;
    private String section5InspectionComment;
    private String section6InspectionComment;
    
    private Byte generalInfo;
    private Byte detailsOfPhysicals;
    private Byte otherFacility;
    private Byte studentCount;
    private Byte grantedSchool;
    private Byte nonGrantedSchool;
    
    private Byte status;
    
    
    
	public Byte getStatus() {
		return status;
	}
	public void setStatus(Byte status) {
		this.status = status;
	}
    
	public Byte getGeneralInfo() {
		return generalInfo;
	}
	public void setGeneralInfo(Byte generalInfo) {
		this.generalInfo = generalInfo;
	}
	public Byte getDetailsOfPhysicals() {
		return detailsOfPhysicals;
	}
	public void setDetailsOfPhysicals(Byte detailsOfPhysicals) {
		this.detailsOfPhysicals = detailsOfPhysicals;
	}
	public Byte getOtherFacility() {
		return otherFacility;
	}
	public void setOtherFacility(Byte otherFacility) {
		this.otherFacility = otherFacility;
	}
	public Byte getStudentCount() {
		return studentCount;
	}
	public void setStudentCount(Byte studentCount) {
		this.studentCount = studentCount;
	}
	public Byte getGrantedSchool() {
		return grantedSchool;
	}
	public void setGrantedSchool(Byte grantedSchool) {
		this.grantedSchool = grantedSchool;
	}
	public Byte getNonGrantedSchool() {
		return nonGrantedSchool;
	}
	public void setNonGrantedSchool(Byte nonGrantedSchool) {
		this.nonGrantedSchool = nonGrantedSchool;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}


	public Long getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(Long schoolId) {
		this.schoolId = schoolId;
	}
	public String getClassroom() {
		return classroom;
	}
	public void setClassroom(String classroom) {
		this.classroom = classroom;
	}
	public String getOfficeRoom() {
		return officeRoom;
	}
	public void setOfficeRoom(String officeRoom) {
		this.officeRoom = officeRoom;
	}
	public String getKitchen() {
		return kitchen;
	}
	public void setKitchen(String kitchen) {
		this.kitchen = kitchen;
	}
	public String getSeparateToiletsForBoysAndGirls() {
		return separateToiletsForBoysAndGirls;
	}
	public void setSeparateToiletsForBoysAndGirls(String separateToiletsForBoysAndGirls) {
		this.separateToiletsForBoysAndGirls = separateToiletsForBoysAndGirls;
	}
	public String getDrinkingWaterFacility() {
		return drinkingWaterFacility;
	}
	public void setDrinkingWaterFacility(String drinkingWaterFacility) {
		this.drinkingWaterFacility = drinkingWaterFacility;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	public String getWhetherSchoolIsMovedToAnotherLocation() {
		return whetherSchoolIsMovedToAnotherLocation;
	}
	public void setWhetherSchoolIsMovedToAnotherLocation(String whetherSchoolIsMovedToAnotherLocation) {
		this.whetherSchoolIsMovedToAnotherLocation = whetherSchoolIsMovedToAnotherLocation;
	}
	public String getTypeOfProofAvailableAndItsDate() {
		return typeOfProofAvailableAndItsDate;
	}
	public void setTypeOfProofAvailableAndItsDate(String typeOfProofAvailableAndItsDate) {
		this.typeOfProofAvailableAndItsDate = typeOfProofAvailableAndItsDate;
	}
	public String getForYouTakePropertyDocumentType() {
		return forYouTakePropertyDocumentType;
	}
	public void setForYouTakePropertyDocumentType(String forYouTakePropertyDocumentType) {
		this.forYouTakePropertyDocumentType = forYouTakePropertyDocumentType;
	}
	public String getAreaSqM() {
		return areaSqM;
	}
	public void setAreaSqM(String areaSqM) {
		this.areaSqM = areaSqM;
	}
	public String getTotalAreaSqM() {
		return totalAreaSqM;
	}
	public void setTotalAreaSqM(String totalAreaSqM) {
		this.totalAreaSqM = totalAreaSqM;
	}
	public String getSchoolTotalAreaSqM() {
		return schoolTotalAreaSqM;
	}
	public void setSchoolTotalAreaSqM(String schoolTotalAreaSqM) {
		this.schoolTotalAreaSqM = schoolTotalAreaSqM;
	}
	public String getPrincipalCount() {
		return principalCount;
	}
	public void setPrincipalCount(String principalCount) {
		this.principalCount = principalCount;
	}
	public String getPrincipalArea() {
		return principalArea;
	}
	public void setPrincipalArea(String principalArea) {
		this.principalArea = principalArea;
	}
	public String getOfficeCount() {
		return officeCount;
	}
	public void setOfficeCount(String officeCount) {
		this.officeCount = officeCount;
	}
	public String getOfficeArea() {
		return officeArea;
	}
	public void setOfficeArea(String officeArea) {
		this.officeArea = officeArea;
	}
	public String getStaffCount() {
		return staffCount;
	}
	public void setStaffCount(String staffCount) {
		this.staffCount = staffCount;
	}
	public String getStaffArea() {
		return staffArea;
	}
	public void setStaffArea(String staffArea) {
		this.staffArea = staffArea;
	}
	public String getStorageCount() {
		return storageCount;
	}
	public void setStorageCount(String storageCount) {
		this.storageCount = storageCount;
	}
	public String getStorageArea() {
		return storageArea;
	}
	public void setStorageArea(String storageArea) {
		this.storageArea = storageArea;
	}
	public String getClassroomCount() {
		return classroomCount;
	}
	public void setClassroomCount(String classroomCount) {
		this.classroomCount = classroomCount;
	}
	public String getClassroomArea() {
		return classroomArea;
	}
	public void setClassroomArea(String classroomArea) {
		this.classroomArea = classroomArea;
	}
	public String getLabCount() {
		return labCount;
	}
	public void setLabCount(String labCount) {
		this.labCount = labCount;
	}
	public String getLabArea() {
		return labArea;
	}
	public void setLabArea(String labArea) {
		this.labArea = labArea;
	}
	public String getCompCount() {
		return compCount;
	}
	public void setCompCount(String compCount) {
		this.compCount = compCount;
	}
	public String getCompArea() {
		return compArea;
	}
	public void setCompArea(String compArea) {
		this.compArea = compArea;
	}
	public String getLibraryCount() {
		return libraryCount;
	}
	public void setLibraryCount(String libraryCount) {
		this.libraryCount = libraryCount;
	}
	public String getLibraryArea() {
		return libraryArea;
	}
	public void setLibraryArea(String libraryArea) {
		this.libraryArea = libraryArea;
	}
	public String getSchoolTotalCount() {
		return schoolTotalCount;
	}
	public void setSchoolTotalCount(String schoolTotalCount) {
		this.schoolTotalCount = schoolTotalCount;
	}
	public String getSchoolTotalArea() {
		return schoolTotalArea;
	}
	public void setSchoolTotalArea(String schoolTotalArea) {
		this.schoolTotalArea = schoolTotalArea;
	}
	public String getWesternToiletCount() {
		return westernToiletCount;
	}
	public void setWesternToiletCount(String westernToiletCount) {
		this.westernToiletCount = westernToiletCount;
	}
	public String getToiletAvailableFacilityDetails() {
		return toiletAvailableFacilityDetails;
	}
	public void setToiletAvailableFacilityDetails(String toiletAvailableFacilityDetails) {
		this.toiletAvailableFacilityDetails = toiletAvailableFacilityDetails;
	}
	
	public String getSeperateGirlsToiletCount() {
		return seperateGirlsToiletCount;
	}
	public void setSeperateGirlsToiletCount(String seperateGirlsToiletCount) {
		this.seperateGirlsToiletCount = seperateGirlsToiletCount;
	}
	public String getSeperateGirlsToiletFacilityDetails() {
		return seperateGirlsToiletFacilityDetails;
	}
	public void setSeperateGirlsToiletFacilityDetails(String seperateGirlsToiletFacilityDetails) {
		this.seperateGirlsToiletFacilityDetails = seperateGirlsToiletFacilityDetails;
	}
	public String getSeperateGirlsWashroomCount() {
		return seperateGirlsWashroomCount;
	}
	public void setSeperateGirlsWashroomCount(String seperateGirlsWashroomCount) {
		this.seperateGirlsWashroomCount = seperateGirlsWashroomCount;
	}
	public String getSeperateGirlsWashroomFacilityDetails() {
		return seperateGirlsWashroomFacilityDetails;
	}
	public void setSeperateGirlsWashroomFacilityDetails(String seperateGirlsWashroomFacilityDetails) {
		this.seperateGirlsWashroomFacilityDetails = seperateGirlsWashroomFacilityDetails;
	}
	public String getSeperateGirlsDrinkingWaterCount() {
		return seperateGirlsDrinkingWaterCount;
	}
	public void setSeperateGirlsDrinkingWaterCount(String seperateGirlsDrinkingWaterCount) {
		this.seperateGirlsDrinkingWaterCount = seperateGirlsDrinkingWaterCount;
	}
	
	public String getSeperateBoysToiletCount() {
		return seperateBoysToiletCount;
	}
	public void setSeperateBoysToiletCount(String seperateBoysToiletCount) {
		this.seperateBoysToiletCount = seperateBoysToiletCount;
	}
	public String getSeperateBoysToiletFacilityDetails() {
		return seperateBoysToiletFacilityDetails;
	}
	public void setSeperateBoysToiletFacilityDetails(String seperateBoysToiletFacilityDetails) {
		this.seperateBoysToiletFacilityDetails = seperateBoysToiletFacilityDetails;
	}
	public String getSeperateBoysWashroomCount() {
		return seperateBoysWashroomCount;
	}
	public void setSeperateBoysWashroomCount(String seperateBoysWashroomCount) {
		this.seperateBoysWashroomCount = seperateBoysWashroomCount;
	}
	public String getSeperateBoysWashroomFacilityDetails() {
		return seperateBoysWashroomFacilityDetails;
	}
	public void setSeperateBoysWashroomFacilityDetails(String seperateBoysWashroomFacilityDetails) {
		this.seperateBoysWashroomFacilityDetails = seperateBoysWashroomFacilityDetails;
	}
	public String getSeperateBoysDrinkingWaterCount() {
		return seperateBoysDrinkingWaterCount;
	}
	public void setSeperateBoysDrinkingWaterCount(String seperateBoysDrinkingWaterCount) {
		this.seperateBoysDrinkingWaterCount = seperateBoysDrinkingWaterCount;
	}
	public String getSeperateBoysDrinkingWaterFacilityDetails() {
		return seperateBoysDrinkingWaterFacilityDetails;
	}
	public void setSeperateBoysDrinkingWaterFacilityDetails(String seperateBoysDrinkingWaterFacilityDetails) {
		this.seperateBoysDrinkingWaterFacilityDetails = seperateBoysDrinkingWaterFacilityDetails;
	}
	public String getSeperateGirlsDrinkingWaterFacilityDetails() {
		return seperateGirlsDrinkingWaterFacilityDetails;
	}
	public void setSeperateGirlsDrinkingWaterFacilityDetails(String seperateGirlsDrinkingWaterFacilityDetails) {
		this.seperateGirlsDrinkingWaterFacilityDetails = seperateGirlsDrinkingWaterFacilityDetails;
	}
	public String getRampRoad() {
		return rampRoad;
	}
	public void setRampRoad(String rampRoad) {
		this.rampRoad = rampRoad;
	}
	public String getRocksOnTheSideOfTheRamp() {
		return rocksOnTheSideOfTheRamp;
	}
	public void setRocksOnTheSideOfTheRamp(String rocksOnTheSideOfTheRamp) {
		this.rocksOnTheSideOfTheRamp = rocksOnTheSideOfTheRamp;
	}
	public String getRampFacilityDetails() {
		return rampFacilityDetails;
	}
	public void setRampFacilityDetails(String rampFacilityDetails) {
		this.rampFacilityDetails = rampFacilityDetails;
	}
	public String getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}
	public String getTheRoofIsSolidRcc() {
		return theRoofIsSolidRcc;
	}
	public void setTheRoofIsSolidRcc(String theRoofIsSolidRcc) {
		this.theRoofIsSolidRcc = theRoofIsSolidRcc;
	}
	public String getFireWarrantyCylinderNo() {
		return fireWarrantyCylinderNo;
	}
	public void setFireWarrantyCylinderNo(String fireWarrantyCylinderNo) {
		this.fireWarrantyCylinderNo = fireWarrantyCylinderNo;
	}
	public String getMedicalPrimaryBoxNumber() {
		return medicalPrimaryBoxNumber;
	}
	public void setMedicalPrimaryBoxNumber(String medicalPrimaryBoxNumber) {
		this.medicalPrimaryBoxNumber = medicalPrimaryBoxNumber;
	}
	public String getCctvNo() {
		return cctvNo;
	}
	public void setCctvNo(String cctvNo) {
		this.cctvNo = cctvNo;
	}
	public String getPlaquesInFacadesOfSchoolRecognition() {
		return plaquesInFacadesOfSchoolRecognition;
	}
	public void setPlaquesInFacadesOfSchoolRecognition(String plaquesInFacadesOfSchoolRecognition) {
		this.plaquesInFacadesOfSchoolRecognition = plaquesInFacadesOfSchoolRecognition;
	}
	public String getaRampForBarrierFreeAccess() {
		return aRampForBarrierFreeAccess;
	}
	public void setaRampForBarrierFreeAccess(String aRampForBarrierFreeAccess) {
		this.aRampForBarrierFreeAccess = aRampForBarrierFreeAccess;
	}
	public String getAreaOfPlayground() {
		return areaOfPlayground;
	}
	public void setAreaOfPlayground(String areaOfPlayground) {
		this.areaOfPlayground = areaOfPlayground;
	}
	public String getAreaOfPlaygroundDetails() {
		return areaOfPlaygroundDetails;
	}
	public void setAreaOfPlaygroundDetails(String areaOfPlaygroundDetails) {
		this.areaOfPlaygroundDetails = areaOfPlaygroundDetails;
	}
	public String getRetainingWallCompound() {
		return retainingWallCompound;
	}
	public void setRetainingWallCompound(String retainingWallCompound) {
		this.retainingWallCompound = retainingWallCompound;
	}
	public String getEntranceWithProtectiveWallAndIronGate() {
		return entranceWithProtectiveWallAndIronGate;
	}
	public void setEntranceWithProtectiveWallAndIronGate(String entranceWithProtectiveWallAndIronGate) {
		this.entranceWithProtectiveWallAndIronGate = entranceWithProtectiveWallAndIronGate;
	}
	public String getKitchenShed() {
		return kitchenShed;
	}
	public void setKitchenShed(String kitchenShed) {
		this.kitchenShed = kitchenShed;
	}
	public String getKitchenShedDetails() {
		return kitchenShedDetails;
	}
	public void setKitchenShedDetails(String kitchenShedDetails) {
		this.kitchenShedDetails = kitchenShedDetails;
	}
	public String getWaterTapCount() {
		return waterTapCount;
	}
	public void setWaterTapCount(String waterTapCount) {
		this.waterTapCount = waterTapCount;
	}
	public String getWaterTankCapacity() {
		return waterTankCapacity;
	}
	public void setWaterTankCapacity(String waterTankCapacity) {
		this.waterTankCapacity = waterTankCapacity;
	}
	public String getActualAvailableFacilityDetailsTap() {
		return actualAvailableFacilityDetailsTap;
	}
	public void setActualAvailableFacilityDetailsTap(String actualAvailableFacilityDetailsTap) {
		this.actualAvailableFacilityDetailsTap = actualAvailableFacilityDetailsTap;
	}
	public String getActualAvailableFacilityDetailsWater() {
		return actualAvailableFacilityDetailsWater;
	}
	public void setActualAvailableFacilityDetailsWater(String actualAvailableFacilityDetailsWater) {
		this.actualAvailableFacilityDetailsWater = actualAvailableFacilityDetailsWater;
	}
	public String getSection1InspectionApproval() {
		return section1InspectionApproval;
	}
	public void setSection1InspectionApproval(String section1InspectionApproval) {
		this.section1InspectionApproval = section1InspectionApproval;
	}
	public String getSection2InspectionApproval() {
		return section2InspectionApproval;
	}
	public void setSection2InspectionApproval(String section2InspectionApproval) {
		this.section2InspectionApproval = section2InspectionApproval;
	}
	public String getSection3InspectionApproval() {
		return section3InspectionApproval;
	}
	public void setSection3InspectionApproval(String section3InspectionApproval) {
		this.section3InspectionApproval = section3InspectionApproval;
	}
	public String getSection4InspectionApproval() {
		return section4InspectionApproval;
	}
	public void setSection4InspectionApproval(String section4InspectionApproval) {
		this.section4InspectionApproval = section4InspectionApproval;
	}
	public String getSection5InspectionApproval() {
		return section5InspectionApproval;
	}
	public void setSection5InspectionApproval(String section5InspectionApproval) {
		this.section5InspectionApproval = section5InspectionApproval;
	}
	public String getSection6InspectionApproval() {
		return section6InspectionApproval;
	}
	public void setSection6InspectionApproval(String section6InspectionApproval) {
		this.section6InspectionApproval = section6InspectionApproval;
	}
	public String getSection1InspectionComment() {
		return section1InspectionComment;
	}
	public void setSection1InspectionComment(String section1InspectionComment) {
		this.section1InspectionComment = section1InspectionComment;
	}
	public String getSection2InspectionComment() {
		return section2InspectionComment;
	}
	public void setSection2InspectionComment(String section2InspectionComment) {
		this.section2InspectionComment = section2InspectionComment;
	}
	public String getSection3InspectionComment() {
		return section3InspectionComment;
	}
	public void setSection3InspectionComment(String section3InspectionComment) {
		this.section3InspectionComment = section3InspectionComment;
	}
	public String getSection4InspectionComment() {
		return section4InspectionComment;
	}
	public void setSection4InspectionComment(String section4InspectionComment) {
		this.section4InspectionComment = section4InspectionComment;
	}
	public String getSection5InspectionComment() {
		return section5InspectionComment;
	}
	public void setSection5InspectionComment(String section5InspectionComment) {
		this.section5InspectionComment = section5InspectionComment;
	}
	public String getSection6InspectionComment() {
		return section6InspectionComment;
	}
	public void setSection6InspectionComment(String section6InspectionComment) {
		this.section6InspectionComment = section6InspectionComment;
	}
    
    

}
