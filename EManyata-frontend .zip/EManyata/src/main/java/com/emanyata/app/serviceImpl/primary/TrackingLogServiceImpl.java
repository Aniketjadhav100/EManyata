package com.emanyata.app.serviceImpl.primary;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emanyata.app.dto.TrackingLogDTO;
import com.emanyata.app.entity.primary.School;
import com.emanyata.app.entity.primary.SchoolApply;
import com.emanyata.app.entity.primary.TrackingLog;
import com.emanyata.app.entity.primary.User;
import com.emanyata.app.repo.primary.SchoolApplyRepo;
import com.emanyata.app.repo.primary.SchoolRepo;
import com.emanyata.app.repo.primary.TrackingLogRepo;
import com.emanyata.app.repo.primary.UserRepo;
import com.emanyata.app.service.primary.TrackingLogService;

@Service
public class TrackingLogServiceImpl implements TrackingLogService{
	
	@Autowired
	private SchoolRepo schoolRepository;

	@Autowired
	private UserRepo userRepository;
	
	@Autowired
	private TrackingLogRepo logRepo;
	
	@Autowired
	private SchoolApplyRepo applyRepo;
	
	@Override
	public TrackingLogDTO createTrackingLog(TrackingLogDTO logDto) {
	    School school = schoolRepository.findById(logDto.getSchoolId())
	            .orElseThrow(() -> new RuntimeException("School not found with ID: " + logDto.getSchoolId()));

	    User user = userRepository.findById(logDto.getUserId())
	            .orElseThrow(() -> new RuntimeException("User not found with ID: " + logDto.getUserId()));

	    TrackingLog log = new TrackingLog();
	    log.setId(logDto.getId());
	    log.setSchool(school);
	    log.setUser(user);
	    log.setStatus(logDto.getStatus());
	    log.setSteps(logDto.getSteps());
	    log.setMessage(logDto.getMessage());
	    log.setApplicationId(logDto.getApplicationId());
	    log.setCreatedAt(LocalDateTime.now());
	    log.setUpdatedAt(LocalDateTime.now());

	    return toDTO(logRepo.save(log));
	}


	@Override
	public TrackingLogDTO findByApplicationNo(String number) {
	    SchoolApply school = applyRepo.findByApplicationNo(number)
	        .orElseThrow(() -> new RuntimeException("No school found with application number: " + number));
	    
	    TrackingLog log = logRepo.findBySchoolId(school.getId())
	        .orElseThrow(() -> new RuntimeException("No Tracking Logs found with application number: " + number));
	    
	    return toDTO(log);
	}
	
	private TrackingLogDTO toDTO(TrackingLog log) {
	    TrackingLogDTO dto = new TrackingLogDTO();
	    dto.setId(log.getId());
	    dto.setSchoolId(log.getSchool().getId());
	    dto.setUserId(log.getUser().getId());
	    dto.setStatus(log.getStatus());
	    dto.setSteps(log.getSteps());
	    dto.setMessage(log.getMessage());
	    dto.setApplicationId(log.getApplicationId());
	    dto.setCreatedAt(log.getCreatedAt());
	    dto.setUpdatedAt(log.getUpdatedAt());
	    return dto;
	}


}
