package com.emanyata.app.service.primary;

import org.springframework.core.io.Resource;

import com.emanyata.app.dto.NonGrantedSchoolInfoDTO;
import com.emanyata.app.entity.primary.NonGrantedSchoolInfo;

public interface NonGrantedSchoolInfoService {
	NonGrantedSchoolInfoDTO saveOrUpdate(NonGrantedSchoolInfoDTO dto);
	NonGrantedSchoolInfoDTO getBySchoolId(Long schoolId);
	Resource loadFileAsResource(String fileName) throws Exception;
}
