package com.emanyata.app.repo.secondary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.emanyata.app.dto.SchoolTypeCountDTO;
import com.emanyata.app.entity.secondary.OldSchool;

@Repository
public interface OldSchoolTypeCountRepo extends JpaRepository<OldSchool, Long> {

	@Query("SELECT new com.emanyata.app.dto.SchoolTypeCountDTO(s.schoolType, COUNT(s)) " +
		       "FROM OldSchool s GROUP BY s.schoolType")
	List<SchoolTypeCountDTO> countBySchoolType();	
}
