package com.emanyata.app.controller.secondary;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.emanyata.app.dto.FormsDataRequest;
import com.emanyata.app.service.secondary.PreviousFormService;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/form")
public class PreviousFormsController {

    @Autowired
    private PreviousFormService formService;

    @PostMapping("/get")
    public ResponseEntity<?> getFormByKeyAndUdise(@RequestBody FormsDataRequest request) {
        Object formData = formService.getFormData(request.getKey(), request.getUdiseNumber());

        if (formData == null) {
            Map<String, Object> response = new HashMap<>();
            response.put("status", "error");
            response.put("message", "No form data found for key: " + request.getKey() + " and UDISE number: " + request.getUdiseNumber());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }

        Map<String, Object> successResponse = new HashMap<>();
        successResponse.put("status", "success");
        successResponse.put("data", formData);

        return ResponseEntity.ok(successResponse);
    }
}
