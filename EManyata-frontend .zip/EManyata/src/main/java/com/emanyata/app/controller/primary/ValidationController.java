package com.emanyata.app.controller.primary;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.emanyata.app.authdto.EmailRequest;
import com.emanyata.app.dto.MobileRequest;
import com.emanyata.app.serviceImpl.primary.ValidationServiceImpl;

@RestController
@RequestMapping("/api/validation")
public class ValidationController {

    @Autowired
    private ValidationServiceImpl validationService;

    // 🔍 API to check if email exists
    @PostMapping("/check-email")
    public ResponseEntity<Map<String, Object>> checkEmailExists(@RequestBody EmailRequest request) {
        Map<String, Object> response = new HashMap<>();

        if (validationService.emailExists(request.getEmail())) {
            response.put("code", 400);
            response.put("message", "Email already exists");
            response.put("email", request.getEmail());
            return ResponseEntity.badRequest().body(response);
        }

        response.put("code", 200);
        response.put("message", "Email is available");
        response.put("email", request.getEmail());
        return ResponseEntity.ok(response);
    }

    // 📱 API to check if mobile exists
    @PostMapping("/check-mobile")
    public ResponseEntity<Map<String, Object>> checkMobileExists(@RequestBody MobileRequest request) {
        Map<String, Object> response = new HashMap<>();

        if (validationService.mobileExists(request.getMobile())) {
            response.put("code", 400);
            response.put("message", "Mobile number already exists");
            response.put("mobile", request.getMobile());
            return ResponseEntity.badRequest().body(response);
        }

        response.put("code", 200);
        response.put("message", "Mobile number is available");
        response.put("mobile", request.getMobile());
        return ResponseEntity.ok(response);
    }
}
