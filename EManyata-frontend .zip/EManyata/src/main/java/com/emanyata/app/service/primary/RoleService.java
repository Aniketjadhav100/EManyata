package com.emanyata.app.service.primary;

public interface RoleService {

}
