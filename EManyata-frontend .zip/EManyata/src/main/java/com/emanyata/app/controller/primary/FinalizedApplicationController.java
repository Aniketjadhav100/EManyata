package com.emanyata.app.controller.primary;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emanyata.app.dto.FinalizedApplicationDTO;
import com.emanyata.app.service.primary.FinalizedApplicationService;

import org.springframework.web.bind.annotation.GetMapping;

@RestController
@RequestMapping("/users/api")
@CrossOrigin(origins = "http://localhost:3000")
public class FinalizedApplicationController {

    @Autowired
    private FinalizedApplicationService finalizedApplicationService;

 // GET all finalized applications
    @PostMapping("/finalized-applications")
    public List<FinalizedApplicationDTO> getAllFinalizedApplications() {
        return finalizedApplicationService.getAllFinalizedApplications();
    }
}

