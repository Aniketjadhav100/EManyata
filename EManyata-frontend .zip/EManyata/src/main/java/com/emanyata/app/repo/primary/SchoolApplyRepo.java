package com.emanyata.app.repo.primary;

import com.emanyata.app.dto.StatusCountDTO;
import com.emanyata.app.entity.primary.School;
import com.emanyata.app.entity.primary.SchoolApply;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface SchoolApplyRepo extends JpaRepository<SchoolApply, Long> {

    List<SchoolApply> findByUserId(Long userId);

    List<SchoolApply> findBySchoolId(Long schoolId);
    
    Optional<SchoolApply> findAllBySchoolId(Long id);

    Optional<SchoolApply> findByApplicationNo(String applicationNo);
    
    List<SchoolApply> findByStatus(String status);

    boolean existsByApplicationNo(String applicationNo);

    long countByApplicationNoStartingWith(String prefix);

    void deleteBySchool(School existingSchool);
    @Query("SELECT s.udiseNo FROM School s WHERE s.id = :schoolId")
    String findUdiseNoBySchoolId(Long schoolId);
    
    // This is for Status Count
    @Query("SELECT new com.emanyata.app.dto.StatusCountDTO(s.status, COUNT(s)) FROM SchoolApply s GROUP BY s.status")
    List<StatusCountDTO> getStatusCounts();

//	Optional<SchoolApply> findTopByApplicationNo(String prefix);

	Optional<SchoolApply> findTopByApplicationNoStartingWithOrderByApplicationNoDesc(String prefix);

}