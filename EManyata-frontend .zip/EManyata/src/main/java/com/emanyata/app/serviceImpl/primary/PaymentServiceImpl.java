package com.emanyata.app.serviceImpl.primary;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emanyata.app.dto.G_PaymentResponseDTO;
import com.emanyata.app.dto.PaymentFieldsDTO;
import com.emanyata.app.dto.PaymentRequestDTO;
import com.emanyata.app.dto.PaymentResponseDTO;
import com.emanyata.app.entity.primary.Payment;
import com.emanyata.app.entity.primary.School;
import com.emanyata.app.entity.primary.SchoolApply;
import com.emanyata.app.repo.primary.PaymentTransactionRepo;
import com.emanyata.app.repo.primary.SchoolApplyRepo;
import com.emanyata.app.repo.primary.SchoolRepo;
import com.emanyata.app.service.primary.PaymentService;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	private PaymentTransactionRepo paymentRepo;

	@Autowired
	private SchoolApplyRepo applyRepo;

	@Autowired
	private SchoolRepo schoolRepo;

	@Override
	public PaymentFieldsDTO createTransaction(PaymentRequestDTO dto) {

		SchoolApply apply = applyRepo.findById(dto.getApplicationId()).orElseThrow(
				() -> new RuntimeException("Application not found for application Id " + dto.getApplicationId()));

		if ("success".equalsIgnoreCase(dto.getPaymentStatus().trim())) {
			apply.setApplyStatus("approved");
			apply.setStatus("pending");
			applyRepo.save(apply);
		}

		Payment txn = new Payment();
		txn.setApplicationNumber(apply.getApplicationNo());
		txn.setTransactionId(dto.getTransactionId());
		txn.setSchoolId(dto.getSchoolId());
		txn.setApplicationId(dto.getApplicationId());
		txn.setSchoolName(dto.getSchoolName());
		txn.setSchoolType(dto.getSchoolType());
		txn.setUdiseNo(dto.getUdiseNo());
		txn.setEmail(dto.getEmail());
		txn.setMobile(dto.getMobile());
		txn.setAmount(dto.getAmount());
		txn.setPaymentStatus(dto.getPaymentStatus());
		txn.setCreatedAt(LocalDateTime.now());
		txn.setPaymentMode(dto.getPaymentMode());

		Payment pay = paymentRepo.save(txn);
		SchoolApply aply = applyRepo.findAllBySchoolId(dto.getSchoolId())
				.orElseThrow(() -> new RuntimeException("Application not found for school Id" + dto.getSchoolId()));

		PaymentFieldsDTO fields = new PaymentFieldsDTO();
		fields.setApplyStatus(aply.getApplyStatus());
		fields.setPaymentStatus(pay.getPaymentStatus());
		return fields;

	}

	@Override
	public PaymentResponseDTO getBySchoolId(Long id) {
	    PaymentResponseDTO dto = new PaymentResponseDTO();

	    // Fetch school
	    School school = schoolRepo.findById(id)
	            .orElseThrow(() -> new RuntimeException("No school found for school Id: " + id));

	    // Fetch application
	    SchoolApply apply = applyRepo.findAllBySchoolId(id)
	            .orElseThrow(() -> new RuntimeException("Application not found for school Id: " + id));

	    // Fetch all payments
	    List<Payment> paymentList = paymentRepo.findAllBySchoolId(id);
	    if (paymentList.isEmpty()) {
	        throw new RuntimeException("Payments not found for school Id: " + id);
	    }

	    // Set values in response DTO
	    dto.setApplicationId(apply.getId());
	    dto.setApplicationNo(apply.getApplicationNo());
	    dto.setApplyStatus(apply.getApplyStatus());
	    dto.setSchoolName(school.getSchoolName());
	    dto.setUdiseNo(school.getUdiseNo());
	    dto.setPaymentList(paymentList); // ✅ Set full list here

	    return dto;
	}
}
