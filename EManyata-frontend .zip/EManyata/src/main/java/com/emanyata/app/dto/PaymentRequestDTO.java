package com.emanyata.app.dto;

public class PaymentRequestDTO {

		private String transactionId;
		private String paymentMode;
	    private Long schoolId;
	    private Long applicationId;
	    private String schoolName;
	    private String schoolType;
	    private String udiseNo;
	    private String email;
	    private String mobile;
	    private Double amount;
	    private String paymentStatus;
	    
	    
	    
		public String getPaymentMode() {
			return paymentMode;
		}
		public void setPaymentMode(String paymentMode) {
			this.paymentMode = paymentMode;
		}
		public String getTransactionId() {
			return transactionId;
		}
		public void setTransactionId(String transactionId) {
			this.transactionId = transactionId;
		}	
		public String getPaymentStatus() {
			return paymentStatus;
		}
		public void setPaymentStatus(String paymentStatus) {
			this.paymentStatus = paymentStatus;
		}
		public Long getSchoolId() {
			return schoolId;
		}
		public void setSchoolId(Long schoolId) {
			this.schoolId = schoolId;
		}
	
		public Long getApplicationId() {
			return applicationId;
		}
		public void setApplicationId(Long applicationId) {
			this.applicationId = applicationId;
		}
		public String getSchoolName() {
			return schoolName;
		}
		public void setSchoolName(String schoolName) {
			this.schoolName = schoolName;
		}
		public String getSchoolType() {
			return schoolType;
		}
		public void setSchoolType(String schoolType) {
			this.schoolType = schoolType;
		}
		public String getUdiseNo() {
			return udiseNo;
		}
		public void setUdiseNo(String udiseNo) {
			this.udiseNo = udiseNo;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getMobile() {
			return mobile;
		}
		public void setMobile(String mobile) {
			this.mobile = mobile;
		}
		public Double getAmount() {
			return amount;
		}
		public void setAmount(Double amount) {
			this.amount = amount;
		}
}
