package com.emanyata.app.serviceImpl.primary;

import com.emanyata.app.dto.GrantedSchoolInfoDTO;  // Make sure this DTO exists
import com.emanyata.app.entity.primary.ApplicationsResult;
import com.emanyata.app.entity.primary.GrantedSchoolInfo;
import com.emanyata.app.entity.primary.School;
import com.emanyata.app.entity.primary.SchoolApply;
import com.emanyata.app.repo.primary.ApplicationResultRepo;
import com.emanyata.app.repo.primary.GrantedSchoolInfoRepository;
import com.emanyata.app.repo.primary.SchoolApplyRepo;
import com.emanyata.app.repo.primary.SchoolRepo;
import com.emanyata.app.service.primary.GrantedSchoolInfoService;
import com.emanyata.app.util.ApplicationFormStepsUtil;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.PathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class GrantedSchoolInfoServiceImpl implements GrantedSchoolInfoService {

    @Autowired
    private GrantedSchoolInfoRepository repository;

    @Autowired
    private SchoolApplyRepo applyRepo;
    
    @Autowired
    private SchoolRepo schoolRepo;
    
    @Autowired
    private ModelMapper modelMapper;
    
    @Autowired
    private ApplicationResultRepo applicationResultRepo;
    
    @Autowired
    private ApplicationFormStepsUtil stepsUtil;

    @Override
    public GrantedSchoolInfoDTO saveOrUpdate(GrantedSchoolInfoDTO dto) {

        Optional<GrantedSchoolInfo> optional = repository.findBySchoolId(dto.schoolId);
        GrantedSchoolInfo info = optional.orElse(new GrantedSchoolInfo());

        if (dto.getSchoolId() != null && dto.getApplicationId() != null) {
            Optional<SchoolApply> opt = applyRepo.findById(dto.getApplicationId());
            if (opt.isPresent()) {
                if (optional.isPresent()) {
                    if (dto.getApplicationId().equals(info.getApplicationId())) {
                        // --- UPDATE LOGIC ---
                        if (dto.governmentDecisionOfApproval != null)
                            info.setGovernmentDecisionOfApproval(dto.governmentDecisionOfApproval);
                        if (dto.approvalOrderOfDeputyDirectorOfEducation != null)
                            info.setApprovalOrderOfDeputyDirectorOfEducation(
                                    dto.approvalOrderOfDeputyDirectorOfEducation);
                        if (dto.firstApprovalOrder != null)
                            info.setFirstApprovalOrder(dto.firstApprovalOrder);
                        if (dto.organizationsRequisitionApplicationInSample1 != null)
                            info.setOrganizationsRequisitionApplicationInSample1(
                                    dto.organizationsRequisitionApplicationInSample1);
                        if (dto.institutionRegistration19501860Certificate != null)
                            info.setInstitutionRegistration19501860Certificate(
                                    dto.institutionRegistration19501860Certificate);
                        if (dto.govtMinorityCertificateIfTheSchoolIsMinority != null)
                            info.setGovtMinorityCertificateIfTheSchoolIsMinority(
                                    dto.govtMinorityCertificateIfTheSchoolIsMinority);
                        if (dto.purchaseDeedLeaseAgreementAwardDeed != null)
                            info.setPurchaseDeedLeaseAgreementAwardDeed(dto.purchaseDeedLeaseAgreementAwardDeed);
                        if (dto.certificationOfJoiningIfJoiningIfAdditionalTeacher != null)
                            info.setCertificationOfJoiningIfJoiningIfAdditionalTeacher(
                                    dto.certificationOfJoiningIfJoiningIfAdditionalTeacher);
                        if (dto.institutionalUndertakingOfSchoolsNotChargingAny != null)
                            info.setInstitutionalUndertakingOfSchoolsNotChargingAny(
                                    dto.institutionalUndertakingOfSchoolsNotChargingAny);
                        if (dto.womenGrievanceRedressalCommittee != null)
                            info.setWomenGrievanceRedressalCommittee(dto.womenGrievanceRedressalCommittee);
                        if (dto.affidavitOnStampOfRs100 != null)
                            info.setAffidavitOnStampOfRs100(dto.affidavitOnStampOfRs100);
                        if (dto.schoolPrincipalSignStamp != null)
                            info.setSchoolPrincipalSignStamp(dto.schoolPrincipalSignStamp);
                        if (dto.schoolLocationChanged != null)
                            info.setSchoolLocationChanged(dto.schoolLocationChanged);
                        if (dto.commonOrder2013To2016 != null)
                            info.setCommonOrder2013To2016(dto.commonOrder2013To2016);
                        if (dto.commonOrder2016To2019 != null)
                            info.setCommonOrder2016To2019(dto.commonOrder2016To2019);
                        if (dto.commonOrder2019To2022 != null)
                            info.setCommonOrder2019To2022(dto.commonOrder2019To2022);
                        if (dto.commonOrder2022To2025 != null)
                            info.setCommonOrder2022To2025(dto.commonOrder2022To2025);
                        if (dto.schoolLocationChangedBit != null)
                            info.setSchoolLocationChangedBit(dto.schoolLocationChangedBit);
                        if (dto.commonOrder2013To2016Bit != null)
                            info.setCommonOrder2013To2016Bit(dto.commonOrder2013To2016Bit);
                        if (dto.commonOrder2016To2019Bit != null)
                            info.setCommonOrder2016To2019Bit(dto.commonOrder2016To2019Bit);
                        if (dto.commonOrder2019To2022Bit != null)
                            info.setCommonOrder2019To2022Bit(dto.commonOrder2019To2022Bit);
                        if (dto.commonOrder2022To2025Bit != null)
                            info.setCommonOrder2022To2025Bit(dto.commonOrder2022To2025Bit);

                        GrantedSchoolInfo gs=repository.save(info);
                        GrantedSchoolInfoDTO dto2= modelMapper.map(gs,GrantedSchoolInfoDTO.class);
                        ApplicationsResult rs=applicationResultRepo.findByApplicationId(gs.getApplicationId()).orElseThrow(()->new RuntimeException("No records found in application result."));
                        dto2.setGeneralInfo(rs.getGeneralInfo());
                        dto2.setStudentCount(rs.getStudentCount());
                        dto2.setDetailsOfPhysicals(rs.getDetailsOfPhysical());
                        dto2.setOtherFacility(rs.getOtherFacilities());
                        dto2.setGranted(rs.getGranted());
                        dto2.setNonGranted(rs.getNonGranted());
                        return dto2;
                    } else {
                        throw new RuntimeException("Application Id mistmatched.");
                    }
                } else {
                    // --- SAVE LOGIC ---
                    info.setCreatedAt(LocalDateTime.now());
                    info.setUpdatedAt(LocalDateTime.now());

                    School school = schoolRepo.findById(dto.getSchoolId())
                            .orElseThrow(() -> new RuntimeException("School not found with ID: " + dto.getSchoolId()));

                    info.setSchool(school);

                    info.setGovernmentDecisionOfApproval(dto.governmentDecisionOfApproval);
                    info.setApprovalOrderOfDeputyDirectorOfEducation(dto.approvalOrderOfDeputyDirectorOfEducation);
                    info.setFirstApprovalOrder(dto.firstApprovalOrder);
                    info.setOrganizationsRequisitionApplicationInSample1(
                            dto.organizationsRequisitionApplicationInSample1);
                    info.setInstitutionRegistration19501860Certificate(dto.institutionRegistration19501860Certificate);
                    info.setGovtMinorityCertificateIfTheSchoolIsMinority(
                            dto.govtMinorityCertificateIfTheSchoolIsMinority);
                    info.setPurchaseDeedLeaseAgreementAwardDeed(dto.purchaseDeedLeaseAgreementAwardDeed);
                    info.setCertificationOfJoiningIfJoiningIfAdditionalTeacher(
                            dto.certificationOfJoiningIfJoiningIfAdditionalTeacher);
                    info.setInstitutionalUndertakingOfSchoolsNotChargingAny(
                            dto.institutionalUndertakingOfSchoolsNotChargingAny);
                    info.setWomenGrievanceRedressalCommittee(dto.womenGrievanceRedressalCommittee);
                    info.setAffidavitOnStampOfRs100(dto.affidavitOnStampOfRs100);
                    info.setSchoolPrincipalSignStamp(dto.schoolPrincipalSignStamp);
                    info.setApplicationId(dto.applicationId);
                    info.setSchoolLocationChanged(dto.schoolLocationChanged);
                    info.setCommonOrder2013To2016(dto.commonOrder2013To2016);
                    info.setCommonOrder2016To2019(dto.commonOrder2016To2019);
                    info.setCommonOrder2019To2022(dto.commonOrder2019To2022);
                    info.setCommonOrder2022To2025(dto.commonOrder2022To2025);
                    info.setSchoolLocationChangedBit(dto.schoolLocationChangedBit);
                    info.setCommonOrder2013To2016Bit(dto.commonOrder2013To2016Bit);
                    info.setCommonOrder2016To2019Bit(dto.commonOrder2016To2019Bit);
                    info.setCommonOrder2019To2022Bit(dto.commonOrder2019To2022Bit);
                    info.setCommonOrder2022To2025Bit(dto.commonOrder2022To2025Bit);
                    info.setStatus((byte) 1);
                    
                     applyRepo.findById(dto.getApplicationId()).ifPresent(apply -> {
                            String updatedSteps = stepsUtil.updateStepsJson(apply.getSteps(), "granted-school-info");
                            apply.setSteps(updatedSteps);
                            applyRepo.save(apply);
                        });
                    
                    GrantedSchoolInfo schoolInfo= repository.save(info);
                    
                    Optional<ApplicationsResult> resultOpt = applicationResultRepo
                            .findByApplicationId(dto.getApplicationId());

                    if (resultOpt.isPresent()) {
                        ApplicationsResult result = resultOpt.get();
                        result.setGranted((byte) 1);
                        applicationResultRepo.save(result);
                    } else {
                        throw new RuntimeException("Application Id not present in application result.");
                    }
                    
                    GrantedSchoolInfoDTO dto2= modelMapper.map(schoolInfo,GrantedSchoolInfoDTO.class);
                    ApplicationsResult rs=applicationResultRepo.findByApplicationId(schoolInfo.getApplicationId()).orElseThrow(()->new RuntimeException("No records found in application result."));
                    dto2.setGeneralInfo(rs.getGeneralInfo());
                    dto2.setStudentCount(rs.getStudentCount());
                    dto2.setDetailsOfPhysicals(rs.getDetailsOfPhysical());
                    dto2.setOtherFacility(rs.getOtherFacilities());
                    dto2.setGranted(rs.getGranted());
                    dto2.setNonGranted(rs.getNonGranted());
                    return dto2;
                }
            } else {
                throw new RuntimeException(
                        "Application not found for Application Id " + dto.getApplicationId() + " in School Applies");
            }
        } else {
            throw new RuntimeException("Application ID and School Id must be provided.");
        }
    }

    @Override
    public GrantedSchoolInfoDTO getBySchoolId(Long schoolId) {
        try {
            GrantedSchoolInfo grantedSchoolInfo = repository.findBySchoolId(schoolId)
                .orElseThrow(() -> new RuntimeException("GrantedSchoolInfo not found for school ID: " + schoolId));

            Long applicationId = grantedSchoolInfo.getApplicationId();

            ApplicationsResult applicationResult = applicationResultRepo.findByApplicationId(applicationId)
                .orElseThrow(() -> new RuntimeException("Application result not found for application ID: " + applicationId));

            GrantedSchoolInfoDTO dto = modelMapper.map(grantedSchoolInfo, GrantedSchoolInfoDTO.class);

           
            dto.setGranted(applicationResult.getGranted());
            dto.setGeneralInfo(applicationResult.getGeneralInfo());
            dto.setDetailsOfPhysicals(applicationResult.getDetailsOfPhysical());
            dto.setStudentCount(applicationResult.getStudentCount());
            dto.setOtherFacility(applicationResult.getOtherFacilities());

            return dto;
        } catch (Exception e) {
            // Log full exception for debugging
            e.printStackTrace();
            throw e; // rethrow or handle gracefully
        }
    }
    
    @Value("${upload.directory:uploads/grantedSchoolDocuments}")
    private String uploadDir;

    @Override
    public Resource loadFileAsResource(String fileName) throws Exception {
        Path filePath = Paths.get(uploadDir).resolve(fileName).normalize();
        if (Files.exists(filePath)) {
            return new PathResource(filePath);
        } else {
            throw new Exception("File not found: " + fileName);
        }
    }

}