package com.emanyata.app.controller.primary;

import com.emanyata.app.dto.SchoolGeneralInfoDTO;
import com.emanyata.app.entity.primary.SchoolGeneralInfo;
import com.emanyata.app.service.primary.SchoolGeneralInfoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/school-general-info")
@CrossOrigin(origins = "http://localhost:3000")
public class SchoolGeneralInfoController {

    @Autowired
    private SchoolGeneralInfoService schoolGeneralInfoService;

    // 🔹 Create SchoolGeneralInfo
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createSchoolInfo(@RequestBody SchoolGeneralInfoDTO dto) {
        Map<String, Object> response = new HashMap<>();
        try {
            SchoolGeneralInfoDTO savedInfo = schoolGeneralInfoService.createSchoolInfo(dto);
            response.put("status", "success");
            response.put("message", "School general info created successfully.");
            response.put("data", savedInfo);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", "Failed to create school info: " + e.getMessage());
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }

    // 🔹 Get SchoolGeneralInfo by ID
    @PostMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getSchoolInfoById(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        try {
            SchoolGeneralInfoDTO info = schoolGeneralInfoService.getSchoolById(id);
            if (info == null) {
                throw new NoSuchElementException("No school info found with ID: " + id);
            }
            response.put("status", "success");
            response.put("message", "School general info fetched successfully.");
            response.put("data", info);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", "Error fetching school info: " + e.getMessage());
            response.put("data", null);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }
}
