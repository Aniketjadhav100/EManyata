package com.emanyata.app.controller.secondary;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emanyata.app.dto.AllFormsDTO;
import com.emanyata.app.dto.EmailMobileDTO;
import com.emanyata.app.service.secondary.OldSchoolService;

@RestController
@RequestMapping("/api/oldschools")
public class OldSchoolController {
    
    @Autowired
    private OldSchoolService oldSchoolService;

    @PostMapping("/udise/{udiseNumber}")
    public ResponseEntity<Map<String, Object>> getSchoolByUdiseNumber(
            @RequestBody EmailMobileDTO dto,
            @PathVariable String udiseNumber) {
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            AllFormsDTO schoolData = oldSchoolService.findByUdiseNo(dto, udiseNumber);
            
            if (schoolData == null) {
                response.put("status", false);
                response.put("message", "No school found with UDISE number: " + udiseNumber);
                return ResponseEntity.status(404).body(response);
            }
            
            response.put("status", true);
            response.put("message", "School data retrieved successfully");
            response.put("data", schoolData);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            response.put("status", false);
            response.put("message", "" + e.getMessage());
            return ResponseEntity.status(400).body(response);
        }
    }
}