package com.emanyata.app.service.primary;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import org.springframework.web.multipart.MultipartFile;

import com.emanyata.app.dto.UdiseDetailsDTO;
import com.emanyata.app.dto.UdiseNumberDTO;
import com.emanyata.app.entity.primary.UdiseNumber;

public interface UdiseNumberService {

	Map<String, Object> saveUdiseFromExcel(MultipartFile file) throws IOException;

	UdiseNumber updateStatus(String udiseNumber, String status);

//    UdiseNumberDTO saveProvidedUdise(UdiseNumberDTO dto);
	UdiseDetailsDTO getUdiseDetails(String udiseNumber);

    List<UdiseNumberDTO> getUdiseByStatus(String status);
//
    List<UdiseNumberDTO> getAllUdiseNumbers();
//
//    UdiseNumberDTO updateStatus(Long udiseNumber);
}
