package com.emanyata.app.authdto;
public class ForgotPasswordRequest {
    private String emailOrMobile;

	public String getEmailOrMobile() {
		return emailOrMobile;
	}
                            
	public void setEmailOrMobile(String emailOrMobile) {
		this.emailOrMobile = emailOrMobile;
	}
    
    // Getters and Setters
     
    
}
