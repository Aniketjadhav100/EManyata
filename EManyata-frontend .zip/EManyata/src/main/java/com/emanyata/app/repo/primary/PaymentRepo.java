package com.emanyata.app.repo.primary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.primary.Payment;



public interface PaymentRepo extends JpaRepository<Payment, Long> {

}
