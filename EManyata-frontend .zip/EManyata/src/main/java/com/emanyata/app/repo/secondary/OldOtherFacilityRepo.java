package com.emanyata.app.repo.secondary;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.secondary.OldOtherFacility;

public interface OldOtherFacilityRepo extends JpaRepository<OldOtherFacility, Long> {
	Optional<OldOtherFacility> findByApplicationId(Long applicationId);

	List<OldOtherFacility> findBySchoolId(Long id);

}
