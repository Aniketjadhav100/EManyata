package com.emanyata.app.dto;

public class AllFormsDTO {
	private BhauticSuvidhaDTO bhauticSuvidhaDTO;
	private OtherFacilityDTO otherFacilityDTO;
	private StudentCountDTO studentCountDTO;
	private SchoolGeneralInfoDTO schoolGeneralInfoDTO;
	private GrantedSchoolInfoDTO grantedSchoolInfoDTO;
	private NonGrantedSchoolInfoDTO nonGrantedSchoolInfoDTO;
	public AllFormsDTO(BhauticSuvidhaDTO bhauticSuvidhaDTO, OtherFacilityDTO otherFacilityDTO,
			StudentCountDTO studentCountDTO, SchoolGeneralInfoDTO schoolGeneralInfoDTO,
			GrantedSchoolInfoDTO grantedSchoolInfoDTO, NonGrantedSchoolInfoDTO nonGrantedSchoolInfoDTO) {
		super();
		this.bhauticSuvidhaDTO = bhauticSuvidhaDTO;
		this.otherFacilityDTO = otherFacilityDTO;
		this.studentCountDTO = studentCountDTO;
		this.schoolGeneralInfoDTO = schoolGeneralInfoDTO;
		this.grantedSchoolInfoDTO = grantedSchoolInfoDTO;
		this.nonGrantedSchoolInfoDTO = nonGrantedSchoolInfoDTO;
	}
	public BhauticSuvidhaDTO getBhauticSuvidhaDTO() {
		return bhauticSuvidhaDTO;
	}
	public void setBhauticSuvidhaDTO(BhauticSuvidhaDTO bhauticSuvidhaDTO) {
		this.bhauticSuvidhaDTO = bhauticSuvidhaDTO;
	}
	public AllFormsDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OtherFacilityDTO getOtherFacilityDTO() {
		return otherFacilityDTO;
	}
	public void setOtherFacilityDTO(OtherFacilityDTO otherFacilityDTO) {
		this.otherFacilityDTO = otherFacilityDTO;
	}
	public StudentCountDTO getStudentCountDTO() {
		return studentCountDTO;
	}
	public void setStudentCountDTO(StudentCountDTO studentCountDTO) {
		this.studentCountDTO = studentCountDTO;
	}
	public SchoolGeneralInfoDTO getSchoolGeneralInfoDTO() {
		return schoolGeneralInfoDTO;
	}
	public void setSchoolGeneralInfoDTO(SchoolGeneralInfoDTO schoolGeneralInfoDTO) {
		this.schoolGeneralInfoDTO = schoolGeneralInfoDTO;
	}
	public GrantedSchoolInfoDTO getGrantedSchoolInfoDTO() {
		return grantedSchoolInfoDTO;
	}
	public void setGrantedSchoolInfoDTO(GrantedSchoolInfoDTO grantedSchoolInfoDTO) {
		this.grantedSchoolInfoDTO = grantedSchoolInfoDTO;
	}
	public NonGrantedSchoolInfoDTO getNonGrantedSchoolInfoDTO() {
		return nonGrantedSchoolInfoDTO;
	}
	public void setNonGrantedSchoolInfoDTO(NonGrantedSchoolInfoDTO nonGrantedSchoolInfoDTO) {
		this.nonGrantedSchoolInfoDTO = nonGrantedSchoolInfoDTO;
	}
		
}
