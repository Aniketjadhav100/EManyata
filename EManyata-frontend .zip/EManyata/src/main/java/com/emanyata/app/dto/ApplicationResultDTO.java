package com.emanyata.app.dto;

import java.time.LocalDateTime;

public class ApplicationResultDTO {

    private Long id;
    private Long applicationId;

    private Byte schoolInfo;
    private Byte generalInfo;
    private Byte formAndArea;
    private Byte studentCount;
    private Byte detailsOfPhysical;
    private Byte otherFacilities;
    private Byte detailsOfTeaching;
    private Byte nonGranted;
    private Byte granted;
    private String comment;
    private Byte governmentDecisionOfApproval;
    private Byte approvalOrderOfDeputyDirectorOfEducation;
    private Byte firstApprovalOrder;
    private Byte organizationsRequisitionApplicationInSample1;
    private Byte institutionRegistration19501860Certificate;
    private Byte govtMinorityCertificateIfTheSchoolIsMinority;
    private Byte institutionalUndertakingOfSchoolsNotChargingAny;
    private Byte womenGrievanceRedressalCommittee;
    private Byte affidavitOnStampOfRs100;
    private Byte schoolPrincipalSignStamp;
    private Byte schoolLocationChanged;
    private Byte commonOrder2013To2016;
    private Byte commonOrder2016To2019;
    private Byte commonOrder2019To2022;
    private Byte jointAccountRetentionReceiptOfInstitution;
    private Byte organizationCompanyRegistrationCertificate;
    private Byte govtMinorityCertificate;
    private Byte auditReport;
    private Byte copyOfEptaApprovalMinutes;
    private Byte freeStructureAccordingToPrevious;
    private Byte transportCommitteeOnlineCopy;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	public Byte getSchoolInfo() {
		return schoolInfo;
	}
	public void setSchoolInfo(Byte schoolInfo) {
		this.schoolInfo = schoolInfo;
	}
	public Byte getGeneralInfo() {
		return generalInfo;
	}
	public void setGeneralInfo(Byte generalInfo) {
		this.generalInfo = generalInfo;
	}
	public Byte getFormAndArea() {
		return formAndArea;
	}
	public void setFormAndArea(Byte formAndArea) {
		this.formAndArea = formAndArea;
	}
	public Byte getStudentCount() {
		return studentCount;
	}
	public void setStudentCount(Byte studentCount) {
		this.studentCount = studentCount;
	}
	public Byte getDetailsOfPhysical() {
		return detailsOfPhysical;
	}
	public void setDetailsOfPhysical(Byte detailsOfPhysical) {
		this.detailsOfPhysical = detailsOfPhysical;
	}
	public Byte getOtherFacilities() {
		return otherFacilities;
	}
	public void setOtherFacilities(Byte otherFacilities) {
		this.otherFacilities = otherFacilities;
	}
	public Byte getDetailsOfTeaching() {
		return detailsOfTeaching;
	}
	public void setDetailsOfTeaching(Byte detailsOfTeaching) {
		this.detailsOfTeaching = detailsOfTeaching;
	}
	public Byte getNonGranted() {
		return nonGranted;
	}
	public void setNonGranted(Byte nonGranted) {
		this.nonGranted = nonGranted;
	}
	public Byte getGranted() {
		return granted;
	}
	public void setGranted(Byte granted) {
		this.granted = granted;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public Byte getGovernmentDecisionOfApproval() {
		return governmentDecisionOfApproval;
	}
	public void setGovernmentDecisionOfApproval(Byte governmentDecisionOfApproval) {
		this.governmentDecisionOfApproval = governmentDecisionOfApproval;
	}
	public Byte getApprovalOrderOfDeputyDirectorOfEducation() {
		return approvalOrderOfDeputyDirectorOfEducation;
	}
	public void setApprovalOrderOfDeputyDirectorOfEducation(Byte approvalOrderOfDeputyDirectorOfEducation) {
		this.approvalOrderOfDeputyDirectorOfEducation = approvalOrderOfDeputyDirectorOfEducation;
	}
	public Byte getFirstApprovalOrder() {
		return firstApprovalOrder;
	}
	public void setFirstApprovalOrder(Byte firstApprovalOrder) {
		this.firstApprovalOrder = firstApprovalOrder;
	}
	public Byte getOrganizationsRequisitionApplicationInSample1() {
		return organizationsRequisitionApplicationInSample1;
	}
	public void setOrganizationsRequisitionApplicationInSample1(Byte organizationsRequisitionApplicationInSample1) {
		this.organizationsRequisitionApplicationInSample1 = organizationsRequisitionApplicationInSample1;
	}
	public Byte getInstitutionRegistration19501860Certificate() {
		return institutionRegistration19501860Certificate;
	}
	public void setInstitutionRegistration19501860Certificate(Byte institutionRegistration19501860Certificate) {
		this.institutionRegistration19501860Certificate = institutionRegistration19501860Certificate;
	}
	public Byte getGovtMinorityCertificateIfTheSchoolIsMinority() {
		return govtMinorityCertificateIfTheSchoolIsMinority;
	}
	public void setGovtMinorityCertificateIfTheSchoolIsMinority(Byte govtMinorityCertificateIfTheSchoolIsMinority) {
		this.govtMinorityCertificateIfTheSchoolIsMinority = govtMinorityCertificateIfTheSchoolIsMinority;
	}
	public Byte getInstitutionalUndertakingOfSchoolsNotChargingAny() {
		return institutionalUndertakingOfSchoolsNotChargingAny;
	}
	public void setInstitutionalUndertakingOfSchoolsNotChargingAny(Byte institutionalUndertakingOfSchoolsNotChargingAny) {
		this.institutionalUndertakingOfSchoolsNotChargingAny = institutionalUndertakingOfSchoolsNotChargingAny;
	}
	public Byte getWomenGrievanceRedressalCommittee() {
		return womenGrievanceRedressalCommittee;
	}
	public void setWomenGrievanceRedressalCommittee(Byte womenGrievanceRedressalCommittee) {
		this.womenGrievanceRedressalCommittee = womenGrievanceRedressalCommittee;
	}
	public Byte getAffidavitOnStampOfRs100() {
		return affidavitOnStampOfRs100;
	}
	public void setAffidavitOnStampOfRs100(Byte affidavitOnStampOfRs100) {
		this.affidavitOnStampOfRs100 = affidavitOnStampOfRs100;
	}
	public Byte getSchoolPrincipalSignStamp() {
		return schoolPrincipalSignStamp;
	}
	public void setSchoolPrincipalSignStamp(Byte schoolPrincipalSignStamp) {
		this.schoolPrincipalSignStamp = schoolPrincipalSignStamp;
	}
	public Byte getSchoolLocationChanged() {
		return schoolLocationChanged;
	}
	public void setSchoolLocationChanged(Byte schoolLocationChanged) {
		this.schoolLocationChanged = schoolLocationChanged;
	}
	public Byte getCommonOrder2013To2016() {
		return commonOrder2013To2016;
	}
	public void setCommonOrder2013To2016(Byte commonOrder2013To2016) {
		this.commonOrder2013To2016 = commonOrder2013To2016;
	}
	public Byte getCommonOrder2016To2019() {
		return commonOrder2016To2019;
	}
	public void setCommonOrder2016To2019(Byte commonOrder2016To2019) {
		this.commonOrder2016To2019 = commonOrder2016To2019;
	}
	public Byte getCommonOrder2019To2022() {
		return commonOrder2019To2022;
	}
	public void setCommonOrder2019To2022(Byte commonOrder2019To2022) {
		this.commonOrder2019To2022 = commonOrder2019To2022;
	}
	public Byte getJointAccountRetentionReceiptOfInstitution() {
		return jointAccountRetentionReceiptOfInstitution;
	}
	public void setJointAccountRetentionReceiptOfInstitution(Byte jointAccountRetentionReceiptOfInstitution) {
		this.jointAccountRetentionReceiptOfInstitution = jointAccountRetentionReceiptOfInstitution;
	}
	public Byte getOrganizationCompanyRegistrationCertificate() {
		return organizationCompanyRegistrationCertificate;
	}
	public void setOrganizationCompanyRegistrationCertificate(Byte organizationCompanyRegistrationCertificate) {
		this.organizationCompanyRegistrationCertificate = organizationCompanyRegistrationCertificate;
	}
	public Byte getGovtMinorityCertificate() {
		return govtMinorityCertificate;
	}
	public void setGovtMinorityCertificate(Byte govtMinorityCertificate) {
		this.govtMinorityCertificate = govtMinorityCertificate;
	}
	public Byte getAuditReport() {
		return auditReport;
	}
	public void setAuditReport(Byte auditReport) {
		this.auditReport = auditReport;
	}
	public Byte getCopyOfEptaApprovalMinutes() {
		return copyOfEptaApprovalMinutes;
	}
	public void setCopyOfEptaApprovalMinutes(Byte copyOfEptaApprovalMinutes) {
		this.copyOfEptaApprovalMinutes = copyOfEptaApprovalMinutes;
	}
	public Byte getFreeStructureAccordingToPrevious() {
		return freeStructureAccordingToPrevious;
	}
	public void setFreeStructureAccordingToPrevious(Byte freeStructureAccordingToPrevious) {
		this.freeStructureAccordingToPrevious = freeStructureAccordingToPrevious;
	}
	public Byte getTransportCommitteeOnlineCopy() {
		return transportCommitteeOnlineCopy;
	}
	public void setTransportCommitteeOnlineCopy(Byte transportCommitteeOnlineCopy) {
		this.transportCommitteeOnlineCopy = transportCommitteeOnlineCopy;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

    
}
