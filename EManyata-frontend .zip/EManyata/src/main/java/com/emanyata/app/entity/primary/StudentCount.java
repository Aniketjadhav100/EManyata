package com.emanyata.app.entity.primary;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "student_counts")
public class StudentCount {
	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "school_id", nullable = false)
	private School school;

	@Lob
	@Column(name = "total_boys")
	private String totalBoys;

	@Lob
	@Column(name = "total_girls")
	private String totalGirls;

	@Lob
	@Column(name = "total")
	private String total;

	@Size(max = 500)
	@Column(name = "lower", length = 500)
	private String lower;

	@Size(max = 500)
	@Column(name = "higher", length = 500)
	private String higher;

	@Column(name = "created_at")
	private LocalDateTime createdAt;

	@Column(name = "updated_at")
	private LocalDateTime updatedAt;

	@Column(name = "application_id")
	private Long applicationId;

	@Size(max = 50)
	@Column(name = "inspection_appoval", length = 50)
	private String inspectionAppoval;

	@Size(max = 255)
	@Column(name = "inspection_comment")
	private String inspectionComment;

	@Column(name = "status")
	private Byte status;

	public Byte getStatus() {
		return status;
	}

	public void setStatus(Byte status) {
		this.status = status;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public School getSchool() {
		return school;
	}

	public void setSchool(School school) {
		this.school = school;
	}

	public String getTotalBoys() {
		return totalBoys;
	}

	public void setTotalBoys(String totalBoys) {
		this.totalBoys = totalBoys;
	}

	public String getTotalGirls() {
		return totalGirls;
	}

	public void setTotalGirls(String totalGirls) {
		this.totalGirls = totalGirls;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	public String getLower() {
		return lower;
	}

	public void setLower(String lower) {
		this.lower = lower;
	}

	public String getHigher() {
		return higher;
	}

	public void setHigher(String higher) {
		this.higher = higher;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public String getInspectionAppoval() {
		return inspectionAppoval;
	}

	public void setInspectionAppoval(String inspectionAppoval) {
		this.inspectionAppoval = inspectionAppoval;
	}

	public String getInspectionComment() {
		return inspectionComment;
	}

	public void setInspectionComment(String inspectionComment) {
		this.inspectionComment = inspectionComment;
	}

}
