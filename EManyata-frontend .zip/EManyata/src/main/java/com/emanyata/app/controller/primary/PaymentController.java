package com.emanyata.app.controller.primary;

import com.emanyata.app.dto.PaymentFieldsDTO;
import com.emanyata.app.dto.PaymentRequestDTO;
import com.emanyata.app.dto.PaymentResponseDTO;
import com.emanyata.app.service.primary.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    // === Create a new payment transaction ===
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createTransaction(@RequestBody PaymentRequestDTO request) {
        Map<String, Object> response = new HashMap<>();
        try {
            PaymentFieldsDTO result = paymentService.createTransaction(request);
            response.put("data", result);
            response.put("message", "Transaction created successfully.");
            response.put("status", true);
            return ResponseEntity.ok(response);
        } catch (Exception ex) {
            response.put("data", null);
            response.put("message", "Transaction creation failed: " + ex.getMessage());
            response.put("status", false);
            return ResponseEntity.internalServerError().body(response);
        }
    }

    // === Get payment info by schoolId ===
    @PostMapping("/get/{schoolId}")
    public ResponseEntity<Map<String, Object>> getBySchoolId(@PathVariable("schoolId") Long schoolId) {
        Map<String, Object> response = new HashMap<>();
        try {
            PaymentResponseDTO result = paymentService.getBySchoolId(schoolId);
            response.put("data", result);
            response.put("message", "Payment info retrieved successfully.");
            response.put("status", true);
            return ResponseEntity.ok(response);
        } catch (Exception ex) {
            response.put("data", null);
            response.put("message", "Error fetching payment info: " + ex.getMessage());
            response.put("status", false);
            return ResponseEntity.internalServerError().body(response);
        }
    }
}
