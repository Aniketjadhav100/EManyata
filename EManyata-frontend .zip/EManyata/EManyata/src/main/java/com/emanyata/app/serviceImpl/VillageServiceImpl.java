package com.emanyata.app.serviceImpl;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emanyata.app.dto.VillageDTO;
import com.emanyata.app.entity.Taluka;
import com.emanyata.app.entity.Village;
import com.emanyata.app.repo.TalukaRepo;
import com.emanyata.app.repo.VillageRepo;
import com.emanyata.app.service.VillageService;

@Service
public class VillageServiceImpl implements VillageService {

	private final VillageRepo villageRepo;

    public VillageServiceImpl(VillageRepo villageRepo) {
        this.villageRepo = villageRepo;
    }

    @Autowired
    private TalukaRepo talukaRepository;

    @Override
    public VillageDTO addVillage(VillageDTO dto) {
        // Find Taluka using talukaId
    	Taluka taluka = talukaRepository.findById(dto.getTalukaId())
                .orElseThrow(() -> new RuntimeException("Taluka not found with ID: " + dto.getTalukaId()));
    	 Village village = villageRepo
    		        .findByNameAndTaluka_Id(dto.getName(), dto.getTalukaId())
    		        .orElseGet(Village::new);

    		    // 3. set or update fields
    		    village.setName(dto.getName());
    		    village.setStatus(dto.getStatus());
    		    village.setTaluka(taluka);

    		    Instant now = Instant.now();
    		    if (village.getId() == null) {
    		        village.setCreatedAt(now);
    		    }
    		    village.setUpdatedAt(now);

    		    // 4. save
    		    Village saved = villageRepo.save(village);

    		    // 5. map back to DTO
    		    return new VillageDTO(saved);
    		}
	@Override
	public VillageDTO getByVillageid(Long villageId) {
		 Village village = villageRepo.findById(villageId).orElse(null);

		    // If the village is not found, return null
		    if (village == null) {
		        return null;  // You can also return a custom message or response here if needed
		    }

		    // Return a new VillageDTO if the village is found
		    return new VillageDTO(village);
		}
	@Override
	public List<VillageDTO> getAllVillages() {
		   List<Village> villages = villageRepo.findAll();
		    return villages.stream()
		                   .map(VillageDTO::new)
		                   .toList();
		}
	@Override
	public boolean deleteVillageById(Long id) {
	    if (villageRepo.existsById(id)) {
	    	villageRepo.deleteById(id);  // This returns void, so we don't assign it
	        return true;
	    } else {
	        return false;
	    }
	}




	@Override
	public VillageDTO updateVillageById(Long id, VillageDTO dto) {
		 Village village = villageRepo.findById(id)
			        .orElseThrow(() -> new RuntimeException("Village not found with ID: " + id));

			    // Update fields
			    village.setName(dto.getName());
			    village.setStatus(dto.getStatus());

			    Taluka taluka = talukaRepository.findById(dto.getTalukaId())
			        .orElseThrow(() -> new RuntimeException("Taluka not found with ID: " + dto.getTalukaId()));
			    village.setTaluka(taluka);

			    village.setUpdatedAt(Instant.now());

			    // Save updated village
			    Village updated = villageRepo.save(village);
			    return new VillageDTO(updated);
			}
	@Override
	public Optional<VillageDTO> getByName(String name) {
	    return villageRepo.findByName(name)
	            .map(village -> new VillageDTO(village)); // Assuming VillageDTO has a constructor that takes a Village entity
	}


	}

		