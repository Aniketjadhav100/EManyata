package com.emanyata.app.controller;

import com.emanyata.app.authdto.ForgotPasswordRequest;
import com.emanyata.app.authdto.LoginRequest;
import com.emanyata.app.authdto.OtpRequest;
import com.emanyata.app.authdto.UpdatePasswordRequest;
import com.emanyata.app.authdto.UserDTO;
import com.emanyata.app.serviceImpl.UserServiceImpl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "*") // Adjust if needed for frontend
public class UserController {

    @Autowired
    private UserServiceImpl userService;

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody UserDTO userDto) {
        String response = userService.register(userDto);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<String> verifyOtp(@RequestBody OtpRequest otpRequest) {
        String response = userService.verifyOtp(otpRequest);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/resend-otp")
    public ResponseEntity<String> resendOtp(@RequestParam String email) {
        String response = userService.resendOtp(email);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginRequest request) {
        String response = userService.login(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logout(@RequestBody Map<String, String> body) {
        String emailOrMobile = body.get("emailOrMobile");
        String response = userService.logout(emailOrMobile);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/verify-forgot")
    public ResponseEntity<String> verifyEmailOrPhone(@RequestBody ForgotPasswordRequest request) {
        String response = userService.verifyEmailOrMobile(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/update-password")
    public ResponseEntity<String> updatePassword(@RequestBody UpdatePasswordRequest request) {
        String response = userService.updatePassword(request);
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/update/{userId}")
    public ResponseEntity<String> updateUser(
            @PathVariable Long userId,
            @RequestBody UserDTO userDTO) {
        String result = userService.updateUser(userId, userDTO);
        return ResponseEntity.ok(result);
    }
    
}
