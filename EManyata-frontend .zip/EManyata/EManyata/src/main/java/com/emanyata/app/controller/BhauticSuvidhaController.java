package com.emanyata.app.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.emanyata.app.dto.BhauticSuvidhaDTO;
import com.emanyata.app.service.BhautikSuvidhaService;

import java.util.*;

@RestController
@RequestMapping("/api/bhautic-suvidha")
public class BhauticSuvidhaController {

    @Autowired
    private BhautikSuvidhaService bhautikSuvidhaService;

    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> create(@RequestBody BhauticSuvidhaDTO dto) {
        BhauticSuvidhaDTO saved = bhautikSuvidhaService.save(dto);

        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", "Record created successfully.");
        response.put("data", saved);

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
    
    @PostMapping("getBySchoolId/{id}")
    public ResponseEntity<Map<String, Object>> create(@PathVariable Long id) {
        BhauticSuvidhaDTO saved = bhautikSuvidhaService.getBySchoolID(id);

        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", "Record Fetched successfully by School Id "+id);
        response.put("data", saved);

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
}

