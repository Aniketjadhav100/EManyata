package com.emanyata.app.serviceImpl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.emanyata.app.dto.SchoolTypeCountDTO;
import com.emanyata.app.dto.SchoolTypeCountResponseDTO;
import com.emanyata.app.repo.SchoolTypeCountRepository;
import com.emanyata.app.service.SchoolTypeCountService;

@Service
public class SchoolTypeCountServiceImpl implements SchoolTypeCountService {

    private final SchoolTypeCountRepository repository;

    public SchoolTypeCountServiceImpl(SchoolTypeCountRepository repository) {
        this.repository = repository;
    }

    @Override
    public SchoolTypeCountResponseDTO getSchoolTypeCounts() {
        Map<String, Long> countMap = new LinkedHashMap<>();
        countMap.put("granted", 0L);
        countMap.put("non-granted", 0L);
        countMap.put("permanently_unaided", 0L);
        countMap.put("self-finance", 0L);
        countMap.put("partially_granted", 0L);

        for (SchoolTypeCountDTO dto : repository.countBySchoolType()) {
            String type = dto.getSchoolType();
            Long count = dto.getCount();
            countMap.put(type, count);
        }

        List<SchoolTypeCountDTO> result = new ArrayList<>();
        Long total = 0L;
        for (Map.Entry<String, Long> entry : countMap.entrySet()) {
            result.add(new SchoolTypeCountDTO(entry.getKey(), entry.getValue()));
            total += entry.getValue();
        }

        return new SchoolTypeCountResponseDTO(result, total);
    }

}
