package com.emanyata.app.serviceImpl;

import com.emanyata.app.service.ImageService;

public class ImageServiceImpl implements ImageService {

}
