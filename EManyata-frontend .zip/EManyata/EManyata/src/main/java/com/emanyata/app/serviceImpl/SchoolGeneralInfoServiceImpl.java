package com.emanyata.app.serviceImpl;

import com.emanyata.app.service.SchoolGeneralInfoService;
import com.emanyata.app.dto.SchoolGeneralInfoDTO;
import com.emanyata.app.entity.School;
import com.emanyata.app.entity.SchoolGeneralInfo;
import com.emanyata.app.repo.SchoolGeneralInfoRepo;
import com.emanyata.app.repo.SchoolRepo;

import java.time.Instant;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SchoolGeneralInfoServiceImpl implements SchoolGeneralInfoService {

	@Autowired
	private SchoolGeneralInfoRepo schoolGeneralInfoRepository;

	@Autowired
	private SchoolRepo schoolRepo;

	@Override
	public SchoolGeneralInfo getSchoolById(Long id) {
		return schoolGeneralInfoRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("School info not found for ID: " + id));
	}

	@Override
	public SchoolGeneralInfo createSchoolInfo(SchoolGeneralInfoDTO dto) {
		SchoolGeneralInfo entity = new SchoolGeneralInfo();

		if (dto.getSchoolId() != null && dto.getApplicationId() != null) {
			Optional<SchoolGeneralInfo> existingSchoolGeneralInfo = schoolGeneralInfoRepository
					.findBySchoolId(dto.getSchoolId());

			if (existingSchoolGeneralInfo.isPresent()) {
				
					if(existingSchoolGeneralInfo.get().getApplicationId().equals(dto.getApplicationId())) {

				if (dto.getSchoolAddress() != null) {
				    existingSchoolGeneralInfo.get().setSchoolAddress(dto.getSchoolAddress());
				}
				if (dto.getAddressMentionedInGovernmentApprovalDocument() != null) {
				    existingSchoolGeneralInfo.get().setAddressMentionedInGovernmentApprovalDocument(dto.getAddressMentionedInGovernmentApprovalDocument());
				}
				if (dto.getSchoolEstablishmentYear() != null) {
				    existingSchoolGeneralInfo.get().setSchoolEstablishmentYear(dto.getSchoolEstablishmentYear());
				}
				if (dto.getDateOfFirstCommencementOfSchool() != null) {
				    existingSchoolGeneralInfo.get().setDateOfFirstCommencementOfSchool(dto.getDateOfFirstCommencementOfSchool());
				}
				if (dto.getSchoolAcademicSession() != null) {
				    existingSchoolGeneralInfo.get().setSchoolAcademicSession(dto.getSchoolAcademicSession());
				}
				if (dto.getSchoolTimeFullTime() != null) {
				    existingSchoolGeneralInfo.get().setSchoolTimeFullTime(dto.getSchoolTimeFullTime());
				}
				if (dto.getSchoolTimeHalfTime() != null) {
				    existingSchoolGeneralInfo.get().setSchoolTimeHalfTime(dto.getSchoolTimeHalfTime());
				}
				if (dto.getAcademicLearningTimeForEachClass() != null) {
				    existingSchoolGeneralInfo.get().setAcademicLearningTimeForEachClass(dto.getAcademicLearningTimeForEachClass());
				}
				if (dto.getLunchTimeForEachClass() != null) {
				    existingSchoolGeneralInfo.get().setLunchTimeForEachClass(dto.getLunchTimeForEachClass());
				}
				if (dto.getSportsAndPhysicalEducationTimeForEachClass() != null) {
				    existingSchoolGeneralInfo.get().setSportsAndPhysicalEducationTimeForEachClass(dto.getSportsAndPhysicalEducationTimeForEachClass());
				}
				if (dto.getNameOfTrustSocietyManagementCommittee() != null) {
				    existingSchoolGeneralInfo.get().setNameOfTrustSocietyManagementCommittee(dto.getNameOfTrustSocietyManagementCommittee());
				}
				if (dto.getRegistrationNo() != null) {
				    existingSchoolGeneralInfo.get().setRegistrationNo(dto.getRegistrationNo());
				}
				if (dto.getUnderTheSocietiesRegistrationAct1860() != null) {
				    existingSchoolGeneralInfo.get().setUnderTheSocietiesRegistrationAct1860(dto.getUnderTheSocietiesRegistrationAct1860());
				}
				if (dto.getUnderTheMumbaiPublicTrusteeSystemAct1950() != null) {
				    existingSchoolGeneralInfo.get().setUnderTheMumbaiPublicTrusteeSystemAct1950(dto.getUnderTheMumbaiPublicTrusteeSystemAct1950());
				}
				if (dto.getTillWhatPeriodTheRegistrationOfTrust() != null) {
				    existingSchoolGeneralInfo.get().setTillWhatPeriodTheRegistrationOfTrust(dto.getTillWhatPeriodTheRegistrationOfTrust());
				}
				if (dto.getIsThereEvidenceThatTheTrust() != null) {
				    existingSchoolGeneralInfo.get().setIsThereEvidenceThatTheTrust(dto.getIsThereEvidenceThatTheTrust());
				}
				if (dto.getSchoolUserName() != null) {
				    existingSchoolGeneralInfo.get().setSchoolUserName(dto.getSchoolUserName());
				}
				if (dto.getSchoolUserDegisnation() != null) {
				    existingSchoolGeneralInfo.get().setSchoolUserDegisnation(dto.getSchoolUserDegisnation());
				}
				if (dto.getSchoolUserAddress() != null) {
				    existingSchoolGeneralInfo.get().setSchoolUserAddress(dto.getSchoolUserAddress());
				}
				if (dto.getSchoolUserTelephone() != null) {
				    existingSchoolGeneralInfo.get().setSchoolUserTelephone(dto.getSchoolUserTelephone());
				}
				if (dto.getAccountYear() != null) {
				    existingSchoolGeneralInfo.get().setAccountYear(dto.getAccountYear());
				}
				if (dto.getAccountIncome() != null) {
				    existingSchoolGeneralInfo.get().setAccountIncome(dto.getAccountIncome());
				}
				if (dto.getAccountExpense() != null) {
				    existingSchoolGeneralInfo.get().setAccountExpense(dto.getAccountExpense());
				}
				if (dto.getAccountBalance() != null) {
				    existingSchoolGeneralInfo.get().setAccountBalance(dto.getAccountBalance());
				}
				if (dto.getForWhichYearYouWantToApplyForACertificate() != null) {
				    existingSchoolGeneralInfo.get().setForWhichYearYouWantToApplyForACertificate(dto.getForWhichYearYouWantToApplyForACertificate());
				}
				if (dto.getYearOfFoundationzOfSchool() != null) {
				    existingSchoolGeneralInfo.get().setYearOfFoundationzOfSchool(dto.getYearOfFoundationzOfSchool());
				}
				if (dto.getDateOfFirstOpeningOfSchool() != null) {
				    existingSchoolGeneralInfo.get().setDateOfFirstOpeningOfSchool(dto.getDateOfFirstOpeningOfSchool());
				}
				if (dto.getLowerStandard() != null) {
				    existingSchoolGeneralInfo.get().setLowerStandard(dto.getLowerStandard());
				}
				if (dto.getHigherStandard() != null) {
				    existingSchoolGeneralInfo.get().setHigherStandard(dto.getHigherStandard());
				}
				if (dto.getSchoolArea() != null) {
				    existingSchoolGeneralInfo.get().setSchoolArea(dto.getSchoolArea());
				}
				if (dto.getMediumOfInstruction() != null) {
				    existingSchoolGeneralInfo.get().setMediumOfInstruction(dto.getMediumOfInstruction());
				}
				if (dto.getSchoolBoard() != null) {
				    existingSchoolGeneralInfo.get().setSchoolBoard(dto.getSchoolBoard());
				}
				if (dto.getSangsthaCompanyName() != null) {
				    existingSchoolGeneralInfo.get().setSangsthaCompanyName(dto.getSangsthaCompanyName());
				}
				if (dto.getSansthaCompanyHasPurposeForOnlyEducationService() != null) {
				    existingSchoolGeneralInfo.get().setSansthaCompanyHasPurposeForOnlyEducationService(dto.getSansthaCompanyHasPurposeForOnlyEducationService());
				}
				if (dto.getIsSchoolOpenWhereAddressMentionedInApproval() != null) {
				    existingSchoolGeneralInfo.get().setIsSchoolOpenWhereAddressMentionedInApproval(dto.getIsSchoolOpenWhereAddressMentionedInApproval());
				}
				if (dto.getIfSansthaIsHandoverToSomeone() != null) {
				    existingSchoolGeneralInfo.get().setIfSansthaIsHandoverToSomeone(dto.getIfSansthaIsHandoverToSomeone());
				}
				if (dto.getDoYouHaveMaharastraShashanManyataNo() != null) {
				    existingSchoolGeneralInfo.get().setDoYouHaveMaharastraShashanManyataNo(dto.getDoYouHaveMaharastraShashanManyataNo());
				}
				if (dto.getMaharastraShashanApprovalNumber() != null) {
				    existingSchoolGeneralInfo.get().setMaharastraShashanApprovalNumber(dto.getMaharastraShashanApprovalNumber());
				}
				if (dto.getMaharastraShashanApprovalDate() != null) {
				    existingSchoolGeneralInfo.get().setMaharastraShashanApprovalDate(dto.getMaharastraShashanApprovalDate());
				}
				if (dto.getDoYouHaveShikshanUpsanchalakApproval() != null) {
				    existingSchoolGeneralInfo.get().setDoYouHaveShikshanUpsanchalakApproval(dto.getDoYouHaveShikshanUpsanchalakApproval());
				}
				if (dto.getShikshanUpsanchalakApprovalDate() != null) {
				    existingSchoolGeneralInfo.get().setShikshanUpsanchalakApprovalDate(dto.getShikshanUpsanchalakApprovalDate());
				}
				if (dto.getShikshanUpsanchalakApprovalNumber() != null) {
				    existingSchoolGeneralInfo.get().setShikshanUpsanchalakApprovalNumber(dto.getShikshanUpsanchalakApprovalNumber());
				}
				if (dto.getDoYouHavePrathamManyataCertificate() != null) {
				    existingSchoolGeneralInfo.get().setDoYouHavePrathamManyataCertificate(dto.getDoYouHavePrathamManyataCertificate());
				}
				if (dto.getPrathamManyataNumber() != null) {
				    existingSchoolGeneralInfo.get().setPrathamManyataNumber(dto.getPrathamManyataNumber());
				}
				if (dto.getPrathamManyataDate() != null) {
				    existingSchoolGeneralInfo.get().setPrathamManyataDate(dto.getPrathamManyataDate());
				}
				if (dto.getDoYouRunOnGovernmentNoObjectionCertificate() != null) {
				    existingSchoolGeneralInfo.get().setDoYouRunOnGovernmentNoObjectionCertificate(dto.getDoYouRunOnGovernmentNoObjectionCertificate());
				}
				if (dto.getNoObjectionCertificateNumber() != null) {
				    existingSchoolGeneralInfo.get().setNoObjectionCertificateNumber(dto.getNoObjectionCertificateNumber());
				}
				if (dto.getNoObjectionCertificateDate() != null) {
				    existingSchoolGeneralInfo.get().setNoObjectionCertificateDate(dto.getNoObjectionCertificateDate());
				}
				if (dto.getWhetherSchoolIsMovedToAnotherLocation() != null) {
				    existingSchoolGeneralInfo.get().setWhetherSchoolIsMovedToAnotherLocation(dto.getWhetherSchoolIsMovedToAnotherLocation());
				}
				if (dto.getMembers() != null) {
				    existingSchoolGeneralInfo.get().setMembers(dto.getMembers());
				}
				if (dto.getSimpleHigherStandard() != null) {
				    existingSchoolGeneralInfo.get().setSimpleHigherStandard(dto.getSimpleHigherStandard());
				}
				if (dto.getSimpleLowerStandard() != null) {
				    existingSchoolGeneralInfo.get().setSimpleLowerStandard(dto.getSimpleLowerStandard());
				}
				if (dto.getUdiseLowerStandard() != null) {
				    existingSchoolGeneralInfo.get().setUdiseLowerStandard(dto.getUdiseLowerStandard());
				}
				if (dto.getUdiseHigherStandard() != null) {
				    existingSchoolGeneralInfo.get().setUdiseHigherStandard(dto.getUdiseHigherStandard());
				}
				if (dto.getIsThereAnAffiliationCertificate() != null) {
				    existingSchoolGeneralInfo.get().setIsThereAnAffiliationCertificate(dto.getIsThereAnAffiliationCertificate());
				}
				if (dto.getAffiliationCertificateNumber() != null) {
				    existingSchoolGeneralInfo.get().setAffiliationCertificateNumber(dto.getAffiliationCertificateNumber());
				}
				if (dto.getAffiliationCertificateDate() != null) {
				    existingSchoolGeneralInfo.get().setAffiliationCertificateDate(dto.getAffiliationCertificateDate());
				}
				if (dto.getSection1InspectionApproval() != null) {
				    existingSchoolGeneralInfo.get().setSection1InspectionApproval(dto.getSection1InspectionApproval());
				}
				if (dto.getSection2InspectionApproval() != null) {
				    existingSchoolGeneralInfo.get().setSection2InspectionApproval(dto.getSection2InspectionApproval());
				}
				if (dto.getSection3InspectionApproval() != null) {
				    existingSchoolGeneralInfo.get().setSection3InspectionApproval(dto.getSection3InspectionApproval());
				}
				if (dto.getSection1InspectionComment() != null) {
				    existingSchoolGeneralInfo.get().setSection1InspectionComment(dto.getSection1InspectionComment());
				}
				if (dto.getSection2InspectionComment() != null) {
				    existingSchoolGeneralInfo.get().setSection2InspectionComment(dto.getSection2InspectionComment());
				}
				if (dto.getSection3InspectionComment() != null) {
				    existingSchoolGeneralInfo.get().setSection3InspectionComment(dto.getSection3InspectionComment());
				}
				return schoolGeneralInfoRepository.save(existingSchoolGeneralInfo.get());
				}else {
					throw new RuntimeException("No records Found with School Id "+dto.getSchoolId());
				}
				

			} else {

				School school = schoolRepo.findById(dto.getSchoolId())
						.orElseThrow(() -> new RuntimeException("School not found with ID: " + dto.getSchoolId()));
				entity.setSchool(school);

				entity.setId(dto.getId());
				entity.setSchoolAddress(dto.getSchoolAddress());
				entity.setAddressMentionedInGovernmentApprovalDocument(dto.getAddressMentionedInGovernmentApprovalDocument());
				entity.setSchoolEstablishmentYear(dto.getSchoolEstablishmentYear());
				
				entity.setDateOfFirstCommencementOfSchool(dto.getDateOfFirstCommencementOfSchool());
				entity.setSchoolAcademicSession(dto.getSchoolAcademicSession());
				entity.setSchoolTimeFullTime(dto.getSchoolTimeFullTime());
				entity.setSchoolTimeHalfTime(dto.getSchoolTimeHalfTime());
				
				entity.setAcademicLearningTimeForEachClass(dto.getAcademicLearningTimeForEachClass());
				entity.setLunchTimeForEachClass(dto.getLunchTimeForEachClass());
				entity.setSportsAndPhysicalEducationTimeForEachClass(dto.getSportsAndPhysicalEducationTimeForEachClass());

				entity.setNameOfTrustSocietyManagementCommittee(dto.getNameOfTrustSocietyManagementCommittee());
				entity.setRegistrationNo(dto.getRegistrationNo());
				entity.setUnderTheSocietiesRegistrationAct1860(dto.getUnderTheSocietiesRegistrationAct1860());
				
				entity.setUnderTheMumbaiPublicTrusteeSystemAct1950(dto.getUnderTheMumbaiPublicTrusteeSystemAct1950());
				entity.setTillWhatPeriodTheRegistrationOfTrust(dto.getTillWhatPeriodTheRegistrationOfTrust());
				entity.setIsThereEvidenceThatTheTrust(dto.getIsThereEvidenceThatTheTrust());

				entity.setSchoolUserName(dto.getSchoolUserName());
				entity.setSchoolUserDegisnation(dto.getSchoolUserDegisnation());
				entity.setSchoolUserAddress(dto.getSchoolUserAddress());
				entity.setSchoolUserTelephone(dto.getSchoolUserTelephone());

				entity.setAccountYear(dto.getAccountYear());
				entity.setAccountIncome(dto.getAccountIncome());
				entity.setAccountExpense(dto.getAccountExpense());
				entity.setAccountBalance(dto.getAccountBalance());

				entity.setApplicationId(dto.getApplicationId());
				entity.setCreatedAt(Instant.now());
				entity.setUpdatedAt(Instant.now());

				entity.setForWhichYearYouWantToApplyForACertificate(dto.getForWhichYearYouWantToApplyForACertificate());
				entity.setYearOfFoundationzOfSchool(dto.getYearOfFoundationzOfSchool());
				entity.setDateOfFirstOpeningOfSchool(dto.getDateOfFirstOpeningOfSchool());

				entity.setLowerStandard(dto.getLowerStandard());
				entity.setHigherStandard(dto.getHigherStandard());
				entity.setSchoolArea(dto.getSchoolArea());
				entity.setMediumOfInstruction(dto.getMediumOfInstruction());
				entity.setSchoolBoard(dto.getSchoolBoard());

				entity.setSangsthaCompanyName(dto.getSangsthaCompanyName());
				entity.setSansthaCompanyHasPurposeForOnlyEducationService(dto.getSansthaCompanyHasPurposeForOnlyEducationService());
				entity.setIsSchoolOpenWhereAddressMentionedInApproval(dto.getIsSchoolOpenWhereAddressMentionedInApproval());
				
				entity.setIfSansthaIsHandoverToSomeone(dto.getIfSansthaIsHandoverToSomeone());
				entity.setDoYouHaveMaharastraShashanManyataNo(dto.getDoYouHaveMaharastraShashanManyataNo());
				entity.setMaharastraShashanApprovalNumber(dto.getMaharastraShashanApprovalNumber());
				entity.setMaharastraShashanApprovalDate(dto.getMaharastraShashanApprovalDate());

				entity.setDoYouHaveShikshanUpsanchalakApproval(dto.getDoYouHaveShikshanUpsanchalakApproval());
				entity.setShikshanUpsanchalakApprovalDate(dto.getShikshanUpsanchalakApprovalDate());
				entity.setShikshanUpsanchalakApprovalNumber(dto.getShikshanUpsanchalakApprovalNumber());

				entity.setDoYouHavePrathamManyataCertificate(dto.getDoYouHavePrathamManyataCertificate());
				entity.setPrathamManyataNumber(dto.getPrathamManyataNumber());
				entity.setPrathamManyataDate(dto.getPrathamManyataDate());

				entity.setDoYouRunOnGovernmentNoObjectionCertificate(dto.getDoYouRunOnGovernmentNoObjectionCertificate());
				entity.setNoObjectionCertificateNumber(dto.getNoObjectionCertificateNumber());
				entity.setNoObjectionCertificateDate(dto.getNoObjectionCertificateDate());

				entity.setWhetherSchoolIsMovedToAnotherLocation(dto.getWhetherSchoolIsMovedToAnotherLocation());
				entity.setMembers(dto.getMembers());

				entity.setSimpleHigherStandard(dto.getSimpleHigherStandard());
				entity.setSimpleLowerStandard(dto.getSimpleLowerStandard());
				entity.setUdiseLowerStandard(dto.getUdiseLowerStandard());
				entity.setUdiseHigherStandard(dto.getUdiseHigherStandard());

				entity.setIsThereAnAffiliationCertificate(dto.getIsThereAnAffiliationCertificate());
				entity.setAffiliationCertificateNumber(dto.getAffiliationCertificateNumber());
				entity.setAffiliationCertificateDate(dto.getAffiliationCertificateDate());

				entity.setSection1InspectionApproval(dto.getSection1InspectionApproval());
				entity.setSection2InspectionApproval(dto.getSection2InspectionApproval());
				entity.setSection3InspectionApproval(dto.getSection3InspectionApproval());

				entity.setSection1InspectionComment(dto.getSection1InspectionComment());
				entity.setSection2InspectionComment(dto.getSection2InspectionComment());
				entity.setSection3InspectionComment(dto.getSection3InspectionComment());

				return schoolGeneralInfoRepository.save(existingSchoolGeneralInfo.get());

			}
		}else {
			throw new RuntimeException("Application ID Or School Id not Provided..");
		}
	}

}
