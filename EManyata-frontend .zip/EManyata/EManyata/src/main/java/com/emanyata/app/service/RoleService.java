package com.emanyata.app.service;

public interface RoleService {

}
