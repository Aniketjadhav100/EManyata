package com.emanyata.app.serviceImpl;

import com.emanyata.app.service.RoleService;

public class RoleServiceImpl implements RoleService {

}
