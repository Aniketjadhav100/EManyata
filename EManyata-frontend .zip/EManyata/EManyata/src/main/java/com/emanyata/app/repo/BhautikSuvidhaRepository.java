package com.emanyata.app.repo;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.emanyata.app.entity.BhauticSuvidha;


@Repository
public interface BhautikSuvidhaRepository extends JpaRepository<BhauticSuvidha, Long> {
	BhauticSuvidha getBySchoolId(Long id); 
	Optional<BhauticSuvidha> findBySchoolId(Long id);
}
