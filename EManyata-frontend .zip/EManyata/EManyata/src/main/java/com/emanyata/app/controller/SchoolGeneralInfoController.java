package com.emanyata.app.controller;

import com.emanyata.app.dto.SchoolGeneralInfoDTO;
import com.emanyata.app.entity.SchoolGeneralInfo;
import com.emanyata.app.service.SchoolGeneralInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/school-general-info")
public class SchoolGeneralInfoController {

    @Autowired
    private SchoolGeneralInfoService schoolGeneralInfoService;

    // 🔹 Create SchoolGeneralInfo
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createSchoolInfo(@RequestBody SchoolGeneralInfoDTO dto) {
        Map<String, Object> response = new HashMap<>();
        try {
            SchoolGeneralInfo savedInfo = schoolGeneralInfoService.createSchoolInfo(dto);
            response.put("status", "success");
            response.put("message", "School general info created successfully.");
            response.put("data", savedInfo);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            response.put("status", "failure");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }

    // 🔹 Get SchoolGeneralInfo by ID
    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getSchoolInfoById(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        try {
            SchoolGeneralInfo info = schoolGeneralInfoService.getSchoolById(id);
            response.put("status", "success");
            response.put("message", "School general info fetched successfully.");
            response.put("data", info);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (RuntimeException e) {
            response.put("status", "failure");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }
}
