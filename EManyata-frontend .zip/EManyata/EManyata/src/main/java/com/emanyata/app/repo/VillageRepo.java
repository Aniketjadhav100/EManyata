package com.emanyata.app.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.Village;


public interface VillageRepo extends JpaRepository<Village, Long> {
	Optional<Village> findByNameAndTaluka_Id(String name, Long talukaId);
    Optional<Village> findByName(String name);

}