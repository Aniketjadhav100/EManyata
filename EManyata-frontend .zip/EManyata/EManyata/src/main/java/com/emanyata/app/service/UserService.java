package com.emanyata.app.service;

import com.emanyata.app.authdto.ForgotPasswordRequest;
import com.emanyata.app.authdto.LoginRequest;
import com.emanyata.app.authdto.OtpRequest;
import com.emanyata.app.authdto.UpdatePasswordRequest;
import com.emanyata.app.authdto.UserDTO;



public interface UserService {

	String register(UserDTO userDto);

    String verifyOtp(OtpRequest otpRequest);

    String resendOtp(String email);

    String login(LoginRequest request);

    String logout(String emailOrMobile);

    String verifyEmailOrMobile(ForgotPasswordRequest request);

    String updatePassword(UpdatePasswordRequest request);

	String updateUser(Long userId, UserDTO dto);   
    
    
}
