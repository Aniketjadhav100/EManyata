package com.emanyata.app.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emanyata.app.entity.SchoolGeneralInfo;

public interface SchoolGeneralInfoRepo extends JpaRepository<SchoolGeneralInfo, Long> {
	Optional<SchoolGeneralInfo> findBySchoolId(Long school_id);
	Optional<SchoolGeneralInfo> findByApplicationId(Long application_id);
}
