package com.emanyata.app.entity;

import jakarta.persistence.*;

import java.time.Instant;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;


@Entity
@Table(name = "school_general_infos", schema = "emanyata")
public class SchoolGeneralInfo {
    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "school_id", nullable = false)
    @JsonIgnore
    private School school;

    @Size(max = 255)
    @Column(name = "school_address")
    private String schoolAddress;

    @Size(max = 255)
    @Column(name = "address_mentioned_in_government_approval_document")
    private String addressMentionedInGovernmentApprovalDocument;

    @Size(max = 255)
    @Column(name = "school_establishment_year")
    private String schoolEstablishmentYear;

    @Size(max = 255)
    @Column(name = "date_of_first_commencement_of_school")
    private String dateOfFirstCommencementOfSchool;

    @Size(max = 255)
    @Column(name = "school_academic_session")
    private String schoolAcademicSession;

    @Size(max = 255)
    @Column(name = "school_time_full_time")
    private String schoolTimeFullTime;

    @Size(max = 255)
    @Column(name = "school_time_half_time")
    private String schoolTimeHalfTime;

    @Size(max = 255)
    @Column(name = "academic_learning_time_for_each_class")
    private String academicLearningTimeForEachClass;

    @Size(max = 255)
    @Column(name = "lunch_time_for_each_class")
    private String lunchTimeForEachClass;

    @Size(max = 255)
    @Column(name = "sports_and_physical_education_time_for_each_class")
    private String sportsAndPhysicalEducationTimeForEachClass;

    @Size(max = 255)
    @Column(name = "name_of_trust_society_management_committee")
    private String nameOfTrustSocietyManagementCommittee;

    @Size(max = 255)
    @Column(name = "registration_no")
    private String registrationNo;

    @Size(max = 255)
    @Column(name = "under_the_societies_registration_act_1860")
    private String underTheSocietiesRegistrationAct1860;

    @Size(max = 255)
    @Column(name = "under_the_mumbai_public_trustee_system_act_1950")
    private String underTheMumbaiPublicTrusteeSystemAct1950;

    @Size(max = 255)
    @Column(name = "till_what_period_the_registration_of_trust")
    private String tillWhatPeriodTheRegistrationOfTrust;

    @Size(max = 255)
    @Column(name = "is_there_evidence_that_the_trust")
    private String isThereEvidenceThatTheTrust;

    @Lob
    @Column(name = "school_user_name")
    private String schoolUserName;

    @Lob
    @Column(name = "school_user_degisnation")
    private String schoolUserDegisnation;

    @Lob
    @Column(name = "school_user_address")
    private String schoolUserAddress;

    @Lob
    @Column(name = "school_user_telephone")
    private String schoolUserTelephone;

    @Lob
    @Column(name = "account_year")
    private String accountYear;

    @Lob
    @Column(name = "account_income")
    private String accountIncome;

    @Lob
    @Column(name = "account_expense")
    private String accountExpense;

    @Lob
    @Column(name = "account_balance")
    private String accountBalance;

    @Column(name = "created_at")
    private Instant createdAt;

    @Column(name = "updated_at")
    private Instant updatedAt;

    @Column(name = "application_id", nullable = false)
    private Long applicationId;

    @Size(max = 255)
    @Column(name = "for_which_year_you_want_to_apply_for_a_certificate")
    private String forWhichYearYouWantToApplyForACertificate;

    @Size(max = 255)
    @Column(name = "year_Of_foundationz_of_school")
    private String yearOfFoundationzOfSchool;

    @Size(max = 255)
    @Column(name = "date_Of_first_opening_of_school")
    private String dateOfFirstOpeningOfSchool;

    @Size(max = 50)
    @Column(name = "lower_standard", length = 50)
    private String lowerStandard;

    @Size(max = 50)
    @Column(name = "higher_standard", length = 50)
    private String higherStandard;

    @Size(max = 50)
    @Column(name = "school_area", length = 50)
    private String schoolArea;

    @Size(max = 50)
    @Column(name = "medium_of_instruction", length = 50)
    private String mediumOfInstruction;

    @Size(max = 50)
    @Column(name = "school_board", length = 50)
    private String schoolBoard;

    @Size(max = 255)
    @Column(name = "sangstha_company_name")
    private String sangsthaCompanyName;

    @Size(max = 255)
    @Column(name = "sanstha_company_has_purpose_for_only_education_service")
    private String sansthaCompanyHasPurposeForOnlyEducationService;

    @Size(max = 255)
    @Column(name = "is_school_open_where_address_mentioned_in_approval")
    private String isSchoolOpenWhereAddressMentionedInApproval;

    @Size(max = 255)
    @Column(name = "if_sanstha_is_handover_to_someone")
    private String ifSansthaIsHandoverToSomeone;

    @Size(max = 255)
    @Column(name = "do_you_have_maharastra_shashan_manyata_no")
    private String doYouHaveMaharastraShashanManyataNo;

    @Size(max = 255)
    @Column(name = "maharastra_shashan_approval_number")
    private String maharastraShashanApprovalNumber;

    @Size(max = 255)
    @Column(name = "maharastra_shashan_approval_date")
    private String maharastraShashanApprovalDate;

    @Size(max = 255)
    @Column(name = "do_you_have_shikshan_upSanchalak_approval")
    private String doYouHaveShikshanUpsanchalakApproval;

    @Size(max = 255)
    @Column(name = "shikshan_upSanchalak_approval_date")
    private String shikshanUpsanchalakApprovalDate;

    @Size(max = 255)
    @Column(name = "shikshan_upSanchalak_approval_number")
    private String shikshanUpsanchalakApprovalNumber;

    @Size(max = 255)
    @Column(name = "do_you_have_pratham_manyata_certificate")
    private String doYouHavePrathamManyataCertificate;

    @Size(max = 255)
    @Column(name = "pratham_manyata_number")
    private String prathamManyataNumber;

    @Size(max = 255)
    @Column(name = "pratham_manyata_date")
    private String prathamManyataDate;

    @Size(max = 255)
    @Column(name = "do_you_run_on_government_no_objection_certificate")
    private String doYouRunOnGovernmentNoObjectionCertificate;

    @Size(max = 255)
    @Column(name = "no_objection_certificate_number")
    private String noObjectionCertificateNumber;

    @Size(max = 255)
    @Column(name = "no_objection_certificate_date")
    private String noObjectionCertificateDate;

    @Size(max = 255)
    @Column(name = "whether_school_is_moved_to_another_location")
    private String whetherSchoolIsMovedToAnotherLocation;

    @Lob
    @Column(name = "members")
    private String members;

    @Size(max = 255)
    @Column(name = "simple_higher_standard")
    private String simpleHigherStandard;

    @Size(max = 255)
    @Column(name = "simple_lower_standard")
    private String simpleLowerStandard;

    @Size(max = 255)
    @Column(name = "UDISE_lower_standard")
    private String udiseLowerStandard;

    @Size(max = 255)
    @Column(name = "UDISE_higher_standard")
    private String udiseHigherStandard;

    @Size(max = 255)
    @Column(name = "is_there_an_affiliation_certificate")
    private String isThereAnAffiliationCertificate;

    @Size(max = 255)
    @Column(name = "affiliation_certificate_number")
    private String affiliationCertificateNumber;

    @Size(max = 255)
    @Column(name = "affiliation_certificate_date")
    private String affiliationCertificateDate;

    @Size(max = 50)
    @Column(name = "section1_inspection_approval", length = 50)
    private String section1InspectionApproval;

    @Size(max = 50)
    @Column(name = "section2_inspection_approval", length = 50)
    private String section2InspectionApproval;

    @Size(max = 50)
    @Column(name = "section3_inspection_approval", length = 50)
    private String section3InspectionApproval;

    @Size(max = 255)
    @Column(name = "section1_inspection_comment")
    private String section1InspectionComment;

    @Size(max = 255)
    @Column(name = "section2_inspection_comment")
    private String section2InspectionComment;

    @Size(max = 255)
    @Column(name = "section3_inspection_comment")
    private String section3InspectionComment;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public School getSchool() {
        return school;
    }

    public void setSchool(School school) {
        this.school = school;
    }

    public String getSchoolAddress() {
        return schoolAddress;
    }

    public void setSchoolAddress(String schoolAddress) {
        this.schoolAddress = schoolAddress;
    }

    public String getAddressMentionedInGovernmentApprovalDocument() {
        return addressMentionedInGovernmentApprovalDocument;
    }

    public void setAddressMentionedInGovernmentApprovalDocument(String addressMentionedInGovernmentApprovalDocument) {
        this.addressMentionedInGovernmentApprovalDocument = addressMentionedInGovernmentApprovalDocument;
    }

    public String getSchoolEstablishmentYear() {
        return schoolEstablishmentYear;
    }

    public void setSchoolEstablishmentYear(String schoolEstablishmentYear) {
        this.schoolEstablishmentYear = schoolEstablishmentYear;
    }

    public String getDateOfFirstCommencementOfSchool() {
        return dateOfFirstCommencementOfSchool;
    }

    public void setDateOfFirstCommencementOfSchool(String dateOfFirstCommencementOfSchool) {
        this.dateOfFirstCommencementOfSchool = dateOfFirstCommencementOfSchool;
    }

    public String getSchoolAcademicSession() {
        return schoolAcademicSession;
    }

    public void setSchoolAcademicSession(String schoolAcademicSession) {
        this.schoolAcademicSession = schoolAcademicSession;
    }

    public String getSchoolTimeFullTime() {
        return schoolTimeFullTime;
    }

    public void setSchoolTimeFullTime(String schoolTimeFullTime) {
        this.schoolTimeFullTime = schoolTimeFullTime;
    }

    public String getSchoolTimeHalfTime() {
        return schoolTimeHalfTime;
    }

    public void setSchoolTimeHalfTime(String schoolTimeHalfTime) {
        this.schoolTimeHalfTime = schoolTimeHalfTime;
    }

    public String getAcademicLearningTimeForEachClass() {
        return academicLearningTimeForEachClass;
    }

    public void setAcademicLearningTimeForEachClass(String academicLearningTimeForEachClass) {
        this.academicLearningTimeForEachClass = academicLearningTimeForEachClass;
    }

    public String getLunchTimeForEachClass() {
        return lunchTimeForEachClass;
    }

    public void setLunchTimeForEachClass(String lunchTimeForEachClass) {
        this.lunchTimeForEachClass = lunchTimeForEachClass;
    }

    public String getSportsAndPhysicalEducationTimeForEachClass() {
        return sportsAndPhysicalEducationTimeForEachClass;
    }

    public void setSportsAndPhysicalEducationTimeForEachClass(String sportsAndPhysicalEducationTimeForEachClass) {
        this.sportsAndPhysicalEducationTimeForEachClass = sportsAndPhysicalEducationTimeForEachClass;
    }

    public String getNameOfTrustSocietyManagementCommittee() {
        return nameOfTrustSocietyManagementCommittee;
    }

    public void setNameOfTrustSocietyManagementCommittee(String nameOfTrustSocietyManagementCommittee) {
        this.nameOfTrustSocietyManagementCommittee = nameOfTrustSocietyManagementCommittee;
    }

    public String getRegistrationNo() {
        return registrationNo;
    }

    public void setRegistrationNo(String registrationNo) {
        this.registrationNo = registrationNo;
    }

    public String getUnderTheSocietiesRegistrationAct1860() {
        return underTheSocietiesRegistrationAct1860;
    }

    public void setUnderTheSocietiesRegistrationAct1860(String underTheSocietiesRegistrationAct1860) {
        this.underTheSocietiesRegistrationAct1860 = underTheSocietiesRegistrationAct1860;
    }

    public String getUnderTheMumbaiPublicTrusteeSystemAct1950() {
        return underTheMumbaiPublicTrusteeSystemAct1950;
    }

    public void setUnderTheMumbaiPublicTrusteeSystemAct1950(String underTheMumbaiPublicTrusteeSystemAct1950) {
        this.underTheMumbaiPublicTrusteeSystemAct1950 = underTheMumbaiPublicTrusteeSystemAct1950;
    }

    public String getTillWhatPeriodTheRegistrationOfTrust() {
        return tillWhatPeriodTheRegistrationOfTrust;
    }

    public void setTillWhatPeriodTheRegistrationOfTrust(String tillWhatPeriodTheRegistrationOfTrust) {
        this.tillWhatPeriodTheRegistrationOfTrust = tillWhatPeriodTheRegistrationOfTrust;
    }

    public String getIsThereEvidenceThatTheTrust() {
        return isThereEvidenceThatTheTrust;
    }

    public void setIsThereEvidenceThatTheTrust(String isThereEvidenceThatTheTrust) {
        this.isThereEvidenceThatTheTrust = isThereEvidenceThatTheTrust;
    }

    public String getSchoolUserName() {
        return schoolUserName;
    }

    public void setSchoolUserName(String schoolUserName) {
        this.schoolUserName = schoolUserName;
    }

    public String getSchoolUserDegisnation() {
        return schoolUserDegisnation;
    }

    public void setSchoolUserDegisnation(String schoolUserDegisnation) {
        this.schoolUserDegisnation = schoolUserDegisnation;
    }

    public String getSchoolUserAddress() {
        return schoolUserAddress;
    }

    public void setSchoolUserAddress(String schoolUserAddress) {
        this.schoolUserAddress = schoolUserAddress;
    }

    public String getSchoolUserTelephone() {
        return schoolUserTelephone;
    }

    public void setSchoolUserTelephone(String schoolUserTelephone) {
        this.schoolUserTelephone = schoolUserTelephone;
    }

    public String getAccountYear() {
        return accountYear;
    }

    public void setAccountYear(String accountYear) {
        this.accountYear = accountYear;
    }

    public String getAccountIncome() {
        return accountIncome;
    }

    public void setAccountIncome(String accountIncome) {
        this.accountIncome = accountIncome;
    }

    public String getAccountExpense() {
        return accountExpense;
    }

    public void setAccountExpense(String accountExpense) {
        this.accountExpense = accountExpense;
    }

    public String getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(String accountBalance) {
        this.accountBalance = accountBalance;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long applicationId) {
        this.applicationId = applicationId;
    }

    public String getForWhichYearYouWantToApplyForACertificate() {
        return forWhichYearYouWantToApplyForACertificate;
    }

    public void setForWhichYearYouWantToApplyForACertificate(String forWhichYearYouWantToApplyForACertificate) {
        this.forWhichYearYouWantToApplyForACertificate = forWhichYearYouWantToApplyForACertificate;
    }

    public String getYearOfFoundationzOfSchool() {
        return yearOfFoundationzOfSchool;
    }

    public void setYearOfFoundationzOfSchool(String yearOfFoundationzOfSchool) {
        this.yearOfFoundationzOfSchool = yearOfFoundationzOfSchool;
    }

    public String getDateOfFirstOpeningOfSchool() {
        return dateOfFirstOpeningOfSchool;
    }

    public void setDateOfFirstOpeningOfSchool(String dateOfFirstOpeningOfSchool) {
        this.dateOfFirstOpeningOfSchool = dateOfFirstOpeningOfSchool;
    }

    public String getLowerStandard() {
        return lowerStandard;
    }

    public void setLowerStandard(String lowerStandard) {
        this.lowerStandard = lowerStandard;
    }

    public String getHigherStandard() {
        return higherStandard;
    }

    public void setHigherStandard(String higherStandard) {
        this.higherStandard = higherStandard;
    }

    public String getSchoolArea() {
        return schoolArea;
    }

    public void setSchoolArea(String schoolArea) {
        this.schoolArea = schoolArea;
    }

    public String getMediumOfInstruction() {
        return mediumOfInstruction;
    }

    public void setMediumOfInstruction(String mediumOfInstruction) {
        this.mediumOfInstruction = mediumOfInstruction;
    }

    public String getSchoolBoard() {
        return schoolBoard;
    }

    public void setSchoolBoard(String schoolBoard) {
        this.schoolBoard = schoolBoard;
    }

    public String getSangsthaCompanyName() {
        return sangsthaCompanyName;
    }

    public void setSangsthaCompanyName(String sangsthaCompanyName) {
        this.sangsthaCompanyName = sangsthaCompanyName;
    }

    public String getSansthaCompanyHasPurposeForOnlyEducationService() {
        return sansthaCompanyHasPurposeForOnlyEducationService;
    }

    public void setSansthaCompanyHasPurposeForOnlyEducationService(String sansthaCompanyHasPurposeForOnlyEducationService) {
        this.sansthaCompanyHasPurposeForOnlyEducationService = sansthaCompanyHasPurposeForOnlyEducationService;
    }

    public String getIsSchoolOpenWhereAddressMentionedInApproval() {
        return isSchoolOpenWhereAddressMentionedInApproval;
    }

    public void setIsSchoolOpenWhereAddressMentionedInApproval(String isSchoolOpenWhereAddressMentionedInApproval) {
        this.isSchoolOpenWhereAddressMentionedInApproval = isSchoolOpenWhereAddressMentionedInApproval;
    }

    public String getIfSansthaIsHandoverToSomeone() {
        return ifSansthaIsHandoverToSomeone;
    }

    public void setIfSansthaIsHandoverToSomeone(String ifSansthaIsHandoverToSomeone) {
        this.ifSansthaIsHandoverToSomeone = ifSansthaIsHandoverToSomeone;
    }

    public String getDoYouHaveMaharastraShashanManyataNo() {
        return doYouHaveMaharastraShashanManyataNo;
    }

    public void setDoYouHaveMaharastraShashanManyataNo(String doYouHaveMaharastraShashanManyataNo) {
        this.doYouHaveMaharastraShashanManyataNo = doYouHaveMaharastraShashanManyataNo;
    }

    public String getMaharastraShashanApprovalNumber() {
        return maharastraShashanApprovalNumber;
    }

    public void setMaharastraShashanApprovalNumber(String maharastraShashanApprovalNumber) {
        this.maharastraShashanApprovalNumber = maharastraShashanApprovalNumber;
    }

    public String getMaharastraShashanApprovalDate() {
        return maharastraShashanApprovalDate;
    }

    public void setMaharastraShashanApprovalDate(String maharastraShashanApprovalDate) {
        this.maharastraShashanApprovalDate = maharastraShashanApprovalDate;
    }

    public String getDoYouHaveShikshanUpsanchalakApproval() {
        return doYouHaveShikshanUpsanchalakApproval;
    }

    public void setDoYouHaveShikshanUpsanchalakApproval(String doYouHaveShikshanUpsanchalakApproval) {
        this.doYouHaveShikshanUpsanchalakApproval = doYouHaveShikshanUpsanchalakApproval;
    }

    public String getShikshanUpsanchalakApprovalDate() {
        return shikshanUpsanchalakApprovalDate;
    }

    public void setShikshanUpsanchalakApprovalDate(String shikshanUpsanchalakApprovalDate) {
        this.shikshanUpsanchalakApprovalDate = shikshanUpsanchalakApprovalDate;
    }

    public String getShikshanUpsanchalakApprovalNumber() {
        return shikshanUpsanchalakApprovalNumber;
    }

    public void setShikshanUpsanchalakApprovalNumber(String shikshanUpsanchalakApprovalNumber) {
        this.shikshanUpsanchalakApprovalNumber = shikshanUpsanchalakApprovalNumber;
    }

    public String getDoYouHavePrathamManyataCertificate() {
        return doYouHavePrathamManyataCertificate;
    }

    public void setDoYouHavePrathamManyataCertificate(String doYouHavePrathamManyataCertificate) {
        this.doYouHavePrathamManyataCertificate = doYouHavePrathamManyataCertificate;
    }

    public String getPrathamManyataNumber() {
        return prathamManyataNumber;
    }

    public void setPrathamManyataNumber(String prathamManyataNumber) {
        this.prathamManyataNumber = prathamManyataNumber;
    }

    public String getPrathamManyataDate() {
        return prathamManyataDate;
    }

    public void setPrathamManyataDate(String prathamManyataDate) {
        this.prathamManyataDate = prathamManyataDate;
    }

    public String getDoYouRunOnGovernmentNoObjectionCertificate() {
        return doYouRunOnGovernmentNoObjectionCertificate;
    }

    public void setDoYouRunOnGovernmentNoObjectionCertificate(String doYouRunOnGovernmentNoObjectionCertificate) {
        this.doYouRunOnGovernmentNoObjectionCertificate = doYouRunOnGovernmentNoObjectionCertificate;
    }

    public String getNoObjectionCertificateNumber() {
        return noObjectionCertificateNumber;
    }

    public void setNoObjectionCertificateNumber(String noObjectionCertificateNumber) {
        this.noObjectionCertificateNumber = noObjectionCertificateNumber;
    }

    public String getNoObjectionCertificateDate() {
        return noObjectionCertificateDate;
    }

    public void setNoObjectionCertificateDate(String noObjectionCertificateDate) {
        this.noObjectionCertificateDate = noObjectionCertificateDate;
    }

    public String getWhetherSchoolIsMovedToAnotherLocation() {
        return whetherSchoolIsMovedToAnotherLocation;
    }

    public void setWhetherSchoolIsMovedToAnotherLocation(String whetherSchoolIsMovedToAnotherLocation) {
        this.whetherSchoolIsMovedToAnotherLocation = whetherSchoolIsMovedToAnotherLocation;
    }

    public String getMembers() {
        return members;
    }

    public void setMembers(String members) {
        this.members = members;
    }

    public String getSimpleHigherStandard() {
        return simpleHigherStandard;
    }

    public void setSimpleHigherStandard(String simpleHigherStandard) {
        this.simpleHigherStandard = simpleHigherStandard;
    }

    public String getSimpleLowerStandard() {
        return simpleLowerStandard;
    }

    public void setSimpleLowerStandard(String simpleLowerStandard) {
        this.simpleLowerStandard = simpleLowerStandard;
    }

    public String getUdiseLowerStandard() {
        return udiseLowerStandard;
    }

    public void setUdiseLowerStandard(String udiseLowerStandard) {
        this.udiseLowerStandard = udiseLowerStandard;
    }

    public String getUdiseHigherStandard() {
        return udiseHigherStandard;
    }

    public void setUdiseHigherStandard(String udiseHigherStandard) {
        this.udiseHigherStandard = udiseHigherStandard;
    }

    public String getIsThereAnAffiliationCertificate() {
        return isThereAnAffiliationCertificate;
    }

    public void setIsThereAnAffiliationCertificate(String isThereAnAffiliationCertificate) {
        this.isThereAnAffiliationCertificate = isThereAnAffiliationCertificate;
    }

    public String getAffiliationCertificateNumber() {
        return affiliationCertificateNumber;
    }

    public void setAffiliationCertificateNumber(String affiliationCertificateNumber) {
        this.affiliationCertificateNumber = affiliationCertificateNumber;
    }

    public String getAffiliationCertificateDate() {
        return affiliationCertificateDate;
    }

    public void setAffiliationCertificateDate(String affiliationCertificateDate) {
        this.affiliationCertificateDate = affiliationCertificateDate;
    }

    public String getSection1InspectionApproval() {
        return section1InspectionApproval;
    }

    public void setSection1InspectionApproval(String section1InspectionApproval) {
        this.section1InspectionApproval = section1InspectionApproval;
    }

    public String getSection2InspectionApproval() {
        return section2InspectionApproval;
    }

    public void setSection2InspectionApproval(String section2InspectionApproval) {
        this.section2InspectionApproval = section2InspectionApproval;
    }

    public String getSection3InspectionApproval() {
        return section3InspectionApproval;
    }

    public void setSection3InspectionApproval(String section3InspectionApproval) {
        this.section3InspectionApproval = section3InspectionApproval;
    }

    public String getSection1InspectionComment() {
        return section1InspectionComment;
    }

    public void setSection1InspectionComment(String section1InspectionComment) {
        this.section1InspectionComment = section1InspectionComment;
    }

    public String getSection2InspectionComment() {
        return section2InspectionComment;
    }

    public void setSection2InspectionComment(String section2InspectionComment) {
        this.section2InspectionComment = section2InspectionComment;
    }

    public String getSection3InspectionComment() {
        return section3InspectionComment;
    }

    public void setSection3InspectionComment(String section3InspectionComment) {
        this.section3InspectionComment = section3InspectionComment;
    }

}