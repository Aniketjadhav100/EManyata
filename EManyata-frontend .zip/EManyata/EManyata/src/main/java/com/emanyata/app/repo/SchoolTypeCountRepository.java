package com.emanyata.app.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.emanyata.app.dto.SchoolTypeCountDTO;
import com.emanyata.app.entity.School;

public interface SchoolTypeCountRepository extends CrudRepository<School, Long> {
	
	@Query("SELECT new com.emanyata.app.dto.SchoolTypeCountDTO(s.schoolType, COUNT(s)) " +
		       "FROM School s GROUP BY s.schoolType")
	List<SchoolTypeCountDTO> countBySchoolType();
}
