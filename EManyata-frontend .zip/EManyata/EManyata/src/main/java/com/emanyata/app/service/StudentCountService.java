package com.emanyata.app.service;


import com.emanyata.app.dto.StudentCountDTO;


public interface StudentCountService {
    StudentCountDTO createStudentCount(StudentCountDTO dto);
    StudentCountDTO getStudentCountBySchoolId(Long schoolId);
}