package com.emanyata.app.controller;

import com.emanyata.app.dto.TrackingLogDTO;
import com.emanyata.app.service.TrackingLogService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/tracking-logs")
public class TrackingLogController {

    @Autowired
    private TrackingLogService trackingLogService;

    // Create new TrackingLog
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createTrackingLog(@RequestBody TrackingLogDTO logDto) {
        Map<String, Object> response = new HashMap<>();
        try {
            TrackingLogDTO createdLog = trackingLogService.createTrackingLog(logDto);  // Returns DTO
            response.put("status", "success");
            response.put("message", "Tracking log created successfully.");
            response.put("data", createdLog);  // Send DTO instead of entity
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            response.put("status", "failure");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }

    // Get TrackingLog by application number
    @PostMapping("/application/{number}")
    public ResponseEntity<Map<String, Object>> getTrackingLogByApplicationNo(@PathVariable String number) {
        Map<String, Object> response = new HashMap<>();
        try {
            TrackingLogDTO log = trackingLogService.findByApplicationNo(number);  // Returns DTO
            response.put("status", "success");
            response.put("message", "Tracking log retrieved successfully.");
            response.put("data", log);  // Send DTO instead of entity
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (RuntimeException e) {
            response.put("status", "failure");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }
}
