package com.emanyata.app.serviceImpl;

import com.emanyata.app.dto.SchoolDTO;
import com.emanyata.app.entity.School;
import com.emanyata.app.entity.User;
import com.emanyata.app.repo.SchoolRepo;
import com.emanyata.app.repo.UserRepo;
import com.emanyata.app.service.SchoolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class SchoolServiceImpl implements SchoolService {

    @Autowired
    private SchoolRepo schoolRepo;

    @Override
    public School save(School school) {
        return schoolRepo.save(school);
    }

    @Override
    public SchoolDTO getSchoolByUdiseNo(String udiseNo) {
        // Fetch the school from the repository
        Optional<School> schoolOptional = schoolRepo.findByUdiseNo(udiseNo);
        
        // If school is not found, return null or you can handle it differently
        if (!schoolOptional.isPresent()) {
            return null;
        }
        
        School school = schoolOptional.get();
        
        // Map entity to DTO
        SchoolDTO schoolDTO = new SchoolDTO();
        schoolDTO.setId(school.getId());
        schoolDTO.setSchoolName(school.getSchoolName());
        schoolDTO.setUdiseNo(school.getUdiseNo());
        schoolDTO.setTransactionalAddress(school.getTransactionalAddress());
        schoolDTO.setDistrict(school.getDistrict());
        schoolDTO.setPincode(school.getPincode());
        schoolDTO.setTelephoneNumber(school.getTelephoneNumber());
        schoolDTO.setSchoolMobile(school.getSchoolMobile());
        schoolDTO.setPoliceStation(school.getPoliceStation());
        schoolDTO.setSchoolType(school.getSchoolType());
        schoolDTO.setCreatedAt(school.getCreatedat());
        schoolDTO.setUpdatedAt(school.getUpdatedat());

        // Handling the Taluka, Village, and User associations
        if (school.getTaluka() != null) {
            schoolDTO.setTalukaId(school.getTaluka().getId());  // Assuming 'Taluka' has 'getId()'
        }
        if (school.getVillage() != null) {
            schoolDTO.setVillageId(school.getVillage().getId());  // Assuming 'Village' has 'getId()'
        }
        if (school.getUser_id() != null) {
            schoolDTO.setUserId(school.getUser_id().getId());  // Assuming 'User' has 'getId()'
        }

        return schoolDTO;
    }
}
