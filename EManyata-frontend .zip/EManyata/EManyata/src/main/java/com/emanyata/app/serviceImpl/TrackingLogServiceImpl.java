package com.emanyata.app.serviceImpl;

import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emanyata.app.dto.TrackingLogDTO;
import com.emanyata.app.entity.School;
import com.emanyata.app.entity.SchoolApply;
import com.emanyata.app.entity.TrackingLog;
import com.emanyata.app.entity.User;
import com.emanyata.app.repo.SchoolApplyRepo;
import com.emanyata.app.repo.SchoolRepo;
import com.emanyata.app.repo.TrackingLogRepo;
import com.emanyata.app.repo.UserRepo;
import com.emanyata.app.service.TrackingLogService;

@Service
public class TrackingLogServiceImpl implements TrackingLogService{
	
	@Autowired
	private SchoolRepo schoolRepository;

	@Autowired
	private UserRepo userRepository;
	
	@Autowired
	private TrackingLogRepo logRepo;
	
	@Autowired
	private SchoolApplyRepo applyRepo;
	
	@Override
	public TrackingLogDTO createTrackingLog(TrackingLogDTO logDto) {
	    School school = schoolRepository.findById(logDto.getSchoolId())
	            .orElseThrow(() -> new RuntimeException("School not found with ID: " + logDto.getSchoolId()));

	    User user = userRepository.findById(logDto.getUserId())
	            .orElseThrow(() -> new RuntimeException("User not found with ID: " + logDto.getUserId()));

	    TrackingLog log = new TrackingLog();
	    log.setId(logDto.getId());
	    log.setSchool(school);
	    log.setUser(user);
	    log.setStatus(logDto.getStatus());
	    log.setSteps(logDto.getSteps());
	    log.setMessage(logDto.getMessage());
	    log.setApplicationId(logDto.getApplicationId());
	    log.setCreatedAt(Instant.now());
	    log.setUpdatedAt(Instant.now());

	    return toDTO(logRepo.save(log));
	}


	@Override
	public TrackingLogDTO findByApplicationNo(String number) {
	    SchoolApply school = applyRepo.findByApplicationNo(number)
	        .orElseThrow(() -> new RuntimeException("No school found with application number: " + number));
	    
	    TrackingLog log = logRepo.findBySchoolId(school.getId())
	        .orElseThrow(() -> new RuntimeException("No Tracking Logs found with application number: " + number));
	    
	    return toDTO(log);
	}
	
	private TrackingLogDTO toDTO(TrackingLog log) {
	    TrackingLogDTO dto = new TrackingLogDTO();
	    dto.setId(log.getId());
	    dto.setSchoolId(log.getSchool().getId());
	    dto.setUserId(log.getUser().getId());
	    dto.setStatus(log.getStatus());
	    dto.setSteps(log.getSteps());
	    dto.setMessage(log.getMessage());
	    dto.setApplicationId(log.getApplicationId());
	    dto.setCreatedAt(log.getCreatedAt());
	    dto.setUpdatedAt(log.getUpdatedAt());
	    return dto;
	}


}
