package com.emanyata.app.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emanyata.app.dto.StudentCountDTO;
import com.emanyata.app.service.StudentCountService;


@RestController
@RequestMapping("/api/student-counts")
public class StudentCountController {

    @Autowired
    private StudentCountService studentCountService;

    @PostMapping("/add")
    public ResponseEntity<Map<String, Object>> addStudentCount(@RequestBody StudentCountDTO dto) {
        StudentCountDTO savedStudentCount = studentCountService.createStudentCount(dto);

        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", "Record created successfully.");
        response.put("data", savedStudentCount);

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @PostMapping("/school/{schoolId}")
    public ResponseEntity<Map<String, Object>> getBySchoolId(@PathVariable Long schoolId) {
        StudentCountDTO studentCounts = studentCountService.getStudentCountBySchoolId(schoolId);

        Map<String, Object> response = new HashMap<>();
        response.put("message", " Record fetched successfully.");
        response.put("data", studentCounts);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
