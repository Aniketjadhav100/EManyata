package com.emanyata.app.dto;

public class SchoolTypeCountDTO {
	private String schoolType;
    private Long count;

    public SchoolTypeCountDTO(String schoolType, Long count) {
        this.schoolType = schoolType;
        this.count = count;
    }

    public String getSchoolType() {
        return schoolType;
    }

    public Long getCount() {
        return count;
    }

}
