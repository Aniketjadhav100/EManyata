package com.emanyata.app.serviceImpl;

import java.time.Instant;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emanyata.app.dto.StudentCountDTO;
import com.emanyata.app.entity.School;
import com.emanyata.app.entity.StudentCount;
import com.emanyata.app.repo.SchoolRepo;
import com.emanyata.app.repo.StudentCountRepository;
import com.emanyata.app.service.StudentCountService;



@Service
public class StudentCountServiceImpl implements StudentCountService {

    @Autowired
    private StudentCountRepository studentCountRepo;

    @Autowired
    private SchoolRepo schoolRepo;

    @Override
    public StudentCountDTO getStudentCountBySchoolId(Long schoolId) {
        return studentCountRepo.findBySchoolId(schoolId)
                .map(sc -> {
                    StudentCountDTO dto = new StudentCountDTO();
                    dto.setId(sc.getId());
                    dto.setSchoolId(sc.getSchool().getId());
                    dto.setTotalBoys(sc.getTotalBoys());
                    dto.setTotalGirls(sc.getTotalGirls());
                    dto.setTotal(sc.getTotal());
                    dto.setLower(sc.getLower());
                    dto.setHigher(sc.getHigher());
                    dto.setCreatedAt(sc.getCreatedAt());
                    dto.setUpdatedAt(sc.getUpdatedAt());
                    dto.setApplicationId(sc.getApplicationId());
                    dto.setInspectionAppoval(sc.getInspectionAppoval());
                    dto.setInspectionComment(sc.getInspectionComment());
                    return dto;
                })
                .orElseThrow(() -> new RuntimeException("StudentCount not found for schoolId: " + schoolId));
    }

    
    private StudentCountDTO toDTO(StudentCount entity) {
        StudentCountDTO dto = new StudentCountDTO();
        dto.setId(entity.getId());
        dto.setSchoolId(entity.getSchool().getId());
        dto.setTotalBoys(entity.getTotalBoys());
        dto.setTotalGirls(entity.getTotalGirls());
        dto.setTotal(entity.getTotal());
        dto.setLower(entity.getLower());
        dto.setHigher(entity.getHigher());
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setUpdatedAt(entity.getUpdatedAt());
        dto.setApplicationId(entity.getApplicationId());
        dto.setInspectionAppoval(entity.getInspectionAppoval());
        dto.setInspectionComment(entity.getInspectionComment());
        return dto;
    }

    @Override
    public StudentCountDTO createStudentCount(StudentCountDTO dto) {
    	
        if (dto.getApplicationId() != null && dto.getSchoolId() != null) {
        	
            Optional<StudentCount> studentCountOpt = studentCountRepo.findBySchoolId(dto.getSchoolId());

            if (studentCountOpt.isPresent()) {
                if(studentCountOpt.get().getApplicationId().equals(dto.getApplicationId())) {
                	StudentCount existing = studentCountOpt.get();

                    if (dto.getTotalBoys() != null) existing.setTotalBoys(dto.getTotalBoys());
                    if (dto.getTotalGirls() != null) existing.setTotalGirls(dto.getTotalGirls());
                    if (dto.getTotal() != null) existing.setTotal(dto.getTotal());
                    if (dto.getLower() != null) existing.setLower(dto.getLower());
                    if (dto.getHigher() != null) existing.setHigher(dto.getHigher());
                    if (dto.getInspectionAppoval() != null) existing.setInspectionAppoval(dto.getInspectionAppoval());
                    if (dto.getInspectionComment() != null) existing.setInspectionComment(dto.getInspectionComment());

                    existing.setUpdatedAt(Instant.now());
                    return toDTO(studentCountRepo.save(existing));
                }else {
                	throw new RuntimeException("Application Id mistmatched..");
                }
            } else {
                School school = schoolRepo.findById(dto.getSchoolId())
                        .orElseThrow(() -> new RuntimeException("School not found with ID: " + dto.getSchoolId()));

                StudentCount newStudentCount = new StudentCount();
                newStudentCount.setSchool(school);
                newStudentCount.setApplicationId(dto.getApplicationId());
                newStudentCount.setTotalBoys(dto.getTotalBoys());
                newStudentCount.setTotalGirls(dto.getTotalGirls());
                newStudentCount.setTotal(dto.getTotal());
                newStudentCount.setLower(dto.getLower());
                newStudentCount.setHigher(dto.getHigher());
                newStudentCount.setInspectionAppoval(dto.getInspectionAppoval());
                newStudentCount.setInspectionComment(dto.getInspectionComment());
                newStudentCount.setCreatedAt(Instant.now());
                newStudentCount.setUpdatedAt(Instant.now());

                return toDTO(studentCountRepo.save(newStudentCount));
            }
        } else {
            throw new RuntimeException("Application ID and School ID must be provided.");
        }
    }


}