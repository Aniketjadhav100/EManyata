package com.emanyata.app.controller;

public class TalukaController {

}
