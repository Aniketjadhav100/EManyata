package com.emanyata.app.serviceImpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emanyata.app.dto.SchoolApplyDTO;
import com.emanyata.app.dto.StatusCountDTO;
import com.emanyata.app.entity.SchoolApply;
import com.emanyata.app.entity.School;
import com.emanyata.app.entity.User;
import com.emanyata.app.repo.SchoolApplyRepo;
import com.emanyata.app.service.SchoolApplyService;

import java.time.Year;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class SchoolApplyServiceImpl implements SchoolApplyService {

    private static final Logger logger = LoggerFactory.getLogger(SchoolApplyServiceImpl.class);

    @Autowired
    private SchoolApplyRepo repository;

    @Override
    public SchoolApplyDTO saveSchoolApply(SchoolApplyDTO dto) {
        if (dto == null) {
            throw new IllegalArgumentException("SchoolApplyDTO cannot be null");
        }

        SchoolApply entity = new SchoolApply();

        entity.setId(dto.getId());

        if (dto.getUserId() != null) {
            User user = new User();
            user.setId(dto.getUserId());
            entity.setUser(user);
        }

        if (dto.getSchoolId() != null) {
            School school = new School();
            school.setId(dto.getSchoolId());
            entity.setSchool(school);
        }

        // Generate application number only for new entities
        if (dto.getId() == null && dto.getSchoolId() != null) {
            String udiseNo = repository.findUdiseNoBySchoolId(dto.getSchoolId());
            if (udiseNo != null && udiseNo.length() >= 4) {
                String applicationNo = generateApplicationNo(udiseNo);
                entity.setApplicationNo(applicationNo);
            }
        }

        entity.setApplyStatus(dto.getApplyStatus());
        entity.setToken(dto.getToken());
        entity.setStatus(dto.getStatus());
        entity.setInspectionStatus(dto.getInspectionStatus());
        entity.setInspectionCompletionDate(dto.getInspectionCompletionDate());
        entity.setVisitingDate(dto.getVisitingDate());
        entity.setInspectionOfficeId(dto.getInspectionOfficeId());
        entity.setSubmittedDate(dto.getSubmittedDate());
        entity.setApprovedDate(dto.getApprovedDate());
        entity.setExpiredDate(dto.getExpiredDate());
        entity.setRenewDate(dto.getRenewDate());
        entity.setSteps(dto.getSteps());
        entity.setTurtiPdf(dto.getTurtiPdf());
        entity.setTipaniPdf(dto.getTipaniPdf());
        entity.setSchoolInspectionPdf(dto.getSchoolInspectionPdf());
        entity.setDocAvailableVerified(dto.getDocAvailableVerified());
        entity.setRte2009Followed(dto.getRte2009Followed());
        entity.setNamuna2Doc(dto.getNamuna2Doc());
        entity.setOfficerComment(dto.getOfficerComment());
        entity.setAbhiprayPdf(dto.getAbhiprayPdf());
        entity.setCreatedAt(dto.getCreatedAt());
        entity.setUpdatedAt(dto.getUpdatedAt());

        SchoolApply saved = repository.save(entity);
        logger.info("SchoolApply saved with ID: {}", saved.getId());

        return mapToDto(saved);
    }

    private String generateApplicationNo(String udiseNo) {
        String year = String.valueOf(Year.now().getValue());
        String udiseSuffix = udiseNo.substring(udiseNo.length() - 4);
        String prefix = year + udiseSuffix;

        long count = repository.countByApplicationNoStartingWith(prefix);
        String sequence = String.format("%04d", count + 1);
        return prefix + sequence;
    }

    @Override
    public List<SchoolApplyDTO> getDetails(Long userId, Long schoolId) {
        List<SchoolApply> entities;

        if (userId != null) {
            entities = repository.findByUserId(userId);
        } else if (schoolId != null) {
            entities = repository.findBySchoolId(schoolId);
        } else {
            throw new IllegalArgumentException("Either userId or schoolId must be provided.");
        }

        logger.info("Fetched {} applications for userId={} schoolId={}", entities.size(), userId, schoolId);

        return entities.stream()
                       .map(this::mapToDto)
                       .collect(Collectors.toList());
    }

    private SchoolApplyDTO mapToDto(SchoolApply entity) {
        SchoolApplyDTO dto = new SchoolApplyDTO();

        dto.setId(entity.getId());

        if (entity.getUser() != null) {
            dto.setUserId(entity.getUser().getId());
        }

        if (entity.getSchool() != null) {
            dto.setSchoolId(entity.getSchool().getId());
        }

        dto.setApplyStatus(entity.getApplyStatus());
        dto.setApplicationNo(entity.getApplicationNo());
        dto.setToken(entity.getToken());
        dto.setStatus(entity.getStatus());
        dto.setInspectionStatus(entity.getInspectionStatus());
        dto.setInspectionCompletionDate(entity.getInspectionCompletionDate());
        dto.setVisitingDate(entity.getVisitingDate());
        dto.setInspectionOfficeId(entity.getInspectionOfficeId());
        dto.setSubmittedDate(entity.getSubmittedDate());
        dto.setApprovedDate(entity.getApprovedDate());
        dto.setExpiredDate(entity.getExpiredDate());
        dto.setRenewDate(entity.getRenewDate());
        dto.setSteps(entity.getSteps());
        dto.setTurtiPdf(entity.getTurtiPdf());
        dto.setTipaniPdf(entity.getTipaniPdf());
        dto.setSchoolInspectionPdf(entity.getSchoolInspectionPdf());
        dto.setDocAvailableVerified(entity.getDocAvailableVerified());
        dto.setRte2009Followed(entity.getRte2009Followed());
        dto.setNamuna2Doc(entity.getNamuna2Doc());
        dto.setOfficerComment(entity.getOfficerComment());
        dto.setAbhiprayPdf(entity.getAbhiprayPdf());
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setUpdatedAt(entity.getUpdatedAt());

        return dto;
    }

	@Override
	public List<SchoolApplyDTO> getAllDetails() {
	    List<SchoolApply> schoolApplyList = repository.findAll();
	    return schoolApplyList.stream()
	        .map(sa -> new SchoolApplyDTO(
	            sa.getId(),
	            sa.getUser() != null ? sa.getUser().getId() : null,
	            sa.getSchool() != null ? sa.getSchool().getId() : null,
	            sa.getApplyStatus(),
	            sa.getToken(),
	            sa.getStatus(),
	            sa.getInspectionStatus(),
	            sa.getInspectionCompletionDate(),
	            sa.getApplicationNo(),
	            sa.getVisitingDate(),
	            sa.getInspectionOfficeId(),
	            sa.getSubmittedDate(),
	            sa.getApprovedDate(),
	            sa.getExpiredDate(),
	            sa.getRenewDate(),
	            sa.getSteps(),
	            sa.getTurtiPdf(),
	            sa.getTipaniPdf(),
	            sa.getSchoolInspectionPdf(),
	            sa.getDocAvailableVerified(),
	            sa.getRte2009Followed(),
	            sa.getNamuna2Doc(),
	            sa.getOfficerComment(),
	            sa.getAbhiprayPdf(),
	            sa.getCreatedAt(),
	            sa.getUpdatedAt()
	        ))
	        .toList();
	}
	
	// THis is FOr Status COunt
	@Override
	public List<StatusCountDTO> getStatusCounts() {
	    // List of all possible status types, even if not found in the database
	    List<String> allStatusTypes = Arrays.asList(
	        "Application Pending", 
	        "Application Accepted", 
	        "Application Rejected", 
	        "Inspection Assigned", 
	        "Inspection Completed", 
	        "Application Finalise"
	    );

	    // Fetch raw data from the repository
	    List<StatusCountDTO> rawList = repository.getStatusCounts();

	    // Convert the raw list into a map for easier look-up by status
	    Map<String, Long> statusCountMap = rawList.stream()
	        .collect(Collectors.toMap(dto -> mapStatus(dto.getStatus()), StatusCountDTO::getCount));

	    // For each status type, check if it exists in the map, if not set count to 0
	    return allStatusTypes.stream()
	        .map(status -> new StatusCountDTO(mapStatus(status), statusCountMap.getOrDefault(mapStatus(status), 0L)))
	        .collect(Collectors.toList());
	}

	// Helper method to map status to the required key
	private String mapStatus(String status) {
	    if (status == null) {
	        // If null status, return a default type
	        return "unknown";
	    }

	    switch (status) {
	        case "Application Pending":
	            return "pending";
	        case "Application Accepted":
	            return "approved";
	        case "Application Rejected":
	            return "reject";
	        case "Inspection Assigned":
	            return "assign-inspection";
	        case "Inspection Completed":
	            return "verified-by-inspection-officer";
	        case "Application Finalise":
	            return "final_submit";
	        default:
	            // Handle unexpected statuses by converting them to lower case and replacing spaces with underscores
	            return status.toLowerCase().replace(" ", "_");
	    }
	}



}