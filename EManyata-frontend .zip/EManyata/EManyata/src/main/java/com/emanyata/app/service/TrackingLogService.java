package com.emanyata.app.service;

import com.emanyata.app.dto.TrackingLogDTO;

public interface TrackingLogService {
	TrackingLogDTO createTrackingLog(TrackingLogDTO log);
	TrackingLogDTO  findByApplicationNo(String number);
}
